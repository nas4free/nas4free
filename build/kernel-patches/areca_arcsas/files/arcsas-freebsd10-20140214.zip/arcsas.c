/*
******************************************************************************
**	OS	: FreeBSD
**	FILE NAME : arcsas.c
**	BY	: C.L. Huang
**	Description: Device Driver for Areca ARC13x0 SAS Host Bus Adapter
******************************************************************************
**  Copyright (C) 2002,2011 Areca Technology Corporation All rights reserved.
******************************************************************************
**
**  Redistribution and use in source and binary forms, with or without
**  modification, are permitted provided that the following conditions
**  are met:
**  1. Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**  2. Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in the
**     documentation and/or other materials provided with the distribution.
**  3. The party using or redistributing the source code and binary forms
**     agrees to the disclaimer below and the terms and conditions set forth
**     herein.
**
**  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
**  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
**  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
**  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
**  FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
**  DAMAGES (CLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
**  OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
**  HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
**  LIABILITY, OR TORT (CLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
**  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
**  SUCH DAMAGE.
******************************************************************************
** History
**
** REV#		DATE		NAME		DESCRIPTION
** 1.00.00.05  2012/09/20  C.L. Huang	Released for distribution
** 1.00.00.06  2013/07/25  C.L. Huang	Added disk write protect
** 1.00.00.07  2013/09/25  C.L. Huang	Added mutex during insert device
******************************************************************************
*/

#include <sys/cdefs.h>
#include <sys/param.h>
#include <sys/systm.h>
#include <sys/malloc.h>
#include <sys/kernel.h>
#include <sys/bus.h>
#include <sys/queue.h>
#include <sys/stat.h>
#include <sys/devicestat.h>
#include <sys/kthread.h>
#include <sys/module.h>
#include <sys/proc.h>
#include <sys/lock.h>
#include <sys/sysctl.h>
#include <sys/poll.h>
#include <sys/ioccom.h>
#include <vm/vm.h>
#include <vm/vm_param.h>
#include <vm/pmap.h>
#include <isa/rtc.h>
#include <machine/bus.h>
#include <machine/resource.h>
#include <machine/atomic.h>
#include <machine/stdarg.h>
#include <sys/conf.h>
#include <sys/rman.h>
#include <cam/cam.h>
#include <cam/cam_ccb.h>
#include <cam/cam_sim.h>
#include <cam/cam_periph.h>
#include <cam/cam_xpt_periph.h>
#include <cam/cam_xpt_sim.h>
#include <cam/cam_debug.h>
#include <cam/scsi/scsi_all.h>
#include <cam/scsi/scsi_message.h>

#if __FreeBSD_version >= 500005
	#include <sys/selinfo.h>
	#include <sys/mutex.h>
	#include <sys/endian.h>
	#include <dev/pci/pcivar.h>
	#include <dev/pci/pcireg.h>
#else
	#include <sys/select.h>
	#include <pci/pcivar.h>
	#include <pci/pcireg.h>
#endif

#if !defined(CAM_NEW_TRAN_CODE) && __FreeBSD_version >= 700025
#define	CAM_NEW_TRAN_CODE	1
#endif

#if defined(__amd64) || defined(IS_64)
	#define BITS_PER_LONG		64
#endif

#define ARCSAS_MSI_INTR	0

#include <dev/arcsas/arcsas.h>

#define ARCSAS_DRIVER_VERSION	"arcsas version v1.00.00.07 2013-09-25"

/*
************************************************************************
* External Functions
************************************************************************
*/
extern u_int8_t arcsas_core_initialize(PACB pACB);
extern u_int32_t arcsas_handle_virtual_ses_device(PACB pACB, PCCB pCCB);
extern void arcsas_handle_ioctl_packet(PACB pACB, struct _SRB_IOCTL_FIELD *pioctlField);

extern int arcsas_list_empty(const struct list_head *head);
extern int arcsas_core_sgpio_led_activated(PDomain_Device pDevice, u_int8_t flag);
extern u_int8_t arcsas_reset_controller(PACB pACB);
extern u_int8_t arcsas_drain_done_queue(PCORE pCore);
extern u_int8_t arcsas_port_abort_ccbs(PDomain_Port pPort, u_int8_t ScsiStatus, PDomain_Device pDevice);
extern u_int8_t arcsas_get_checksum(u_int8_t *Address, u_int32_t Size);
extern u_int16_t arcsas_core_handle_intr(PACB pACB);
extern u_int16_t arcsas_init_chip(PACB pACB);
extern u_int32_t arcsas_get_core_resource_quota(PACB pACB, enum Resource_Type type);
extern void arcsas_os_bus_reset(PACB pACB);
extern void arcsas_flush_devices_cache(PACB pACB);
extern void arcsas_set_lba_and_sector_count(PCCB pCCB);
extern void arcsas_hba_timer(void *param);
extern void arcsas_quiet_hba_isr(PACB pACB);
extern void arcsas_unquiet_hba_isr(PACB pACB);
extern void arcsas_hba_reset(PACB pACB);
extern void arcsas_check_update_flash_device_map(PACB pACB, u_int8_t flag);
extern void arcsas_release_pool_tag(PTag_Stack pTagStack, u_int16_t tag);
extern void arcsas_list_add_tail(kmutex_t *list_lock, struct list_head *new_one, struct list_head *head);
extern void arcsas_post_waiting_list_ccb(PCORE pCore);
extern void arcsas_sg_table_init( PARCSAS_SG_Table pSGTable, u_int16_t max_entry_count);
extern void arcsas_done_os_ccb_callback(PVOID pCmd_Initiator, PCCB pCCB);
extern void arcsas_disable_hba_isr(PACB pACB);
extern void arcsas_clear_all_irq_status(PACB pACB);
extern void arcsas_do_generic_dpc(PACB pACB);
extern void arcsas_remove_device(PDomain_Device pDevice);
extern void arcsas_add_waitingCCB_tail(PCORE pCore, PCCB pCCB);
extern void arcsas_core_free_ccb_to_pool(PCORE pCore, PCCB pCCB);
extern void arcsas_list_delete(kmutex_t *list_lock, struct list_head *entry);
extern void arcsas_free_prd_buffer_to_list(PCORE pCore, PPRD_Buffer pPRD_Buffer);
extern void arcsas_list_add_head(kmutex_t *list_lock, struct list_head *new_one, struct list_head *head);
extern void arcsas_sas_error_handling(PDomain_Device pDevice, PCCB pCCB);
extern void arcsas_sata_error_handling(PDomain_Device pDevice, PCCB pCCB);
extern void arcsas_init_virtual_ses_device(PACB pACB);
extern void arcsas_sorting_entry_index(PACB pACB);
extern void arcsas_core_ses_led_activated(PDomain_Device pDevice, u_int8_t flag);
extern void arcsas_port_state_machine(PCORE pCore, PDomain_Port pPort);
extern void arcsas_shift_device_entry_index(PACB pACB);
extern void arcsas_lostIRQ_handler(void *param);
extern void arcsas_bzero(uint8_t *ptr, u_int32_t len);
extern void arcsas_memcpy(uint8_t *des, uint8_t *src, u_int32_t len);
extern PCCB arcsas_core_get_ccb_from_list(PCORE pCore);
extern PCCB arcsas_core_get_waiting_ccb_from_list(PCORE pCore);
extern PCCB arcsas_device_get_sent_ccb_from_list(PDomain_Device pDevice);

/*
************************************************************************
* Functions referred by external
************************************************************************
*/
void arcsas_free_resource(PACB pACB);
void arcsas_core_notify_device_hotplug(PCORE pCore, u_int8_t plugin, u_int16_t EntryIndex);
void arcsas_hba_event_log(int level, char *fmt, ...);
void arcsas_scsi_ioctl(PACB pACB, PCCB pCCB);
void arcsas_cmd_done(PACB pACB, PCCB pCCB);
void arcsas_set_residue(PCCB pCCB, u_int32_t information);
void arcsas_delay_rescan_devices(PACB pACB);
void arcsas_rescan_device(PACB pACB, int target, int lun);
void arcsas_hba_sleep_msec(u_int32_t msec);
void arcsas_hba_sleep_usec(u_int32_t usec);
void arcsas_inc_32(volatile u_int32_t *ptr);
void arcsas_dec_32(volatile u_int32_t *ptr);
void arcsas_inc_16(volatile u_int16_t *ptr);
void arcsas_dec_16(volatile u_int16_t *ptr);
void arcsas_inc_8(volatile u_int8_t *ptr);
void arcsas_dec_8(volatile u_int8_t *ptr);
void arcsas_uncached_sync_dev(PACB pACB, bus_dmasync_op_t op);
void arcsas_uncached_sync_kernel(PACB pACB, bus_dmasync_op_t op);
void arcsas_pciCfg_put32(PACB pACB, int addr, uint32_t data);
void arcsas_init_hba_timer(PACB pACB);
void arcsas_start_lostIRQ_timer(PACB pACB);
void arcsas_cli_sleep(PACB pACB, struct _SRB_IOCTL_FIELD *pioctlField);
void arcsas_wait_discovery_sleep(PACB pACB, struct _SRB_IOCTL_FIELD *pioctlField);
void arcsas_reg_write4(PACB pACB, bus_size_t reg, u_int32_t data);
void arcsas_io_write4(PACB pACB, bus_size_t reg, u_int32_t data);
void arcsas_mutex_init_core(PCORE pCore);
void arcsas_mutex_enter(arcsas_lock_t *ptr);
void arcsas_mutex_exit(arcsas_lock_t *ptr);
int arcsas_mutex_tryenter(arcsas_lock_t *ptr);
time_t arcsas_get_time(void);
u_int32_t arcsas_pciCfg_get32(PACB pACB, int addr);
u_int32_t arcsas_reg_read4(PACB pACB, bus_size_t reg);
u_int32_t arcsas_io_read4(PACB pACB, bus_size_t reg);

static int arcsas_probe(device_t dev);
static int arcsas_attach(device_t dev);
static int arcsas_detach(device_t dev);
static int arcsas_shutdown(device_t dev);
static int arcsas_resume(device_t dev);
static int arcsas_suspend(device_t dev);
static int arcsas_seek_cmd2abort(PACB pACB, union ccb *pAbortCCB);
static void arcsas_ccb_complete(PCCB pCCB, int stand_flag);
static void arcsas_action(struct cam_sim *psim, union ccb *pccb);
static void arcsas_build_os_ccb(PCCB pCCB, bus_dma_segment_t *dm_segs, int nseg);
static void arcsas_generate_sg_table(PCCB pCCB);
static void arcsas_Discover_Devices(PACB pACB);
static void arcsas_intr_handler(void *arg);
static void arcsas_async(void *cb_arg, u_int32_t code, struct cam_path *path, void *arg);
static void arcsas_event_log(char *fmt, ...);
static void arcsas_mutex_init_adapter(PACB pACB);
static void arcsas_mutex_destroy_adapter(PACB pACB);
static void arcsas_mutex_destroy_core(PACB pACB);
static void arcsas_rescan_next1(void *param);
static u_int32_t arcsas_hba_initialize(device_t dev);

static bus_dmamap_callback_t arcsas_map_mailBoxMem;
static bus_dmamap_callback_t arcsas_execute_ccb;
static d_open_t	 arcsas_open;
static d_close_t arcsas_close;
static d_ioctl_t arcsas_ioctl;

static device_method_t arcsas_methods[] = {
	DEVMETHOD(device_probe,		arcsas_probe),
	DEVMETHOD(device_attach,	arcsas_attach),
	DEVMETHOD(device_detach,	arcsas_detach),
	DEVMETHOD(device_shutdown,	arcsas_shutdown),
	DEVMETHOD(device_suspend,	arcsas_suspend),
	DEVMETHOD(device_resume,	arcsas_resume),

#if __FreeBSD_version >= 803000
	DEVMETHOD_END
#else
	{ 0, 0 }
#endif
};

static driver_t arcsas_driver = {
	"arcsas", arcsas_methods, sizeof(struct _ACB)
};

static devclass_t arcsas_devclass;
DRIVER_MODULE(arcsas, pci, arcsas_driver, arcsas_devclass, 0, 0);
MODULE_DEPEND(arcsas, pci, 1, 1, 1);
MODULE_DEPEND(arcsas, cam, 1, 1, 1);

#ifndef BUS_DMA_COHERENT
	#define	BUS_DMA_COHERENT	0x04	/* hint: map memory in a coherent way */
#endif

#if __FreeBSD_version >= 501000
	#ifndef D_NEEDGIANT
		#define D_NEEDGIANT	0x00400000	/* driver want Giant */
	#endif
	#ifndef D_VERSION
		#define D_VERSION	0x20011966
	#endif
static struct cdevsw arcsas_cdevsw = {
	#if __FreeBSD_version > 502010
		.d_version = D_VERSION,
	#endif
	#if (__FreeBSD_version >= 503000 && __FreeBSD_version < 600034)
		.d_flags   = D_NEEDGIANT,
	#endif
		.d_open    = arcsas_open, 	/* open */
		.d_close   = arcsas_close, 	/* close */
		.d_ioctl   = arcsas_ioctl, 	/* ioctl */
		.d_name    = "arcsas", 		/* name */
	};
#else
	#define ARCSAS_CDEV_MAJOR	180

static struct cdevsw arcsas_cdevsw = {
		arcsas_open,		/* open */
		arcsas_close,		/* close */
		noread,			/* read */
		nowrite,		/* write */
		arcsas_ioctl,		/* ioctl */
		nopoll,			/* poll */
		nommap,			/* mmap */
		nostrategy,		/* strategy */
		"arcsas",		/* name */
		ARCSAS_CDEV_MAJOR,	/* major */
		nodump,			/* dump */
		nopsize,		/* psize */
		0			/* flags */
	};
#endif

static void arcsas_event_log(char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	(void) vprintf(fmt, ap);
	va_end(ap);
}

void arcsas_hba_event_log(int level, char *fmt, ...)
{
	va_list ap;

	va_start(ap, fmt);
	(void) vprintf(fmt, ap);
	va_end(ap);
}

#if __FreeBSD_version < 500005
	static int arcsas_open(dev_t dev, int flags, int fmt, struct proc *proc)
#else
	#if __FreeBSD_version < 503000
	static int arcsas_open(dev_t dev, int flags, int fmt, struct thread *proc)
	#else
	static int arcsas_open(struct cdev *dev, int flags, int fmt, struct thread *proc)
	#endif
#endif
{
	#if __FreeBSD_version < 503000
		PACB pACB = dev->si_drv1;
	#else
		int	unit = dev2unit(dev);
		PACB pACB = devclass_get_softc(arcsas_devclass, unit);
	#endif
	if (pACB == NULL) {
		return (ENXIO);
	}
	return (0);
}

#if __FreeBSD_version < 500005
	static int arcsas_close(dev_t dev, int flags, int fmt, struct proc *proc)
#else
	#if __FreeBSD_version < 503000
	static int arcsas_close(dev_t dev, int flags, int fmt, struct thread *proc)
	#else
	static int arcsas_close(struct cdev *dev, int flags, int fmt, struct thread *proc)
	#endif
#endif
{
	#if __FreeBSD_version < 503000
		PACB pACB = dev->si_drv1;
	#else
		int	unit = dev2unit(dev);
		PACB pACB = devclass_get_softc(arcsas_devclass, unit);
	#endif
	if (pACB == NULL) {
		return (ENXIO);
	}
	return (0);
}

#if __FreeBSD_version < 500005
	static int arcsas_ioctl(dev_t dev, u_long ioctl_cmd, caddr_t arg, int flags, struct proc *proc)
#else
	#if __FreeBSD_version < 503000
	static int arcsas_ioctl(dev_t dev, u_long ioctl_cmd, caddr_t arg, int flags, struct thread *proc)
	#else
	static int arcsas_ioctl(struct cdev *dev, u_long ioctl_cmd, caddr_t arg, int flags, struct thread *proc)
	#endif
#endif
{
	struct _SRB_IOCTL_FIELD	*pioctlField;
	int	retvalue = EINVAL;

	#if __FreeBSD_version < 503000
		PACB pACB = dev->si_drv1;
	#else
		int	unit = dev2unit(dev);
		PACB pACB = devclass_get_softc(arcsas_devclass, unit);
	#endif

	if (pACB == NULL) {
		return (ENXIO);
	}

	pioctlField = (struct _SRB_IOCTL_FIELD *)arg;

	if (memcmp(pioctlField->srbioctl.Signature, "ARCSAS", 6) != 0) {
		pioctlField->srbioctl.ReturnCode = ARCSAS_IOCTL_RETURNCODE_ERROR;
		retvalue = EINVAL;
		goto ioctl_out;
	}

	switch (ioctl_cmd) {
	case ARCSAS_IOCTL_SAS:
	{
		pioctlField->srbioctl.ReturnCode = 0;
		arcsas_handle_ioctl_packet(pACB, pioctlField);
		retvalue = 0;
	}
	break;
	case ARCSAS_IOCTL_SAY_HELLO:
	{
		pioctlField->srbioctl.ReturnCode = ARCSAS_IOCTL_RETURNCODE_OK;
		retvalue = 0;
	}
	break;
	case ARCSAS_IOCTL_RETURN_CODE_3F:
	{
		pioctlField->srbioctl.ReturnCode = ARCSAS_IOCTL_RETURNCODE_3F;
		retvalue = 0;
	}
	break;
	default:
		pioctlField->srbioctl.ReturnCode = ARCSAS_IOCTL_RETURNCODE_ERROR;
		retvalue = ENXIO;
	}
ioctl_out:
	return (retvalue);
}

static void arcsas_poll(struct cam_sim * psim)
{
	PACB pACB;
	int	mutex;

	pACB = (PACB)cam_sim_softc(psim);
	mutex = mtx_owned(&pACB->isr_mutex);
	if ( mutex == 0 )
		ARCSAS_MTX_LOCK(&pACB->isr_mutex);
	arcsas_core_handle_intr(pACB);
	if ( mutex == 0 )
		ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
}

static int arcsas_probe(device_t dev)
{
	u_int32_t id;
	static char buf[256];
	char unknown[] = {"Unknown"};
	char *type;

	if (pci_get_vendor(dev) != PCI_VENDOR_ID_ARECA) {
		return (ENXIO);
	}
	switch(id = pci_get_devid(dev)) {
	case PCIDevVenIDARC1300:
		type = "ARC1300 PCIe to SAS 3G";
		break;
	case PCIDevVenIDARC1320:
		type = "ARC1320 PCIe to SAS 6G";
		break;
	default:
		type = unknown;
		break;
	}
	if (type == unknown)
		return (ENXIO);
	sprintf(buf, "Areca %s Host Bus Adapter.\n%s\n",
		type, ARCSAS_DRIVER_VERSION);
	device_set_desc_copy(dev, buf);
	return (BUS_PROBE_VENDOR);
}

static int arcsas_attach(device_t dev)
{
	PACB 	pACB;
	int 	unit;
	struct ccb_setasync csa;
	struct cam_devq		*devq;	/* Device Queue to use for this SIM */
	struct resource		*irqres;

	pACB = (PACB)device_get_softc(dev);
	unit = device_get_unit(dev);
	if (pACB == NULL) {
		printf("arcsas%d: cannot allocate softc\n", unit);
		return (ENOMEM);
	}
	arcsas_bzero((uint8_t *)pACB, sizeof(struct _ACB));
	pACB->pci_dev = dev;
	pACB->device_number = unit;
	arcsas_mutex_init_adapter(pACB);
#if	ARCSAS_MSI_INTR
#if __FreeBSD_version >= 700000
	if (pci_msix_count(dev) == 1) {
			pACB->intr_count = 1;
		if (pci_alloc_msix(dev, &pACB->intr_count) == 0)
			pACB->irq_rid = 1;
		else
			pACB->intr_count = 0;
	}
	if (pACB->irq_rid == 0 && pci_msi_count(dev) == 1) {
		pACB->intr_count = 1;
		if (pci_alloc_msi(dev, &pACB->intr_count) == 0)
			pACB->irq_rid  = 1;
		else
			pACB->intr_count = 0;
	}
#endif
#endif
	if (arcsas_hba_initialize(dev)) {
		printf("arcsas%d: initialize failure!\n", unit);
		arcsas_free_resource(pACB);
		return (ENXIO);
	}

	arcsas_quiet_hba_isr(pACB);
	arcsas_clear_all_irq_status(pACB);
	/* After setting up the adapter, map our interrupt */
	irqres = bus_alloc_resource(dev, SYS_RES_IRQ, &pACB->irq_rid, 0ul, ~0ul, 1, RF_SHAREABLE | RF_ACTIVE);
	pACB->irqres = irqres;
	if (irqres == NULL ||
#if __FreeBSD_version >= 700025
		bus_setup_intr(dev, irqres, INTR_TYPE_CAM|INTR_ENTROPY|INTR_MPSAFE, NULL, arcsas_intr_handler, pACB, &pACB->ihandle)) {
#else
		bus_setup_intr(dev, irqres, INTR_TYPE_CAM|INTR_ENTROPY|INTR_MPSAFE, arcsas_intr_handler, pACB, &pACB->ihandle)) {
#endif
		printf("arcsas%d: unable to register interrupt handler!\n", unit);
		arcsas_free_resource(pACB);
		return (ENXIO);
	}
	/* Register with MSI interrupt, will Disable_INTx and Enable_MSI in PCIe cfg register by upper layer driver */
	if (pACB->intr_count)
		printf("arcsas%d: using MSI interrupt.\n", unit);

	arcsas_Discover_Devices(pACB);

	/*
	 * Now let the CAM generic SCSI layer find the SCSI devices on
	 * the bus *  start queue to reset to the idle loop. *
	 * Create device queue of SIM(s) *  (MAX_START_JOB - 1) :
	 * max_sim_transactions
	*/
	devq = cam_simq_alloc(ARCSAS_MAX_START_JOB);
	if (devq == NULL) {
		printf("arcsas%d: cam_simq_alloc failure!\n", unit);
		arcsas_free_resource(pACB);
		return (ENXIO);
	}
	pACB->devq = devq;
#if __FreeBSD_version >= 700025
	pACB->psim = cam_sim_alloc(arcsas_action, arcsas_poll, "arcsas", pACB, unit, &pACB->isr_mutex, 1, ARCSAS_MAX_OUTSTANDING_CMD, devq);
#else
	pACB->psim = cam_sim_alloc(arcsas_action, arcsas_poll, "arcsas", pACB, unit, 1, ARCSAS_MAX_OUTSTANDING_CMD, devq);
#endif
	if (pACB->psim == NULL) {
		printf("arcsas%d: cam_sim_alloc failure!\n", unit);
		arcsas_free_resource(pACB);
		return (ENXIO);
	}
	ARCSAS_MTX_LOCK(&pACB->isr_mutex);
#if __FreeBSD_version >= 700044
	if (xpt_bus_register(pACB->psim, dev, 0) != CAM_SUCCESS) {
#else
	if (xpt_bus_register(pACB->psim, 0) != CAM_SUCCESS) {
#endif
		printf("arcsas%d: xpt_bus_register failure!\n", unit);
		ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
		arcsas_free_resource(pACB);
		return (ENXIO);
	}
	pACB->bus_registed = 1;
	if (xpt_create_path(&pACB->ppath, /* periph */ NULL, cam_sim_path(pACB->psim), CAM_TARGET_WILDCARD, CAM_LUN_WILDCARD) != CAM_REQ_CMP) {
		printf("arcsas%d: xpt_create_path failure!\n", unit);
		ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
		arcsas_free_resource(pACB);
		return (ENXIO);
	}

	arcsas_unquiet_hba_isr(pACB);

	xpt_setup_ccb(&csa.ccb_h, pACB->ppath, /* priority */ 5);
	csa.ccb_h.func_code = XPT_SASYNC_CB;
	csa.event_enable = AC_FOUND_DEVICE | AC_LOST_DEVICE;
	csa.callback = arcsas_async;
	csa.callback_arg = pACB->psim;
	xpt_action((union ccb *)&csa);
	arcsas_hba_sleep_msec(250);
	ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
	/* Create the control device. */
	pACB->ioctl_dev = make_dev(&arcsas_cdevsw, unit, UID_ROOT, GID_WHEEL /* GID_OPERATOR */, S_IRUSR | S_IWUSR, "arcsas%d", unit);

#if __FreeBSD_version < 503000
	pACB->ioctl_dev->si_drv1 = pACB;
#endif

#if __FreeBSD_version > 500005
	(void)make_dev_alias(pACB->ioctl_dev, "arcs%d", unit);
#endif

	arcsas_callout_init(&pACB->devmap_callout);
	arcsas_callout_init(&pACB->timeout_callout);
	callout_reset(&pACB->timeout_callout, ARCSAS_TIMER_FIRE * hz, arcsas_hba_timer, pACB);
	pACB->ACB_Flag |= ACB_FLAG_TIMER_RUNNING;
	arcsas_callout_init(&pACB->timer_handle2);

	return (0);
}

static int arcsas_detach(device_t dev)
{
	PACB pACB;

	pACB = (PACB)device_get_softc(dev);
	callout_stop(&pACB->devmap_callout);
	callout_stop(&pACB->timeout_callout);
	if (pACB->ACB_Flag & ACB_FLAG_DEV_MAP_CHANGED)
		arcsas_check_update_flash_device_map(pACB, FALSE);
	bus_teardown_intr(dev, pACB->irqres, pACB->ihandle);
	pACB->ihandle = 0;
	arcsas_shutdown(dev);
	arcsas_free_resource(pACB);
	return (0);
}

static int arcsas_shutdown(device_t dev)
{
	u_int16_t	i, max_core_num, core_index;
	u_int8_t	index;
	PCORE	pCore;
	PACB	pACB;

	pACB = device_get_softc(dev);
	ARCSAS_MTX_LOCK(&pACB->event_mutex);
	max_core_num = (pACB->ACB_Flag & ACB_FLAG_DUAL_CORE)?2:1;
	for (core_index = 0; core_index < max_core_num; core_index++)
	{
		pCore = pACB->pCore[core_index];
		for (i = 0; i < ARCSAS_MAX_CORE_PHYSICAL_PORT_NUMBER; i++)
		{
			index = pCore->Ports_EntryIndex[i];
			if (index != ARCSAS_ID_NOT_MAPPED)
			{
				arcsas_port_abort_ccbs(&pCore->Ports[index], CCB_STATUS_NO_DEVICE, NULL);
			}
		}
	}
	if (!(pACB->ACB_Flag & (ACB_FLAG_DONE_HBA_SHUTDOWN | ACB_FLAG_DOING_HBA_SHUTDOWN)))
	{
		pACB->ACB_Flag |= ACB_FLAG_DOING_HBA_SHUTDOWN;
		arcsas_flush_devices_cache(pACB);
		pACB->ACB_Flag &= ~ACB_FLAG_DOING_HBA_SHUTDOWN;
		pACB->ACB_Flag |= ACB_FLAG_DONE_HBA_SHUTDOWN;
	}
	pACB->outstanding_CCB = 0;
	pACB->ACB_Flag &= ~ACB_FLAG_CORES_STATE_STARTED;
	ARCSAS_MTX_UNLOCK(&pACB->event_mutex);
	arcsas_disable_hba_isr(pACB);
	return (0);
}

static int arcsas_suspend(device_t dev)
{
	PACB pACB;

	pACB = device_get_softc(dev);
	if (pACB->ACB_Flag & ACB_FLAG_TIMER_RUNNING)
	{
		pACB->ACB_Flag &= ~ACB_FLAG_TIMER_RUNNING;
		callout_stop(&pACB->devmap_callout);
		callout_stop(&pACB->timeout_callout);
	}
	arcsas_flush_devices_cache(pACB);
	arcsas_disable_hba_isr(pACB);
	return(0);
}

static int arcsas_resume(device_t dev)
{
	PACB pACB;

	pACB = device_get_softc(dev);
	ARCSAS_MTX_LOCK(&pACB->timer_mutex);
	pACB->org_all_device_count = pACB->all_device_count;
	TDLIST_INIT_HDR(&(pACB->timerlist));
	pACB->ACB_Flag |= ACB_FLAG_HIBERNATE_WAKEUP;
	arcsas_hba_sleep_msec(4000);
	arcsas_hba_reset(pACB);
	arcsas_Discover_Devices(pACB);
	arcsas_unquiet_hba_isr(pACB);
	ARCSAS_MTX_UNLOCK(&pACB->timer_mutex);
	return(0);
}

static PDomain_Device arcsas_get_pDevice(PACB pACB, u_int16_t EntryIndex, target_id_t target, lun_id_t lun)
{
	PDomain_Device pDevice;
	u_int16_t	dep_entry_index, i;

	pDevice = NULL;
	if (lun == 0)
	{
		dep_entry_index = Get_DevicesExpandersPMs_EntryIndex(pACB, target);
		if (dep_entry_index != ARCSAS_ID_NOT_MAPPED)
			pDevice = &pACB->pDevices[dep_entry_index];
	}
	else
	{
		for (i = 0; i <= ARCSAS_MAX_TARGETLUN; i++)
		{
			if (pACB->pDevicesLun[i].EntryIndex == EntryIndex)	/* this value is (target_lun,target_id) */
			{
				pDevice = &pACB->pDevicesLun[i];
				break;
			}
		}
	}
	return (pDevice);
}

static void arcsas_action(struct cam_sim *psim, union ccb *pccb)
{
	PACB pACB;
	struct _CCB *pCCB;
	struct _CORE *pCore;
	PDomain_Device pDevice;
	target_id_t	target;
	lun_id_t 	lun;
	u_int32_t	error;
	u_int16_t	EntryIndex;
#if __FreeBSD_version < 901505
	u_int32_t	s;
	struct bus_dma_segment	seg;
	struct bus_dma_segment *psegs;
#endif

	pACB = (PACB) cam_sim_softc(psim);
	if (pACB == NULL) {
		pccb->ccb_h.status |= CAM_REQ_INVALID;
		xpt_done(pccb);
		return;
	}
	if (pACB->ACB_Flag & (ACB_FLAG_SYNC_DEVICE_ID | ACB_FLAG_BUS_RESET))
	{
		pccb->ccb_h.status |= CAM_SCSI_BUSY;
		pccb->csio.scsi_status = SCSI_STATUS_BUSY;
		xpt_done(pccb);
		return;
	}
	pACB->dump_timer_count = 0;
	target = pccb->ccb_h.target_id;
	lun = pccb->ccb_h.target_lun;
	EntryIndex = MAKE_DEVICE_ENTRY_INDEX(target, lun);
	switch (pccb->ccb_h.func_code) {
	case XPT_SCSI_IO: {
		if ((pccb->ccb_h.flags & CAM_CDB_POINTER) && (pccb->ccb_h.flags & CAM_CDB_PHYS))
		{
			pccb->ccb_h.status |= CAM_REQ_INVALID;
			xpt_done(pccb);
			return;
		}
		pDevice = arcsas_get_pDevice(pACB, EntryIndex, target, lun);
		if (pDevice == NULL)
		{
			pccb->ccb_h.status |= CAM_DEV_NOT_THERE;
			xpt_done(pccb);
			return;
		}
		if (pDevice->Status == DEVICE_STATUS_NO_DEVICE)
			goto	NSA;
		pCore = pDevice->pCore;
		if ((pCCB = arcsas_core_get_ccb_from_list(pCore)) == NULL)
		{
			printf("arcsas: free CCB run out!, Queued cmd= 0x%x\n", (pCore->RequestCount - pCore->ReturnCount));
NSA:
			pccb->ccb_h.status |= CAM_RESRC_UNAVAIL;
			xpt_done(pccb);
			return;
		}
		pCCB->pccb = pccb;
		pCCB->pACB = pACB;
		pCCB->pCore = pCore;
		pCCB->pDevice = pDevice;
		pCCB->TargetId = target;
		pCCB->Lun = lun;
		pCCB->EntryIndex = EntryIndex;;
		if (target == ARCSAS_VIRTUAL_DEVICE_ID)	/* virtual device for iop message transfer */
		{
			if (lun != 0)
			{
				pccb->ccb_h.status |= CAM_DEV_NOT_THERE;
				goto ACTXIT0;
			}
			bcopy(pccb->csio.cdb_io.cdb_bytes, pCCB->Cdb, pccb->csio.cdb_len);	/* bcopy(s, d, n) */
			pCCB->pData_Buffer = (PVOID)pccb->csio.data_ptr;
			pCCB->DataTransferLength = pccb->csio.dxfer_len;
			pccb->ccb_h.status |= arcsas_handle_virtual_ses_device(pACB, pCCB);
			if (pccb->ccb_h.status & (CAM_REQ_INVALID | CAM_REQ_CMP | CAM_CMD_TIMEOUT))
			{
ACTXIT0:
				arcsas_core_free_ccb_to_pool(pCCB->pCore, pCCB);
				xpt_done(pccb);
			}
			return;
		}
#if __FreeBSD_version >= 901505
		error =	bus_dmamap_load_ccb(pACB->dataBuf_dmaTag
				, pCCB->dataBuf_dmaMap
				, pccb
				, arcsas_execute_ccb, pCCB, /* flags */ 0);
		if (error == EINPROGRESS) {
			xpt_freeze_simq(pACB->psim, 1);
			pccb->ccb_h.status |= CAM_RELEASE_SIMQ;
		}
#else
		if ((pccb->ccb_h.flags & CAM_DIR_MASK) != CAM_DIR_NONE)
		{
			if ((pccb->ccb_h.flags & CAM_SCATTER_VALID) == 0) /* non scatter gather buffer */
			{
				if ((pccb->ccb_h.flags & CAM_DATA_PHYS) == 0) /* Buffer is virtual */
				{
					pCCB->Cmd_Flag |= CMD_FLAG_DMAMAP_LOADED;
					s = splsoftvm();
					error =	bus_dmamap_load(pACB->dataBuf_dmaTag, pCCB->dataBuf_dmaMap
						, pccb->csio.data_ptr, pccb->csio.dxfer_len
						, arcsas_execute_ccb, pCCB, /* flags */ 0);
					if (error == EINPROGRESS)
					{
						xpt_freeze_simq(pACB->psim, 1);
						pccb->ccb_h.status |= CAM_RELEASE_SIMQ;
					}
					else if (error == EINVAL)
						arcsas_event_log("arcsas: bus_dmamap_load error!\n");
					splx(s);
				}
				else	/* a single segment Buffer with physical address */
				{
	#ifdef	PAE
					panic("arcmsr: CAM_DATA_PHYS not supported");
	#else
					seg.ds_addr = (bus_addr_t)pccb->csio.data_ptr;
					seg.ds_len = pccb->csio.dxfer_len;
					arcsas_execute_ccb(pCCB, &seg, 1, 0);
	#endif
				}
			}
			else		/* Scatter/gather list */
			{
				if ((pccb->ccb_h.flags & CAM_SG_LIST_PHYS) == 0 || (pccb->ccb_h.flags & CAM_DATA_PHYS) != 0)
				{
					pccb->ccb_h.status |= CAM_PROVIDE_FAIL;
					arcsas_core_free_ccb_to_pool(pCCB->pCore, pCCB);
					xpt_done(pccb);
					return;
				}
				else
				{
					psegs = (struct bus_dma_segment *)pccb->csio.data_ptr;
					arcsas_execute_ccb(pCCB, psegs, pccb->csio.sglist_cnt, 0);
				}
			}
		}
		else
			arcsas_execute_ccb(pCCB, NULL, 0, 0);
#endif
		break;
	}
	case XPT_TARGET_IO: {
		/* target mode not yet support vendor specific commands. */
		pccb->ccb_h.status |= CAM_REQ_INVALID;
		xpt_done(pccb);
		break;
	}
	case XPT_PATH_INQ: {
		struct ccb_pathinq *cpi = &pccb->cpi;

		cpi->version_num = 1;
		cpi->hba_inquiry = PI_SDTR_ABLE | PI_TAG_ABLE;
		cpi->target_sprt = 0;
		cpi->hba_misc = 0;
		cpi->hba_eng_cnt = 0;
		cpi->max_target = ARCSAS_MAX_TARGETID;
		cpi->max_lun = ARCSAS_MAX_TARGETLUN;
		cpi->initiator_id = ARCSAS_SCSI_INITIATOR_ID;	/* 255 */
		cpi->bus_id = cam_sim_bus(psim);
		strncpy(cpi->sim_vid, "FreeBSD", SIM_IDLEN);
		strncpy(cpi->hba_vid, "ARCSAS", HBA_IDLEN);
		strncpy(cpi->dev_name, cam_sim_name(psim), DEV_IDLEN);
		cpi->unit_number = cam_sim_unit(psim);
	#ifdef	CAM_NEW_TRAN_CODE
		if (pACB->system_device_id == PCI_DEVICE_ID_ARECA_1320)
			cpi->base_transfer_speed = 600000;
		else
			cpi->base_transfer_speed = 300000;
		cpi->transport = XPORT_SAS;
		cpi->transport_version = 2;
		cpi->protocol = PROTO_SCSI;
		cpi->protocol_version = SCSI_REV_2;
	#endif
		cpi->ccb_h.status |= CAM_REQ_CMP;
		xpt_done(pccb);
		break;
	}
	case XPT_ABORT: {
		union ccb *pAbortCCB;

		pAbortCCB = pccb->cab.abort_ccb;
		switch (pAbortCCB->ccb_h.func_code) {
		case XPT_ACCEPT_TARGET_IO:
		case XPT_IMMED_NOTIFY:
		case XPT_CONT_TARGET_IO:
			if (arcsas_seek_cmd2abort(pACB, pAbortCCB) == TRUE)
			{
				pAbortCCB->ccb_h.status |= CAM_REQ_ABORTED;
				xpt_done(pAbortCCB);
				pccb->ccb_h.status |= CAM_REQ_CMP;
			}
			else
			{
				xpt_print_path(pAbortCCB->ccb_h.path);
				printf("Not found\n");
				pccb->ccb_h.status |= CAM_PATH_INVALID;
			}
			break;
		case XPT_SCSI_IO:
			pccb->ccb_h.status |= CAM_UA_ABORT;
			break;
		default:
			pccb->ccb_h.status |= CAM_REQ_INVALID;
			break;
		}
		xpt_done(pccb);
		break;
	}
	case XPT_RESET_BUS:
	case XPT_RESET_DEV: {
		arcsas_os_bus_reset(pACB);
		arcsas_hba_sleep_msec(500);
		pccb->ccb_h.status |= CAM_REQ_CMP;
		xpt_done(pccb);
		break;
	}
	case XPT_TERM_IO: {
		pccb->ccb_h.status |= CAM_REQ_INVALID;
		xpt_done(pccb);
		break;
	}
	case XPT_GET_TRAN_SETTINGS: {
		struct ccb_trans_settings *cts;

		pDevice = arcsas_get_pDevice(pACB, EntryIndex, target, lun);
		if ((pDevice == NULL) || (pccb->ccb_h.target_id >= ARCSAS_MAX_TARGETID))
		{
			pccb->ccb_h.status |= CAM_FUNC_NOTAVAIL;
			xpt_done(pccb);
			break;
		}
		cts = &pccb->cts;
	#ifdef	CAM_NEW_TRAN_CODE
		{
			struct ccb_trans_settings_scsi *scsi;

			scsi = &cts->proto_specific.scsi;
			scsi->flags = CTS_SCSI_FLAGS_TAG_ENB;
			scsi->valid = CTS_SCSI_VALID_TQ;

			cts->protocol = PROTO_SCSI;
			cts->protocol_version = SCSI_REV_2;
			cts->transport_version = 2;
			cts->transport = XPORT_SAS;
			struct ccb_trans_settings_sas *sas;
			sas = &cts->xport_specific.sas;
			sas->valid = CTS_SAS_VALID_SPEED;
			if (pDevice->Ability & DEVICE_ABILITY_RATE_6G)
				sas->bitrate = 600000;
			else if (pDevice->Ability & DEVICE_ABILITY_RATE_3G)
				sas->bitrate = 300000;
			else if (pDevice->Ability & DEVICE_ABILITY_RATE_1_5G)
				sas->bitrate = 150000;
			else
				sas->bitrate = 600000;
		}
	#else
		{
			cts->flags = (CCB_TRANS_DISC_ENB | CCB_TRANS_TAG_ENB);
			cts->sync_period = 3;
			cts->sync_offset = 32;
			cts->bus_width = MSG_EXT_WDTR_BUS_16_BIT;
			cts->valid = CCB_TRANS_SYNC_RATE_VALID | CCB_TRANS_SYNC_OFFSET_VALID |
						 CCB_TRANS_BUS_WIDTH_VALID | CCB_TRANS_DISC_VALID | CCB_TRANS_TQ_VALID;
		}
	#endif
		pccb->ccb_h.status |= CAM_REQ_CMP;
		xpt_done(pccb);
		break;
	}
	case XPT_SET_TRAN_SETTINGS: {
		pccb->ccb_h.status |= CAM_FUNC_NOTAVAIL;
		xpt_done(pccb);
		break;
	}
	case XPT_CALC_GEOMETRY: {
		if (pccb->ccb_h.target_id >= ARCSAS_MAX_TARGETID)
		{
			pccb->ccb_h.status |= CAM_FUNC_NOTAVAIL;
			xpt_done(pccb);
			break;
		}
#if __FreeBSD_version >= 500000
		cam_calc_geometry(&pccb->ccg, 1);
#else
		struct ccb_calc_geometry *ccg;
		u_int32_t size_mb;
		u_int32_t secs_per_cylinder;

		ccg = &pccb->ccg;
		if (ccg->block_size == 0)
		{
			pccb->ccb_h.status = CAM_REQ_INVALID;
			xpt_done(pccb);
			break;
		}
		if (((1024L * 1024L)/ccg->block_size) < 0)
		{
			pccb->ccb_h.status = CAM_REQ_INVALID;
			xpt_done(pccb);
			break;
		}
		size_mb = ccg->volume_size/((1024L * 1024L)/ccg->block_size);
		if (size_mb > 1024 )
		{
			ccg->heads = 255;
			ccg->secs_per_track = 63;
		}
		else
		{
			ccg->heads = 64;
			ccg->secs_per_track = 32;
		}
		secs_per_cylinder = ccg->heads * ccg->secs_per_track;
		ccg->cylinders = ccg->volume_size / secs_per_cylinder;
		pccb->ccb_h.status |= CAM_REQ_CMP;
#endif
		xpt_done(pccb);
		break;
	}
	default:
		pccb->ccb_h.status |= CAM_REQ_INVALID;
		xpt_done(pccb);
		break;
	}
}

static void arcsas_execute_ccb(void *arg, bus_dma_segment_t *dm_segs, int nseg, int error)
{
	PCCB pCCB;
	PACB pACB;
	PCORE		pCore;
	union ccb	*pccb;
	int target, lun;
	PDomain_Device pDevice;

	pCCB = (PCCB)arg;
	pACB = pCCB->pACB;
	pccb = pCCB->pccb;
	target = pCCB->TargetId;
	lun = pCCB->Lun;
	if (error != 0)
	{
		if (error != EFBIG)
			printf("arcsas%d: unexpected error %x returned from 'bus_dmamap_load' \n", pACB->device_number, error);
		if ((pccb->ccb_h.status & CAM_STATUS_MASK) == CAM_REQ_INPROG)
			pccb->ccb_h.status |= CAM_REQ_TOO_BIG;
		arcsas_ccb_complete(pCCB, 0);
		return;
	}
	if (nseg > ARCSAS_MAX_OS_SG_ENTRIES)
	{
		printf("arcsas%d: PRD segment more than ARCSAS_MAX_OS_SG_ENTRIES.\n", pACB->device_number);
		pccb->ccb_h.status |= CAM_REQ_TOO_BIG;
		arcsas_ccb_complete(pCCB, 0);
		return;
	}
	if ((pccb->ccb_h.status & CAM_STATUS_MASK) != CAM_REQ_INPROG)
	{
		if (nseg != 0)
			bus_dmamap_unload(pACB->dataBuf_dmaTag, pCCB->dataBuf_dmaMap);
		arcsas_ccb_complete(pCCB, 0);
		return;
	}
	pDevice = pCCB->pDevice;
	if (pACB->outstanding_CCB >= ARCSAS_MAX_OUTSTANDING_CMD)
	{
		xpt_freeze_simq(pACB->psim, 1);
		pccb->ccb_h.status = CAM_REQUEUE_REQ;
		pACB->ACB_Flag |= ACB_FLAG_CAM_DEV_QFRZN;
		arcsas_ccb_complete(pCCB, 0);
		return;
	}
	pccb->ccb_h.status |= CAM_SIM_QUEUED;
	arcsas_build_os_ccb(pCCB, dm_segs, nseg);
	pCore = pDevice->pCore;
	arcsas_add_waitingCCB_tail(pCore, pCCB);
	atomic_add_int(&pACB->outstanding_CCB, 1);
	arcsas_inc_32(&pCore->RequestCount);
	arcsas_post_waiting_list_ccb(pCore);
}

static void arcsas_build_os_ccb(PCCB pCCB, bus_dma_segment_t *dm_segs, int nseg)
{
	PACB	pACB;
	union ccb *pccb;
	struct ccb_scsiio *pcsio;
	u_int32_t	io_flag;
	bus_dmasync_op_t op;

	pACB = pCCB->pACB;
	pccb = pCCB->pccb;
	pcsio= &pccb->csio;
	arcsas_bzero((uint8_t *)pCCB->Cdb, MAX_CDB_SIZE);
	if (pccb->ccb_h.flags & CAM_CDB_POINTER)
		bcopy(pcsio->cdb_io.cdb_ptr, pCCB->Cdb, pcsio->cdb_len);
	else
		bcopy(pcsio->cdb_io.cdb_bytes, pCCB->Cdb, pcsio->cdb_len);	/* bcopy(s, d, n) */
	switch(pCCB->Cdb[0])
	{
	case SCSI_CMD_READ_TOC:
		pCCB->Cdb[0] = SCSI_CMD_READ_TOC;
		pCCB->Cdb[2] = pCCB->Cdb[9] >> 6;
		break;
//	case SCSI_CMD_FORMAT_UNIT:
//		pCCB->Cdb[0] = 0x24; /* ATAPI opcodes */
//		break;
	}
	io_flag = pccb->ccb_h.flags & CAM_DIR_MASK;
	if ( io_flag == CAM_DIR_IN )
	{
		pCCB->Cmd_Flag |= (CMD_FLAG_DATA_IN | CMD_FLAG_DMA);
		op = BUS_DMASYNC_PREREAD;
	}
	else if ( io_flag == CAM_DIR_OUT )
	{
		pCCB->Cmd_Flag |= (CMD_FLAG_DATA_OUT | CMD_FLAG_DMA);
		op = BUS_DMASYNC_PREWRITE;
	}
	else
	{
		pCCB->Cmd_Flag |= CMD_FLAG_NON_DATA;
		op = 0;
	}
	if ( nseg )
		bus_dmamap_sync(pACB->dataBuf_dmaTag, pCCB->dataBuf_dmaMap, op);
	if ( !(pccb->ccb_h.flags & (CAM_DIS_AUTOSENSE | CAM_SENSE_PHYS | CAM_SNS_BUF_PHYS)))
	{
		pCCB->Cmd_Flag |= CMD_FLAG_AUTO_SENSE_OK;
		if ( pccb->ccb_h.flags & CAM_SENSE_PTR )
			pCCB->pSense_Buffer = *(PVOID *)&pcsio->sense_data;
		else
			pCCB->pSense_Buffer = (PVOID)&pcsio->sense_data;
		pCCB->SenseBufferLength = pcsio->sense_len;
	}
	pCCB->CCB_Type = CCB_TYPE_OS;
	pCCB->pOrg_Req  = pccb;
	pCCB->CCB_Status = CCB_STATUS_PENDING;
	pCCB->Completion = arcsas_done_os_ccb_callback;
	pCCB->pCmd_Initiator = (PVOID)pACB;
	pCCB->SlotNo = ARCSAS_EMPTY_TAG;
	pCCB->Time_Out = pccb->ccb_h.timeout / 1000;	/* convert timeout value from unit in mini second to second */
	pCCB->pData_Buffer = pcsio->data_ptr;
	if ( nseg )
		pCCB->DataTransferLength = pcsio->dxfer_len;
	pCCB->pSGsegment = dm_segs;
	pCCB->sgCount = nseg;
	pCCB->SG_Table.pSGEntry = (PARCSAS_SGENTRY)pCCB->sgList;
	arcsas_sg_table_init(&pCCB->SG_Table, ARCSAS_MAX_OS_SG_ENTRIES);
	arcsas_generate_sg_table(pCCB);	/* fill pCCB->SG_Table */
	arcsas_set_lba_and_sector_count(pCCB);	/* fill pCCB->LBA and pCCB->Sector_Count */
}

static void arcsas_generate_sg_table(PCCB pCCB)
{
	u_int16_t sgCount;
	bus_dma_segment_t	*pSGseg;
	PARCSAS_SG_Table	pSGTable;
	PARCSAS_SGENTRY		pSGEntry;

	sgCount = pCCB->sgCount;
	if (sgCount)
	{
		pSGseg = pCCB->pSGsegment;
		pSGTable = &pCCB->SG_Table;
		pSGEntry = pSGTable->pSGEntry;
		while (sgCount)
		{
			pSGEntry->baseAddr.parts.low = arcsas_htole32(dma_addr_lo32(pSGseg->ds_addr));
			pSGEntry->baseAddr.parts.high = arcsas_htole32(dma_addr_hi32(pSGseg->ds_addr));
			pSGEntry->size = arcsas_htole32(pSGseg->ds_len);
			pSGTable->Byte_Count += pSGEntry->size;
			pSGTable->Valid_Entry_Count++;
			sgCount--;
			if (sgCount == 0)
			{
				pSGEntry->flags |= SGD_EOT;
				break;
			}
			else
				pSGEntry->flags = 0;
			pSGEntry++;
			pSGseg++;
		}
	}
}
/*
**********************************************************************
**	Function:  arcsas_intr_handler
**	Output:  VOID
**********************************************************************
*/
static void arcsas_intr_handler(void *arg)
{
	PACB pACB=(PACB)arg;

	ARCSAS_MTX_LOCK(&pACB->isr_mutex);
	arcsas_core_handle_intr(pACB);
	ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
}

static void arcsas_async(void *cb_arg, u_int32_t code, struct cam_path *path, void *arg)
{
	PACB	pACB;
	u_int8_t target_id, target_lun;
	struct cam_sim * sim;

	sim = (struct cam_sim *) cb_arg;
	pACB = (PACB) cam_sim_softc(sim);
	switch (code) {
	case AC_LOST_DEVICE:
		target_id = xpt_path_target_id(path);
		target_lun = xpt_path_lun_id(path);
		if ((target_id > ARCSAS_MAX_TARGETID) || (target_lun > ARCSAS_MAX_TARGETLUN))
			break;
		break;
	default:
		break;
	}
}

static void arcsas_rescan_device_cb(struct cam_periph *periph, union ccb *pccb)
{
	PACB pACB;

	if (pccb->ccb_h.status != CAM_REQ_CMP)
		printf("arcsas_rescan_cb: Rescan Target=%x, lun=%x, failure status=%x\n", pccb->ccb_h.target_id, pccb->ccb_h.target_lun, pccb->ccb_h.status);
	pACB = pccb->ccb_h.spriv_ptr1;
	xpt_free_path(pccb->ccb_h.path);
	xpt_free_ccb(pccb);
	if ((pACB->ACB_Flag & ACB_FLAG_WAITING_RESCAN) == 0)
		arcsas_rescan_next1((void *)pACB);
}

void arcsas_rescan_device(PACB pACB, int target, int lun)
{
	struct cam_path	*path;
	union ccb	*pccb;
	cam_status	error;

	if ((pccb = (union ccb *)xpt_alloc_ccb_nowait()) == NULL)
		return;
#if __FreeBSD_version >= 901505
	int	mutex;
	mutex = arcsas_mutex_tryenter(&pACB->isr_mutex);
	error = xpt_create_path(&path, NULL, cam_sim_path(pACB->psim), target, lun);
	if (mutex)
		ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
#else
	error = xpt_create_path(&path, xpt_periph, cam_sim_path(pACB->psim), target, lun);
#endif
	if (error != CAM_REQ_CMP)
	{
		xpt_free_ccb(pccb);
		return;
	}
	arcsas_bzero((uint8_t *)pccb, sizeof(union ccb));
#if __FreeBSD_version >= 901505
	mutex = arcsas_mutex_tryenter(&pACB->isr_mutex);
#endif
	xpt_setup_ccb(&pccb->ccb_h, path, 5);
	pccb->ccb_h.func_code = XPT_SCAN_LUN;
	pccb->ccb_h.cbfcnp = arcsas_rescan_device_cb;
	pccb->crcn.flags = CAM_FLAG_NONE;
	pccb->ccb_h.spriv_ptr1 = pACB;
	xpt_action(pccb);
#if __FreeBSD_version >= 901505
	arcsas_hba_sleep_msec(250);
	if (mutex)
		ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
#endif
}

static void arcsas_rescan_next1(void *param)
{
	PACB pACB;
	u_int16_t	target, lun;

	pACB = (PACB)param;
	if (pACB->ACB_Flag & ACB_FLAG_WAITING_RESCAN)
	{
		callout_stop(&pACB->devmap_callout);
		pACB->ACB_Flag &= ~ACB_FLAG_WAITING_RESCAN;
		pACB->ACB_Flag |= ACB_FLAG_RESCAN_DEVICES;
	}
	for (target = 0; target < ARCSAS_MAX_DEVICE_INDEX; target++)
	{
		if (pACB->Hot_plug_map[target])
		{
			for (lun = 0; lun <= ARCSAS_MAX_TARGETLUN; lun++)
			{
				if (pACB->Hot_plug_map[target] & (1 << lun))
				{
					pACB->Hot_plug_map[target] &= ~(1 << lun);
					arcsas_rescan_device(pACB, target, lun);
					return;
				}
			}
		}
	}
	pACB->ACB_Flag &= ~ACB_FLAG_RESCAN_DEVICES;
}

void arcsas_delay_rescan_devices(PACB pACB)
{
	if (pACB->ACB_Flag & ACB_FLAG_WAITING_RESCAN)
	{
		callout_stop(&pACB->devmap_callout);
		callout_reset(&pACB->devmap_callout, ARCSAS_TIMER_RESCAN * hz, arcsas_rescan_next1, pACB);
	}
	else if (pACB->ACB_Flag & ACB_FLAG_RESCAN_DEVICES)
	{
		pACB->ACB_Flag |= ACB_FLAG_WAITING_RESCAN;
		pACB->ACB_Flag &= ~ACB_FLAG_RESCAN_DEVICES;
		callout_reset(&pACB->devmap_callout, ARCSAS_TIMER_RESCAN * hz, arcsas_rescan_next1, pACB);
	}
}

void arcsas_core_notify_device_hotplug(PCORE pCore, u_int8_t plugin, u_int16_t EntryIndex)
{
	PACB pACB;
	PDomain_Device pDevice;
	u_int16_t	target, lun;

	pACB = pCore->pACB;
	pDevice = &pACB->pDevices[Get_DevicesExpandersPMs_EntryIndex(pACB, EntryIndex)];
	if (pACB->ACB_Flag & ACB_FLAG_CORES_STATE_STARTED)
	{
		target = EntryIndex & 0xff;
		lun = EntryIndex >> 8;
		if (plugin == TRUE)
		{
			printf("arcsas: Target=0x%2x, lun=%x, Plug-IN!!!\n",target, lun);
			pDevice->Need_Notify = ARCSAS_DEVICE_NO_NEED_NOTIFY;
			if (pACB->ACB_Flag & ACB_FLAG_WAITING_RESCAN)
				callout_stop(&pACB->devmap_callout);
			else
				pACB->ACB_Flag |= ACB_FLAG_WAITING_RESCAN;
			pACB->Hot_plug_map[target] |= 1 << lun;
			callout_reset(&pACB->devmap_callout, ARCSAS_TIMER_RESCAN * hz, arcsas_rescan_next1, pACB);
		}
		else
		{
			pACB->Hot_plug_map[target] &= ~(1 << lun);
			printf("arcsas: Target=0x%2x, lun=%x, GONE!!!\n",target, lun);
			arcsas_hba_sleep_msec(500); /* time for os respone */
			arcsas_rescan_device(pACB, target, lun);
		}
	}
	if ((plugin) && (!IS_ENCLOSURE(pDevice)))
	{
		if (pDevice->Connection & DC_SGPIO)
			arcsas_core_sgpio_led_activated(pDevice, SES_LED_FLAG_ALL_OFF); /* active this drive normal LED */
		else if ((pDevice->pExpander != NULL) && (pDevice->Connection & DC_SCSI))
			arcsas_core_ses_led_activated(pDevice, SES_LED_FLAG_ALL_OFF); /* active this drive normal LED */
	}
}

static void arcsas_acb_ioctlcmd(PACB pACB, PCCB pCCB)
{
	union ccb *pccb;
	PSRB_IOCTL_FIELD pioctlField;
	PSRB_IO_CONTROL pioctlsrb;
	u_int8_t *pArecaPacket;

	pccb = pCCB->pccb;
	pioctlField = (PSRB_IOCTL_FIELD)pccb->csio.data_ptr;
	pioctlsrb = &pioctlField->srbioctl;
	pArecaPacket = pioctlField->ioctldatabuffer;
	pioctlsrb->ReturnCode = 0;
	switch(pioctlsrb->ControlCode)
	{
		case ARCSAS_IOCTL_SAS:
		{

			arcsas_handle_ioctl_packet(pACB, pioctlField);
			if (pioctlsrb->ReturnCode)
				pccb->ccb_h.status |= CAM_REQ_CMP;
		}
		break;
		case ARCSAS_IOCTL_SAY_HELLO:
		{
			u_int8_t *hello_string = "Hello! I am ARCSAS.KO";
			u_int16_t packet_len = (u_int16_t)strlen(hello_string);
			u_int16_t *ppacket_len = (u_int16_t *)(NumToPtr(PtrToNum(pArecaPacket)+3));
			u_int8_t *ppacket_data = (u_int8_t *)(NumToPtr(PtrToNum(pArecaPacket)+5));
			u_int8_t *checksum = (u_int8_t *)(NumToPtr(PtrToNum(pArecaPacket)+packet_len+5));

			arcsas_bzero((uint8_t *)ppacket_data, packet_len);
			*ppacket_len = ARCSAS_CPU_TO_LE16(packet_len);
			arcsas_memcpy(ppacket_data, hello_string,packet_len);
			*checksum = arcsas_get_checksum((u_int8_t *)ppacket_len,packet_len+2);
			pioctlsrb->ReturnCode = ARCSAS_IOCTL_RETURNCODE_OK;
			pccb->ccb_h.status |= CAM_REQ_CMP;
		}
		break;
		case ARCSAS_IOCTL_RETURN_CODE_3F:
		{
			pioctlsrb->ReturnCode = ARCSAS_IOCTL_RETURNCODE_3F;
			pccb->ccb_h.status |= CAM_REQ_CMP;
		}
		break;
		default:
		{
			pioctlsrb->ReturnCode = ARCSAS_IOCTL_RETURNCODE_ERROR;
			pccb->ccb_h.status |= CAM_REQ_INVALID;
		}
		break;
	}
}

void arcsas_scsi_ioctl(PACB pACB, PCCB pCCB)
{
	union ccb	*pccb = pCCB->pccb;
	PSRB_IOCTL_FIELD pioctlField = (PSRB_IOCTL_FIELD)pccb->csio.data_ptr;
	PSRB_IO_CONTROL pioctlsrb;

	pccb = pCCB->pccb;
	pioctlField = (PSRB_IOCTL_FIELD)pccb->csio.data_ptr;
	if (pioctlField == NULL)
	{
		pccb->ccb_h.status |= CAM_REQ_INVALID;
		return;
	}
	pioctlsrb = &pioctlField->srbioctl;
	if (memcmp(pioctlsrb->Signature,"ARCSAS",6)==0)
		arcsas_acb_ioctlcmd(pACB, pCCB);
	else
		pccb->ccb_h.status |= CAM_REQ_INVALID;
}

void arcsas_cmd_done(PACB pACB, PCCB pCCB)
{
	union ccb	*pccb;
	PDomain_Device pDevice;

	pDevice = pCCB->pDevice;
	pccb = pCCB->pccb;
	switch(pCCB->CCB_Status)
	{
	case CCB_STATUS_SUCCESS:
		pccb->ccb_h.status |= CAM_REQ_CMP;
		pccb->csio.scsi_status = SCSI_STATUS_OK;
		pDevice->CmdErrorCount = 0;
		break;
	case CCB_STATUS_BUSY:
		pccb->ccb_h.status |= CAM_SCSI_BUSY;
		pccb->csio.scsi_status = SCSI_STATUS_BUSY;
		break;
	case CCB_STATUS_MEDIA_ERROR:
		pccb->ccb_h.status |= CAM_REQ_TERMIO;
		pccb->csio.scsi_status = SCSI_STATUS_CHECK_COND;
		break;
	case CCB_STATUS_NO_DEVICE:
		pccb->ccb_h.status |= CAM_DEV_NOT_THERE;
		break;
	case CCB_STATUS_HAS_SENSE: {
		pccb->ccb_h.status |= CAM_SCSI_STATUS_ERROR; //CAM_REQ_CMP_ERR;
		pccb->csio.scsi_status = SCSI_STATUS_CHECK_COND;
		if (pCCB->Cmd_Flag & CMD_FLAG_AUTO_SENSE_OK)
			pccb->ccb_h.status |= CAM_AUTOSNS_VALID;

		PARCSAS_Sense_Data  senseBuffer = (PARCSAS_Sense_Data) pCCB->pSense_Buffer;

		senseBuffer->Valid = 1;		/* Sense buffer data is valid already. */
		switch(senseBuffer->SenseKey)
		{
			case SCSI_SK_MEDIUM_ERROR:
			{
				if (pDevice->EntryIndex != ARCSAS_ID_NOT_MAPPED)	/* scsi id lun */
				{
					pDevice->CmdErrorCount++;
					if (pDevice->CmdErrorCount > ARCSAS_MAX_DEVICE_MEDIUM_ERROR_COUNT)
					{
						pDevice->Need_Notify = (ARCSAS_DEVICE_NEED_NOTIFY|ARCSAS_DEVICE_FAILED_DRIVER_KICKOUT_NOTIFY); /* os notify device offline */
						arcsas_remove_device(pDevice);
					}
				}
			}
			break;
			case SCSI_SK_RECOVERED_ERROR:
			case SCSI_SK_HARDWARE_ERROR:
			{
				if (pDevice->EntryIndex != ARCSAS_ID_NOT_MAPPED)	/* scsi id lun */
				{
					pDevice->Need_Notify = (ARCSAS_DEVICE_NEED_NOTIFY|ARCSAS_DEVICE_FAILED_DRIVER_KICKOUT_NOTIFY); /* os notify device offline */
					arcsas_remove_device(pDevice);
				}
			}
			break;
		}
	}
	break;
	case CCB_STATUS_ERROR_WITH_SENSE:	/* request sense error */
		pccb->ccb_h.status |= CAM_AUTOSENSE_FAIL;
		pccb->csio.scsi_status = SCSI_STATUS_CHECK_COND;
		break;
	case CCB_STATUS_INVALID_REQUEST:
		pccb->ccb_h.status |= CAM_REQ_INVALID;
//		pccb->csio.scsi_status = SCSI_STATUS_CMD_TERMINATED;
		break;
	default:
		pccb->ccb_h.status |= CAM_UNCOR_PARITY;	/* unknow error or crc error just for retry */
		break;
	}

	if ((pCCB->CCB_Status != CCB_STATUS_SUCCESS) && (pCCB->CCB_Status != CCB_STATUS_HAS_SENSE) && (pCCB->TargetId < ARCSAS_MAX_REAL_DEVICE_NUMBER))
		printf(" arcsas_cmd_done: target=0x%x, lun=0x%x, SCSI Command=0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,0x%x,"
		    "cmd_status=0x%x, scsi_status=0x%x, ccb_status=0x%x\n",pCCB->TargetId, pCCB->Lun, pCCB->Cdb[0], pCCB->Cdb[1],
		    pCCB->Cdb[2], pCCB->Cdb[3], pCCB->Cdb[4], pCCB->Cdb[5], pCCB->Cdb[6], pCCB->Cdb[7], pCCB->Cdb[8], pCCB->Cdb[9],
		    pccb->ccb_h.status, pccb->csio.scsi_status, pCCB->CCB_Status);

	arcsas_inc_32(&pCCB->pCore->ReturnCount);
	arcsas_ccb_complete(pCCB, 1);
}
/*
**********************************************************************
**  command complete
**********************************************************************
*/
static void arcsas_ccb_complete(PCCB pCCB, int stand_flag)
{
	PACB	pACB;
	union ccb	*pccb;
	bus_dmasync_op_t op;

	pACB = pCCB->pACB;
	pccb = pCCB->pccb;
	if (pCCB->CCB_Flag & CCB_FLAG_TIMER_START)
		callout_stop(&pCCB->ccb_callout);
	if ((pccb->ccb_h.flags & CAM_DIR_MASK) != CAM_DIR_NONE) {

		if (	pCCB->Cmd_Flag & CMD_FLAG_DMAMAP_LOADED)
		{
			if ((pccb->ccb_h.flags & CAM_DIR_MASK) == CAM_DIR_IN)
				op = BUS_DMASYNC_POSTREAD;
			else
				op = BUS_DMASYNC_POSTWRITE;
			bus_dmamap_sync(pACB->dataBuf_dmaTag, pCCB->dataBuf_dmaMap, op);
			bus_dmamap_unload(pACB->dataBuf_dmaTag, pCCB->dataBuf_dmaMap);
		}
	}
	if (stand_flag == 1)
	{
		atomic_subtract_int(&pACB->outstanding_CCB, 1);
		if ((pACB->ACB_Flag & ACB_FLAG_CAM_DEV_QFRZN) && (pACB->outstanding_CCB < ARCSAS_RELEASE_SIMQ_LEVEL))
		{
			pACB->ACB_Flag &= ~ACB_FLAG_CAM_DEV_QFRZN;
			pccb->ccb_h.status |= CAM_RELEASE_SIMQ;
		}
	}
	arcsas_core_free_ccb_to_pool(pCCB->pCore, pCCB);
	xpt_done(pccb);
}

void arcsas_free_resource(PACB pACB)
{
	device_t dev;
	int max_core_num, core_index, i;
	struct _CORE *pCore;
	PCCB	pCCB;
	int	mutex;

	mutex = arcsas_mutex_tryenter(&pACB->isr_mutex);
	dev = pACB->pci_dev;
	if (pACB->ioctl_dev)
		destroy_dev(pACB->ioctl_dev);
	if (pACB->ppath)
		xpt_free_path(pACB->ppath);
	if (pACB->bus_registed)
		xpt_bus_deregister(cam_sim_path(pACB->psim));
	if (pACB->psim)
		cam_sim_free(pACB->psim, 0);
	if (pACB->devq)
		cam_simq_free(pACB->devq);
	if (pACB->ihandle)
		bus_teardown_intr(dev, pACB->irqres, pACB->ihandle);
	if (pACB->irqres)
		bus_release_resource(dev, SYS_RES_IRQ, pACB->irq_rid, pACB->irqres);
#if __FreeBSD_version >= 700000
	if (pACB->intr_count)
		pci_release_msi(pACB->pci_dev);
#endif
	if (mutex)
		ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
	arcsas_mutex_destroy_adapter(pACB);
	if (pACB->mtx_init)
		arcsas_mutex_destroy_core(pACB);
	if (pACB->dataBufMap_created)
	{
		max_core_num = (pACB->ACB_Flag & ACB_FLAG_DUAL_CORE)?2:1;
		for (core_index = 0; core_index < max_core_num; core_index++)
		{
			pCore = pACB->pCore[core_index];
			for (i = 0; i < ARCSAS_MAX_CORE_CCB_COUNT; i++)	/* 128 core ccb */
			{
				pCCB = arcsas_core_get_ccb_from_list( pCore );
				if (pCCB == 0)
					break;
				else if (pCCB->dataBuf_dmaMap)
					bus_dmamap_destroy(pACB->dataBuf_dmaTag, pCCB->dataBuf_dmaMap);
			}
		}
	}
	switch(pACB->adapter_type)
	{
		case PCI_DEVICE_ID_ARECA_1300:
		{
			if (pACB->sys_res_arcsas[0])
				bus_release_resource(dev, SYS_RES_MEMORY, PCIR_BAR(4), pACB->sys_res_arcsas[0]);
			if (pACB->sys_res_arcsas[1])
				bus_release_resource(dev, SYS_RES_IOPORT, PCIR_BAR(2), pACB->sys_res_arcsas[1]);
			break;
		}
		case PCI_DEVICE_ID_ARECA_1320:
		{
			if (pACB->sys_res_arcsas[0])
				bus_release_resource(dev, SYS_RES_MEMORY, PCIR_BAR(2), pACB->sys_res_arcsas[0]);
			break;
		}
	}
	if (pACB->dmaMap_loaded)
		bus_dmamap_unload(pACB->mailBox_dmaTag, pACB->mailBox_dmaMap);
	if (pACB->mailBox_dmaMap)
		bus_dmamap_destroy(pACB->mailBox_dmaTag, pACB->mailBox_dmaMap);
	if (pACB->mailBox_dmaTag)
		bus_dma_tag_destroy(pACB->mailBox_dmaTag);
	if (pACB->dataBuf_dmaTag)
		bus_dma_tag_destroy(pACB->dataBuf_dmaTag);
	if (pACB->parent_dmat)
		bus_dma_tag_destroy(pACB->parent_dmat);
}

static void	arcsas_mutex_init_adapter(PACB pACB)
{
	ARCSAS_MTX_INIT(&pACB->timer_mutex, "arcsas timer mtx");
	ARCSAS_MTX_INIT(&pACB->isr_mutex, "arcsas isr mtx");
	ARCSAS_MTX_INIT(&pACB->device_list_mutex, "arcsas device list mtx");
	ARCSAS_MTX_INIT(&pACB->expander_list_mutex, "arcsas expander list mtx");
	ARCSAS_MTX_INIT(&pACB->wait_registerset_mutex, "arcsas register set mtx");
	ARCSAS_MTX_INIT(&pACB->io_mutex, "arcsas io mtx");
	ARCSAS_MTX_INIT(&pACB->generic_dpcQ_mutex, "arcsas dpcQ mtx");
	ARCSAS_MTX_INIT(&pACB->smp_element_mutex, "arcsas smp element mtx");
	ARCSAS_MTX_INIT(&pACB->event_mutex, "arcsas event mtx");
	ARCSAS_MTX_INIT(&pACB->Tag_Pool_Device.tag_mutex, "arcsas device pool tag mtx");
	ARCSAS_MTX_INIT(&pACB->Tag_Pool_Expander.tag_mutex, "arcsas expander pool tag mtx");
	ARCSAS_MTX_INIT(&pACB->Tag_Pool_PM.tag_mutex, "arcsas PM pool tag mtx");
}

void arcsas_mutex_init_core(PCORE pCore)
{
	ARCSAS_MTX_INIT(&pCore->ccb_waiting_list_mutex, "arcsas ccb waiting list mtx");
	ARCSAS_MTX_INIT(&pCore->ccb_complete_list_mutex, "arcsas ccb completed list mtx");
	ARCSAS_MTX_INIT(&pCore->core_ccb_list_mutex, "arcsas ccb list mtx");
	ARCSAS_MTX_INIT(&pCore->context_list_mutex, "arcsas context list mtx");
	ARCSAS_MTX_INIT(&pCore->sas_scratch_list_mutex, "arcsas sas scratch list mtx");
	ARCSAS_MTX_INIT(&pCore->smp_scratch_list_mutex, "arcsas smp scratch list mtx");
	ARCSAS_MTX_INIT(&pCore->prd_buffer_list_mutex, "arcsas prd buffer list mtx");
	ARCSAS_MTX_INIT(&pCore->ccb_sent_list_mutex, "ccb send list mtx");
	ARCSAS_MTX_INIT(&pCore->Tag_Pool_CmdSlot.tag_mutex, "arcsas cmdSlot mtx");
	ARCSAS_MTX_INIT(&pCore->Tag_Pool_Port.tag_mutex, "arcsas Port mtx");
}

static void	arcsas_mutex_destroy_adapter(PACB pACB)
{
	ARCSAS_MTX_DESTROY(&pACB->wait_registerset_mutex);
	ARCSAS_MTX_DESTROY(&pACB->timer_mutex);
	ARCSAS_MTX_DESTROY(&pACB->isr_mutex);
	ARCSAS_MTX_DESTROY(&pACB->device_list_mutex);
	ARCSAS_MTX_DESTROY(&pACB->expander_list_mutex);
	ARCSAS_MTX_DESTROY(&pACB->Tag_Pool_Device.tag_mutex);
	ARCSAS_MTX_DESTROY(&pACB->Tag_Pool_Expander.tag_mutex);
	ARCSAS_MTX_DESTROY(&pACB->Tag_Pool_PM.tag_mutex);
	ARCSAS_MTX_DESTROY(&pACB->io_mutex);
	ARCSAS_MTX_DESTROY(&pACB->generic_dpcQ_mutex);
	ARCSAS_MTX_DESTROY(&pACB->smp_element_mutex);
	ARCSAS_MTX_DESTROY(&pACB->event_mutex);
}

static void	arcsas_mutex_destroy_core(PACB pACB)
{
	int max_core_num, core_index;
	struct _CORE *pCore;

	max_core_num = (pACB->ACB_Flag & ACB_FLAG_DUAL_CORE)?2:1;
	for (core_index = 0; core_index < max_core_num; core_index++)
	{
		pCore = pACB->pCore[core_index];
		ARCSAS_MTX_DESTROY(&pCore->ccb_waiting_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->ccb_complete_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->core_ccb_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->context_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->sas_scratch_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->smp_scratch_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->prd_buffer_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->ccb_sent_list_mutex);
		ARCSAS_MTX_DESTROY(&pCore->Tag_Pool_CmdSlot.tag_mutex);
		ARCSAS_MTX_DESTROY(&pCore->Tag_Pool_Port.tag_mutex);
	}
}

static void	arcsas_Discover_Devices(PACB pACB)
{
	int i, max_core_num, core_index, retry = 0;
	PCORE pCore;
	PDomain_Device pDevice;
	u_int16_t irq_handle;

	max_core_num = (pACB->ACB_Flag & ACB_FLAG_DUAL_CORE)?2:1;
	for (core_index = 0; core_index < max_core_num; core_index++)
	{
		pCore = pACB->pCore[core_index];
		pCore->State |= CORE_STATE_IDLE;
		arcsas_port_state_machine(pCore, NULL); /* start odin discovery state machine */
	}
	arcsas_hba_sleep_msec(1000);
	do {
		arcsas_do_generic_dpc(pACB);
		arcsas_hba_sleep_msec(25);
		/*
		***************************************************
		** polling command completion on Find Adapter stage
		** clear SAS interrupt
		***************************************************
		*/
		irq_handle = arcsas_core_handle_intr(pACB);
		retry = irq_handle ? 0 : retry+1;
		if (retry > 800) /* 20 secs timeout for irq polling ,in case of disk spin */
		{
			for (i = 0; i <= pACB->last_device_mapped_id; i++) /* 135 */
			{
				if (pACB->DevicesExpandersPMs_EntryIndex[i] == ARCSAS_ID_NOT_MAPPED)
				{
					continue;
				}
				pDevice = &pACB->pDevices[Get_DevicesExpandersPMs_EntryIndex(pACB,i)]; /* (0..135) */
				if (pDevice->pPort == NULL)
				{
					continue; /* virtual device */
				}
				if (pDevice->State != DEVICE_STATE_INIT_DONE)
				{
					pDevice->Need_Notify = (ARCSAS_DEVICE_FAILED_NO_NEED_NOTIFY|ARCSAS_DEVICE_FAILED_DRIVER_KICKOUT_NOTIFY); /* os notify device offline */
					arcsas_remove_device(pDevice);
				}
			}
			pACB->ACB_Flag |= ACB_FLAG_CORES_STATE_STARTED;
			break;
		}
	} while (!(pACB->ACB_Flag & ACB_FLAG_CORES_STATE_STARTED));
	arcsas_shift_device_entry_index(pACB);
	arcsas_sorting_entry_index(pACB);
	arcsas_check_update_flash_device_map(pACB,TRUE);
}

static void arcsas_map_mailBoxMem(void *arg, bus_dma_segment_t *segs, int nseg, int error)
{
	PACB pACB;

	pACB = arg;
	pACB->mailBox_physAddr = segs->ds_addr;
	pACB->error = error;
}

static u_int32_t arcsas_hba_initialize(device_t dev)
{
	PACB pACB;
	u_int16_t pci_command;
	bus_size_t max_coherent_size;

	if (pci_get_vendor(dev) != PCI_VENDOR_ID_ARECA)
		return (ENXIO);
	pACB = device_get_softc(dev);
	switch (pci_get_devid(dev)) {
	case PCIDevVenIDARC1300: {
		pACB->adapter_type = PCI_DEVICE_ID_ARECA_1300;
		pACB->ACB_Flag &= ~ACB_FLAG_DUAL_CORE;
		}
		break;
	case PCIDevVenIDARC1320: {
		pACB->adapter_type = PCI_DEVICE_ID_ARECA_1320;
		pACB->ACB_Flag |= ACB_FLAG_DUAL_CORE;
		}
		break;
	default: {
			printf("arcsas%d: unknown Host adapter type \n", device_get_unit(dev));
			return ENOMEM;
		}
	}
	pACB->system_vendor_id = pci_read_config(dev, PCIR_VENDOR, 2);
	pACB->system_device_id = pci_read_config(dev, PCIR_DEVICE, 2);
	pACB->subsystem_vendor_id = pci_read_config(dev, PCIR_SUBVEND_0, 2);
	pACB->subsystem_device_id = pci_read_config(dev, PCIR_SUBDEV_0, 2);
	pACB->Revision_Id = pci_read_config(dev, PCIR_REVID, 2);
	pACB->outstanding_CCB = 0;
	pACB->enclosure_mask = 0;		/* bit0..bit7=>128...135 */
	pACB->UsecsPerTick = 1000000;	/* 1 sec */
	pACB->SMART_Timer_ID = NO_CURRENT_TIMER;
	pACB->cache_size = arcsas_get_core_resource_quota(pACB,RESOURCE_CACHED_MEMORY);
	pACB->noncache_size = arcsas_get_core_resource_quota(pACB, RESOURCE_UNCACHED_MEMORY);
	pACB->pCLI_chan =  pACB;
	max_coherent_size = pACB->cache_size + pACB->noncache_size;
	/* initialize the timerlist */
	TDLIST_INIT_HDR(&(pACB->timerlist));

#if __FreeBSD_version >= 700000
	if (bus_dma_tag_create(  /* parent */	bus_get_dma_tag(dev),
#else
	if (bus_dma_tag_create(  /* PCI parent */	NULL,
#endif
				/* alignemnt */	1,
				/* boundary */	0,
				/* lowaddr */	BUS_SPACE_MAXADDR,
				/* highaddr */	BUS_SPACE_MAXADDR,
				/* filter */	NULL,
				/* filterarg */	NULL,
				/* maxsize */	BUS_SPACE_MAXSIZE_32BIT,
				/* nsegments */	BUS_SPACE_UNRESTRICTED,
				/* maxsegsz */	BUS_SPACE_MAXSIZE_32BIT,
				/* flags */	BUS_DMA_WAITOK,
#if __FreeBSD_version >= 502010
				/* lockfunc */	NULL,
				/* lockarg */	NULL,
#endif
				&pACB->parent_dmat) != 0)
	{
		printf("arcsas%d: parent_dmat bus_dma_tag_create failure!\n", device_get_unit(dev));
		return ENOMEM;
	}

	/* Create a tag for data read/write transfer. */
	if (bus_dma_tag_create(  /* parent_dmat*/	pACB->parent_dmat,
				/* alignment */	1,
				/* boundary */	0,
				/* lowaddr */	BUS_SPACE_MAXADDR,
				/* highaddr */	BUS_SPACE_MAXADDR,
				/* filter */	NULL,
				/* filterarg */	NULL,
				/* maxsize */	ARCSAS_MAX_OS_SG_ENTRIES * PAGE_SIZE, /* ARCSAS_MAX_CORE_SLOT_COUNT */
				/* nsegments */	ARCSAS_MAX_OS_SG_ENTRIES,
				/* maxsegsz */	0x3FFFFF, /* segment size 22 bits only */
				/* flags */	BUS_DMA_WAITOK,
#if __FreeBSD_version >= 502010
				/* lockfunc */	busdma_lock_mutex,
	#if __FreeBSD_version >= 700025
				/* lockarg */	&pACB->isr_mutex,
	#else
				/* lockarg */	&Giant,
	#endif
#endif
				&pACB->dataBuf_dmaTag) != 0)
	{
		printf("arcsas%d: dataBuf_dmaTag bus_dma_tag_create failure!\n", device_get_unit(dev));
		return ENOMEM;
	}

	/* DMA tag for our Mail box table .... Delivery, Completion, command header, command table, PRD table,... memory */
	if (bus_dma_tag_create(  /* parent_dmat */	pACB->parent_dmat,
				/* alignment */	0x20,
				/* boundary */	0,
				/* lowaddr */	BUS_SPACE_MAXADDR_32BIT,
				/* highaddr */	BUS_SPACE_MAXADDR,
				/* filter */	NULL,
				/* filterarg */	NULL,
				/* maxsize */	max_coherent_size,
				/* nsegments */	1,
				/* maxsegsz */	BUS_SPACE_MAXSIZE_32BIT,
				/* flags */	BUS_DMA_WAITOK,
#if __FreeBSD_version >= 502010
				/* lockfunc */	NULL,
				/* lockarg */	NULL,
#endif
				&pACB->mailBox_dmaTag) != 0)
	{
		printf("arcsas%d: mailBox_dmaTag bus_dma_tag_create failure!\n", device_get_unit(dev));
		return ENXIO;
	}
	/* Allocation for mailBox working buffer */
	if (bus_dmamem_alloc(pACB->mailBox_dmaTag, (void **)&pACB->pMailBoxPtr, BUS_DMA_WAITOK | BUS_DMA_COHERENT | BUS_DMA_ZERO, &pACB->mailBox_dmaMap) != 0) {
		printf("arcsas%d: mailBox_dmaTag bus_dmamem_alloc failure!\n", device_get_unit(dev));
		return ENXIO;
	}
	/* Creates a mapping in device visible address space of buflen bytes of buf, associated with the DMA map */
	if (bus_dmamap_load(pACB->mailBox_dmaTag, pACB->mailBox_dmaMap, pACB->pMailBoxPtr, max_coherent_size, arcsas_map_mailBoxMem, pACB, /* flags */ 0)) {
		printf("arcsas%d: mailBox_dmaTag bus_dmamap_load failure!\n", device_get_unit(dev));
		return ENXIO;
	}
	pACB->mailBox_size = pACB->noncache_size;
	pACB->pCacheDataStruct = pACB->pMailBoxPtr + pACB->noncache_size;
	pACB->dmaMap_loaded = 1;
	pci_command = pci_read_config(dev, PCIR_COMMAND, 2);
	switch(pACB->adapter_type) {
	case PCI_DEVICE_ID_ARECA_1300: {
		u_int32_t rid[] = { PCIR_BAR(2), PCIR_BAR(4) };
		vm_offset_t	mem_base0;	//, io_base0;

		/* Enable Busmaster/Mem/IO */
		pci_command |= (PCIM_CMD_PORTEN | PCIM_CMD_BUSMASTEREN | PCIM_CMD_MEMEN);
		pci_write_config(dev, PCIR_COMMAND, pci_command, 2);
		pACB->sys_res_arcsas[1] = bus_alloc_resource(dev, SYS_RES_IOPORT, &rid[0], 0ul, ~0ul, 0x100, RF_ACTIVE);
		if (pACB->sys_res_arcsas[1] == NULL) {
			printf("arcsas%d: bus_alloc_resource IO failure!\n", device_get_unit(dev));
			return ENOMEM;
		}
		if (rman_get_start(pACB->sys_res_arcsas[1]) <= 0) {
			printf("arcsas%d: rman_get_start IO failure!\n", device_get_unit(dev));
			return ENXIO;
		}
		pACB->btag[1] = rman_get_bustag(pACB->sys_res_arcsas[1]);
		pACB->bhandle[1] = rman_get_bushandle(pACB->sys_res_arcsas[1]);

		pACB->sys_res_arcsas[0] = bus_alloc_resource(dev, SYS_RES_MEMORY, &rid[1], 0ul, ~0ul, 0x1000, RF_ACTIVE);
		if (pACB->sys_res_arcsas[0] == NULL) {
			printf("arcsas%d: bus_alloc_resource MEMORY failure!\n", device_get_unit(dev));
			return ENOMEM;
		}
		if (rman_get_start(pACB->sys_res_arcsas[0]) <= 0) {
			printf("arcsas%d: rman_get_start MEMORY failure!\n", device_get_unit(dev));
			return ENXIO;
		}
		mem_base0 = (vm_offset_t) rman_get_virtual(pACB->sys_res_arcsas[0]);
		if (mem_base0 == 0) {
			printf("arcsas%d: rman_get_virtual MEMORY failure!\n", device_get_unit(dev));
			return ENXIO;
		}
		pACB->btag[0] = rman_get_bustag(pACB->sys_res_arcsas[0]);
		pACB->bhandle[0] = rman_get_bushandle(pACB->sys_res_arcsas[0]);
		pACB->mem_map_base = mem_base0;
		if (arcsas_core_initialize(pACB) == FALSE)
		{
			printf( "arcsas%d: arcsas_core_initialize Failure!\n", device_get_unit(dev));
			return(ENXIO);
		}
		pACB->pCore[0]->io_map_base = 0;
		pACB->pCore[0]->mem_map_base = 0;
	}
	break;
	case PCI_DEVICE_ID_ARECA_1320: {
		u_int32_t rid0 = PCIR_BAR(2);
		vm_offset_t	mem_base0;

		/* Enable Busmaster/Mem */
		pci_command |= (PCIM_CMD_BUSMASTEREN | PCIM_CMD_MEMEN);
		pci_write_config(dev, PCIR_COMMAND, pci_command, 2);
		pACB->sys_res_arcsas[0] = bus_alloc_resource(dev, SYS_RES_MEMORY, &rid0, 0ul, ~0ul, 0x3FFFF, RF_ACTIVE);
		if (pACB->sys_res_arcsas[0] == NULL) {
			printf("arcsas%d: bus_alloc_resource failure!\n", device_get_unit(dev));
			return ENOMEM;
		}
		if (rman_get_start(pACB->sys_res_arcsas[0]) <= 0) {
			printf("arcsas%d: rman_get_start failure!\n", device_get_unit(dev));
			return ENXIO;
		}
		mem_base0 = (vm_offset_t) rman_get_virtual(pACB->sys_res_arcsas[0]);
		if (mem_base0 == 0) {
			printf("arcsas%d: rman_get_virtual failure!\n", device_get_unit(dev));
			return ENXIO;
		}
		pACB->btag[0] = rman_get_bustag(pACB->sys_res_arcsas[0]);
		pACB->bhandle[0] = rman_get_bushandle(pACB->sys_res_arcsas[0]);
		pACB->mem_map_base = mem_base0;
		pACB->ACB_Flag |= ACB_FLAG_DUAL_CORE;
		if (arcsas_core_initialize(pACB) == FALSE)
		{
			printf( "arcsas%d: arcsas_core_initialize Failure!\n", device_get_unit(dev));
			return(ENXIO);
		}
		/*
		********************************************************************************
		**	pCore->mem_map_base: (SAS/SATA A Register) port0...port3 20000h-23FFFh
		**pCore->mem_map_base+0x4000: (SAS/SATA B Register) port4...port7 24000h-24FFFh
		********************************************************************************
		*/
		pACB->pCore[0]->mem_map_base_ext = 0;
		pACB->pCore[1]->mem_map_base_ext = 0;
		pACB->pCore[0]->mem_map_base = ARCSAS_SAS_A_BASE;
		pACB->pCore[1]->mem_map_base = ARCSAS_SAS_B_BASE;
	}
	break;
	}
	if (arcsas_reset_controller(pACB) == FALSE)
	{
		printf( "arcsas: arcsas_reset_controller Failure!\n");
		return (ENXIO);
	}

	if (arcsas_init_chip(pACB) == FALSE)
	{
		printf( "arcsas: arcsas_init_chip Failure!\n");
		return (ENXIO);
	}
	arcsas_init_virtual_ses_device(pACB);
	return(0);
}

static void arcsas_device_ccb_abort(PDomain_Device pDevice, union ccb *pccb)
{
	PDomain_Port pPort;
	PCORE pCore;
	PACB pACB;
	PCCB pCCB, pCCBabort;
	u_int32_t doneQ_index;
	u_int16_t i;
	vm_offset_t	mem_map_base;

	pPort = pDevice->pPort;
	pCore = (PCORE)pPort->pCore;
	pACB = pCore->pACB;
	pCCBabort = NULL;
	mem_map_base = pCore->mem_map_base;
	/* get the request that need to abort */
	while ((pCCB = arcsas_device_get_sent_ccb_from_list(pDevice)) != NULL)
	{
		/* To Tail, for SAS, let the next ccb to come, for sata, it will be deleted below anyway. */
		if ((pCCB->pCmd_Initiator == pACB) && (pccb == (union ccb *)pCCB->pOrg_Req))
		{
			pCCBabort = pCCB;
			break;
		}
		arcsas_list_add_tail(&pCore->ccb_sent_list_mutex, &pCCB->Queue_Pointer, &pDevice->Sent_CCB_List);
	}
	if (pCCBabort == NULL)
	{
		return;
	}
	/* Check if it is already handled (reset/aborted) */
	if ((pCore->Resetting_Slot[pCCBabort->SlotNo/32] & (0x1L<<(pCCBabort->SlotNo%32))) && (!arcsas_list_empty(&pDevice->Sent_CCB_List)))
	{
		/* To Tail, for SAS, let the next ccb to come, for sata, it will be deleted below anyway. */
		arcsas_list_add_tail(&pCore->ccb_sent_list_mutex, &pCCBabort->Queue_Pointer, &pDevice->Sent_CCB_List);
	}
	for (i = 0; i < pCore->Slot_Count_Supported; i++)
	{
		pCCB = pCore->pRunning_CCB[i];
		if (pCCB != NULL)
		{
			DONE_Q_ENTRY entry;
			PDONE_Q_ENTRY pDoneQ = (PDONE_Q_ENTRY) pCore->pCompletionQ;

			if (pDevice->EntryIndex != pCCB->EntryIndex)
			{
			/*
			*************************************************
			** this ccb is not belong to this abort Device
			*************************************************
			*/
				continue;
			}
			/*
			***********************************************
			**	check if this is being completed
			***********************************************
			*/
			doneQ_index = pCore->last_DoneQ_index;
			while (doneQ_index != ARCSAS_LE32_TO_CPU(((u_int32_t *) pDoneQ)[0]))
			{
				doneQ_index++;
				if (doneQ_index >= pCore->Max_DoneQ_Index) /* 522 */
				{
					doneQ_index = 0;
				}
				entry = pDoneQ[doneQ_index+1];
				ARCSAS_LE32_TO_CPU_PTR(&entry);
				if ((!entry.ATTENTION) && ((u_int16_t) entry.SLOT_NM) == i)
				{
					/* the abort request is actually in the completion queue we handle that and move on */
					if (pCCBabort == pCCB)
					{
						/* Areca SAS controller core device ccb abort */
						arcsas_event_log( "arcsas%d: Areca SAS controller core device ccb abort.", device_get_unit(pACB->pci_dev));
						ARCSAS_MTX_LOCK(&pACB->isr_mutex);
						arcsas_drain_done_queue(pCore);
						ARCSAS_MTX_UNLOCK(&pACB->isr_mutex);
						return;
					}
					break;
				}
			}
			if ((Get_DevicesExpandersPMs_EntryIndex(pACB, pCCB->EntryIndex) != ARCSAS_ID_NOT_MAPPED) && (pPort->DiscoveryInstance == 0)) /* (0..135,136..143,144..151) */
			{
			/*
			*********************************************
			** this port is not working on discovery
			*********************************************
			*/
				if ((pDevice != NULL) && IS_STP_OR_SATA_ATAPI(pDevice))
				{
					u_int16_t command_cmd_addr = 0,command_cmd_data = 0;

					switch(pACB->system_device_id)
					{
						case PCI_DEVICE_ID_ARECA_1300:
						{
							command_cmd_addr = COMMON_CMD_ADDR_1300;
							command_cmd_data = COMMON_CMD_DATA_1300;
						}
						break;
						case PCI_DEVICE_ID_ARECA_1320:
						{
							command_cmd_addr = COMMON_CMD_ADDR_1320;
							command_cmd_data = COMMON_CMD_DATA_1320;
						}
						break;
					}
					/* reset slot - clear this ccb active and ccb issue */
					CHIP_REG_WRITE32((mem_map_base+command_cmd_addr), CMD_PORT_ACTIVE0+(pCCB->SlotNo >> 3));
					CHIP_REG_WRITE32((mem_map_base+command_cmd_data), ARCSAS_BIT(pCCB->SlotNo % 32));
					CHIP_REG_WRITE32((mem_map_base+command_cmd_addr), CMD_PORT_ISS0+(pCCB->SlotNo >> 3));
					CHIP_REG_WRITE32((mem_map_base+command_cmd_data), ARCSAS_BIT(pCCB->SlotNo % 32));
					pCore->pRunning_CCB[pCCB->SlotNo] = NULL;
					pCore->Running_Slot[pCCB->SlotNo >> 5] &= ~(1L << (pCCB->SlotNo % 32));
					pCore->Resetting_Slot[pCCB->SlotNo >> 5] &= ~(1L << (pCCB->SlotNo % 32));
					if (pCCB != pCCBabort)
					{
					/*
					**************************************
					** this ccb is not abort ccb
					** queue it into CCB_Waiting_List again
					** and wait to execute
					**************************************
					*/
						arcsas_list_delete(&pCore->ccb_sent_list_mutex, &pCCB->Queue_Pointer);
						/* Fix to avoid SG buffer memory leak. */
						if (pCCB->PRD_Buffer)
						{
							arcsas_free_prd_buffer_to_list(pCore, pCCB->PRD_Buffer);
						}
						arcsas_list_add_head(&pCore->ccb_waiting_list_mutex, &pCCB->Queue_Pointer, &pCore->CCB_Waiting_List);
					}
					arcsas_release_pool_tag(&pCore->Tag_Pool_CmdSlot, pCCB->SlotNo);
					atomic_subtract_int(&pDevice->Outstanding_CCB, 1);
					printf(" arcsas_device_ccb_abort....pDevice->Outstanding_CCB=%d.....................\n", pDevice->Outstanding_CCB);
				}
			}
		}
	}
	if ((Get_DevicesExpandersPMs_EntryIndex(pACB, pCCBabort->EntryIndex) != ARCSAS_ID_NOT_MAPPED) && (pPort->DiscoveryInstance == 0) && (pPort->Type & PORT_TYPE_SAS) && IS_SSP(pDevice))
	{
	/* this port is SAS device */
		pDevice->Error_Handling_State = EH_ABORT_REQUEST;
		arcsas_sas_error_handling(pDevice, pCCBabort);
	}
	if ((pDevice != NULL) && IS_STP_OR_SATA_ATAPI(pDevice))
	{
		arcsas_list_delete(&pCore->ccb_sent_list_mutex, &pCCBabort->Queue_Pointer);
		pDevice->Error_Handling_State = EH_ABORT_REQUEST;
		arcsas_sata_error_handling(pDevice, pCCBabort);
	}
}

static int arcsas_seek_cmd2abort(PACB pACB, union ccb *pAbortCCB)
{
	struct list_head *pPosition;
	PCORE pCore;
	PDomain_Device pDevice = NULL;
	PCCB	pCCB;
	union ccb *pccb;
	int max_core_num, core_index;
	int i, count = 0;
	int found = 0;
	u_int16_t EntryIndex;

	/*
	*******************************************************
	** It is the upper layer do abort command this lock
	** just prior to calling us.
	** First determine if we currently own this command.
	** Start by searching the device queue. If not found
	** at all, and the system wanted us to just abort the
	** command return success.
	*******************************************************
	*/
	/*
	*******************************************************
	**  abort ccb if it is in waiting ccb
	*******************************************************
	*/
	max_core_num = (pACB->ACB_Flag & ACB_FLAG_DUAL_CORE) ? 2 : 1;
	for (core_index = 0; core_index < max_core_num; core_index++)
	{

		pCore = pACB->pCore[core_index];
		if (!arcsas_list_empty(&pCore->CCB_Waiting_List))
		{
			for (pPosition = (&pCore->CCB_Waiting_List)->next; pPosition != (&pCore->CCB_Waiting_List); pPosition = pPosition->next)
				count++;
			for (i = 0; i < count; i++)
			{
				pCCB = arcsas_core_get_waiting_ccb_from_list(pCore);
				/* only Allocate Core Driver Context for Core request. */
				if (pCCB->pCmd_Initiator == pACB)
				{
					pccb = pCCB->pccb;
					if (pccb == pAbortCCB)
					{
						pAbortCCB->ccb_h.status = CAM_REQ_ABORTED;
						arcsas_ccb_complete(pCCB, 1);
						found = 1;
					}
				}
				if (found)
					break;
				else
					arcsas_list_add_tail(&pCore->ccb_waiting_list_mutex, &pCCB->Queue_Pointer, &pCore->CCB_Waiting_List);
			}
			if (found)
				return (TRUE);
		}
	}
	/*
	*******************************************************
	**  abort CCB if it is in outstanding ccb
	*******************************************************
	*/
	if (pAbortCCB->ccb_h.target_lun)
	{
		EntryIndex = MAKE_DEVICE_ENTRY_INDEX(pAbortCCB->ccb_h.target_id, pAbortCCB->ccb_h.target_lun);
		for (i = 0; i <= ARCSAS_MAX_TARGETLUN; i++)
		{
			if (pACB->pDevicesLun[i].EntryIndex == EntryIndex)	/* this value is (target_lun,target_id) */
			{
				pDevice = &pACB->pDevicesLun[i];
				break;
			}
		}
	}
	else
	{
		EntryIndex = Get_DevicesExpandersPMs_EntryIndex(pACB, pAbortCCB->ccb_h.target_id);
		if (EntryIndex == ARCSAS_ID_NOT_MAPPED)
			return (TRUE);
		else
			pDevice = &pACB->pDevices[EntryIndex];
	}
	arcsas_device_ccb_abort(pDevice, pAbortCCB);
		return (TRUE);
}

void arcsas_set_residue(PCCB pCCB, u_int32_t information)
{
	union ccb	*pccb;

	pccb = pCCB->pccb;
	if (pccb)
		pccb->csio.resid = information;
}

time_t arcsas_get_time(void)
{
	struct timeval	tv;

	microtime(&tv);
	return(tv.tv_sec);
}

void arcsas_mutex_enter(arcsas_lock_t *ptr)
{
	ARCSAS_MTX_LOCK(ptr);
}

void arcsas_mutex_exit(arcsas_lock_t *ptr)
{
	ARCSAS_MTX_UNLOCK(ptr);
}

int arcsas_mutex_tryenter(arcsas_lock_t *ptr)
{
	int	rtn;
	rtn = ARCSAS_MTX_TRYLOCK(ptr);
	return(rtn);
}

void arcsas_hba_sleep_msec(uint32_t msec)
{
	uint32_t Index;
	for (Index = 0; Index < msec; Index++)
		DELAY(999);
}

void arcsas_hba_sleep_usec(uint32_t usec)
{
	DELAY(usec);
}

void arcsas_inc_32(volatile u_int32_t *ptr)
{
	atomic_add_int(ptr, 1);
}

void arcsas_dec_32(volatile u_int32_t *ptr)
{
	atomic_subtract_int(ptr, 1);
}

void arcsas_inc_16(volatile u_int16_t *ptr)
{
	atomic_add_16(ptr, 1);
}

void arcsas_dec_16(volatile u_int16_t *ptr)
{
	atomic_subtract_16(ptr, 1);
}

void arcsas_inc_8(volatile u_int8_t *ptr)
{
	atomic_add_8(ptr, 1);
}

void arcsas_dec_8(volatile u_int8_t *ptr)
{
	atomic_subtract_8(ptr, 1);
}

void arcsas_uncached_sync_dev(PACB pACB, bus_dmasync_op_t op)
{
	bus_dmamap_sync(pACB->mailBox_dmaTag, pACB->mailBox_dmaMap, op);
}

void arcsas_uncached_sync_kernel(PACB pACB, bus_dmasync_op_t op)
{
	bus_dmamap_sync(pACB->mailBox_dmaTag, pACB->mailBox_dmaMap, op);
}

void arcsas_pciCfg_put32(PACB pACB, int addr, uint32_t data)
{
	pci_write_config(pACB->pci_dev, addr, data, 4);
}

uint32_t arcsas_pciCfg_get32(PACB pACB, int addr)
{
	uint32_t	data;
	data = pci_read_config(pACB->pci_dev, addr, 4);
	return(data);
}

void arcsas_init_hba_timer(PACB pACB)
{
	callout_reset(&pACB->timeout_callout, ARCSAS_TIMEOUT_WATCH * hz, arcsas_hba_timer, pACB);
}

void arcsas_start_lostIRQ_timer(PACB pACB)
{
	callout_reset(&pACB->timer_handle2, (hz >> 3), arcsas_lostIRQ_handler, pACB);
}

u_int32_t arcsas_reg_read4(PACB pACB, bus_size_t reg)
{
	u_int32_t rtn;
	rtn = bus_space_read_4( pACB->btag[0], pACB->bhandle[0], reg);
	return(rtn);
}

void arcsas_reg_write4(PACB pACB, bus_size_t reg, u_int32_t data)
{
	bus_space_write_4( pACB->btag[0], pACB->bhandle[0], reg, data);
}

u_int32_t arcsas_io_read4(PACB pACB, bus_size_t reg)
{
	u_int32_t rtn;
	rtn = bus_space_read_4( pACB->btag[1], pACB->bhandle[1], reg);
	return(rtn);
}

void arcsas_io_write4(PACB pACB, bus_size_t reg, u_int32_t data)
{
	bus_space_write_4( pACB->btag[1], pACB->bhandle[1], reg, data);
}

void arcsas_cli_sleep(PACB pACB, struct _SRB_IOCTL_FIELD *pioctlField)
{
	int	error, time_elapsed;

	if (pioctlField->srbioctl.ReturnCode)
		return;
	time_elapsed = 0;
	while (time_elapsed < ARCSAS_CLI_TIMEOUT)
	{
		error =	tsleep(pACB->pCLI_chan, PUSER, "arccli", ARCSAS_CLI_WATCH);
		if (error == EWOULDBLOCK)
			time_elapsed++;
	//	printf("tsleep return code = 0x%x, time elapsed is %d\n", error, time_elapsed);
		if (pioctlField->srbioctl.ReturnCode)
			break;
	}
}

void arcsas_wait_discovery_sleep(PACB pACB, struct _SRB_IOCTL_FIELD *pioctlField)
{
	int	error, time_elapsed;

	time_elapsed = 0;
	while (time_elapsed < ARCSAS_CLI_TIMEOUT)
	{
		error =	tsleep(pACB->pCLI_chan, PUSER, "arccli", ARCSAS_CLI_WATCH);
		if (error == EWOULDBLOCK)
			time_elapsed++;
	//	printf("tsleep return code = 0x%x, time elapsed is %d\n", error, time_elapsed);
		if ((pACB->ACB_Flag & ACB_FLAG_DOING_DISCOVERY) == 0)
			break;
	}
}
