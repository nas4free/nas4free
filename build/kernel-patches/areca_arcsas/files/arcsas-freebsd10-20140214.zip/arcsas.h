/*
******************************************************************************
**	OS	: FreeBSD
**	FILE NAME : arcsas.h
**	BY	: Erich Chen, Ching Huang
**	Description: Device Driver for Areca ARC13x0 SAS Host Bus Adapter
******************************************************************************
**	Copyright (C) 2002,2011 Areca Technology Corporation All rights reserved.
******************************************************************************
*/
#define __LITTLE_ENDIAN
#define __LITTLE_ENDIAN_BITFIELD

#if defined(__LITTLE_ENDIAN)
	#define __ARCSAS_BIG_ENDIAN__		0
#elif defined(__BIG_ENDIAN)
	#define __ARCSAS_BIG_ENDIAN__		1
#else
	#   error "error in endianness"
#endif

#if defined(__LITTLE_ENDIAN_BITFIELD)
	#define __ARCSAS_BIG_ENDIAN_BITFIELD__	0
#elif defined(__BIG_ENDIAN_BITFIELD)
	#define __ARCSAS_BIG_ENDIAN_BITFIELD__	1
#else
	#error "error in endianness"
#endif

#if __ARCSAS_BIG_ENDIAN__
	#define ARCSAS_CPU_TO_LE16(x)	ARCSAS_SWAP_16(x)
	#define ARCSAS_CPU_TO_LE32(x)	ARCSAS_SWAP_32(x)
	#define ARCSAS_CPU_TO_LE64(x)	ARCSAS_SWAP_64(x)
	#define ARCSAS_CPU_TO_BE16(x)	x
	#define ARCSAS_CPU_TO_BE32(x)	x
	#define ARCSAS_CPU_TO_BE64(x)	(x).value

	#define ARCSAS_LE16_TO_CPU(x)	ARCSAS_SWAP_16(x)
	#define ARCSAS_LE32_TO_CPU(x)	ARCSAS_SWAP_32(x)
	#define ARCSAS_LE64_TO_CPU(x)	ARCSAS_SWAP_64(x)
	#define ARCSAS_BE16_TO_CPU(x)	x
	#define ARCSAS_BE32_TO_CPU(x)	x
	#define ARCSAS_BE64_TO_CPU(x)	(x).value

	#define ARCSAS_CPU_TO_LE16_PTR(pu16)	*((u_int16_t *)(pu16))= ARCSAS_CPU_TO_LE16(*(u_int16_t *) (pu16))
	#define ARCSAS_CPU_TO_LE32_PTR(pu32)	*((u_int32_t *)(pu32))= ARCSAS_CPU_TO_LE32(*(u_int32_t *) (pu32))
	#define ARCSAS_LE16_TO_CPU_PTR(pu16)	*((u_int16_t *)(pu16))= ARCSAS_LE16_TO_CPU(*(u_int16_t *) (pu16))
	#define ARCSAS_LE32_TO_CPU_PTR(pu32)	*((u_int32_t *)(pu32))= ARCSAS_LE32_TO_CPU(*(u_int32_t *) (pu32))
#else  /* __ARCSAS_LITTLE_ENDIAN__ */
	#define ARCSAS_CPU_TO_LE16(x)	x
	#define ARCSAS_CPU_TO_LE32(x)	x
	#define ARCSAS_CPU_TO_LE64(x)	(x).value
	#define ARCSAS_CPU_TO_BE16(x)	ARCSAS_SWAP_16(x)
	#define ARCSAS_CPU_TO_BE32(x)	ARCSAS_SWAP_32(x)
	#define ARCSAS_CPU_TO_BE64(x)	ARCSAS_SWAP_64(x)

	#define ARCSAS_LE16_TO_CPU(x)	x
	#define ARCSAS_LE32_TO_CPU(x)	x
	#define ARCSAS_LE64_TO_CPU(x)	(x).value
	#define ARCSAS_BE16_TO_CPU(x)	ARCSAS_SWAP_16(x)
	#define ARCSAS_BE32_TO_CPU(x)	ARCSAS_SWAP_32(x)
	#define ARCSAS_BE64_TO_CPU(x)	ARCSAS_SWAP_64(x)

	#define ARCSAS_CPU_TO_LE16_PTR(pu16)
	#define ARCSAS_CPU_TO_LE32_PTR(pu32)
	#define ARCSAS_LE16_TO_CPU_PTR(pu32)
	#define ARCSAS_LE32_TO_CPU_PTR(pu32)
#endif /* __ARCSAS_BIG_ENDIAN__ */

#ifndef	TRUE
	#define	TRUE	1
	#define	FALSE	0
#endif

#if __FreeBSD_version >= 500005
	typedef struct mtx		arcsas_lock_t, kmutex_t;
	#define ARCSAS_MTX_INIT(l, s)	mtx_init(l, s, NULL, MTX_DEF)
	#define ARCSAS_MTX_DESTROY(l)	mtx_destroy(l)
	#define ARCSAS_MTX_LOCK(l)	mtx_lock(l)
	#define ARCSAS_MTX_UNLOCK(l)	mtx_unlock(l)
	#define ARCSAS_MTX_TRYLOCK(l)	mtx_trylock(l)
	#define arcsas_htole32(x)	htole32(x)
#else
	typedef struct simplelock	arcsas_lock_t, kmutex_t;
	#define ARCSAS_MTX_INIT(l, s)	simple_lock_init(l)
	#define ARCSAS_MTX_DESTROY(l)
	#define ARCSAS_MTX_LOCK(l)	simple_lock(l)
	#define ARCSAS_MTX_UNLOCK(l)	simple_unlock(l)
	#define ARCSAS_MTX_TRYLOCK(l)	simple_lock_try(l)
	#define arcsas_htole32(x)	(x)
#endif

#if __FreeBSD_version > 500000
#define arcsas_callout_init(a)	callout_init(a, /*mpsafe*/1);
#else
#define arcsas_callout_init(a)	callout_init(a);
#endif

/*
************************************************************
**
************************************************************
*/
#if defined(__amd64) || defined(_LP64)
	#define	PtrToNum(p)	(u_int64_t)((caddr_t)p)
	#define	NumToPtr(ul)	(caddr_t *)((u_int64_t)ul)
	#define	GetValue	*(u_int64_t *)
#else
	#define	PtrToNum(p)	(u_int32_t)((caddr_t)p)
	#define	NumToPtr(ul)	(caddr_t *)((u_int32_t)ul)
	#define	GetValue	*(u_int32_t *)
#endif
/*
************************************************************************
**
************************************************************************
*/
#define CHIP_IO_READ32(reg)		arcsas_io_read4( pACB, (bus_size_t)reg)
#define CHIP_IO_WRITE32(reg, data)	arcsas_io_write4(pACB, (bus_size_t)reg, data)
#define CHIP_REG_READ32(reg)		arcsas_reg_read4( pACB, (bus_size_t)reg)
#define CHIP_REG_WRITE32(reg, data)	arcsas_reg_write4(pACB, (bus_size_t)reg, data)
/*
************************************************************
**  Definition for porting from Solaris
************************************************************
*/
#define	CE_CONT		0
#define	CE_WARN		1
#define	uint8_t		u_int8_t
#define	uint16_t	u_int16_t
#define	uint32_t	u_int32_t
#define	ARCSAS_BASE_T	vm_offset_t
#define	arcsas_printf	arcsas_hba_event_log

#define	arcsas_get_buffer_addr()	\
		data_buffer = pCCB->pData_Buffer;

#define	arcsas_get_buf_addr()	\
		data_buffer = pCCB->pData_Buffer;

#define	arcsas_dma_sync()

#define	MODE_DAD_WP		0x80
#define	MODE_DAD_DPOFUA		0x10

/* driver capabilities */
#define ARCSAS_MAX_HOST_ADAPTER_SUPPORTED	4
#define ARCSAS_MAX_CMDXFER_LENGTH		(256*4096)
#define ARCSAS_MAX_CMDXFER_LENGTH_NTLDR_DUMP	(16*4096)
#define ARCSAS_MAX_BASE_ADDRESS			2
#define ARCSAS_MAX_REAL_DEVICE_NUMBER		128
#define ARCSAS_MAX_DISK_ID			127
#define ARCSAS_MAX_TARGETID			136 /* 0..136 "0..127 real","128..135 enclosure",136 virtual */
#define ARCSAS_MAX_TARGETLUN			7 /* 0..127 */
#define ARCSAS_SCSI_INITIATOR_ID		255
#define ARCSAS_DEV_PAUSE_TIMEOUT		20	/* max 20 sec */
#define ARCSAS_MAX_SG_BUFFER_COUNT		512
#define ARCSAS_MAX_OS_SG_ENTRIES		128
#define ARCSAS_MAX_OS_SG_ENTRIES_NTLDR_DUMP	16
#define ARCSAS_MAX_CORE_SG_ENTRIES		64
#define ARCSAS_MAX_CORE_SG_ENTRIES_NTLDR_DUMP	8
/* hardware capabilities */
#define ARCSAS_MAX_CORE_PHYSICAL_PORT_NUMBER	4
#define ARCSAS_MAX_EXPANDER_SUPPORTED		8
#define ARCSAS_MAX_PM_SUPPORTED			8
#define ARCSAS_MAX_CORE_SLOT_COUNT		512
#define ARCSAS_MAX_OUTSTANDING_CMD		256
#define ARCSAS_MAX_CORE_CCB_COUNT		(ARCSAS_MAX_OUTSTANDING_CMD + 64)
#define ARCSAS_MAX_SAS_SCRATCH_COUNT		ARCSAS_MAX_CORE_CCB_COUNT
#define ARCSAS_MAX_SMP_SCRATCH_COUNT		ARCSAS_MAX_CORE_CCB_COUNT
#define ARCSAS_MAX_DEVICE_PER_PM		15	/* for ARC5040 */
#define ARCSAS_MIN_DEVICE_ID			0
#define ARCSAS_MAX_DEVICE_ID			135  /* 0...135 */
#define ARCSAS_MIN_ENCLOSURE_ID			128  /* min enclosure scsi id */
#define ARCSAS_MAX_ENCLOSURE_ID			135  /* max enclosure scsi id */
#define ARCSAS_VIRTUAL_DEVICE_ID		136
#define ARCSAS_MIN_EXPANDER_ID			136  /* ARCSAS_VIRTUAL_DEVICE_ID + 1= 137 */
#define ARCSAS_MAX_EXPANDER_ID			143  /* ARCSAS_MIN_EXPANDER_ID + ARCSAS_MAX_EXPANDER_SUPPORTED - 1= 144 */
#define ARCSAS_MIN_PM_ID			144  /* ARCSAS_MAX_EXPANDER_ID + 1= 145 */
#define ARCSAS_MAX_PM_ID			151  /* ARCSAS_MIN_PM_ID + ARCSAS_MAX_PM_SUPPORTED - 1= 152 */
#define ARCSAS_MAX_DEVICE_INDEX			160
#define ARCSAS_MAX_ROUTE_INDEX			256
#define ARCSAS_MAX_DEVICE_PER_EXPANDER		128
#define ARCSAS_MAX_CONFIG_ROUTES		136
#define ARCSAS_MAX_DISCOVER_REQUESTS		12
#define ARCSAS_MAX_WIDEPORT_PHYS		4
#define ARCSAS_MAX_CORE_NUMBER			2

#define ARCSAS_MAX_START_JOB			256
#define ARCSAS_RELEASE_SIMQ_LEVEL		230

#define ARCSAS_EMPTY_TAG			0xFFF
#define	ARCSAS_EMPTY_DONE			0xfff
#define ARCSAS_ID_NOT_MAPPED			0xFF
#define ARCSAS_MAX_QUEUE_DEPTH			32
#define	ARCSAS_TIMEOUT_WATCH			5
#define	ARCSAS_TIMER_FIRE			30
#define	ARCSAS_TIMER_RESCAN			5
#define	ARCSAS_CLI_WATCH			hz/4
#define	ARCSAS_CLI_TIMEOUT			4*300 /* 300 seconds */
#define ARCSAS_MAX_DEVICE_MODE_SELECT_ERROR_COUNT	0x03
#define ARCSAS_MAX_DEVICE_MEDIUM_ERROR_COUNT		0x03
#define ARCSAS_MAX_DEVICE_RETRY_ERROR_COUNT		0x300
#define ARCSAS_MAX_DEVICE_START_STOP_RETRY_COUNT	0x1000
#define ARCSAS_MAX_DEVICE_RESET_COUNT			0x03
#define ARCSAS_MAX_REGISTER_SET_1300		16
#define ARCSAS_MAX_REGISTER_SET_1320		64
#define ARCSAS_MAX_SMP_RETRY_COUNT		0x03
#define ARCSAS_MAX_NCQ_ERROR_COUNT		3
#define	ARCSAS_SENSE_BUF_SIZE			32

#define	ARCSAS_SAS_A_BASE		0x20000
#define	ARCSAS_SAS_B_BASE		0x24000
/*
**********************************************************************************
**
**********************************************************************************
*/
#define OSS_VIRTUAL_MEMORY_LARGE_PAGES		128L
#define OSS_VIRTUAL_MEMORY_LARGE_PAGE_SIZE	512L
#define OSS_VIRTUAL_MEMORY_POOL_SIZE		(OSS_VIRTUAL_MEMORY_LARGE_PAGE_SIZE * OSS_VIRTUAL_MEMORY_LARGE_PAGES * 6)*ARCSAS_MAX_HOST_ADAPTER_SUPPORTED

#define ARCSAS_CORE_NONE	0
#define ARCSAS_CORE_A		1
#define ARCSAS_CORE_B		2
#define ARCSAS_CORE_AB		3
/*
**********************************************************************************
**
**********************************************************************************
*/
#define PCI_VENDOR_ID_ARECA		0x17D3	/* Vendor ID	*/
#define	PCI_VENDOR_ID_SILICON_IMAGE	0x1095
/*
************************************************
** Product device id
************************************************
*/
#define PCI_DEVICE_ID_ARECA_1300	0x1300	/* Device ID */
#define PCI_DEVICE_ID_ARECA_1320	0x1320	/* Device ID */
#define SUB_DEVICE_ID_1301		0x1301	/* 3G SAS 8 port */
#define SUB_DEVICE_ID_1321		0x1321	/* 6G SAS 8 port */
#define PCIDevVenIDARC1300		0x130017D3 /* Vendor Device ID */
#define PCIDevVenIDARC1320		0x132017D3 /* Vendor Device ID */
/*
**********************************************************************************
*/
typedef  struct	_CCB		CCB,*PCCB;
typedef  struct	_ACB		ACB,*PACB;
typedef  struct	_DPC		DPC,*PDPC;
typedef  struct	_CORE		CORE,*PCORE;
typedef  struct	_OS_CCB		OS_CCB,*POS_CCB;
typedef  struct _EVENT_ELEMENT	EVENT_ELEMENT,*PEVENT_ELEMENT;
typedef  struct	_PCI_DEVICE_ID	PCI_DEVICE_ID,*PPCI_DEVICE_ID;
typedef  struct _BLACK_NAME	BLACK_NAME,*PBLACK_NAME;
typedef  struct	_EVPD_INQUIRYDATA	EVPD_INQUIRYDATA,*PEVPD_INQUIRYDATA;
typedef  struct	_Tag_Stack		Tag_Stack, *PTag_Stack;
typedef  struct	_ARCSAS_SGENTRY		ARCSAS_SGENTRY, *PARCSAS_SGENTRY;
typedef  struct	_Domain_Phy		Domain_Phy, *PDomain_Phy;
typedef  struct	_Domain_Port		Domain_Port, *PDomain_Port;
typedef  struct	_Domain_Device		Domain_Device, *PDomain_Device;
typedef  struct	_Domain_Expander	Domain_Expander, *PDomain_Expander;
typedef  struct	_Domain_PM		Domain_PM, *PDomain_PM;
typedef  struct	_Discovery		Discovery, *PDiscovery;
typedef  struct	_SMPBuffer_Context	SMPBuffer_Context, *PSMPBuffer_Context;
typedef  struct	_ATA_TaskFile		ATA_TaskFile, *PATA_TaskFile;
typedef  struct	_AdapterInfo		AdapterInfo, *PAdapterInfo;
typedef  struct _SMP_ELEMENT		SMP_ELEMENT, *PSMP_ELEMENT;
typedef  struct	_SCSI_PASS_THROUGH_DIRECT	SCSI_PASS_THROUGH_DIRECT, *PSCSI_PASS_THROUGH_DIRECT;
typedef  struct	_SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER	SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER, *PSCSI_PASS_THROUGH_DIRECT_WITH_BUFFER;
typedef  struct	_Assigned_Uncached_Memory	Assigned_Uncached_Memory, *PAssigned_Uncached_Memory;
typedef  struct	_PassThrough_Config	PassThrough_Config, *PPassThorugh_Config;
typedef  struct	_NDI_DEVI_NOTIFY	NDI_DEVI_NOTIFY, *PNDI_DEVI_NOTIFY;
typedef  struct _SD_SmartStatus		SD_SmartStatus, *PSD_SmartStatus;
typedef  struct	_SD_Info		SD_Info, *PSD_Info;
typedef  struct	_SD_Config		SD_Config, *PSD_Config;
typedef  struct	_PM_Info		PM_Info, *PPM_Info;
typedef  struct _Expander_Info		Expander_Info, *PExpander_Info;
typedef  struct	_Adapter_Info		Adapter_Info, *PAdapter_Info;
typedef  struct	_Version_Info		Version_Info, *PVersion_Info;
typedef  struct	_Link_Entity		Link_Entity, *PLink_Entity;
typedef  struct	_Link_Endpoint		Link_Endpoint, *PLink_Endpoint;
typedef  struct	_BIOS_Info_Page		BIOS_Info_Page, *PBIOS_Info_Page;
typedef  struct	_PHY_TUNING		PHY_TUNING, *PPHY_TUNING;
typedef  struct	_ARCSAS_Sense_Data	ARCSAS_Sense_Data, *PARCSAS_Sense_Data;
typedef  struct	_ARCSAS_SG_Table	ARCSAS_SG_Table, *PARCSAS_SG_Table;
typedef  struct _OS_EVENT_ELEMENT	OS_EVENT_ELEMENT, *POS_EVENT_ELEMENT;
typedef  struct	_CSMI_SAS_FIRMWARE_DOWNLOAD	CSMI_SAS_FIRMWARE_DOWNLOAD, *PCSMI_SAS_FIRMWARE_DOWNLOAD;
typedef  struct	_CORE_CONTEXT		CORE_CONTEXT, *PCORE_CONTEXT;
typedef  struct	_DONE_Q_ENTRY		DONE_Q_ENTRY, *PDONE_Q_ENTRY;
typedef  struct	_DELIVERY_Q_ENTRY	DELIVERY_Q_ENTRY, *PDELIVERY_Q_ENTRY;
typedef  struct	_SRB_IOCTL_FIELD	SRB_IOCTL_FIELD, *PSRB_IOCTL_FIELD;
typedef  struct	_ARCSAS_Command_Table	ARCSAS_Command_Table, *PARCSAS_Command_Table;
typedef  struct	_STATUS_BUFFER		STATUS_BUFFER, *PSTATUS_BUFFER;
typedef  struct	_ERR_INFO_RECORD	ERR_INFO_RECORD, *PERR_INFO_RECORD;
typedef  struct	_OPEN_ADDRESS_FRAME	OPEN_ADDRESS_FRAME, *POPEN_ADDRESS_FRAME;
typedef  struct _Unmap_Block_Descriptor	Unmap_Block_Descriptor, *PUnmap_Block_Descriptor;
typedef  struct	_ARCSAS_SATA_STP_Command_Table	ARCSAS_SATA_STP_Command_Table, *PARCSAS_SATA_STP_Command_Table;
typedef  struct	_SMPRequest		ARCSAS_SMP_Command_Table, SMPRequest, *PSMPRequest;
typedef  struct	_SMPResponse		SMPResponse,*PSMPResponse;
typedef  struct	_ARCSAS_SSP_Command_Table	ARCSAS_SSP_Command_Table, *PARCSAS_SSP_Command_Table;
typedef  struct	_PROTECT_INFO_RECORD	PROTECT_INFO_RECORD, *PPROTECT_INFO_RECORD;
typedef  struct	_SSP_RESPONSE_IU	SSP_RESPONSE_IU, *PSSP_RESPONSE_IU;
typedef  struct	_SSP_XFERRDY_IU		SSP_XFERRDY_IU, *PSSP_XFERRDY_IU;
typedef  struct	_SSP_TASK_IU		SSP_TASK_IU, *PSSP_TASK_IU;
typedef  struct	_SSP_COMMAND_IU		SSP_COMMAND_IU, *PSSP_COMMAND_IU;
typedef  struct	_SSP_Frame_Header	SSP_Frame_Header, *PSSP_Frame_Header;
typedef  struct	_ARCSAS_Command_Header	ARCSAS_Command_Header, *PARCSAS_Command_Header;
typedef  struct	_REG_CONFIG_PHY_STATUS	REG_CONFIG_PHY_STATUS, *PREG_CONFIG_PHY_STATUS;
typedef  struct	_ATA_Identify_Data	ATA_Identify_Data, *PATA_Identify_Data;
typedef  struct	_SATA_FIS_REG_H2D	SATA_FIS_REG_H2D, *PSATA_FIS_REG_H2D;
typedef  struct _SATA_FIS_REG_D2H	SATA_FIS_REG_D2H, *PSATA_FIS_REG_D2H;
typedef  struct	_Discover_Target	Discover_Target, *PDiscover_Target;
typedef  struct	_Discover_PortInfo	Discover_PortInfo, *PDiscover_PortInfo;
typedef  struct	_Config_RouteInfo	Config_RouteInfo, *PConfig_RouteInfo;
typedef  struct	_Target_Dev_Map		Target_Dev_Map, *PTarget_Dev_Map;
typedef  struct	_Target_Dev		Target_Dev, *PTarget_Dev;
typedef  struct _Target_Disc_Info	Target_Disc_Info, *PTarget_Disc_Info;
typedef  struct	_SENSE_CODE_SET		SENSE_CODE_SET, *PSENSE_CODE_SET;
typedef  struct	_PRDTableWalkCtx	PRDTableWalkCtx, *PPRDTableWalkCtx;
typedef  struct	_SAS_Scratch_Buffer	SAS_Scratch_Buffer, *PSAS_Scratch_Buffer;
typedef  struct	_SMP_Scratch_Buffer	SMP_Scratch_Buffer, *PSMP_Scratch_Buffer;
typedef  struct	_PRD_Buffer		PRD_Buffer, *PPRD_Buffer;
typedef  struct	_TdList			TdList, *PTdList;
typedef  struct	_Timer_Request		Timer_Request, *PTimer_Request;
typedef  struct	_SCSI_MODE_HEADER_6	SCSI_MODE_HEADER_6,*PSCSI_MODE_HEADER_6;
typedef  struct	_SCSI_MODE_HEADER_10	SCSI_MODE_HEADER_10,*PSCSI_MODE_HEADER_10;
typedef  struct	_SCSI_MODE_BLOCK_DESCRIPTOR		SCSI_MODE_BLOCK_DESCRIPTOR,*PSCSI_MODE_BLOCK_DESCRIPTOR;
typedef  struct	_MODEPAGE00_VENDOR_UNIQUE_PAGE		MODEPAGE00_VENDOR_UNIQUE_PAGE,*PMODEPAGE00_VENDOR_UNIQUE_PAGE;
typedef  struct	_MODEPAGE01_READWRITE_ERROR_RECOVERY_PAGE	MODEPAGE01_READWRITE_ERROR_RECOVERY_PAGE,*PMODEPAGE01_READWRITE_ERROR_RECOVERY_PAGE;
typedef  struct	_MODEPAGE02_DISCONNECT_RECONNECT_PAGE		MODEPAGE02_DISCONNECT_RECONNECT_PAGE,*PMODEPAGE02_DISCONNECT_RECONNECT_PAGE;
typedef  struct	_MODEPAGE03_FORMAT_DEVICE_PAGE			MODEPAGE03_FORMAT_DEVICE_PAGE,*PMODEPAGE03_FORMAT_DEVICE_PAGE;
typedef  struct	_MODEPAGE04_RIGID_DISKDRIVE_GEOMETRY_PAGE	MODEPAGE04_RIGID_DISKDRIVE_GEOMETRY_PAGE,*PMODEPAGE04_RIGID_DISKDRIVE_GEOMETRY_PAGE;
typedef  struct	_MODEPAGE05_FLEXIBLE_DISK_PAGE			MODEPAGE05_FLEXIBLE_DISK_PAGE,*PMODEPAGE05_FLEXIBLE_DISK_PAGE;
typedef  struct	_MODEPAGE07_VERIFY_ERROR_RECOVERY_PAGE		MODEPAGE07_VERIFY_ERROR_RECOVERY_PAGE,*PMODEPAGE07_VERIFY_ERROR_RECOVERY_PAGE;
typedef  struct	_MODEPAGE08_CACHING_PAGE			MODEPAGE08_CACHING_PAGE,*PMODEPAGE08_CACHING_PAGE;
typedef  struct	_MODEPAGE0A_CONTROL_MODE_PAGE		MODEPAGE0A_CONTROL_MODE_PAGE,*PMODEPAGE0A_CONTROL_MODE_PAGE;
typedef  struct	_MODEPAGE0C_NOTCH_PARTITION_PAGE	MODEPAGE0C_NOTCH_PARTITION_PAGE,*PMODEPAGE0C_NOTCH_PARTITION_PAGE;
typedef  struct	_MODEPAGE19_PORT_CONTROL_PAGE		MODEPAGE19_PORT_CONTROL_PAGE,*PMODEPAGE19_PORT_CONTROL_PAGE;
typedef  struct	_MODEPAGE1A_POWER_CONTROL_PAGE		MODEPAGE1A_POWER_CONTROL_PAGE,*PMODEPAGE1A_POWER_CONTROL_PAGE;
typedef  struct	_MODEPAGE1C_INFORMATION_EXCEPTION_CONTROL_PAGE	MODEPAGE1C_INFORMATION_EXCEPTION_CONTROL_PAGE,*PMODEPAGE1C_INFORMATION_EXCEPTION_CONTROL_PAGE;
typedef  struct	scsi_inquiry_data	*PINQUIRY_DATA;
typedef	 union	ccb			*Pccb;
typedef  struct  _ARCSAS_CONTEXT	ARCSAS_CONTEXT, *PARCSAS_CONTEXT;
/*
************************************************************************
**
************************************************************************
*/
typedef  struct	_sgd_3g_prd	sgd_3g_prd, *psgd_3g_prd;
typedef  struct	_sgd_6g_prd	sgd_6g_prd, *psgd_6g_prd;
/*
************************************************************************
**
************************************************************************
*/
typedef	 union	_SAS_ADDR	SAS_ADDR, *PSAS_ADDR;
typedef  union 	_ARCSAS_U64	ARCSAS_U64, *PARCSAS_U64;
/*
************************************************************************
**
************************************************************************
*/
typedef void	*PVOID;
typedef void	(*CCB_CBFunc) (PVOID pCmd_Initiator, PCCB pCCB);
typedef void	(*Timer_CBFunc) (PACB pACB, PVOID timerData);
typedef void	(*SMP_CBFunc) (PDomain_Port pPort, PSMPRequest pSMPReq);
typedef void	(*DISC_CBFunc) (PDiscovery pDiscovery, PDomain_Port pPort);
typedef void	(*DPCFUN) (PACB pACB, PVOID parg);

#define arcsas_CCB_ptr		spriv_ptr0
#define arcsas_ACB_ptr		spriv_ptr1
#define	dma_addr_hi32(addr)	(u_int32_t)((addr>>16)>>16)
#define	dma_addr_lo32(addr)	(u_int32_t)(addr & 0xffffffff)


/*
************************************************************
**
************************************************************
*/
#define ARCSAS_PCI_COMMAND_REG		0x04
/*
************************************************************
**
************************************************************
*/
#define ARCSAS_IOP_ERROR_ILLEGALPCI		0x0001
#define ARCSAS_IOP_ERROR_VENDORID		0x0002
#define ARCSAS_IOP_ERROR_DEVICEID		0x0003
#define ARCSAS_IOP_ERROR_ILLEGALCCB		0x0004
#define ARCSAS_IOP_ERROR_UNKNOW_CDBERR		0x0005
#define ARCSAS_SYS_ERROR_MEMORY_ALLOCATE	0x0006
#define ARCSAS_SYS_ERROR_MEMORY_CROSS4G		0x0007
#define ARCSAS_SYS_ERROR_MEMORY_LACK		0x0008
#define ARCSAS_SYS_ERROR_MEMORY_RANGE		0x0009
#define ARCSAS_SYS_ERROR_DEVICE_BASE		0x000A
#define ARCSAS_SYS_ERROR_PORT_VALIDATE		0x000B
#define ARCSAS_SYS_ERROR_PENDINGCMD_QUEUE	0x000D
#define ARCSAS_SYS_ERROR_SCSI_STATUS		0x000E
#define ARCSAS_IOP_WARN_STB_TIMEOUT		0x000F /* stop adapter rebulid timeout */
#define ARCSAS_IOP_WARN_FAC_TIMEOUT		0x0010 /* flush adapter cache timeout */
#define ARCSAS_IOP_WARN_SAB_TIMEOUT		0x0011 /* start adapter background rebulid timeout */
#define ARCSAS_IOP_WARN_ABC_TIMEOUT		0x0012 /* abort all outstanding command timeout */
#define ARCSAS_IOP_WARN_GFS_TIMEOUT		0x0013 /* get adapter firmware miscellaneous data timeout */
#define ARCSAS_IOP_WARN_HPY_TIMEOUT		0x0014 /* set ccb high part physical address timeout */
#define ARCSAS_IOP_WARN_PQW_TIMEOUT		0x0015 /* set ccb post Q window timeout */
#define ARCSAS_IOP_WARN_SET_DRIVER_MODE_TIMEOUT	0x0016 /* set driver mode timeout */
#define ARCSAS_IOP_WARN_SET_POST_WINDOW_TIMEOUT	0x0017 /* set driver mode timeout */
#define ARCSAS_RAID_VOLUME_KICK_OUT		0x0018 /* */
#define ARCSAS_IOP_ENABLE_EOI_MODE_TIMEOUT	0x0019 /* */

#define ARCSAS_CCB_INSTANCE_POST	0x00
#define ARCSAS_CCB_INSTANCE_DONE	0x01
#define ARCSAS_CCB_INSTANCE_DPC		0x02
/*
************************************************************
**
************************************************************
*/
#define NVRAM_ENTRY_ID			0x5A
#define MAX_BOOTDEVICE_SUPPORTED	8
#define ARCSAS_MAX_EVENT_ELEMENT	128  /* event record */
#define ARCSAS_MAX_OS_EVENT_ELEMENT	16   /* event record */
#define ARCSAS_MAX_SMP_ELEMENT		16
#define ARCSAS_MAX_GENERIC_DPC		(ARCSAS_MAX_EVENT_ELEMENT+ARCSAS_MAX_SMP_ELEMENT)
#define ARCSAS_MAX_MAP_ENTRY		16
#define ARCSAS_MAX_MODE_PAGE_LENGTH	192 /* all pages */
#define ARCSAS_SECTOR_SIZE		512
#define ARCSAS_IOCTL_BUF_LEN		(1024*1024)
#define ARCSAS_HBA_LOG_BUF_SIZE		2048
#define ARCSAS_BIT(x)			(1LL << (x))
#define ARCSAS_HOST_ADAPTER_EVENT	0xFFFF
/*
**********************************************************
** two wire serial interface TWSI EEPROM
** for retriving vendor spectfic PCI conficguration contents
**********************************************************
*/
#define TWSI_READ	ARCSAS_BIT(4)
#define TWSI_WRITE	ARCSAS_BIT(3)

#define IDENTIFY_CMD_PACKET_SET_MASK 0x1f00
#define IDENTIFY_CMD_PACKET_SET_TAPE 0x0100
#define IDENTIFY_GENERAL_CONFIG_ATAPI ARCSAS_BIT(15)

#define ATA_REGISTER_DATA		0x08
#define ATA_REGISTER_ERROR		0x09
#define ATA_REGISTER_FEATURES		0x09
#define ATA_REGISTER_SECTOR_COUNT	0x0A
#define ATA_REGISTER_LBA_LOW		0x0B
#define ATA_REGISTER_LBA_MID		0x0C
#define ATA_REGISTER_LBA_HIGH		0x0D
#define ATA_REGISTER_DEVICE		0x0E
#define ATA_REGISTER_STATUS		0x0F
#define ATA_REGISTER_COMMAND		0x0F

#define ATA_REGISTER_ALT_STATUS		0x16
#define ATA_REGISTER_DEVICE_CONTROL	0x16

#define HD_WRITECACHE_OFF		0
#define HD_WRITECACHE_ON		1

#define PCI_CONFIG_DATA_SIZE		256
#define NUM_PCI_CONFIG_DATA_ELEMENTS	(PCI_CONFIG_DATA_SIZE/sizeof(u_int32_t))

/* RAID controller returned status */
#define ARCSAS_GUI_OK				0x41 /* Operation successed */
#define ARCSAS_GUI_RAIDSET_NOT_NORMAL		0x42
#define ARCSAS_GUI_VOLUMESET_NOT_NORMAL		0x43
#define ARCSAS_GUI_NO_RAIDSET			0x44
#define ARCSAS_GUI_NO_VOLUMESET			0x45
#define ARCSAS_GUI_NO_PHYSICAL_DRIVE		0x46
#define ARCSAS_GUI_PARAMETER_ERROR		0x47
#define ARCSAS_GUI_UNSUPPORTED_COMMAND		0x48
#define ARCSAS_GUI_DISK_CONFIG_CHANGED		0x49
#define ARCSAS_GUI_INVALID_PASSWORD		0x4a
#define ARCSAS_GUI_NO_DISK_SPACE		0x4b
#define ARCSAS_GUI_CHECKSUM_ERROR		0x4c
#define ARCSAS_GUI_PASSWORD_REQUIRED		0x4d
#define ARCSAS_GUI_NO_MORE_DATA			0x4e /* Internal use only */
#define ARCSAS_GUI_INTERNAL_ERROR		0x4f
#define ARCSAS_GUI_FIRMWARE_CRC_ERROR		0x50
#define ARCSAS_GUI_FIRMWARE_INVALID		0x51
#define ARCSAS_GUI_FIRMWARE_UPDATE_FAILED	0x52
#define ARCSAS_GUI_FIRMWARE_NO_HDD		0x53
#define ARCSAS_GUI_END_OF_DATA			0x54

/*
**********************************************************************************
**			API
**		ARCSAS IOCTL control code
**	main commands CDB[0] CDB definitions 
***********************************************************************************
*/
typedef struct _SRB_IO_CONTROL {
	u_int32_t HeaderLength;
	u_int8_t  Signature[8];
	u_int32_t Timeout;
	u_int32_t ControlCode;
	u_int32_t ReturnCode;
	u_int32_t Length;
} SRB_IO_CONTROL, *PSRB_IO_CONTROL;

#define	MSGDATABUFLEN	4096 + 64 - 28
struct _SRB_IOCTL_FIELD {
	SRB_IO_CONTROL	srbioctl;	/* 28 byte ioctl header */
	u_int8_t		ioctldatabuffer[MSGDATABUFLEN];
	/* areca gui program does not accept more than xxxx byte */
};
/*
*******************************************************
**  Areca packet format:
**  --------------------- 
**  Request packet:
**	(HEADER + LENGTH + COMMAND_PACKET + CHECKSUM)
**
**  Reply packet:
**	(HEADER + LENGTH + REPLY_PACKET + CHECKSUM)
**
**  Where:
**  HEADER(3 bytes)= 0x5E 0x01 0x61
**  LENGTH(2 bytes)= little endian, length of command packet or reply packet, not including checksum byte.
**  COMMAND_PACKET or length of REPLY_PACKET(n bytes)
**  CHECKSUM(1 byte) : including length, sum of the bytes value (HEADER, LENGTH, XXXXXXX_PACKET)
**
*******************************************************
*/
typedef struct _RequestHeader
{
	u_int8_t	version;
	u_int8_t	requestType;
	u_int16_t	startingIndexOrId;
	u_int16_t	numRequested;
	u_int16_t	numReturned;
	u_int16_t	nextStartingIndex;
	u_int8_t	reserved1[6];
} RequestHeader, *PRequestHeader;

typedef struct _Info_Request
{
	RequestHeader	header;
	u_int8_t		data[1];
} Info_Request, *PInfo_Request;

#define ARCSAS_IOCTL_REQUEST_BY_RANGE	1
#define ARCSAS_IOCTL_REQUEST_BY_ID	2
#define ARCSAS_IOCTL_NO_MORE_DATA	0xFFFF

/* DeviceType */
#define ARECA_SAS			0x90000000
/* FunctionCode */
#define FUNCTION_SAS			0x0801
#define FUNCTION_SAY_HELLO		0x0802
#define FUNCTION_RETURN_CODE_3F		0x0803

#define	METHOD_BUFFERED			0
#define	FILE_ANY_ACCESS			0

/* ARECA IO CONTROL CODE*/
#define ARCSAS_IOCTL_SAS		_IOWR('F', FUNCTION_SAS, struct _SRB_IOCTL_FIELD)
#define ARCSAS_IOCTL_SAY_HELLO		_IOWR('F', FUNCTION_SAY_HELLO, struct _SRB_IOCTL_FIELD)
#define ARCSAS_IOCTL_RETURN_CODE_3F	_IOWR('F', FUNCTION_RETURN_CODE_3F, struct _SRB_IOCTL_FIELD)
/* ARECA IO CONTROL ReturnCode */
#define ARCSAS_IOCTL_RETURNCODE_OK		0x01
#define ARCSAS_IOCTL_RETURNCODE_ERROR		0x06
#define ARCSAS_IOCTL_RETURNCODE_BUS_HANG_ON	0x88
#define ARCSAS_IOCTL_RETURNCODE_3F		0x3F
/*
********************************************************************
*******************************************************************
*/
/* main commands CDB[0] CDB definitions */
#define API_CDB0_ADAPTER_COMMAND		0xF0
#define API_CDB0_LOGICAL_DISK_COMMAND		0xF1
#define API_CDB0_PHYSICAL_DISK_COMMAND		0xF2
#define API_CDB0_PERIPHERAL_DEVICE_COMMAND	0xF3
#define API_CDB0_EVENT_COMMAND			0xF4
#define API_CDB0_DEBUG_COMMAND			0xF5
#define API_CDB0_FLASH_COMMAND			0xF6
/* for SDI(HP CSMI) */
#define API_CDB0_CSMI_CORE_COMMAND		0xF7
#define API_CDB0_CSMI_RAID_COMMAND		0xF8
#define API_CDB0_PASS_THRU_SCSI_COMMAND		0xFA
#define API_CDB0_PASS_THRU_ATA_COMMAND		0xFB
#define API_CDB0_AES				0xFC

/* sub commands CDB[1] for Adapter */
//*****	API_CDB0_ADAPTER_COMMAND		0xF0
#define API_CDB1_ADAPTER_GETCOUNT		0
#define API_CDB1_ADAPTER_GETINFO		(API_CDB1_ADAPTER_GETCOUNT + 1)
#define API_CDB1_ADAPTER_GETCONFIG		(API_CDB1_ADAPTER_GETCOUNT + 2)
#define API_CDB1_ADAPTER_SETCONFIG		(API_CDB1_ADAPTER_GETCOUNT + 3)
#define API_CDB1_ADAPTER_POWER_STATE_CHANGE	(API_CDB1_ADAPTER_GETCOUNT + 4)
#define API_CDB1_ADAPTER_SET_PASSWORD		(API_CDB1_ADAPTER_GETCOUNT + 5)
#define API_CDB1_ADAPTER_DO_DEVICES_DISCOVER	(API_CDB1_ADAPTER_GETCOUNT + 6)
#define API_CDB1_ADAPTER_MAX			(API_CDB1_ADAPTER_GETCOUNT + 7)

/* for LD */
//*****	API_CDB0_LOGICAL_DISK_COMMAND			0xF1
#define API_CDB1_LOGICAL_DISK_CREATE			0
#define API_CDB1_LOGICAL_DISK_GETMAXSIZE		(API_CDB1_LOGICAL_DISK_CREATE + 1)
#define API_CDB1_LOGICAL_DISK_GETINFO			(API_CDB1_LOGICAL_DISK_CREATE + 2)
#define API_CDB1_LOGICAL_DISK_GETTARGETLDINFO		(API_CDB1_LOGICAL_DISK_CREATE + 3)
#define API_CDB1_LOGICAL_DISK_DELETE			(API_CDB1_LOGICAL_DISK_CREATE + 4)
#define API_CDB1_LOGICAL_DISK_GETSTATUS			(API_CDB1_LOGICAL_DISK_CREATE + 5)
#define API_CDB1_LOGICAL_DISK_GETCONFIG			(API_CDB1_LOGICAL_DISK_CREATE + 6)
#define API_CDB1_LOGICAL_DISK_SETCONFIG			(API_CDB1_LOGICAL_DISK_CREATE + 7)
#define API_CDB1_LOGICAL_DISK_STARTREBUILD		(API_CDB1_LOGICAL_DISK_CREATE + 8)
#define API_CDB1_LOGICAL_DISK_STARTCONSISTENCYCHECK	(API_CDB1_LOGICAL_DISK_CREATE + 9)
#define API_CDB1_LOGICAL_DISK_STARTINIT			(API_CDB1_LOGICAL_DISK_CREATE + 10)
#define API_CDB1_LOGICAL_DISK_STARTMIGRATION		(API_CDB1_LOGICAL_DISK_CREATE + 11)
#define API_CDB1_LOGICAL_DISK_BGACONTROL		(API_CDB1_LOGICAL_DISK_CREATE + 12)
#define API_CDB1_LOGICAL_DISK_WIPEMDD			(API_CDB1_LOGICAL_DISK_CREATE + 13)
#define API_CDB1_LOGICAL_DISK_GETSPARESTATUS		(API_CDB1_LOGICAL_DISK_CREATE + 14)
#define API_CDB1_LOGICAL_DISK_SETGLOBALSPARE		(API_CDB1_LOGICAL_DISK_CREATE + 15)
#define API_CDB1_LOGICAL_DISK_SETLDSPARE		(API_CDB1_LOGICAL_DISK_CREATE + 16)
#define API_CDB1_LOGICAL_DISK_REMOVESPARE		(API_CDB1_LOGICAL_DISK_CREATE + 17)
#define API_CDB1_LOGICAL_DISK_HD_SETSTATUS		(API_CDB1_LOGICAL_DISK_CREATE + 18)
#define API_CDB1_LOGICAL_DISK_SHUTDOWN			(API_CDB1_LOGICAL_DISK_CREATE + 19)
#define API_CDB1_LOGICAL_DISK_HD_FREE_SPACE_INFO	(API_CDB1_LOGICAL_DISK_CREATE + 20)
#define API_CDB1_LOGICAL_DISK_HD_GETMBRINFO		(API_CDB1_LOGICAL_DISK_CREATE + 21)
#define API_CDB1_LOGICAL_DISK_SIZEOF_MIGRATE_TARGET	(API_CDB1_LOGICAL_DISK_CREATE + 22)
#define API_CDB1_LOGICAL_DISK_TARGET_LUN_TYPE		(API_CDB1_LOGICAL_DISK_CREATE + 23)
#define API_CDB1_LOGICAL_DISK_HD_MPCHECK		(API_CDB1_LOGICAL_DISK_CREATE + 24)
#define API_CDB1_LOGICAL_DISK_HD_GETMPSTATUS		(API_CDB1_LOGICAL_DISK_CREATE + 25)
#define API_CDB1_LOGICAL_DISK_HD_GET_RCT_COUNT		(API_CDB1_LOGICAL_DISK_CREATE + 26)
#define API_CDB1_LOGICAL_DISK_HD_RCT_REPORT		(API_CDB1_LOGICAL_DISK_CREATE + 27)
#define API_CDB1_LOGICAL_DISK_HD_START_DATASCRUB	(API_CDB1_LOGICAL_DISK_CREATE + 28)	// temp
#define API_CDB1_LOGICAL_DISK_HD_BGACONTROL		(API_CDB1_LOGICAL_DISK_CREATE + 29)	// temp
#define API_CDB1_LOGICAL_DISK_HD_GETBGASTATUS		(API_CDB1_LOGICAL_DISK_CREATE + 30)	// temp
// Added reserved for future expansion so that MRU/CLI can be backward compatible with drier.
#define API_CDB1_LOGICAL_DISK_RESERVED1			(API_CDB1_LOGICAL_DISK_CREATE + 31)
#define API_CDB1_LOGICAL_DISK_RESERVED2			(API_CDB1_LOGICAL_DISK_CREATE + 32)
#define API_CDB1_LOGICAL_DISK_RESERVED3			(API_CDB1_LOGICAL_DISK_CREATE + 33)
#define API_CDB1_LOGICAL_DISK_RESERVED4			(API_CDB1_LOGICAL_DISK_CREATE + 34)
#define API_CDB1_LOGICAL_DISK_RESERVED5			(API_CDB1_LOGICAL_DISK_CREATE + 35)
#define API_CDB1_LOGICAL_DISK_MAX			(API_CDB1_LOGICAL_DISK_CREATE + 36)

// *****	API_CDB0_PHYSICAL_DISK_COMMAND		0xF2
// **********for Block device CDB[1]***********
#define API_CDB1_PHYSICAL_DISK_GET_INFO		0
#define API_CDB1_PHYSICAL_DISK_BLOCKIDS		1
#define API_CDB1_PHYSICAL_DISK_MAX		2

// ***** API_CDB0_PERIPHERAL_DEVICE_COMMAND	0xF3
/* CDB[1], subcommands for PD and CDB[2], parameter= HD_ID or EXP_ID */
#define API_CDB1_PD_GET_INFO					0
#define API_CDB1_PERIPHERAL_DEVICE_GET_SCSI_DEVICE_INFO		0
#define API_CDB1_PERIPHERAL_DEVICE_GET_EXPANDER_INFO		1
#define API_CDB1_PERIPHERAL_DEVICE_GET_PM_INFO			2	/* CDB[2]:0...7 */
#define API_CDB1_PERIPHERAL_DEVICE_GET_DISK_CONFIG		3
#define API_CDB1_PERIPHERAL_DEVICE_SET_DISK_CONFIG		4
/*
*********Sub command for API_CDB1_PERIPHERAL_DEVICE_SET_DISK_CONFIG 
*/
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_WRITE_CACHE_OFF	0
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_WRITE_CACHE_ON	1
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_SMART_OFF		2
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_SMART_ON		3
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_DATA_PROTECT	4
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_SPEED_1_5G		5
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_SPEED_3G		6
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_SPEED_6G		7
#define API_CDB4_PERIPHERAL_DEVICE_SET_DISK_ID			8	/* new scsi id:CDB[5]=>id, CDB[6]=>lun */

#define API_CDB1_PERIPHERAL_DEVICE_BSL_DUMP			5
#define API_CDB1_PERIPHERAL_DEVICE_GET_LUN_DEVICE_INFO  	6	// not used
#define API_CDB1_PERIPHERAL_DEVICE_RESERVED1			7	// not used
#define API_CDB1_PERIPHERAL_DEVICE_GET_SMART_STATUS		8
/*
*********Sub command for API_CDB1_PERIPHERAL_DEVICE_GET_SMART_STATUS
*/
#define API_CDB4_PERIPHERAL_DEVICE_SMART_RETURN		0

#define API_CDB1_PERIPHERAL_DEVICE_MAX			9

//***** API_CDB0_EVENT_COMMAND		0xF4
/* for event */
#define API_CDB1_EVENT_GET_ALL_EVENT		0
#define API_CDB1_EVENT_GET_CURRENT_EVENT_INDEX	1
#define API_CDB1_EVENT_CLEAR_ALL_EVENT		2

//***** API_CDB0_DEBUG_COMMAND		0xF5
/* for DBG */
#define API_CDB1_DBG_PDWR		0
#define API_CDB1_DBG_MAP		(API_CDB1_DBG_PDWR + 1)
#define API_CDB1_DBG_MAX		(API_CDB1_DBG_PDWR + 2)

//***** API_CDB0_FLASH_COMMAND		0xF6
/* for FLASH */
#define API_CDB1_GET_BIOS_FLASH_SIZE		0
#define API_CDB1_READ_BIOS_FLASH_OFFSET		1
#define API_CDB1_ERASE_BIOS_FLASH		2
#define API_CDB1_WRITE_BIOS_FLASH_OFFSET	3
#define API_CDB1_SYNC_FLASH_DEVICES_MAP_WITH_SLOT_NUM	4
#define API_CDB1_FLASH_MAX				5

/* for SDI(HP CSMI) */
#define API_CDB0_CSMI_CORE_COMMAND	0xF7
	#define API_CDB1_CSMI_SAS_SMP_PASSTHRU	0	/* CDB[2]:Expander id(136...143),CDB[3]:its PHY id */
	/*
	*********Sub command for API_CDB1_PERIPHERAL_DEVICE_SET_DISK_CONFIG
	*/
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_GENERAL				0x00
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_MANUFACTURER_INFORMATION		0x01
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_READ_GPIO_REGISTER			0x02
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_SELF_CONFGRIGRUATION_STATUS	0x03
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_DISCOVER 				0x10
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_PHY_ERROR_LOG 			0x11
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_PHY_SATA 				0x12
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_ROUTE_INFORMATION 		0x13
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_PHY_EVENT_INFORMATION		0x14
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_PHY_BROADCAST_COUNTS		0x15
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_DISCOVER_LIST				0x16
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_REPORT_EXPANDER_ROUTE_TABLE		0x17
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_CONFIGURE_GENERAL			0x80
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_ENABLE_DISABLE_ZONING			0x81
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_WRITE_GPIO_REGISTER 			0x82
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_ZONED_BROADCAST				0x85
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_CONFIGURE_ROUTE_INFORMATION 		0x90
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL 				0x91
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_PHY_NOP				0x00
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_LINK_RESET				0x01
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_HARD_RESET				0x02
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_DISABLE				0x03
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_CLEAR_ERROR_LOG			0x05
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_CLEAR_AFFILIATION			0x06
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_TRANSMIT_SATA_PORT_SELECTION_SIGNAL	0x07
		#define API_CDB5_CSMI_SAS_SMP_PASSTHRU_PHY_CONTROL_CLEAR_STP_NEXUS_LOSS			0x08

	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_PHY_TEST 				0x92
	#define API_CDB4_CSMI_SAS_SMP_PASSTHRU_CONFIGURE_PHY_EVENT_INFORMATION		0x93

#define API_CDB0_CSMI_RAID_COMMAND	0xF8

/*********************************************************************
**	for passthru commands
********************************************************************
	Cdb[0]: API_CDB0_PASS_THRU_SCSI_COMMAND or API_CDB0_PASS_THRU_ATA_COMMAND
	Cdb[1]: API_CDB1 (Data flow)
	Cdb[2]: TargetID MSB
	Cdb[3]: TargetID LSB
	Cdb[4]-Cdb[15]: SCSI/ATA command is embedded here
		SCSI command: SCSI command Cdb bytes is in the same order as the spec
		ATA Command:
			Features= pCCB->Cdb[0];
			Sector_Count= pCCB->Cdb[1];
			LBA_Low= pCCB->Cdb[2];
			LBA_Mid= pCCB->Cdb[3];
			LBA_High= pCCB->Cdb[4];
			Device= pCCB->Cdb[5];
			Command= pCCB->Cdb[6];

			if necessary:
			Feature_Exp= pCCB->Cdb[7];
			Sector_Count_Exp= pCCB->Cdb[8];
			LBA_Low_Exp= pCCB->Cdb[9];
			LBA_Mid_Exp= pCCB->Cdb[10];
			LBA_High_Exp= pCCB->Cdb[11];
********************************************************************
*/
// ***** API_CDB0_PASS_THRU_SCSI_COMMAND	0xFA
#define API_CDB1_SCSI_NON_DATA			0x00
#define API_CDB1_SCSI_DATA_IN			0x01 // goes with Read Long
#define API_CDB1_SCSI_DATA_OUT			0x02 // goes with Write Long

// ***** API_CDB0_PASS_THRU_ATA_COMMAND		0xFB
#define API_CDB1_ATA_NON_DATA			0x00
#define API_CDB1_ATA_DATA_IN			0x01
#define API_CDB1_ATA_DATA_OUT			0x02

//***** API_CDB0_AES				0xFC
	#define API_CDB1_AES_SET_LINK		0x00
	#define API_CDB1_AES_GETCONFIG		0x01
	#define API_CDB1_AES_SETCONFIG		0x02
/*
********************************************************************
**
********************************************************************
*/

#define MAX_SMP_RESP_SIZE			1016
#define MAX_SSP_RESP_SENSE_SIZE			sizeof(ARCSAS_Sense_Data)

#define MAX_HBA_CMD_SG_3G_PRD_BUFFER_SIZE	(sizeof(sgd_3g_prd) * ARCSAS_MAX_OS_SG_ENTRIES)
#define MIN_HBA_CMD_SG_3G_PRD_BUFFER_SIZE	(sizeof(sgd_3g_prd) * ARCSAS_MAX_OS_SG_ENTRIES_NTLDR_DUMP)

#define MAX_HBA_CMD_SG_6G_PRD_BUFFER_SIZE	(sizeof(sgd_6g_prd) * ARCSAS_MAX_OS_SG_ENTRIES)
#define MIN_HBA_CMD_SG_6G_PRD_BUFFER_SIZE	(sizeof(sgd_6g_prd) * ARCSAS_MAX_OS_SG_ENTRIES_NTLDR_DUMP)

//TBD: Checking the following naming
#define MAX_RX_FIS_NUMBER			17
#define RX_FIS_D2H_REG				0x40	/* offset of D2H Register FIS data */
#define FIS_REG_H2D_SIZE_IN_DWORD		5
#define RX_FIS_SIZE				256
#define UNASSOCIATED_FIS_POOL_SIZE_1300		0x400	/* 1300:1024(1k) 1320:2048(2K) */
#define UNASSOCIATED_FIS_POOL_SIZE_1320		0x800	/* 1300:1024(1k) 1320:2048(2K) */
#define MAX_RX_FIS_POOL_SIZE_1300		(RX_FIS_SIZE*MAX_RX_FIS_NUMBER + UNASSOCIATED_FIS_POOL_SIZE_1300)
#define MIN_RX_FIS_POOL_SIZE_1300		(RX_FIS_SIZE*1 + UNASSOCIATED_FIS_POOL_SIZE_1300)
#define MAX_RX_FIS_POOL_SIZE_1320		(RX_FIS_SIZE*MAX_RX_FIS_NUMBER + UNASSOCIATED_FIS_POOL_SIZE_1320)
#define MIN_RX_FIS_POOL_SIZE_1320		(RX_FIS_SIZE*1 + UNASSOCIATED_FIS_POOL_SIZE_1320)

#define SAS_SCRATCH_BUFFER_SIZE			(sizeof(struct _ATA_Identify_Data)+256)
#define SMP_SCRATCH_BUFFER_SIZE			(sizeof(struct _SMPRequest))
#define SES_STATUS_CONTROL_BUFFER_SIZE		SAS_SCRATCH_BUFFER_SIZE

#define SMART_POLLING_REQUEST_CYCLE		360	/* in sec */
#define REQUEST_TIME_OUT			90	/* in sec */
#define	ARCSAS_TIMEOUT_DELAY			5	/* in sec */
#define MAX_TIME_OUT_COUNT			3
#define NO_CURRENT_TIMER			0xFF
/*
**********************************
**  Peripheral Device Type definitions
**********************************
*/
#define SCSI_DASD		0x00	/* Direct-access Device		*/
#define SCSI_SEQACESS		0x01	/* Sequential-access device	*/
#define SCSI_PRINTER		0x02	/* Printer device		*/
#define SCSI_PROCESSOR		0x03	/* Processor device		*/
#define SCSI_WRITEONCE		0x04	/* Write-once device 		*/
#define SCSI_CDROM		0x05	/* CD-ROM device		*/
#define SCSI_SCANNER		0x06	/* Scanner device		*/
#define SCSI_OPTICAL		0x07	/* Optical memory device	*/
#define SCSI_MEDCHGR		0x08	/* Medium changer device	*/
#define SCSI_COMM		0x09	/* Communications device	*/
#define SCSI_NODEV		0x1F	/* Unknown or no device type	*/
/*
**************************************************************************
** Log Sense Scsi command translation
**************************************************************************
*/
#define SUPPORTED_LOG_PAGES_LOG_PAGE		0x00
#define SELF_TEST_RESULTS_LOG_PAGE		0x10
#define INFORMATIONAL_EXCEPTIONS_LOG_PAGE	0x2F
/*
* Format Unit Scsi command translation
*/
#define LBA_BLOCK_COUNT				256
/**
* Self-Test Code translation for Send Diagnostic Command
**/
#define DEFAULT_SELF_TEST			0X0
#define BACKGROUND_SHORT_SELF_TEST		0x1
#define BACKGROUND_EXTENDED_SELF_TEST		0x2
#define ABORT_BACKGROUND_SELF_TEST		0x4
#define FOREGROUND_SHORT_SELF_TEST		0x5
#define FOREGROUND_EXTENDED_SELF_TEST		0x6
/* assume the maximum number of phys in an expander device is 128 */
#define MAXIMUM_EXPANDER_PHYS 			128
/* assume the maximum number of indexes per phy is 128 */
#define MAXIMUM_EXPANDER_INDEXES 		128
/* limit to 8 initiators for this example */
#define MAXIMUM_INITIATORS 			8
/* defines for SMP frame types */
#define SMP_REQUEST_FRAME 			0x40
#define SMP_RESPONSE_FRAME 			0x41
/* defines for SMP request functions */
#define REPORT_GENERAL 				0x00
#define REPORT_MANUFACTURER_INFORMATION 	0x01
#define READ_GPIO_REGISTER			0x02
#define REPORT_SELF_CONFGRIGRUATION_STATUS	0x03
#define DISCOVER 				0x10
#define REPORT_PHY_ERROR_LOG 			0x11
#define REPORT_PHY_SATA 			0x12
#define REPORT_ROUTE_INFORMATION 		0x13
#define REPORT_PHY_EVENT_INFORMATION		0x14
#define REPORT_PHY_BROADCAST_COUNTS		0x15
#define DISCOVER_LIST				0x16
#define REPORT_EXPANDER_ROUTE_TABLE		0x17
#define CONFIGURE_GENERAL			0x80
#define ENABLE_DISABLE_ZONING			0x81
#define WRITE_GPIO_REGISTER 			0x82
#define ZONED_BROADCAST				0x85
#define CONFIGURE_ROUTE_INFORMATION 		0x90
#define PHY_CONTROL 				0x91
#define PHY_TEST 				0x92
#define CONFIGURE_PHY_EVENT_INFORMATION		0x93
/* defines for open responses, arbitrary values, not defined in the spec */
#define OPEN_ACCEPT				0
#define OPEN_REJECT_BAD_DESTINATION		1
#define OPEN_REJECT_RATE_NOT_SUPPORTED		2
#define OPEN_REJECT_NO_DESTINATION		3
#define OPEN_REJECT_PATHWAY_BLOCKED		4
#define OPEN_REJECT_PROTOCOL_NOT_SUPPORTED	5
#define OPEN_REJECT_RESERVE_ABANDON		6
#define OPEN_REJECT_RESERVE_CONTINUE		7
#define OPEN_REJECT_RESERVE_INITIALIZE		8
#define OPEN_REJECT_RESERVE_STOP		9
#define OPEN_REJECT_RETRY			10
#define OPEN_REJECT_STP_RESOURCES_BUSY		11
#define OPEN_REJECT_WRONG_DESTINATION		12
#define OPEN_REJECT_WAITING_ON_BREAK		13

/* Request Structure. */
#define SENSE_INFO_BUFFER_SIZE			32

#define CC_CSMI_SAS_GET_DRIVER_INFO		1
#define CC_CSMI_SAS_GET_CNTLR_CONFIG		2
#define CC_CSMI_SAS_GET_CNTLR_STATUS		3
#define CC_CSMI_SAS_FIRMWARE_DOWNLOAD		4

// Control Codes requiring CSMI_RAID_SIGNATURE

#define CC_CSMI_SAS_GET_RAID_INFO		10
#define CC_CSMI_SAS_GET_RAID_CONFIG		11

// Control Codes requiring CSMI_SAS_SIGNATURE

#define CC_CSMI_SAS_GET_PHY_INFO		20
#define CC_CSMI_SAS_SET_PHY_INFO		21
#define CC_CSMI_SAS_GET_LINK_ERRORS		22
#define CC_CSMI_SAS_SMP_PASSTHRU		23
#define CC_CSMI_SAS_SSP_PASSTHRU		24
#define CC_CSMI_SAS_STP_PASSTHRU		25
#define CC_CSMI_SAS_GET_SATA_SIGNATURE		26
#define CC_CSMI_SAS_GET_SCSI_ADDRESS		27
#define CC_CSMI_SAS_GET_DEVICE_ADDRESS		28
#define CC_CSMI_SAS_TASK_MANAGEMENT		29
#define CC_CSMI_SAS_GET_CONNECTOR_INFO		30
#define CC_CSMI_SAS_GET_LOCATION		31

// Control Codes requiring CSMI_PHY_SIGNATURE

#define CC_CSMI_SAS_PHY_CONTROL		60

#define IOCTL_HEADER SRB_IO_CONTROL
#define PIOCTL_HEADER PSRB_IO_CONTROL

/*************************************************************************/
/* OS INDEPENDENT CODE							*/
/*************************************************************************/
#define	OS_SENSE_DATA_DESCR_LEN		(sizeof (struct scsi_descr_sense_hdr) + sizeof (struct scsi_information_sense_descr))  /* (8 + 12)bytes */
/* * * * * * * * * * Class Independent IOCTL Constants * * * * * * * * * */

// Return codes for all IOCTL's regardless of class
// (IoctlHeader.ReturnCode)

#define CSMI_SAS_STATUS_SUCCESS			0
#define CSMI_SAS_STATUS_FAILED			1
#define CSMI_SAS_STATUS_BAD_CNTL_CODE		2
#define CSMI_SAS_STATUS_INVALID_PARAMETER	3
#define CSMI_SAS_STATUS_WRITE_ATTEMPTED		4

// Signature value
// (IoctlHeader.Signature)

#define CSMI_ALL_SIGNATURE	"CSMIALL"

// Timeout value default of 60 seconds
// (IoctlHeader.Timeout)

#define CSMI_ALL_TIMEOUT		60

//  Direction values for data flow on this IOCTL
// (IoctlHeader.Direction, Linux only)
#define CSMI_SAS_DATA_READ		0
#define CSMI_SAS_DATA_WRITE		1

// I/O Bus Types
// ISA and EISA bus types are not supported
// (bIoBusType)

#define CSMI_SAS_BUS_TYPE_PCI		3
#define CSMI_SAS_BUS_TYPE_PCMCIA	4

// Offline Status Reason
// (uOfflineReason)

#define CSMI_SAS_OFFLINE_REASON_NO_REASON		0
#define CSMI_SAS_OFFLINE_REASON_INITIALIZING		1
#define CSMI_SAS_OFFLINE_REASON_BACKSIDE_BUS_DEGRADED	2
#define CSMI_SAS_OFFLINE_REASON_BACKSIDE_BUS_FAILURE	3

// Controller Class
// (bControllerClass)

#define CSMI_SAS_CNTLR_CLASS_HBA	5

// Controller Flag bits
// (uControllerFlags)

#define CSMI_SAS_CNTLR_SAS_HBA		0x00000001
#define CSMI_SAS_CNTLR_SAS_RAID		0x00000002
#define CSMI_SAS_CNTLR_SATA_HBA		0x00000004
#define CSMI_SAS_CNTLR_SATA_RAID	0x00000008

// for firmware download
#define CSMI_SAS_CNTLR_FWD_SUPPORT	0x00010000
#define CSMI_SAS_CNTLR_FWD_ONLINE	0x00020000
#define CSMI_SAS_CNTLR_FWD_SRESET	0x00040000
#define CSMI_SAS_CNTLR_FWD_HRESET	0x00080000
#define CSMI_SAS_CNTLR_FWD_RROM		0x00100000

// Download Flag bits
// (uDownloadFlags)
#define CSMI_SAS_FWD_VALIDATE		0x00000001
#define CSMI_SAS_FWD_SOFT_RESET		0x00000002
#define CSMI_SAS_FWD_HARD_RESET		0x00000004

// Firmware Download Status
// (usStatus)
#define CSMI_SAS_FWD_SUCCESS		0
#define CSMI_SAS_FWD_FAILED		1
#define CSMI_SAS_FWD_USING_RROM		2
#define CSMI_SAS_FWD_REJECT		3
#define CSMI_SAS_FWD_DOWNREV		4

// Firmware Download Severity
// (usSeverity>
#define CSMI_SAS_FWD_INFORMATION	0
#define CSMI_SAS_FWD_WARNING		1
#define CSMI_SAS_FWD_ERROR		2
#define CSMI_SAS_FWD_FATAL		3

/* * * * * * * * * * SAS RAID Class IOCTL Constants  * * * * * * * * */

// Return codes for the RAID IOCTL's regardless of class
// (IoctlHeader.ControlCode)

#define CSMI_SAS_RAID_SET_OUT_OF_RANGE	1000

// Signature value
// (IoctlHeader.Signature)

#define CSMI_RAID_SIGNATURE	"CSMIARY"

// Timeout value default of 60 seconds
// (IoctlHeader.Timeout)

#define CSMI_RAID_TIMEOUT	60

// RAID Types
// (bRaidType)
#define CSMI_SAS_RAID_TYPE_NONE		0
#define CSMI_SAS_RAID_TYPE_0		1
#define CSMI_SAS_RAID_TYPE_1		2
#define CSMI_SAS_RAID_TYPE_10		3
#define CSMI_SAS_RAID_TYPE_5		4
#define CSMI_SAS_RAID_TYPE_15		5
#define CSMI_SAS_RAID_TYPE_OTHER	255

// RAID Status
// (bStatus)
#define CSMI_SAS_RAID_SET_STATUS_OK		0
#define CSMI_SAS_RAID_SET_STATUS_DEGRADED	1
#define CSMI_SAS_RAID_SET_STATUS_REBUILDING	2
#define CSMI_SAS_RAID_SET_STATUS_FAILED		3

// RAID Drive Status
// (bDriveStatus)
#define CSMI_SAS_DRIVE_STATUS_OK		0
#define CSMI_SAS_DRIVE_STATUS_REBUILDING	1
#define CSMI_SAS_DRIVE_STATUS_FAILED		2
#define CSMI_SAS_DRIVE_STATUS_DEGRADED		3

// RAID Drive Usage
// (bDriveUsage)
#define CSMI_SAS_DRIVE_CONFIG_NOT_USED		0
#define CSMI_SAS_DRIVE_CONFIG_MEMBER		1
#define CSMI_SAS_DRIVE_CONFIG_SPARE		2

/* * * * * * * * * * SAS HBA Class IOCTL Constants * * * * * * * * * */

// Return codes for SAS IOCTL's
// (IoctlHeader.ReturnCode)

#define CSMI_SAS_PHY_INFO_CHANGED		CSMI_SAS_STATUS_SUCCESS
#define CSMI_SAS_PHY_INFO_NOT_CHANGEABLE	2000
#define CSMI_SAS_LINK_RATE_OUT_OF_RANGE		2001

#define CSMI_SAS_PHY_DOES_NOT_EXIST		2002
#define CSMI_SAS_PHY_DOES_NOT_MATCH_PORT	2003
#define CSMI_SAS_PHY_CANNOT_BE_SELECTED		2004
#define CSMI_SAS_SELECT_PHY_OR_PORT		2005
#define CSMI_SAS_PORT_DOES_NOT_EXIST		2006
#define CSMI_SAS_PORT_CANNOT_BE_SELECTED	2007
#define CSMI_SAS_CONNECTION_FAILED		2008

#define CSMI_SAS_NO_SATA_DEVICE		2009
#define CSMI_SAS_NO_SATA_SIGNATURE	2010
#define CSMI_SAS_SCSI_EMULATION		2011
#define CSMI_SAS_NOT_AN_END_DEVICE	2012
#define CSMI_SAS_NO_SCSI_ADDRESS	2013
#define CSMI_SAS_NO_DEVICE_ADDRESS	2014

// Signature value
// (IoctlHeader.Signature)

#define CSMI_SAS_SIGNATURE	"CSMISAS"

// Timeout value default of 60 seconds
// (IoctlHeader.Timeout)

#define CSMI_SAS_TIMEOUT	60

// Device types
// (bDeviceType)

#define CSMI_SAS_PHY_UNUSED			0x00
#define CSMI_SAS_NO_DEVICE_ATTACHED		0x00
#define CSMI_SAS_END_DEVICE			0x10
#define CSMI_SAS_EDGE_EXPANDER_DEVICE		0x20
#define CSMI_SAS_FANOUT_EXPANDER_DEVICE		0x30

// Protocol options
// (bInitiatorPortProtocol, bTargetPortProtocol)

#define CSMI_SAS_PROTOCOL_SATA		0x01
#define CSMI_SAS_PROTOCOL_SMP		0x02
#define CSMI_SAS_PROTOCOL_STP		0x04
#define CSMI_SAS_PROTOCOL_SSP		0x08

// Negotiated and hardware link rates
// (bNegotiatedLinkRate, bMinimumLinkRate, bMaximumLinkRate)

#define CSMI_SAS_LINK_RATE_UNKNOWN	0x00
#define CSMI_SAS_PHY_DISABLED		0x01
#define CSMI_SAS_LINK_RATE_FAILED	0x02
#define CSMI_SAS_SATA_SPINUP_HOLD	0x03
#define CSMI_SAS_SATA_PORT_SELECTOR	0x04
#define CSMI_SAS_LINK_RATE_1_5_GBPS	0x08
#define CSMI_SAS_LINK_RATE_3_0_GBPS	0x09
#define CSMI_SAS_LINK_RATE_6_0_GBPS	0x10
#define CSMI_SAS_LINK_VIRTUAL		0x11

// Discover state
// (bAutoDiscover)

#define CSMI_SAS_DISCOVER_NOT_SUPPORTED		0x00
#define CSMI_SAS_DISCOVER_NOT_STARTED		0x01
#define CSMI_SAS_DISCOVER_IN_PROGRESS		0x02
#define CSMI_SAS_DISCOVER_COMPLETE		0x03
#define CSMI_SAS_DISCOVER_ERROR			0x04

// Programmed link rates
// (bMinimumLinkRate, bMaximumLinkRate)
// (bProgrammedMinimumLinkRate, bProgrammedMaximumLinkRate)

#define CSMI_SAS_PROGRAMMED_LINK_RATE_UNCHANGED		0x00
#define CSMI_SAS_PROGRAMMED_LINK_RATE_1_5_GBPS		0x08
#define CSMI_SAS_PROGRAMMED_LINK_RATE_3_0_GBPS		0x09
#define CSMI_SAS_PROGRAMMED_LINK_RATE_6_0_GBPS		0x10
// Link rate
// (bNegotiatedLinkRate in CSMI_SAS_SET_PHY_INFO)

#define CSMI_SAS_LINK_RATE_NEGOTIATE		0x00
#define CSMI_SAS_LINK_RATE_PHY_DISABLED		0x01

// Signal class
// (bSignalClass in CSMI_SAS_SET_PHY_INFO)

#define CSMI_SAS_SIGNAL_CLASS_UNKNOWN		0x00
#define CSMI_SAS_SIGNAL_CLASS_DIRECT		0x01
#define CSMI_SAS_SIGNAL_CLASS_SERVER		0x02
#define CSMI_SAS_SIGNAL_CLASS_ENCLOSURE		0x03

// Link error reset
// (bResetCounts)

#define CSMI_SAS_LINK_ERROR_DONT_RESET_COUNTS	0x00
#define CSMI_SAS_LINK_ERROR_RESET_COUNTS	0x01

// Phy identifier
// (bPhyIdentifier)

#define CSMI_SAS_USE_PORT_IDENTIFIER	0xFF

// Port identifier
// (bPortIdentifier)

#define CSMI_SAS_IGNORE_PORT		0xFF

// Connection status
// (bConnectionStatus)

#define CSMI_SAS_OPEN_ACCEPT				0
#define CSMI_SAS_OPEN_REJECT_BAD_DESTINATION		1
#define CSMI_SAS_OPEN_REJECT_RATE_NOT_SUPPORTED		2
#define CSMI_SAS_OPEN_REJECT_NO_DESTINATION		3
#define CSMI_SAS_OPEN_REJECT_PATHWAY_BLOCKED		4
#define CSMI_SAS_OPEN_REJECT_PROTOCOL_NOT_SUPPORTED	5
#define CSMI_SAS_OPEN_REJECT_RESERVE_ABANDON		6
#define CSMI_SAS_OPEN_REJECT_RESERVE_CONTINUE		7
#define CSMI_SAS_OPEN_REJECT_RESERVE_INITIALIZE		8
#define CSMI_SAS_OPEN_REJECT_RESERVE_STOP		9
#define CSMI_SAS_OPEN_REJECT_RETRY			10
#define CSMI_SAS_OPEN_REJECT_STP_RESOURCES_BUSY		11
#define CSMI_SAS_OPEN_REJECT_WRONG_DESTINATION		12

// SSP Status
// (bSSPStatus)

#define CSMI_SAS_SSP_STATUS_UNKNOWN	0x00
#define CSMI_SAS_SSP_STATUS_WAITING	0x01
#define CSMI_SAS_SSP_STATUS_COMPLETED	0x02
#define CSMI_SAS_SSP_STATUS_FATAL_ERROR	0x03
#define CSMI_SAS_SSP_STATUS_RETRY	0x04
#define CSMI_SAS_SSP_STATUS_NO_TAG	0x05

// SSP Flags
// (uFlags)

#define CSMI_SAS_SSP_READ		0x00000001
#define CSMI_SAS_SSP_WRITE		0x00000002
#define CSMI_SAS_SSP_UNSPECIFIED	0x00000004

#define CSMI_SAS_SSP_TASK_ATTRIBUTE_SIMPLE		0x00000000
#define CSMI_SAS_SSP_TASK_ATTRIBUTE_HEAD_OF_QUEUE	0x00000010
#define CSMI_SAS_SSP_TASK_ATTRIBUTE_ORDERED		0x00000020
#define CSMI_SAS_SSP_TASK_ATTRIBUTE_ACA			0x00000040

// SSP Data present
// (bDataPresent)

#define CSMI_SAS_SSP_NO_DATA_PRESENT		0x00
#define CSMI_SAS_SSP_RESPONSE_DATA_PRESENT	0x01
#define CSMI_SAS_SSP_SENSE_DATA_PRESENT		0x02

// STP Flags
// (uFlags)

#define CSMI_SAS_STP_READ		0x00000001
#define CSMI_SAS_STP_WRITE		0x00000002
#define CSMI_SAS_STP_UNSPECIFIED	0x00000004
#define CSMI_SAS_STP_PIO		0x00000010
#define CSMI_SAS_STP_DMA		0x00000020
#define CSMI_SAS_STP_PACKET		0x00000040
#define CSMI_SAS_STP_DMA_QUEUED		0x00000080
#define CSMI_SAS_STP_EXECUTE_DIAG	0x00000100
#define CSMI_SAS_STP_RESET_DEVICE	0x00000200

// Task Management Flags
// (uFlags)

#define CSMI_SAS_TASK_IU		0x00000001
#define CSMI_SAS_HARD_RESET_SEQUENCE	0x00000002
#define CSMI_SAS_SUPPRESS_RESULT	0x00000004

// Task Management Functions
// (bTaskManagement)

#define CSMI_SAS_SSP_ABORT_TASK			0x01
#define CSMI_SAS_SSP_ABORT_TASK_SET		0x02
#define CSMI_SAS_SSP_CLEAR_TASK_SET		0x04
#define CSMI_SAS_SSP_LOGICAL_UNIT_RESET		0x08
#define CSMI_SAS_SSP_CLEAR_ACA			0x40
#define CSMI_SAS_SSP_QUERY_TASK			0x80

// Task Management Information
// (uInformation)

#define CSMI_SAS_SSP_TEST		1
#define CSMI_SAS_SSP_EXCEEDED		2
#define CSMI_SAS_SSP_DEMAND		3
#define CSMI_SAS_SSP_TRIGGER		4

// Connector Pinout Information
// (uPinout)

#define CSMI_SAS_CON_UNKNOWN		0x00000001
#define CSMI_SAS_CON_SFF_8482		0x00000002
#define CSMI_SAS_CON_SFF_8470_LANE_1	0x00000100
#define CSMI_SAS_CON_SFF_8470_LANE_2	0x00000200
#define CSMI_SAS_CON_SFF_8470_LANE_3	0x00000400
#define CSMI_SAS_CON_SFF_8470_LANE_4	0x00000800
#define CSMI_SAS_CON_SFF_8484_LANE_1	0x00010000
#define CSMI_SAS_CON_SFF_8484_LANE_2	0x00020000
#define CSMI_SAS_CON_SFF_8484_LANE_3	0x00040000
#define CSMI_SAS_CON_SFF_8484_LANE_4	0x00080000

// Connector Location Information
// (bLocation)

// same as uPinout above...
// #define CSMI_SAS_CON_UNKNOWN		0x01
#define CSMI_SAS_CON_INTERNAL		0x02
#define CSMI_SAS_CON_EXTERNAL		0x04
#define CSMI_SAS_CON_SWITCHABLE		0x08
#define CSMI_SAS_CON_AUTO		0x10
#define CSMI_SAS_CON_NOT_PRESENT	0x20
#define CSMI_SAS_CON_NOT_CONNECTED	0x80

// Device location identification
// (bIdentify)

#define CSMI_SAS_LOCATE_UNKNOWN		0x00
#define CSMI_SAS_LOCATE_FORCE_OFF	0x01
#define CSMI_SAS_LOCATE_FORCE_ON	0x02

// Location Valid flags
// (uLocationFlags)

#define CSMI_SAS_LOCATE_SAS_ADDRESS_VALID		0x00000001
#define CSMI_SAS_LOCATE_SAS_LUN_VALID			0x00000002
#define CSMI_SAS_LOCATE_ENCLOSURE_IDENTIFIER_VALID	0x00000004
#define CSMI_SAS_LOCATE_ENCLOSURE_NAME_VALID		0x00000008
#define CSMI_SAS_LOCATE_BAY_PREFIX_VALID		0x00000010
#define CSMI_SAS_LOCATE_BAY_IDENTIFIER_VALID		0x00000020
#define CSMI_SAS_LOCATE_LOCATION_STATE_VALID		0x00000040

/* * * * * * * * SAS Phy Control Class IOCTL Constants * * * * * * * * */

// Return codes for SAS Phy Control IOCTL's
// (IoctlHeader.ReturnCode)

// Signature value
// (IoctlHeader.Signature)

#define CSMI_PHY_SIGNATURE	"CSMIPHY"

// Phy Control Functions
// (bFunction)

// values 0x00 to 0xFF are consistent in definition with the SMP PHY CONTROL 
// function defined in the SAS spec
#define CSMI_SAS_PC_NOP			0x00000000
#define CSMI_SAS_PC_LINK_RESET		0x00000001
#define CSMI_SAS_PC_HARD_RESET		0x00000002
#define CSMI_SAS_PC_PHY_DISABLE		0x00000003
// 0x04 to 0xFF reserved...
#define CSMI_SAS_PC_GET_PHY_SETTINGS	0x00000100

// Link Flags
#define CSMI_SAS_PHY_ACTIVATE_CONTROL		0x00000001
#define CSMI_SAS_PHY_UPDATE_SPINUP_RATE		0x00000002
#define CSMI_SAS_PHY_AUTO_COMWAKE		0x00000004

// Device Types for Phy Settings
// (bType)
#define CSMI_SAS_UNDEFINED	0x00
#define CSMI_SAS_SATA		0x01
#define CSMI_SAS_SAS		0x02

// Transmitter Flags
// (uTransmitterFlags)
#define CSMI_SAS_PHY_PREEMPHASIS_DISABLED	0x00000001

// Receiver Flags
// (uReceiverFlags)
#define CSMI_SAS_PHY_EQUALIZATION_DISABLED	0x00000001

// Pattern Flags
// (uPatternFlags)
// #define CSMI_SAS_PHY_ACTIVATE_CONTROL	0x00000001
#define CSMI_SAS_PHY_DISABLE_SCRAMBLING		0x00000002
#define CSMI_SAS_PHY_DISABLE_ALIGN		0x00000004
#define CSMI_SAS_PHY_DISABLE_SSC		0x00000008

#define CSMI_SAS_PHY_FIXED_PATTERN		0x00000010
#define CSMI_SAS_PHY_USER_PATTERN		0x00000020

// Fixed Patterns
// (bFixedPattern)
#define CSMI_SAS_PHY_CJPAT	0x00000001
#define CSMI_SAS_PHY_ALIGN	0x00000002

// Type Flags
// (bTypeFlags)
#define CSMI_SAS_PHY_POSITIVE_DISPARITY		0x01
#define CSMI_SAS_PHY_NEGATIVE_DISPARITY		0x02
#define CSMI_SAS_PHY_CONTROL_CHARACTER		0x04

/* ATMEL */
#define AT25F2048	0x0101
#define AT25DF041A	0x0102
#define AT25DF021	0x0103
/* MXIC */
#define MX25L2005	0x0201
#define MX25L4005	0x0202
#define MX25L8005	0x0203
/* WINBOND */
#define WINBOND		0x0301
/* SST */
#define SST25VF040B	0x0501
/* CHINGIS */
#define PM25LV010A	0x0601 /* 128K*/
#define PM25LV020	0x0602 /* 256K*/
#define PM25LV040	0x0603 /* 512K*/
#define PM25LD010C	0x0604 /* 128K*/
#define PM25LD020C	0x0605 /* 256K*/

/*
**************************************************************
**	Configuration Registers
**	ARC1320 RESET REQUEST
**************************************************************
*/
#define CLEAR_RESET_REQUEST_ARC1320		0x07
#define RESET_REQUEST_ARC1320			0x10108
	#define POWER_ON_RESET			ARCSAS_BIT(0) /* active 1 clear 0 */
	#define WATCHDOG_TIMER_RESET		ARCSAS_BIT(1) /* active 1 clear 0 */
	#define PCI_LINK_DOWN_RESET		ARCSAS_BIT(2) /* active 1 clear 0 */
	#define PCIE_RESET			ARCSAS_BIT(3) /* active 1 clear 0 */
	#define SOFTWARE_RESET_0		ARCSAS_BIT(4) /* active 1 clear 0 */
	#define SOFTWARE_RESET_1		ARCSAS_BIT(5) /* active 1 clear 0 */

#define CLEAR_RESET_ENABLE_ARC1320		0x0
#define RESET_ENABLE_ARC1320			0x1010C
	#define CHIP_RST_EN_POWER_ON_RESET		ARCSAS_BIT(0) /* bit0 : rising edge asserted 3 ns */
	#define CHIP_RST_EN_WATCHDOG_TIMER_RESET	ARCSAS_BIT(1) /* bit1 : rising edge asserted 3 ns */
	#define CHIP_RST_EN_PCI_LINK_DOWN_RESET		ARCSAS_BIT(2) /* bit2 : rising edge asserted 3 ns */
	#define CHIP_RST_EN_PCIE_RESET			ARCSAS_BIT(3) /* bit3 : rising edge asserted 3 ns */
	#define CHIP_RST_EN_SOFTWARE_RESET_0		ARCSAS_BIT(4) /* bit4 : rising edge asserted 3 ns */
	#define CHIP_RST_EN_SOFTWARE_RESET_1		ARCSAS_BIT(5) /* bit5 : rising edge asserted 3 ns */

	//#define SW_RST_EN_POWER_ON_RESET		ARCSAS_BIT(8) /* bit8 : rising edge asserted 3 ns */
	//#define SW_RST_EN_WATCHDOG_TIMER_RESET	ARCSAS_BIT(9) /* bit9 : rising edge asserted 3 ns */
	//#define SW_RST_EN_PCI_LINK_DOWN_RESET		ARCSAS_BIT(10) /* bit10: rising edge asserted 3 ns */
	//#define SW_RST_EN_PCIE_RESET			ARCSAS_BIT(11) /* bit11: rising edge asserted 3 ns */
	//#define SW_RST_EN_SOFTWARE_RESET_0		ARCSAS_BIT(12) /* bit12: rising edge asserted 3 ns */
	//#define SW_RST_EN_SOFTWARE_RESET_1		ARCSAS_BIT(13) /* bit13: rising edge asserted 3 ns */

	#define PCIE_RST_EN_POWER_ON_REST		ARCSAS_BIT(16) /* bit16: rising edge asserted 3 ns */
	#define PCIE_RST_EN_WATCHDOG_TIMER_RESET	ARCSAS_BIT(17) /* bit17: rising edge asserted 3 ns */
	#define PCIE_RST_EN_PCI_LINK_DOWN_RESET		ARCSAS_BIT(18) /* bit18: rising edge asserted 3 ns */
	#define PCIE_RST_EN_PCIE_RESET			ARCSAS_BIT(19) /* bit19: rising edge asserted 3 ns */
	#define PCIE_RST_EN_SOFTWARE_RESET_0		ARCSAS_BIT(20) /* bit20: rising edge asserted 3 ns */
	#define PCIE_RST_EN_SOFTWARE_RESET_1		ARCSAS_BIT(21) /* bit21: rising edge asserted 3 ns */

	#define RST_OUT_EN_POWER_ON_RESET		ARCSAS_BIT(24) /* bit24: rising edge asserted 3 ns */
	#define RST_OUT_EN_WATCHDOG_TIMER_RESET		ARCSAS_BIT(25) /* bit25: rising edge asserted 3 ns */
	#define RST_OUT_EN_PCI_LINK_DOWN_RESET		ARCSAS_BIT(26) /* bit26: rising edge asserted 3 ns */
	#define RST_OUT_EN_PCIE_RESET			ARCSAS_BIT(27) /* bit27: rising edge asserted 3 ns */
	#define RST_OUT_EN_SOFTWARE_RESET_0		ARCSAS_BIT(28) /* bit28: rising edge asserted 3 ns */
	#define RST_OUT_EN_SOFTWARE_RESET_1		ARCSAS_BIT(29) /* bit29: rising edge asserted 3 ns */

#define CLEAR_RESET_OCCURRED_ARC1320	0x0F
#define RESET_OCCURRED_ARC1320		0x10114
	#define CHIP_RST_OCCURRED	ARCSAS_BIT(0) /* active 1 clear 0 */
	//#define SW_RST_OCCURRED	ARCSAS_BIT(1) /* active 1 clear 0 */
	#define RST_OUT_OCCURRED	ARCSAS_BIT(2) /* active 1 clear 0 */
	#define PCIE_RST_OCCURRED	ARCSAS_BIT(3) /* active 1 clear 0 */
/*
**************************************************************
**	Peripherals Registers
**	ARC1320 SPI
**************************************************************
*/
#define SPI_CTRL_SpiStart_1320		ARCSAS_BIT(0)
#define SPI_ADDR_VLD_1320		ARCSAS_BIT(1)
#define SPI_CTRL_READ_1320		ARCSAS_BIT(2)

#define SPI_CTRL_REG_1320		0xc800
#define SPI_ADDR_REG_1320		0xc804
#define SPI_WRITE_DATA_REG_1320		0xc808
#define SPI_READ_DATA_REG_1320		0xc80c
/*
**************************************************************
**	ARC1300 SPI
**************************************************************
*/
#define SPI_CTRL_SpiStart_1300		ARCSAS_BIT( 20 )
#define SPI_CTRL_SpiRdy_1300		ARCSAS_BIT( 22 )
#define SPI_CTRL_VenderEnable_1300	ARCSAS_BIT( 29 )

#define SPI_CTRL_REG_1300		0x10
#define SPI_CMD_REG_1300		0x14
#define SPI_WRITE_DATA_REG_1300		0x18 /* same address as read */
#define SPI_READ_DATA_REG_1300		0x18 /* same address as write */
/*
**************************************************************
**
**************************************************************
*/
#define SPI_INS_WREN	0 /* spi instruction write enable */
#define SPI_INS_WRDI	1 /* spi instruction write disable */
#define SPI_INS_RDSR	2 /* spi instruction read status register */
#define SPI_INS_WRSR	3 /* spi instruction write status register,The WRSR instruction also allows the user to enable or disable the Write Protect */
#define SPI_INS_READ	4 /* spi instruction read */
#define SPI_INS_PROG	5 /* spi instruction program */
#define SPI_INS_SERASE	6 /* spi instruction sector erase, Erase One Sector in Memory Array */
#define SPI_INS_CERASE	7 /* spi instruction chip erase, Erase All Sectors in Memory Array  */
#define SPI_INS_RDID	8 /* spi instruction read flash id */
#define SPI_INS_PTSEC	9 /* spi instruction protect sector */
#define SPI_INS_UPTSEC	10 /* spi instruction unprotect sector */
#define SPI_INS_RDPT	11 /* spi instruction read protect */
#define SPI_MAX_CMD	12

/* SES2 Page Code */
/*
**********************************************************************************************************************
**		SES2 Page Code 
**	This standard documents the commands and parameters necessary to manage and sense the state of the
**	power supplies, cooling devices, displays, indicators, individual drives, and other non-SCSI elements installed
**	in an enclosure.
**	The command set uses the SCSI "SEND DIAGNOSTIC (0x1D H)"=>SCSI_CMD_SND_DIAG
**		and "RECEIVE DIAGNOSTIC RESULTS (0x1C H)"=>SCSI_CMD_RCV_DIAG_RSLT
**	commands (see SPC-4)
**	to obtain configuration information for the enclosure and to set and sense
**	standard bits for each type of element that may be installed in the enclosure.
**
**	The following concepts from previous versions of this standard are made obsolete by this standard:
**	a) Array Control and Array Status diagnostic pages (page code 06h); and
**	b) secondary subenclosure support in the Help Text, String Out, and String In diagnostic pages
**********************************************************************************************************************
*/
#define SES_PG_SUPPORTED_DIAGNOSTICS	0x00
#define SES_PG_CONFIGURATION		0x01
#define SES_PG_ENCLOSURE_STATUS		0x02 /* Enclosure status diagnostic page	,mandatory if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_ENCLOSURE_CONTROL	0x02 /* Enclosure control diagnostic page	,mandatory if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_HELP_TEXT		0x03
#define SES_PG_STRING_IN		0x04
#define SES_PG_STRING_OUT		0x04 /* String OUT diagnostic page		,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_THRESHOLD_IN		0x05
#define SES_PG_THRESHOLD_OUT		0x05 /* Threshold OUT diagnostic page		,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_ARRAY_DIAGNOSTIC_STATUS	0x06 /* Array status diagnostic page (obsolete) */
#define SES_PG_ARRAY_DIAGNOSTIC_CONTRL	0x06 /* Array control diagnostic page (obsolete) */
#define SES_PG_ELEMENT_DESCRIPTOR	0x07
#define SES_PG_SHORT_ENCLOSURE_STATUS	0x08
#define SES_PG_ENCLOSURE_BUSY		0x09
#define SES_PG_ADDITIONAL_ELEMENT_STATUS	0x0a /* Additional Element Status diagnostic page	,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_SUBENCLOSURE_HELP_TEXT		0x0b /* Subenclosure Help Text diagnostic page		,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_SUBENCLOSURE_STRING_IN		0x0c /* Subenclosure String IN diagnostic page		,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_SUBENCLOSURE_STRING_OUT		0x0c /* Subenclosure String OUT diagnostic page		,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_SUPPORTED_SES_DIAGNOSTICS	0x0d /* Supported SES Diagnostic Pages diagnostic page	,optional if the Short Enclosure Status diagnostic page is not supported */
#define SES_PG_DOWNLOAD_MICROCODE_STATUS	0x0e /* Download Microcode control/status diagnostic page*/
#define SES_PG_DOWNLOAD_MICROCODE_CONTROL	0x0e /* Download Microcode control/status diagnostic page*/
#define SES_PG_VENDOR_SPECIFIC_SES_PAGE		0x10
#define SES_PG_VENDOR_PAGEA0			0xa0
#define ARCSAS_SES_DEVICE_STATE_PAGE_MASK	(ARCSAS_BIT(SES_PG_SUPPORTED_DIAGNOSTICS) + ARCSAS_BIT(SES_PG_CONFIGURATION) + ARCSAS_BIT(SES_PG_ENCLOSURE_STATUS) + ARCSAS_BIT(SES_PG_ELEMENT_DESCRIPTOR) + ARCSAS_BIT(SES_PG_ADDITIONAL_ELEMENT_STATUS))
/* pre-set flags for RAID module to use */
#define LED_FLAG_REBUILD	1
#define LED_FLAG_HOT_SPARE	2
#define LED_FLAG_FAIL_DRIVE	3
#define LED_FLAG_OFF_ALL	0xff
/* SBus dma burst sizes */
#ifndef BURSTSIZE
	#define	BURSTSIZE
	#define	BURST1			0x01
	#define	BURST2			0x02
	#define	BURST4			0x04
	#define	BURST8			0x08
	#define	BURST16			0x10
	#define	BURST32			0x20
	#define	BURST64			0x40
	#define	BURSTSIZE_MASK		0x7f
	#define	DEFAULT_BURSTSIZE	BURST16|BURST8|BURST4|BURST2|BURST1
#endif  /* BURSTSIZE */
/*  SAS/SATA Vendor Specific Port Registers */
enum sas_sata_vsp_regs
{
	ARC1300_VSR_PHY_STAT		= 0x00, /* Phy Status */
	ARC1300_VSR_PHY_MODE1		= 0x01, /* phy tx */
	ARC1300_VSR_PHY_MODE2		= 0x02, /* tx scc */
	ARC1300_VSR_PHY_MODE3		= 0x03, /* pll */
	ARC1300_VSR_PHY_MODE4		= 0x04, /* VCO */
	ARC1300_VSR_PHY_MODE5		= 0x05, /* Rx */
	ARC1300_VSR_PHY_MODE6		= 0x06, /* CDR */
	ARC1300_VSR_PHY_MODE7		= 0x07, /* Impedance */
	ARC1300_VSR_PHY_MODE8		= 0x08, /* Voltage */
	ARC1300_VSR_PHY_MODE9		= 0x09, /* Test */
	ARC1300_VSR_PHY_MODE10		= 0x0A, /* Power */
	ARC1300_VSR_PHY_MODE11		= 0x0B, /* Phy Mode */
	ARC1300_VSR_PHY_VS0		= 0x0C, /* Vednor Specific 0 */
	ARC1300_VSR_PHY_VS1		= 0x0D, /* Vednor Specific 1 */
	ARC1320_VSR_IRQ_STATUS			= 0x00,
	ARC1320_VSR_IRQ_MASK			= 0x04,
	ARC1320_VSR_PHY_CONFIG			= 0x08,
	ARC1320_VSR_PHY_STATUS			= 0x0c,
	ARC1320_VSR_PHY_MODE_REG_1		= 0x064,
	ARC1320_VSR_PHY_FFE_CONTROL		= 0x10C,
	ARC1320_VSR_PHY_DFE_UPDATE_CRTL		= 0x110,
	ARC1320_VSR_REF_CLOCK_CRTL		= 0x1A0,
	ARC1320_VSR_PHY_GENERATION_1_SETTING	= 0x118,
	ARC1320_VSR_PHY_GENERATION_1_2_SETTING	= 0x11C,
	ARC1320_VSR_PHY_GENERATION_2_3_SETTING	= 0x120,
	ARC1320_VSR_PHY_GENERATION_3_4_SETTING	= 0x124,
	ARC1320_VSR_PHY_STAT		= 0x00 * 4, /* Phy Status */
	ARC1320_VSR_PHY_MODE1		= 0x01 * 4, /* phy tx */
	ARC1320_VSR_PHY_MODE2		= 0x02 * 4, /* tx scc */
	ARC1320_VSR_PHY_MODE3		= 0x03 * 4, /* pll */
	ARC1320_VSR_PHY_MODE4		= 0x04 * 4, /* VCO */
	ARC1320_VSR_PHY_MODE5		= 0x05 * 4, /* Rx */
	ARC1320_VSR_PHY_MODE6		= 0x06 * 4, /* CDR */
	ARC1320_VSR_PHY_MODE7		= 0x07 * 4, /* Impedance */
	ARC1320_VSR_PHY_MODE8		= 0x08 * 4, /* Voltage */
	ARC1320_VSR_PHY_MODE9		= 0x09 * 4, /* Test */
	ARC1320_VSR_PHY_MODE10		= 0x0A * 4, /* Power */
	ARC1320_VSR_PHY_MODE11		= 0x0B * 4, /* Phy Mode */
	ARC1320_VSR_PHY_VS0		= 0x0C * 4, /* Vednor Specific 0 */
	ARC1320_VSR_PHY_VS1		= 0x0D * 4, /* Vednor Specific 1 */
};

typedef struct _ReceiveDiagnostic
{
	u_int8_t OperationCode;

	u_int8_t PCV:1;
	u_int8_t Reserved:7;

	u_int8_t PageCode;

	u_int8_t AllocationLength[2];

	u_int8_t Control;
}ReceiveDiagnostic, *PReceiveDiagnostic;

typedef struct _SendDiagnostic
{
	u_int8_t OperationCode;

	u_int8_t UnitOffL:1;
	u_int8_t DevOffL:1;
	u_int8_t SelfTest:1;
	u_int8_t Reserved:1;
	u_int8_t PF:1;
	u_int8_t SelfTestCode:3;

	u_int8_t Reserved2;	/* Cdb[2] */

	u_int8_t ParamLength[2];

	u_int8_t Control;
}SendDiagnostic, *PSendDiagnostic;

/* SES_PG_CONFIGURATION */
/*
*****************************************************************************************************************
** Mandatory:	Supported diagnostic page (SPC-4)
** ---------------------------------------------------------------
** The Supported Diagnostic Pages diagnostic page 
** returns the list of diagnostic pages implemented by the device server
** ---------------------------------------------------------------
**	Byte	7 6 5 4 3 2 1 0
**	0		PAGE CODE (00h)
**	1		Reserved
**	2 (MSB) PAGE LENGTH (n-3)
**	3 (LSB) PAGE LENGTH (n-3)
**	4		SUPPORTED PAGE  0
**	.		..
**	n		SUPPORTED PAGE  ?
** ---------------------------------------------------------------
** The PAGE LENGTH field specifies the length in bytes of the following supported page list.
** ---------------------------------------------------------------
** The SUPPORTED PAGE LIST field shall contain a list of all diagnostic page codes,
** one per byte, implemented by the device server in ascending order beginning with page code 00h
*****************************************************************************************************************
*/
typedef struct _SupportedPageHeader
{
	u_int8_t PageCode;
	u_int8_t Reserved;
	u_int8_t PageLength[2];
	/*
	** The PAGE LENGTH field specifies the length in bytes of the following supported page list
	*/
} SupportedPageHeader, *PSupportedPageHeader;
/*
********************************************************************************
**	Byte\Bit 7 6 5 4 3 2 1 0
**	0	PAGE CODE (01h)
**	1	NUMBER OF SECONDARY SUBENCLOSURES
**
**	2	(MSB) PAGE LENGTH (n - 3)
**	3	(LSB) PAGE LENGTH (n - 3)
**
**	4	(MSB) GENERATION CODE
**	5	GENERATION CODE 
**	6	GENERATION CODE
**	7	(LSB) GENERATION CODE
**
**		==>Enclosure descriptor list
**	8	Enclosure descriptor(s) (one per subenclosure)(see table 7 in 6.1.2.2)
**		==>Type descriptor header list (see 6.1.2.3)
**		Type descriptor header(s)(see table 8 in 6.1.2.3)
**		==>Type descriptor text list (see 6.1.2.4)
**	Type descriptor text(s) (one per type descriptor header)(see 6.1.2.4)
**	n
********************************************************************************
*/
typedef struct _ConfigurationPageHeader
{
	u_int8_t PageCode;
	u_int8_t SubEnclosureCount;
	/*
	** The NUMBER OF SECONDARY SUBENCLOSURES field indicates the number of secondary subenclosures
	** included in the enclosure descriptor list.
	** The primary subenclosure shall be described by the first enclosure descriptor.
	** Secondary subenclosures shall be described in subsequent enclosure descriptors,
	** and may be included in any order.
	*/
	u_int8_t PageLength[2];
	/*
	** The PAGE LENGTH field indicates the number of bytes that follow in the diagnostic page
	*/
	u_int8_t GenerationCode[4];
	/*
	** The GENERATION CODE field indicates the value of the generation code (see 4.3.2).
	*/
} ConfigurationPageHeader, *PConfigurationPageHeader;

typedef struct _EnclosureDescriptorHeader
{
	u_int8_t EnclosureServiceProcessesCount:3;
	u_int8_t Reserved1:1;
	u_int8_t RelativeEnclosureServiceProcessID:3;
	u_int8_t Reserved2:1;

	u_int8_t SubEnclosureID;
	u_int8_t NumberOfElementTypesSupported;
	u_int8_t EnclosureDescriptorLength;

} EnclosureDescriptorHeader, *PEnclosureDescriptorHeader;

typedef struct _EnclosureDescriptor
{
	u_int8_t EnclosureLogicalID[8];
	u_int8_t EnclosureVendorID[8];
	u_int8_t ProductID[16];
	u_int8_t ProductRevisionLevel[4];
	u_int8_t VendorSpecific;
} EnclosureDescriptor, *PEnclosureDescriptor;

typedef struct _TypeDescriptorHeader
{
/*
** The ELEMENT TYPE field in the type descriptor header indicates the element type being described in the type
** descriptor.
** The list of element types is shown in table 60 (see 7.1).
** More than one type descriptor header may
** contain the same ELEMENT TYPE field value 
** (
**  e.g., there may be two power supplies that provide +12 volts, and five power supplies that provide +5 volts.
**  In this case, a separate TYPE DESCRIPTOR HEADER may be used for
**  the +12 volt power supplies and for the +5 volt power supplies
** ).
*/
	u_int8_t ElementType;		/* SesElementType */
/*
** The NUMBER OF POSSIBLE ELEMENTS field in the type descriptor header indicates the number of elements of the
** indicated type that it is possible to install in the subenclosure. The actual number of elements installed may be
** smaller than the number that the configuration is capable of accepting. If the NUMBER OF POSSIBLE ELEMENTS
** field is set to zero, then the type descriptor corresponds to one overall element and no individual elements.
** The maximum number of elements represented by a single type descriptor shall be 255
*/
	u_int8_t NumberOfPossibleElements;
/*
** The SUBENCLOSURE IDENTIFIER field in the type descriptor header indicates the subenclosure (see 4.3)
** in which the elements described by this type descriptor reside.
*/
	u_int8_t SubEnclosureID;
/*
** The TYPE DESCRIPTOR TEXT LENGTH field in the type descriptor header indicates the number of bytes in the type
** descriptor text (see 6.1.2.4), if any. If the ELEMENT TYPE field is set to a vendor specific value, then the TYPE
** DESCRIPTOR TEXT LENGTH field shall be set to a nonzero value and shall have type descriptor text adequate to
** identify the element to an application client. Other element types may have a TYPE DESCRIPTOR TEXT LENGTH
** field set to 00h
** (6.1.2.4) Type descriptor text list
** The type descriptor text list shall contain type descriptor texts in the same order as the type descriptor
** headers. If the TYPE DESCRIPTOR TEXT LENGTH field is set to zero in the type descriptor header, then there is no
** type descriptor text.
** The type descriptor text is a text string (see 3.1.42) from zero to 255 bytes for each type descriptor header
** (see 6.1.2.3). The text string, if it has a length greater than zero, may contain any descriptive information
** about the element type that may be useful to an application client that is displaying the configuration of the
** enclosure (e.g., the manufacturer��s part number for a replacement element, a brief description of the element
** and its properties, or instructions about configuration limitations and redundancy requirements of the elements
** of that type).
** The type descriptor text uses the character encoding and language indicated by the Language element (see
** 7.3.18)
*/
	u_int8_t TypeDescriptorTextLength;
} TypeDescriptorHeader, *PTypeDescriptorHeader;

/* SES_PG_DEVICE_ELEMENT_STATUS */
typedef struct _DeviceElementStatusPage
{
	u_int8_t PageCode;
	u_int8_t Reserved;
	u_int8_t PageLength[2];
	u_int8_t GenerationCode[4];
} DeviceElementStatusPage, *PDeviceElementStatusPage;
/*
**************************************************************************************
**	An INVALID bit set to one
**	indicates that the contents of the protocol-specific information are invalid.
**	An INVALID bit set to zero
**	indicates that the contents of the protocol-specific information are valid.
**	The enclosure services process may set the INVALID bit to one
**
**	when the ELEMENT STATUS CODE field in the element status
**	for the associated element (see table 63 in 7.2.3)
**	is set to 5h (i.e., not installed),
**		6h (i.e., unknown),
**		or 7h (i.e., not available).
**
**	An EIP (element index present) bit set to one
**	indicates that the Additional Element Status descriptor
**	has the format defined in table 27.
**	An EIP bit set to zero 
**	indicates that the Additional Element Status descriptor
**	has the format defined in table 28
**	(
**	i.e.,
**	does not include the two extra bytes
**	including the ELEMENT INDEX field that are defined in table 27
**	).
**	The EIP bit should be set to one.
**
**	The PROTOCOL IDENTIFIER field is defined in SPC-4
**	and
**	identifies the protocol of the device being described
**	by the Additional Element Status descriptor.
**
**	The ADDITIONAL ELEMENT STATUS DESCRIPTOR LENGTH field
**	indicates the number of bytes that follow in the Additional Element Status descriptor.
**
**	The ELEMENT INDEX field 
**	indicates the index of the status element that this descriptor is describing.
**	The index is based on the position of the status element in the Enclosure Status diagnostic pages (see 6.1.4)
**	relative to all other individual status elements.
**	It does not include the overall status elements.
**
**	The protocol-specific information bytes 
**	contain information defined based on the PROTOCOL IDENTIFIER field.
**	If the PROTOCOL IDENTIFIER field is set to 0h (i.e., Fibre Channel),
**	then the protocol-specific information is defined in table 29 (see 6.1.13.2).
**	If the PROTOCOL IDENTIFIER field is set to 6h (i.e., SAS),
**	then the protocol-specific information is defined in table 33 (see 6.1.13.3).
**************************************************************************************
*/
/*
**************************************************************************************
** Additional Element Status descriptor protocol-specific information for
** Device Slot elements
** and
** Array Device Slot elements
** for SAS with the EIP bit set to zero
** --------------------------------------
** --------------------------------------
**	Byte\Bit 7 6 5 4 3 2 1 0
**	0	NUMBER OF PHY DESCRIPTORS
**	1	DESCRIPTOR TYPE (00b) Reserved NOT ALL PHYS
**		==>Phy descriptor list
**	2...29	Phy descriptor (first)(see SASPhyDescriptor),each descriptor 28 bytes
**	.
**	.
**	(Z-27)...Z   Phy descriptor (last)(see SASPhyDescriptor),each descriptor 28 bytes
**************************************************************************************
*/
typedef struct _DeviceElementStatusDescriptorEIP0
{
	u_int8_t ProtocolID:4;
	u_int8_t bEIP:1;
	u_int8_t Reserved1:2;
	u_int8_t Invalid:1;

	u_int8_t DeviceElementStatusDescriptorLength;
	u_int8_t PhyDescriptorCount;

	u_int8_t NotAllPhys:1;
	u_int8_t Reserved2:5;
	u_int8_t DescriptorType:2;
} DeviceElementStatusDescriptorEIP0, *PDeviceElementStatusDescriptorEIP0;
/*
**************************************************************************************
**  Additional Element Status descriptor protocol-specific information for
**  Device Slot elements
**  and
**  Array Device Slot elements
**  for SAS with the EIP bit set to one
**  --------------------------------------
**  --------------------------------------
**	Byte\Bit 7 6 5 4 3 2 1 0
**	0	NUMBER OF PHY DESCRIPTORS
**	1	DESCRIPTOR TYPE (00b) Reserved NOT ALL PHYS
**	2	Reserved
**	3	DEVICE SLOT NUMBER
**	==>Phy descriptor list
**	4...31	Phy descriptor (first)(see SASPhyDescriptor),each descriptor 28 bytes
**	.
**	.
**	(Z-27)...Z	Phy descriptor (last)(see SASPhyDescriptor),each descriptor 28 bytes
**************************************************************************************
*/

typedef struct _DeviceElementStatusDescriptorEIP1
{
	u_int8_t ProtocolID:4;
	u_int8_t bEIP:1;
	u_int8_t Reserved1:2;
	u_int8_t Invalid:1;

	u_int8_t DeviceElementStatusDescriptorLength;
	u_int8_t Reserved2;
	u_int8_t ElementIndex;
	u_int8_t PhyDescriptorCount;

	u_int8_t NotAllPhys:1;
	u_int8_t Reserved3:5;
	u_int8_t DescriptorType:2;

	u_int8_t Reserved4;
	u_int8_t BayNumber;
} DeviceElementStatusDescriptorEIP1, *PDeviceElementStatusDescriptorEIP1;

typedef union
{
	DeviceElementStatusDescriptorEIP0	EIP0;
	DeviceElementStatusDescriptorEIP1	EIP1;
}DeviceElementStatusDescriptor, *PDeviceElementStatusDescriptor;

typedef struct _SASPhyDescriptor
{
	u_int8_t Reserved1:4;
	u_int8_t DeviceType:3;
	u_int8_t Reserved2:1;

	u_int8_t Reserved3;

	u_int8_t Reserved4:1;
	u_int8_t SMPInitiatorPort:1;
	u_int8_t STPInitiatorPort:1;
	u_int8_t SSPInitiatorPort:1;
	u_int8_t Reserved5:4;

	u_int8_t Reserved6:1;
	u_int8_t SMPTargetPort:1;
	u_int8_t STPTargetPort:1;
	u_int8_t SSPTargetPort:1;
	u_int8_t Reserved7:4;

	u_int8_t AttachedSASAddress[8];
	u_int8_t SASAddress[8];
	u_int8_t PhyIdentifier;
	u_int8_t Reserved8[7];
} SASPhyDescriptor, *PSASPhyDescriptor;


/* SES_PG_ELEMENT_DESCRIPTOR */
typedef struct _ElementDescriptorPage
{
	u_int8_t PageCode;
	u_int8_t Reserved1;
	u_int8_t PageLength[2];
	u_int8_t GenerationCode[4];
} ElementDescriptorPage, *PElementDescriptorPage;

typedef struct _ElementDescriptor
{
	u_int8_t Reserved1;
	u_int8_t Reserved2;
	u_int8_t DescriptorLength[2];
	u_int8_t Descriptor[1];
} ElementDescriptor, *PElementDescriptor;

/* SES_PG_ENCLOSURE_STATUS */
typedef struct _OverallEnclosureStatus
{
	u_int8_t UnrecoverableCondition:1;
	u_int8_t CriticalCondition:1;
	u_int8_t NoncriticalCondition:1;
	u_int8_t InformationCondition:1;
	u_int8_t InvalidOperationRequested:1;
	u_int8_t Reserved1:3;
	/* byte0 */
} OverallEnclosureStatus, *pOverallEnclosureStatus;

typedef struct _EnclosureStatusPage
{
	u_int8_t PageCode;
	/* byte0 */
	OverallEnclosureStatus Status;
	/* byte1 */
	u_int8_t PageLength[2];
	/* byte2,3 */
	u_int8_t GenerationCode[4];
	/* byte4,5,6,7 */
} EnclosureStatusPage, *PEnclosureStatusPage;
/*
**************************************************************************************
**	Device Slot status element
**
** The Device Slot element manages a device slot
** (e.g., containing a SCSI device such as a disk drive)
** in the enclosure.
** Additional information about a Device Slot element
** may be reported in the Additional Element Status diagnostic page
**************************************************************************************
*/
typedef struct _DiskDeviceSlotStatusElement
{
	u_int8_t ElementStatusCode:4;
	u_int8_t Swap:1;
	u_int8_t Reserved0_5:1;
	u_int8_t Prdfail:1;
	u_int8_t Reserved0_7:1;
	/* byte0:COMMON STATUS */
	u_int8_t SlotAddress;
	/* byte1:SLOT ADDRESS */
	u_int8_t Report:1;		/* 0:REPORT */
	u_int8_t Ident:1;		/* 1:IDENT */
	u_int8_t Rmv:1;			/* 2:RMV */
	u_int8_t ReadyToInsert:1;	/* 3:READY TO INSERT */
	u_int8_t EnclosureBypassedB:1;	/* 4:ENCLOSURE BYPASSED B */
	u_int8_t EnclosureBypassedA:1;	/* 5:ENCLOSURE BYPASSED A */
	u_int8_t DoNotRemove:1;		/* 6:DO NOT REMOVE */
	u_int8_t AppClientBypassedA:1;	/* 7:APP CLIENT BYPASSED A */
	/* byte2 */
	u_int8_t DeviceBypassedB:1;	/* 0:DEVICE BYPASSED B */
	u_int8_t DeviceBypassedA:1;	/* 1:DEVICE BYPASSED A */
	u_int8_t BypassedB:1;		/* 2:BYPASSED B */
	u_int8_t BypassedA:1;		/* 3:BYPASSED A */
	u_int8_t DeviceOff:1;		/* 4:DEVICE OFF */
	u_int8_t FaultReqstd:1;		/* 5:FAULT REQSTD */
	u_int8_t FaultSensed:1;		/* 6:FAULT SENSED */
	u_int8_t AppClientBypassedB:1;	/* 7:APP CLIENT BYPASSED B */
	/* byte3 */
}DiskDeviceSlotStatusElement, *PDiskDeviceSlotStatusElement;
/* Element Status, Summary SES Status Defines, Common Status Codes */
enum ses_status
{
	SES_STATUS_UNSUPPORTED = 0x00,	/* 0x00 */
	SES_STATUS_OK,			/* 0x01 */
	SES_STATUS_CRITICAL,		/* 0x02 */
	SES_STATUS_NONCRITICAL,		/* 0x03 */
	SES_STATUS_UNRECOVERABLE,	/* 0x04 */
	SES_STATUS_NOTINSTALLED,	/* 0x05 */
	SES_STATUS_UNKNOWN,		/* 0x06 */
	SES_STATUS_NOTAVAILABLE,	/* 0x07 */
	SES_STATUS_RESERVED		/* 0x08 */
};
/*
**************************************************************************************
**	Array Device Slot STATUS element
**
**	The Array Device Slot element manages a device slot
**	(e.g., containing a SCSI device such as a disk drive)
**	in an enclosure that is being used in a storage array
**	(e.g., by a RAID controller).
**	The mapping between the visual indicators
**	associated with the Array Device Slot element
**	and the requests to set those indicators is vendor specific.
**	Additional information about an Array Device Slot element 
**	may be reported in the Additional Element Status diagnostic page
**************************************************************************************
*/
typedef struct _ArrayDeviceSlotStatusElement
{
	u_int8_t StatusCode:4;
	u_int8_t Swap:1;
	u_int8_t Reserved0_5:1;
	u_int8_t PredictedFailure:1;
	u_int8_t Reserved0_7:1;
	/* byte0 */
	u_int8_t RequestRebuildRemapAbort:1;
	u_int8_t RequestRebuildRemap:1;
	u_int8_t RequestInFailedArray:1;
	u_int8_t RequestInCriticalArray:1;
	u_int8_t RequestConsistencyCheck:1;
	u_int8_t RequestHotSpare:1;
	u_int8_t RequestReservedDevice:1;
	u_int8_t RequestOK:1;
	/* byte1 */
	u_int8_t Report:1;
	u_int8_t RequestIdentify:1;
	u_int8_t RequestRemove:1;
	u_int8_t ReadyToInsert:1;
	u_int8_t EnclosureBypassedB:1;
	u_int8_t EnclosureBypassedA:1;
	u_int8_t DoNotRemove:1;
	u_int8_t AppBypassedA:1;
	/* byte2 */
	u_int8_t DeviceBypassedB:1;
	u_int8_t DeviceBypassedA:1;
	u_int8_t BypassedB:1;
	u_int8_t BypassedA:1;
	u_int8_t DeviceOff:1;
	u_int8_t RequestFault:1;
	u_int8_t SensedFault:1;
	u_int8_t AppBypassedB:1;
	/* byte3 */
} ArrayDeviceSlotStatusElement, *PArrayDeviceSlotStatusElement;

typedef struct _ArrayElementForEnclosureStatusPage
{
	u_int8_t StatusCode:4;
	u_int8_t Swap:1;
	u_int8_t Reserved1:1;
	u_int8_t PredictedFailure:1;
	u_int8_t Reserved2:1;
	/* byte0 */
	u_int8_t RebuildRemapAbort:1;
	u_int8_t RebuildRemap:1;
	u_int8_t InFailedArray:1;
	u_int8_t InCriticalArray:1;
	u_int8_t ConsistencyCheck:1;
	u_int8_t HotSpare:1;
	u_int8_t ReservedDevice:1;
	u_int8_t OK:1;
	/* byte1 */
	u_int8_t Report:1;
	u_int8_t Identify:1;
	u_int8_t Rmv:1;
	u_int8_t ReadyToInsert:1;
	u_int8_t EnclosureBypassedB:1;
	u_int8_t EnclosureBypassedA:1;
	u_int8_t DoNotRemove:1;
	u_int8_t AppBypassedA:1;
	/* byte2 */
	u_int8_t DeviceBypassedB:1;
	u_int8_t DeviceBypassedA:1;
	u_int8_t BypassedB:1;
	u_int8_t BypassedA:1;
	u_int8_t DeviceOff:1;
	u_int8_t FaultRequested:1;
	u_int8_t FaultSensed:1;
	u_int8_t AppBypassedB:1;
	/* byte3 */
} ArrayElementForEnclosureStatusPage, *PArrayElementForEnclosureStatusPage;

/* SES_PG_ENCLOSURE_CONTROL */
typedef struct _EnclosureControlPage
{
	u_int8_t PageCode;
	u_int8_t UnrecoverableCondition:1;
	u_int8_t CriticalCondition:1;
	u_int8_t NoncriticalCondition:1;
	u_int8_t InformationCondition:1;
	u_int8_t Reserved1:4;
	u_int8_t PageLength[2];
	u_int8_t GenerationCode[4];
} EnclosureControlPage, *PEnclosureControlPage;

typedef struct _DiskDeviceSlotControlElement
{
	u_int8_t Reserved0_0123:4;
	u_int8_t ResetSwap:1;
	u_int8_t Disable:1;
	u_int8_t PredictedFailure:1;
	u_int8_t Select:1;
	/* byte0 */
	u_int8_t Reserved2;
	/* byte1 */
	u_int8_t Reserved3:1;
	u_int8_t RequestIdentify:1;
	u_int8_t RequestRemove:1;
	u_int8_t RequestInsert:1;
	u_int8_t RequestMissing:1; /*4:RQST MISSING*/
	u_int8_t Reserved4:1;
	u_int8_t DoNotRemove:1;
	u_int8_t Active:1;
	/* byte2 */
	u_int8_t Reserved5:2;
	u_int8_t EnableBypassB:1;
	u_int8_t EnableBypassA:1;
	u_int8_t DeviceOff:1;
	u_int8_t RequestFault:1;
	u_int8_t Reserved6:2;
	/* byte3 */
} DiskDeviceSlotControlElement, *PDiskDeviceSlotControlElement;
/*
**************************************************************************************
**	Array Device Slot CONTROL element
**
**	The Array Device Slot element manages a device slot
**	(e.g., containing a SCSI device such as a disk drive) Array Device Slot control element
**	in an enclosure that is being used in a storage array
**	(e.g., by a RAID controller).
**	The mapping between the visual indicators
**	associated with the Array Device Slot element
**	and the requests to set those indicators is vendor specific.
**	Additional information about an Array Device Slot element
**	may be reported in the Additional Element Status diagnostic page
**************************************************************************************
*/
typedef struct _ArrayDeviceSlotControlElement
{
	u_int8_t Reserved0_0123:4;
	u_int8_t ResetSwap:1;
	u_int8_t Disable:1;
	u_int8_t PredictedFailure:1;
	u_int8_t Select:1;
	/* byte0 */
	u_int8_t RequestRebuildRemapAbort:1;
	u_int8_t RequestRebuildRemap:1;
	u_int8_t RequestInFailedArray:1;
	u_int8_t RequestInCriticalArray:1;
	u_int8_t RequestConsistencyCheck:1;
	u_int8_t RequestHotSpare:1;
	u_int8_t RequestReservedDevice:1;
	u_int8_t RequestOK:1;
	/* byte1 */
	u_int8_t Reserved2:1;
	u_int8_t RequestIdentify:1;
	u_int8_t RequestRemove:1;
	u_int8_t ReadyToInsert:1;
	u_int8_t Reserved3:2;
	u_int8_t DoNotRemove:1;
	u_int8_t Active:1;
	/* byte2 */
	u_int8_t Reserved4:2;
	u_int8_t EnableBypassB:1;
	u_int8_t EnableBypassA:1;
	u_int8_t DeviceOff:1;
	u_int8_t RequestFault:1;
	u_int8_t Reserved5:2;
	/* byte3 */
} ArrayDeviceSlotControlElement, *PArrayDeviceSlotControlElement;
/*
******************************************************************************
**	The Device Slot element manages a device slot
**	(e.g., containing a SCSI device such as a disk drive)
**	in the enclosure.
**	Additional information about a Device Slot element
**	may be reported in the Additional Element Status diagnostic page
******************************************************************************
*/
typedef union
{
	DiskDeviceSlotStatusElement  Status;	/* 4 bytes */
	DiskDeviceSlotControlElement Control;	/* 4 bytes */
} DiskDeviceEnclosureElement, *PDiskDeviceEnclosureElement;
/*
******************************************************************************
**	The Array Device Slot element manages a device slot 
**	(e.g., containing a SCSI device such as a disk drive)
**	in an enclosure that is being used in a storage array
**	(e.g., by a RAID controller).
**	The mapping between the visual indicators associated with
**	the Array Device Slot element
**	and the requests to set those indicators is vendor specific.
**	Additional information about an Array Device Slot element
**	may be reported in the Additional Element Status diagnostic page
******************************************************************************
*/
typedef union
{
	ArrayDeviceSlotStatusElement  Status;	/* 4 bytes */
	ArrayDeviceSlotControlElement Control;	/* 4 bytes */
} ArrayDeviceEnclosureElement, *PArrayDeviceEnclosureElement;

typedef union
{
	DiskDeviceEnclosureElement   DiskType;  /* 4 bytes */
	ArrayDeviceEnclosureElement  ArrayType;	/* 4 bytes such as ARC8060 in ENCLOSURE */
} SesEnclosureElement, *PSesEnclosureElement;

#define CMD_SSP		0x01
#define CMD_SMP		0x02
#define CMD_STP		0x03
#define CMD_SSP_TGT	0x04
#define CMD_SLOT_RESET	0x07

/*
************************************************
**	I2C
************************************************
*/
#define REQ_CMD_HOST_ID_I2CWRITE	0x0010
#define REQ_CMD_HOST_ID_I2CREAD		0x0011
#define REQ_CMD_CRC32_I2CWRITE		0x8010
#define REQ_CMD_CRC32_I2CREAD		0x8011
#define I2C_DATA_WRITE			0x00
#define I2C_DATA_READ			0x01
/*
************************************************
**	I2C_1300
************************************************
*/
#define I2C_SOFTWARE_CONTROL_1300	0x1c
#define I2C_HARDWARE_CONTROL_1300	0x20
#define I2C_STATUS_DATA_1300		0x24
/*
************************************************
**	I2C_1320
************************************************
*/
#define I2C_SOFTWARE_CONTROL_1320_A	0x0C51C
#define I2C_HARDWARE_CONTROL_1320_A	0x0C520
#define I2C_STATUS_DATA_1320_A		0x0C524
#define I2C_SOFTWARE_CONTROL_1320_B	0x0C61C
#define I2C_HARDWARE_CONTROL_1320_B	0x0C620
#define I2C_STATUS_DATA_1320_B		0x0C624
#define I2C_SOFTWARE_CONTROL_1320_C	0x1C71C
#define I2C_HARDWARE_CONTROL_1320_C	0x1C720
#define I2C_STATUS_DATA_1320_C		0x1C724
/*
******************************************
** BUS_PTL value
******************************************
*/
#define BUS_PTL_WRITE_QUICK	0x00 /* Write quick. */
#define BUS_PTL_READ_QUICK	0x01 /* Read quick. */
#define BUS_PTL_SEND_BYTE	0x02 /* Send byte. */
#define BUS_PTL_RCV_BYTE	0x03 /* Receive byte. */
#define BUS_PTL_WRITE_BYTE	0x04 /* Write byte. */
#define BUS_PTL_READ_BYTE	0x05 /* Read byte. */
#define BUS_PTL_WRITE_WORD	0x06 /* Write word. */
#define BUS_PTL_READ_WORD	0x07 /* Read word. */
#define BUS_PTL_RCV_WORD	0x0F /* Receive word. */
/*
******************************************
** I2C_STATUS_DATA bits
******************************************
*/
typedef struct _REG_I2C_STATUS_DATA
{
	u_int32_t	INT_ST:8;	/* 7:0 for INT_ST value */
	u_int32_t	Reserved:8;	/* 15:8  */
	u_int32_t	DATA_LO:8;	/* 23:16 */
	u_int32_t	DATA_HI:8;	/* 31:24 */
} REG_I2C_STATUS_DATA, *PREG_I2C_STATUS_DATA;
/*
******************************************
** I2C_HARDWARE_CONTROL bits
******************************************
*/
typedef struct _REG_I2C_HARDWARE_CONTROL
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int32_t	INT:1;		/* 31 */
	u_int32_t	Reserved:6;	/* 30:25 */
	u_int32_t	BUS_PTL_START:1; /* 24 */
	u_int32_t	CMD_CODE:8;	/* 23:16 */
	u_int32_t	BUS_PTL:8;	/* 15:8 */
	u_int32_t	SLV_ADRS:8;	/* 7:0 */
#else
	u_int32_t	SLV_ADRS:8;	/* 7:0 */
	u_int32_t	BUS_PTL:8;	/* 15:8 */
	u_int32_t	CMD_CODE:8;	/* 23:16 */
	u_int32_t	BUS_PTL_START:1; /* 24 */
	u_int32_t	Reserved:6;	/* 30:25 */
	u_int32_t	INT:1;		/* 31 */
#endif
} REG_I2C_HARDWARE_CONTROL, *PREG_I2C_HARDWARE_CONTROL;
/*
*****************************************************************
** To be backward compatible, keep the original Adapter_Config
*****************************************************************
*/
typedef struct _Adapter_Config
{
	u_int32_t	BIOS_Flag;	/* 4 bytes, refer to BIOS_Flag in struct _BIOS_Info_Page */
	u_int32_t	Reserved;	/* 4 bytes */
} Adapter_Config, *PAdapter_Config;
/*
************************************************
** [ARC100 address]
************************************************
*/
#define I2C_ARC100_ADDR		0x10 /* ARC100 i2c slave address */
/*
* ATA IDE Command definition
*/
/* SATA SSD TRIM COMMAND */
#define ATA_CMD_DATA_SET_MANAGEMENT		0x06
/* PIO command */
#define ATA_CMD_READ_PIO			0x20
#define ATA_CMD_READ_PIO_EXT			0x24
#define ATA_CMD_READ_PIO_MULTIPLE_EXT 		0x29
#define ATA_CMD_WRITE_PIO			0x30
#define ATA_CMD_WRITE_PIO_EXT			0x34
#define ATA_CMD_WRITE_PIO_MULTIPLE_EXT		0x39

/* DMA read write command */
#define ATA_CMD_READ_DMA			0xC8	/* 24 bit DMA read */
#define ATA_CMD_READ_DMA_QUEUED			0xC7	/* 24 bit TCQ DMA read */
#define ATA_CMD_READ_DMA_EXT			0x25	/* 48 bit DMA read */
#define ATA_CMD_READ_DMA_QUEUED_EXT		0x26	/* 48 bit TCQ DMA read */
#define ATA_CMD_READ_FPDMA_QUEUED		0x60	/* NCQ DMA read: SATA only. Always 48 bit */

#define ATA_CMD_WRITE_DMA			0xCA
#define ATA_CMD_WRITE_DMA_QUEUED		0xCC
#define ATA_CMD_WRITE_DMA_EXT  			0x35
#define ATA_CMD_WRITE_DMA_QUEUED_EXT		0x36
#define ATA_CMD_WRITE_FPDMA_QUEUED		0x61

/* Identify command */
#define ATA_CMD_IDENTIFY_ATA			0xEC
#define ATA_CMD_IDENTIFY_ATAPI			0xA1

#define ATA_CMD_VERIFY				0x40	/* 24 bit read verifty */
#define ATA_CMD_VERIFY_EXT			0x42	/* 48 bit read verify */

#define ATA_CMD_FLUSH				0xE7	/* 24 bit flush */
#define ATA_CMD_FLUSH_EXT			0xEA	/* 48 bit flush */

#define ATA_CMD_PACKET				0xA0
#define ATA_CMD_SMART				0xB0

#define ATA_CMD_SMART_READ_VALUES 		0xD0
#define ATA_CMD_SMART_READ_THRESHOLDS		0xD1
#define ATA_CMD_SMART_ATTRIBUTE_AUTOSAVE	0xD2
#define ATA_CMD_SMART_SAVE			0xD3
#define ATA_CMD_SMART_IMMEDIATE_OFFLINE		0xD4
#define ATA_CMD_SMART_READ_LOG_SECTOR		0xD5
#define ATA_CMD_SMART_WRITE_LOG_SECTOR 		0xD6
#define ATA_CMD_SMART_WRITE_THRESHOLDS		0xD7
#define ATA_CMD_SMART_ENABLE			0xD8
#define ATA_CMD_SMART_DISABLE			0xD9
#define ATA_CMD_SMART_RETURN_STATUS		0xDA
#define ATA_CMD_SMART_AUTO_OFFLINE		0xDB

#define ATA_CMD_SET_FEATURES			0xEF
	#define ATA_FEATURE_ENABLE_WRITE_CACHE		0x02
	#define ATA_FEATURE_SET_TRANSFER_MODE		0x03
	#define ATA_FEATURE_DISABLE_READ_LOOK_AHEAD	0x55
	#define ATA_FEATURE_DISABLE_WRITE_CACHE		0x82
	#define ATA_FEATURE_ENABLE_READ_LOOK_AHEAD	0xAA

#define ATA_CMD_STANDBY_IMMEDIATE		0xE0
#define ATA_CMD_CHECK_POWER_MODE		0xE5
#define	ATA_CMD_SLEEP				0xE6

#define ATA_CMD_SEEK				0x70
#define ATA_CMD_READ_LOG_EXT			0x2F

/* PM commands & registers */
#define ATA_CMD_PM_READ				0xE4
#define ATA_CMD_PM_WRITE			0xE8
#define ATA_CMD_PM_CHECK			0xE5

#define ATA_CMD_EXECUTE_DEVICE_DIAGNOSTIC	0x90

/* Some macros to make device type easier to use */
#define IS_SSP(pDevice)			((pDevice->Connection & DC_SCSI) && !(pDevice->Connection & DC_ATA))
#define IS_STP(pDevice)			((pDevice->Connection & DC_SCSI) && (pDevice->Connection & DC_ATA))
#define IS_NATIVE_SATA(pDevice)		(!(pDevice->Connection & DC_SCSI) && (pDevice->Connection & DC_ATA))
#define IS_STP_OR_SATA_ATAPI(pDevice)	(pDevice->Connection & DC_ATA)
#define IS_SATAPI(pDevice)		((pDevice->Connection & DC_SCSI) && (pDevice->Connection & DC_ATAPI) && (pDevice->Connection & DC_ATA))
#define IS_ATAPI(pDevice)		((pDevice->Connection & DC_ATAPI) && (pDevice->Connection & DC_ATA))
#define IS_SGPIO(pDevice)		(pDevice->Connection & DC_SGPIO)

#define IS_DISK(pDevice)		(pDevice->Dev_Type == DT_DIRECT_ACCESS_BLOCK)
#define IS_TAPE(pDevice)		(pDevice->Dev_Type == DT_SEQ_ACCESS)
#define IS_MEDIA_CHANGER(pDevice)	(pDevice->Dev_Type == DT_MEDIA_CHANGER)
#define IS_ENCLOSURE(pDevice)		((pDevice->Dev_Type == DT_ENCLOSURE) || (pDevice->Dev_Type == DT_SES_DEVICE))

#define DEVICE_SETTING_SMART_ENABLED		ARCSAS_BIT(0)
#define DEVICE_SETTING_WRITECACHE_ENABLED	ARCSAS_BIT(1)
#define DEVICE_SETTING_PROTECT_INFO_ENABLED	ARCSAS_BIT(2)
#define DEVICE_SETTING_READ_LOOK_AHEAD		ARCSAS_BIT(3)
#define DEVICE_SETTING_WRITE_PROTECT		ARCSAS_BIT(4)
#define DEVICE_SETTING_NCQ_SUPPORTED		ARCSAS_BIT(5)
#define DEVICE_SETTING_MAX_LINK_SPEED		(ARCSAS_BIT(10)|ARCSAS_BIT(9)|ARCSAS_BIT(8)) /* came from BIOS_Flag */

/*
**========================================================================
**  64xx chip registers
**========================================================================
*/
#define ARCSAS_PCI_BAR			5
#define GEN_HOST_CONTROL_REG_START	0x0
#define VENDOR_SPECIFIC_REG_START	0xa0
#define SAS_PORT_REG_START		0x100

/* Power Mode PM_CNTRL/PMODE */
#define PMODE_PARTIAL			0x10
#define PMODE_SLUMBER			0x01

/* CONFIG_R_ERR_COUNT/CONFIG_CRC_ERR_COUNT bits */
#define ERR_COUNT_MASK			0x0ffff

/* Tag */
#define SSP_I_HEADR_TAG_MASK		0xfe00	/* lower 9 bits from HW command slot */
#define SSP_T_HEADR_TAG_MASK		0xffff
#define STP_HEADR_TAG_MASK		0x001f	/* NCQ uses lower 5 bits */
/* TargetTag */
#define SSP_T_HEADR_TGTTAG_MASK		0xfe00	/* lower 9 bits from HW command slot */
/*
********************************************************
**	Task Management Functions.
********************************************************
*/
#define TMF_ABORT_TASK			0x01
#define TMF_ABORT_TASK_SET		0x02
#define TMF_CLEAR_TASK_SET		0x04
#define TMF_LOGICAL_UNIT_RESET		0x08
#define TMF_CLEAR_ACA			0x40
#define TMF_QUERY_TASK			0x80

#define CORE_CONTEXT_TYPE_NONE		0		/* No valid context */
#define CORE_CONTEXT_TYPE_CDB		1		/* Context is the CDB */
#define CORE_CONTEXT_TYPE_BIG_REQUEST	2		/* Context for large request */

/*
* Here is the definition for the command consolidate sub module
* This is only changed when we modify the consolidate algorithm.
*/
//#define CONS_MAX_INTERNAL_REQUEST_COUNT	CORE_MAX_REQUEST_NUMBER

#define CONS_MAX_EXTERNAL_REQUEST_SIZE	(1024*128)
#define CONS_SEQUENTIAL_MAX		64		/* Avoid overflow. It's determined by Sequential variable size */

#define CONS_MAX_INTERNAL_REQUEST_SIZE	(1024*128)	/* The maximum request size hardware can handle. */
#define CONS_MIN_INTERNAL_REQUEST_SIZE	(1024*128)	/* We'll accumulate the request to this size and then fire. */

#define	U64_ASSIGN_VALUE(x,y)		((x).value= (y))
#define	U64_ASSIGN_U64(x,y)		((x).value= (y).value)
#define	U64_COMPARE_U64(x,y)		((x)== (y).value)
#define U64_COMPARE_U64_VALUE(x,y)	((x).value== (y).value)
#define U32_ASSIGN_U64(v64, v32)	((v64).value= (v32))
#define	U64_SHIFT_LEFT(v64, v32)	((v64).value=(v64).value << (v32))
#define	U64_SHIFT_RIGHT(v64, v32)	((v64).value=(v64).value >> (v32))
#define U64_ZERO_VALUE(v64)		((v64).value= 0)

/*
* Data Structure
*/
#define MAX_CDB_SIZE		16

/* Work around free disks suporting temporarily */
#define RESTORE_FREE_DISK_TID	1

#define ARCSAS_MAX(x,y)		(((x) > (y)) ? (x) : (y))
#define ARCSAS_MIN(x,y)		(((x) < (y)) ? (x) : (y))

#define ARCSAS_MAX_U64(x, y)	((((x).value) > ((y).value)) ? (x) : (y))
#define ARCSAS_MIN_U64(x, y)	((((x).value) < ((y).value)) ? (x) : (y))

#define ARCSAS_ALIGN(x, a)	(((x) + (a) - 1) & ~((a) - 1))
#define ROUNDING(value, align)	(((value)+(align)-1)/(align)*(align))
#define OFFSET_OF(type, member)	offsetof(type, member)

#define FILO_TAG 		0x00
#define FIFO_TAG		0x01

//#define SERVICE_ACTION_IN	0x9e
/* values for service action in */
#define	SAI_READ_CAPACITY_16	0x10

#define SGD_DOMAIN_MASK		0xF0000000L
#define SGD_EOT			(1L<<27)	/* End of table */
#define SGD_COMPACT		(1L<<26)	/* Compact (12 bytes) SG format, not verified yet */
#define SGD_WIDE		(1L<<25)	/* 32 byte SG format */
#define SGD_X64			(1L<<24)	/* the 2nd part of SGD_WIDE */
#define SGD_NEXT_TBL		(1L<<23)	/* Next SG table format */
#define SGD_VIRTUAL		(1L<<22)	/* Virtual SG format, either 32 or 64 bit is determined during compile time. */
#define SGD_REFTBL		(1L<<21)	/* sg table reference format, either 32 or 64 bit is determined during compile time. */
#define SGD_REFSGD		(1L<<20)	/* sg item reference format */
#define SGD_VP			(1L<<19)	/* virtual and physical, not verified yet */
#define SGD_VWOXCTX		(1L<<18)	/* virtual without translation context */
#define SGD_PCTX		(1L<<17)	/* sgd_pctx_t, 64 bit only */

#define SIZEOF_COMPACT_SGD	12

/*
* SCSI command
*/
#define SCSI_CMD_INQUIRY		0x12
#define SCSI_CMD_START_STOP_UNIT	0x1B
#define SCSI_CMD_TEST_UNIT_READY	0x00
#define SCSI_CMD_RESERVE_6		0x16
#define SCSI_CMD_RELEASE_6		0x17
#define SCSI_CMD_READ_6			0x08
#define SCSI_CMD_READ_10		0x28
#define SCSI_CMD_READ_12		0xA8
#define SCSI_CMD_READ_16		0x88
#define SCSI_CMD_READ_LONG_10		0x3E
#define SCSI_CMD_WRITE_6		0x0A
#define SCSI_CMD_WRITE_10		0x2A
#define SCSI_CMD_WRITE_12		0xAA
#define SCSI_CMD_WRITE_16		0x8A
#define SCSI_CMD_WRITE_LONG_10		0x3F
#define SCSI_CMD_READ_CAPACITY_10	0x25
#define SCSI_CMD_READ_CAPACITY_16	0x9E	/* 9Eh/10h */
#define SCSI_CMD_VERIFY_10		0x2F
#define SCSI_CMD_VERIFY_12		0xAF
#define SCSI_CMD_VERIFY_16		0x8F
#define SCSI_CMD_REQUEST_SENSE		0x03
#define SCSI_CMD_MODE_SENSE_6		0x1A
#define SCSI_CMD_MODE_SENSE_10		0x5A
#define SCSI_CMD_MODE_SELECT_6		0x15
#define SCSI_CMD_MODE_SELECT_10		0x55
#define SCSI_CMD_LOG_SELECT		0x4C
#define SCSI_CMD_LOG_SENSE		0x4D
#define SCSI_CMD_WRITE_VERIFY_10	0x2E
#define SCSI_CMD_WRITE_VERIFY_12	0xAE
#define SCSI_CMD_WRITE_VERIFY_16	0x8E
#define SCSI_CMD_SYNCHRONIZE_CACHE_10	0x35
#define SCSI_CMD_SYNCHRONIZE_CACHE_16	0x91
#define SCSI_CMD_WRITE_SAME_10		0x41
#define SCSI_CMD_WRITE_SAME_16		0x93
#define SCSI_CMD_XDWRITE_10		0x50
#define SCSI_CMD_XPWRITE_10		0x51
#define SCSI_CMD_XDREAD_10		0x52
#define SCSI_CMD_XDWRITEREAD_10		0x53
#define SCSI_CMD_FORMAT_UNIT		0x04
#define SCSI_CMD_RCV_DIAG_RSLT		0x1C
#define SCSI_CMD_SND_DIAG		0x1D
#define SCSI_CMD_PERSISTENT_RESERVE_IN	0x5E
#define SCSI_CMD_PERSISTENT_RESERVE_OUT	0x5F
#define SCSI_CMD_READ_WRITE_32		0x7F
	#define SCSI_CMD_XDREAD_32	0x0003
	#define SCSI_CMD_XDWRITE_32	0x0004
	#define SCSI_CMD_XPWRITE_32	0x0006
	#define SCSI_CMD_XDWRITEREAD_32	0x0007
	#define SCSI_CMD_READ_32	0x0009
	#define SCSI_CMD_VERIFY_32	0x000A
	#define SCSI_CMD_WRITE_32	0x000B
	#define SCSI_CMD_WRITE_VERIFY_32	0x000C
	#define SCSI_CMD_WRITE_SAME_32		0x000D
#define SCSI_CMD_SERVICE_ACTION_IN		0x9E /* Data Set Management (DSM) IN command:9Eh/ SERVICE_ACTION_IN:9Eh / SAI_READ_CAPACITY_16:10h */
/* values for service action in */
	#define	SCSI_SAI_READ_CAPACITY_16	0x10
	#define SCSI_SAI_GET_LBA_STATUS		0x12
#define SCSI_CMD_SAT_COMMAND_PASS_THROUGH_16	0x85 /* SAT:sata pass through 16CDB */
#define SCSI_CMD_SAT_COMMAND_PASS_THROUGH_12	0xA1 /* SAT:sata pass through 12CDB */
#define SCSI_CMD_WRITE_SAME_10			0x41
#define SCSI_CMD_UNMAP				0x42
/* MMC */
#define SCSI_CMD_SET_WINDOW			0x24
#define SCSI_CMD_REPORT_LUN			0xA0
#define SCSI_CMD_PREVENT_MEDIUM_REMOVAL		0x1E
#define SCSI_CMD_READ_DEFECT_DATA_10		0x37
#define SCSI_CMD_READ_SUB_CHANNEL		0x42
#define SCSI_CMD_READ_TOC			0x43
#define SCSI_CMD_READ_DISC_STRUCTURE		0xAD
#define SCSI_CMD_READ_CD			0xBE
#define SCSI_CMD_GET_EVENT_STATUS_NOTIFICATION	0x4A
#define SCSI_CMD_BLANK				0xA1
#define SCSI_CMD_SECURITY_PROTOCOL_IN		0xA2
#define SCSI_CMD_SECURITY_PROTOCOL_OUT		0xB5
#define SCSI_CMD_READ_DISC_INFO			0x51
#define SCSI_CMD_ARECA_SPECIFIC			0xE1

#define CDB_CORE_MODULE				0x1
#define CDB_CORE_SOFT_RESET_1			0x1
#define CDB_CORE_SOFT_RESET_0			0x2
#define CDB_CORE_IDENTIFY			0x3
#define CDB_CORE_SET_UDMA_MODE			0x4
#define CDB_CORE_SET_PIO_MODE			0x5
#define CDB_CORE_ENABLE_WRITE_CACHE		0x6
#define CDB_CORE_DISABLE_WRITE_CACHE		0x7
#define CDB_CORE_ENABLE_SMART			0x8
#define CDB_CORE_DISABLE_SMART			0x9
#define CDB_CORE_SMART_RETURN_STATUS		0xA
#define CDB_CORE_SHUTDOWN 			0xB
#define CDB_CORE_ENABLE_READ_AHEAD		0xC
#define CDB_CORE_DISABLE_READ_AHEAD		0xD
#define CDB_CORE_READ_LOG_EXT			0xE
#define CDB_CORE_TASK_MGMT			0xF
#define CDB_CORE_SMP				0x10
#define CDB_CORE_PM_READ_REG			0x11
#define CDB_CORE_PM_WRITE_REG			0x12
#define CDB_CORE_RESET_DEVICE			0x13
#define CDB_CORE_RESET_PORT			0x14
#define CDB_CORE_OS_SMART_CMD			0x15
#define CDB_CORE_ATA_IDENTIFY_ATA		0x16
#define CDB_CORE_ATA_IDENTIFY_ATAPI		0x17
#define CDB_CORE_ATA_SMART_READ_VALUES		0x18
#define CDB_CORE_ATA_SMART_READ_THRESHOLDS	0x19
#define CDB_CORE_ATA_SMART_READ_LOG_SECTOR	0x1A
#define CDB_CORE_ATA_SMART_WRITE_LOG_SECTOR	0x1B
#define CDB_CORE_ATA_SMART_AUTO_OFFLINE		0x1C
#define CDB_CORE_ATA_SMART_AUTOSAVE		0x1D
#define CDB_CORE_ATA_SMART_IMMEDIATE_OFFLINE	0x1E

#define CDB_CORE_ATA_SLEEP			0x20
#define CDB_CORE_ATA_IDLE			0x21
#define CDB_CORE_ATA_STANDBY			0x22
#define CDB_CORE_ATA_IDLE_IMMEDIATE		0x23
#define CDB_CORE_ATA_STANDBY_IMMEDIATE		0x24
#define CDB_CORE_ATA_CHECK_POWER_MODE		0x25

#define CDB_CORE_SMP_VIRTUAL_DISCOVER		0x30
#define CDB_CORE_SMP_VIRTUAL_CONFIG_ROUTE	0x31

#define SMP_CDB_USE_ADDRESS			0x01

#define SCSI_IS_INTERNAL(cmd)	((cmd)== SCSI_CMD_ARECA_SPECIFIC)

/* ANSI SCSI-3 Log Pages retrieved by LOG SENSE. */
#define SUPPORTED_LPAGES			0x00
#define BUFFER_OVERRUN_LPAGE			0x01
#define WRITE_ERROR_COUNTER_LPAGE		0x02
#define READ_ERROR_COUNTER_LPAGE		0x03
#define READ_REVERSE_ERROR_COUNTER_LPAGE	0x04
#define VERIFY_ERROR_COUNTER_LPAGE		0x05
#define NON_MEDIUM_ERROR_LPAGE			0x06
#define LAST_N_ERROR_LPAGE			0x07
#define FORMAT_STATUS_LPAGE			0x08
#define TEMPERATURE_LPAGE			0x0d
#define STARTSTOP_CYCLE_COUNTER_LPAGE		0x0e
#define APPLICATION_CLIENT_LPAGE		0x0f
#define SELFTEST_RESULTS_LPAGE			0x10
#define BACKGROUND_RESULTS_LPAGE		0x15	/* SBC-3 */
#define IE_LPAGE				0x2f

/* Seagate vendor specific log pages. */
#define SEAGATE_CACHE_LPAGE			0x37
#define SEAGATE_FACTORY_LPAGE			0x3e

/*
* FIS ATA status
*/
#define		ATA_S_OK		0x00	/* ok */
#define		ATA_S_ERROR		0x01	/* error */
#define		ATA_S_INDEX		0x02	/* index */
#define		ATA_S_CORR		0x04	/* data corrected */
#define		ATA_S_DRQ		0x08	/* data request */
#define		ATA_S_DSC		0x10	/* drive seek completed */
#define		ATA_S_SERVICE		0x10	/* drive needs service */
#define		ATA_S_DWF		0x20	/* drive write fault */
#define		ATA_S_DMA		0x20	/* DMA ready */
#define		ATA_S_READY		0x40	/* drive ready */
#define		ATA_S_BUSY		0x80	/* busy */

/*
* SCSI status
*/
#define SCSI_STATUS_GOOD			0x00
#define SCSI_STATUS_CHECK_CONDITION		0x02
#define SCSI_STATUS_CONDITION_MET		0x04
#define SCSI_STATUS_BUSY			0x08
#define SCSI_STATUS_INTERMEDIATE		0x10
#define SCSI_STATUS_INTERMEDIATE_MET		0x14
#define SCSI_STATUS_RESERVATION_CONFLICT	0x18
#define SCSI_STATUS_FULL			0x28
#define SCSI_STATUS_ACA_ACTIVE			0x30
#define SCSI_STATUS_ABORTED			0x40

/*
* SCSI sense key
*/
#define SCSI_SK_NO_SENSE		0x00
#define SCSI_SK_RECOVERED_ERROR		0x01
#define SCSI_SK_NOT_READY		0x02
#define SCSI_SK_MEDIUM_ERROR		0x03
#define SCSI_SK_HARDWARE_ERROR		0x04
#define SCSI_SK_ILLEGAL_REQUEST		0x05
#define SCSI_SK_UNIT_ATTENTION		0x06
#define SCSI_SK_DATA_PROTECT		0x07
#define SCSI_SK_BLANK_CHECK		0x08
#define SCSI_SK_VENDOR_SPECIFIC		0x09
#define SCSI_SK_COPY_ABORTED		0x0A
#define SCSI_SK_ABORTED_COMMAND		0x0B
#define SCSI_SK_VOLUME_OVERFLOW		0x0D
#define SCSI_SK_MISCOMPARE		0x0E

/*
* SCSI additional sense code
*/
#define SCSI_ASC_NO_ASC					0x00
#define SCSI_ASC_FILEMARK_DETECTED			0x00
#define SCSI_ASC_LUN_NOT_READY				0x04
#define SCSI_ASC_LOGICAL_UNIT_NOT_RESP_TO_SEL		0x05
#define SCSI_ASC_ECC_ERROR				0x10
#define SCSI_ASC_UNRECOVERED_READ_ERROR			0x11
#define SCSI_ASC_ID_ADDR_MARK_NOT_FOUND			0x12
#define SCSI_ASC_RECORD_NOT_FOUND			0x14
#define SCSI_ASC_PARAMETER_LIST_LENGTH_ERROR		0x1A
#define SCSI_ASC_MISCOMPARE_DURING_VERIFY		0x1D
#define SCSI_ASC_INVALID_OPCODE				0x20
#define SCSI_ASC_LBA_OUT_OF_RANGE			0x21
#define SCSI_ASC_INVALID_FEILD_IN_CDB			0x24
#define SCSI_ASC_LOGICAL_UNIT_NOT_SUPPORTED		0x25
#define SCSI_ASC_INVALID_FIELD_IN_PARAMETER		0x26
#define SCSI_ASC_WRITE_PROTECTED			0x27
#define SCSI_ASC_MEDIA_CHANGED				0x28
#define SCSI_ASC_CMD_SEQUENCE_ERROR			0x2C
#define SCSI_ASC_MEDIUM_FORMAT_CORRUPTED		0x31
#define SCSI_ASC_SAVING_PARAMETERS_NOT_SUPPORT		0x39
#define SCSI_ASC_MEDIUM_NOT_PRESENT			0x3A
#define SCSI_ASC_TOO_MANY_LOGICAL_OBJECTS_ON_PARTITION	0x3B
#define SCSI_ASC_LOGICAL_UNIT_FAILURE			0x3E
#define SCSI_ASC_INTERNAL_TARGET_FAILURE		0x44
#define SCSI_ASC_SCSI_PARITY_ERROR			0x47
#define SCSI_ASC_MEDIA_LOAD_EJECT_FAILURE		0x53
#define SCSI_ASC_SYSTEM_RESOURCE_FAILURE		0x55
#define SCSI_ASC_OPERATOR_MEDIUM_REMOVAL_REQUEST	0x5A
#define SCSI_ASC_FAILURE_PREDICTION_THRESHOLD_EXCEEDED	0x5D
#define SCSI_ASC_CONFIGURATION_FAILURE			0x67

/*
* SCSI additional sense code qualifier
*/
#define SCSI_ASCQ_NO_ASCQ				0x00
#define SCSI_ASCQ_FILEMARK_DETECTED			0x01
#define SCSI_ASCQ_FORMAT_FAILED				0x01
#define SCSI_ASCQ_END_OF_PARTITION_MEDIUM_DETECTED	0x02
#define SCSI_ASCQ_INSUFFICIENT_RESERVATION_RESOURCES	0x02
#define SCSI_ASCQ_INTERVENTION_REQUIRED			0x03
#define SCSI_ASCQ_FORMAT_IN_PROGRESS			0x04
#define SCSI_ASCQ_HIF_GENERAL_HD_FAILURE		0x10
#define SCSI_ASCQ_ATA_PASSTHRU_INFO			0x1D
#define SCSI_ASCQ_MAINTENANCE_IN_PROGRESS		0x80

/*
** SCSI sense ErrorCode
*/
#define ARCSAS_SCSI_RESPONSE_CODE		0x70
#define ARCSAS_SCSI_DIRECT_ACCESS_DEVICE	0x00

/* Virtual Device Inquiry Related */
#define VIRTUALD_INQUIRY_DATA_SIZE		36
#define VPD_PAGE0_VIRTUALD_SIZE			7
#define VPD_PAGE80_VIRTUALD_SIZE		12
#define VPD_PAGE83_VIRTUALD_SIZE		24

#define NVRAM_DATA_MAJOR_VERSION		0
#define NVRAM_DATA_MINOR_VERSION		1

#define ARCSAS_FLASH_ROM_SIZE			0x40000				/* rom region 0x00000....0x40000 256k bytes */
#define ARCSAS_FLASH_SECTOR_SIZE		(64L * 1024)			/* 64K,0x10000 :0x00000...0xFFFF,0x10000...0x1FFFF,0x20000...0x2FFFF,0x30000...0x3FFFF */
#define ARCSAS_FLASH_BIOS_PARAM_SIZE 		(sizeof(BIOS_Info_Page))	/* 256 bytes */
#define ARCSAS_FLASH_DEVICES_MAP_SIZE		(sizeof(ARCSAS_U64)*128)	/* 1K */
#define ARCSAS_FLASH_DEVICES_MAP_OFFSET		ARCSAS_FLASH_ROM_SIZE - 0x20000 /* rom region 0x20000....0x20400 (1K), 8 bytes pattern for each device 8*128=1024 */
#define ARCSAS_FLASH_HBA_EVENT_OFFSET		ARCSAS_FLASH_ROM_SIZE - 0x1FB00 /* rom region 0x20500....0x21500 (4K), 32 bytes one event, 128 events 32*128=4096 */
#define ARCSAS_FLASH_BIOS_PARAM_OFFSET		ARCSAS_FLASH_ROM_SIZE - 0x00100 /* rom region 0x3FF00....0x40000 last 256 bytes */

#define DRIVER_STATUS_IDLE			1	/* The first status */
#define DRIVER_STATUS_STARTING			2	/* Begin to start all modules */
#define DRIVER_STATUS_STARTED			3	/* All modules are all settled. */
#define HBA_REQ_TIMER_AFTER_RESET		20
#define HBA_REQ_TIMER				10
#define HBA_REQ_TIMER_IOCTL			(HBA_REQ_TIMER_AFTER_RESET+3)
#define NO_CURRENT_TIMER			0xFF
#define MSG_QUEUE_DEPTH				32

#define MAX_PASS_THRU_DATA_BUFFER_SIZE		(SECTOR_LENGTH+128)

#define BASE_ADDRESS_MAX_NUM			6

#define SUPPORT_LD_MODE_RAID0			ARCSAS_BIT(0)
#define SUPPORT_LD_MODE_RAID1			ARCSAS_BIT(1)
#define SUPPORT_LD_MODE_RAID10			ARCSAS_BIT(2)
#define SUPPORT_LD_MODE_RAID1E			ARCSAS_BIT(3)
#define SUPPORT_LD_MODE_RAID5			ARCSAS_BIT(4)
#define SUPPORT_LD_MODE_RAID6			ARCSAS_BIT(5)
#define SUPPORT_LD_MODE_RAID50			ARCSAS_BIT(6)
#define SUPPORT_LD_MODE_JBOD			ARCSAS_BIT(7)
#define FEATURE_BGA_MEDIAPATROL_SUPPORT		ARCSAS_BIT(4)

/* PTR_INTEGER is necessary to convert between pointer and integer. */

#define ERR_GENERIC	2
#define ERR_RAID	50
#define ERR_CORE	100
#define ERR_API	150

#define ERR_NONE	0
#define ERR_FAIL	1
/* generic error */
#define ERR_UNKNOWN				(ERR_GENERIC + 1)
#define ERR_NO_RESOURCE				(ERR_GENERIC + 2)
#define ERR_REQ_OUT_OF_RANGE			(ERR_GENERIC + 3)
#define ERR_INVALID_REQUEST			(ERR_GENERIC + 4)
#define ERR_INVALID_PARAMETER			(ERR_GENERIC + 5)
#define ERR_INVALID_LOGICAL_DISK_ID		(ERR_GENERIC + 6)
#define ERR_INVALID_PHYSICAL_DISK_ID		(ERR_GENERIC + 7)
#define ERR_INVALID_EXP_ID			(ERR_GENERIC + 8)
#define ERR_INVALID_PM_ID			(ERR_GENERIC + 9)
#define ERR_INVALID_BLOCK_ID			(ERR_GENERIC + 10)
#define ERR_INVALID_ADAPTER_ID			(ERR_GENERIC + 11)
#define ERR_INVALID_RAID_MODE			(ERR_GENERIC + 12)
#define ERR_INVALID_ENC_ID			(ERR_GENERIC + 13)
#define ERR_INVALID_BU_ID			(ERR_GENERIC + 14)
#define ERR_INVALID_DG_ID			(ERR_GENERIC + 15)
#define ERR_INVALID_ENC_ELEMENT_ID		(ERR_GENERIC + 16)
#define ERR_NOT_SUPPORTED			(ERR_GENERIC + 17)
#define ERR_DRIVER_SENSOR			(ERR_GENERIC + 18)

/* RAID errors */
#define ERR_TARGET_IN_LD_FUNCTIONAL		(ERR_RAID + 1)
#define ERR_TARGET_NO_ENOUGH_SPACE		(ERR_RAID + 2)
#define ERR_HD_IS_NOT_SPARE			(ERR_RAID + 3)
#define ERR_HD_IS_SPARE				(ERR_RAID + 4)
#define ERR_HD_NOT_EXIST			(ERR_RAID + 5)
#define ERR_HD_IS_ASSIGNED_ALREADY		(ERR_RAID + 6)
#define ERR_INVALID_HD_COUNT			(ERR_RAID + 7)
#define ERR_LD_NOT_READY			(ERR_RAID + 8)
#define ERR_LD_NOT_EXIST			(ERR_RAID + 9)
#define ERR_LD_IS_FUNCTIONAL			(ERR_RAID + 10)
#define ERR_HAS_BGA_ACTIVITY			(ERR_RAID + 11)
#define ERR_NO_BGA_ACTIVITY			(ERR_RAID + 12)
#define ERR_BGA_RUNNING				(ERR_RAID + 13)
#define ERR_RAID_NO_AVAILABLE_ID		(ERR_RAID + 14)
#define ERR_LD_NO_ATAPI				(ERR_RAID + 15)
#define ERR_INVALID_RAID6_PARITY_DISK_COUNT	(ERR_RAID + 16)
#define ERR_INVALID_BLOCK_SIZE			(ERR_RAID + 17)
#define ERR_MIGRATION_NOT_NEED			(ERR_RAID + 18)
#define ERR_STRIPE_BLOCK_SIZE_MISMATCH		(ERR_RAID + 19)
#define ERR_MIGRATION_NOT_SUPPORT		(ERR_RAID + 20)
#define ERR_LD_NOT_FULLY_INITED			(ERR_RAID + 21)
#define ERR_LD_NAME_INVALID			(ERR_RAID + 22)

/* API errors */
#define ERR_INVALID_MATCH_ID			(ERR_API + 1)
#define ERR_INVALID_HDCOUNT			(ERR_API + 2)
#define ERR_INVALID_BGA_ACTION			(ERR_API + 3)
#define ERR_HD_IN_DIFF_CARD			(ERR_API + 4)
#define ERR_INVALID_FLASH_TYPE			(ERR_API + 5)
#define ERR_INVALID_FLASH_ACTION		(ERR_API + 6)
#define ERR_TOO_FEW_EVENT			(ERR_API + 7)
#define ERR_VD_HAS_RUNNING_OS			(ERR_API + 8)
#define ERR_DISK_HAS_RUNNING_OS			(ERR_API + 9)
#define ERR_COMMAND_NOT_SUPPURT			(ERR_API + 10)

//The Flags of Eroor Handling
#define EH_READ_VERIFY_REQ_ERROR		ARCSAS_BIT(0)
#define EH_WRITE_REQ_ERROR			ARCSAS_BIT(1)
#define EH_WRITE_RECOVERY_ERROR			ARCSAS_BIT(2)
#define EH_MEDIA_ERROR				ARCSAS_BIT(3)
#define EH_TIMEOUT_ERROR			ARCSAS_BIT(4)

#define CONSISTENCYCHECK_ONLY		0
#define CONSISTENCYCHECK_FIX		1

#define INIT_QUICK			0	//Just initialize first part size of LD
#define INIT_FULLFOREGROUND		1	//Initialize full LD size
#define INIT_FULLBACKGROUND		2	//Initialize full LD size background
#define INIT_NONE			3

#define INIT_QUICK_WITHOUT_EVENT	0xf	// Used for QUICK INIT but set cdb[5]to 0xf so driver won't send event. 

#define BGA_CONTROL_START			0
#define BGA_CONTROL_RESTART			1
#define BGA_CONTROL_PAUSE			2
#define BGA_CONTROL_RESUME			3
#define BGA_CONTROL_ABORT			4
#define BGA_CONTROL_COMPLETE			5
#define BGA_CONTROL_IN_PROCESS			6
#define BGA_CONTROL_TERMINATE_IMMEDIATE		7
#define BGA_CONTROL_AUTO_PAUSE			8

#define LD_STATUS_FUNCTIONAL		0
#define LD_STATUS_DEGRADE		1
#define LD_STATUS_DELETED		2
#define LD_STATUS_MISSING		3 /* LD missing in system. */
#define LD_STATUS_OFFLINE		4
#define LD_STATUS_PARTIALLYOPTIMAL	5 /* r6 w/ 2 pd, 1 hd drops */
#define LD_STATUS_INVALID		0xFF

#define LD_BGA_NONE			0
#define LD_BGA_REBUILD			ARCSAS_BIT(0)
#define LD_BGA_CONSISTENCY_FIX		ARCSAS_BIT(1)
#define LD_BGA_CONSISTENCY_CHECK	ARCSAS_BIT(2)
#define LD_BGA_INIT_QUICK		ARCSAS_BIT(3)
#define LD_BGA_INIT_BACK		ARCSAS_BIT(4)
#define LD_BGA_MIGRATION		ARCSAS_BIT(5)

#define LD_MODE_RAID0		0x0
#define LD_MODE_RAID1		0x1
#define LD_MODE_RAID5		0x5
#define LD_MODE_RAID6		0x6
#define LD_MODE_JBOD		0x0f
#define LD_MODE_RAID10		0x10
#define LD_MODE_RAID1E		0x11
#define LD_MODE_RAID50		0x50
#define LD_MODE_RAID60		0x60
#define LD_MODE_UNKNOWN		0xFF

#define HD_WIPE_MDD		0
#define HD_WIPE_FORCE		1

#define ROUNDING_SCHEME_NONE	0	/* no rounding */
#define ROUNDING_SCHEME_1GB	1	/* 1 GB rounding */
#define ROUNDING_SCHEME_10GB	2	/* 10 GB rounding */

#define SD_SPEED_AUTO		0
#define SD_SPEED_1_5G		1	// current 
#define SD_SPEED_3G		2
#define SD_SPEED_6G		3

#define SECTOR_LENGTH		512

#define FIS_REG_H2D_SIZE_IN_DWORD		5

#define ARCSAS_SATA_GSCR_ID_REG_NUM		0
#define ARCSAS_SATA_GSCR_REVISION_REG_NUM	1
#define ARCSAS_SATA_GSCR_INFO_REG_NUM		2
#define ARCSAS_SATA_GSCR_ERROR_REG_NUM		0x20	//32
#define ARCSAS_SATA_GSCR_ERROR_ENABLE_REG_NUM	0x21	//33
#define ARCSAS_SATA_GSCR_FEATURES_REG_NUM	0x40	//64
#define ARCSAS_SATA_GSCR_FEATURES_ENABLE_REG_NUM	0x60	//96
#define ARCSAS_SATA_PSCR_SSTATUS_REG_NUM	0
#define ARCSAS_SATA_PSCR_SERROR_REG_NUM		1
#define ARCSAS_SATA_PSCR_SCONTROL_REG_NUM	2
#define ARCSAS_SATA_PSCR_SACTIVE_REG_NUM	3

#define SERROR_EXCHANGED		ARCSAS_BIT(26)
#define SERROR_COMM_WAKE		ARCSAS_BIT(18)
#define SERROR_PHYRDY_CHANGE		ARCSAS_BIT(16)

/*
Proposed Interface Between Core Driver and Discover Engine (IBCD)
Objective
Looking for an interface to help extend the flexibility, since Discover Engine
is planned to be used for different applications while the core driver has limited
resource and dedicated function need.
*/

#define SAS_ADDR_SIZE	8

/*
************************************************************************
**
************************************************************************
*/
typedef enum _ARCSAS_QUEUE_COMMAND_RESULT
{
	ARCSAS_QUEUE_COMMAND_RESULT_FINISHED = 0,
	ARCSAS_QUEUE_COMMAND_RESULT_FULL,
	ARCSAS_QUEUE_COMMAND_RESULT_NO_RESOURCE,
	ARCSAS_QUEUE_COMMAND_RESULT_SENT,		/* Request is sent to the hardware and not finished yet. */
	ARCSAS_QUEUE_COMMAND_RESULT_WAIT_REG_SET,
} ARCSAS_QUEUE_COMMAND_RESULT;
/*
************************************************************************
**
************************************************************************
*/
enum
{
	HBA_TIMER_IDLE = 0,
	HBA_TIMER_RUNNING,
	HBA_TIMER_LEAVING,
};
/*
************************************************************************
**
************************************************************************
*/
enum _tag_hba_msg_state
{
	MSG_QUEUE_IDLE = 0,
	MSG_QUEUE_PROC
};
/*
************************************************************************
**
************************************************************************
*/
enum
{
	/* COMMON_DONE_Q_CONFIG (R134h) bits */
	DONE_QUEUE_SIZE_MASK	= (0xFFF << 0),
	DONE_QUEUE_ENABLE	= ARCSAS_BIT(16),
};
/*
************************************************************************
**
************************************************************************
*/
enum
{
	/* module status (module_descriptor) */
	ARCSAS_MOD_VOID = 0,
	ARCSAS_MOD_UNINIT,
	ARCSAS_MOD_REGISTERED,	/* module ops pointer registered */
	ARCSAS_MOD_INITED,	/* resource assigned */
	ARCSAS_MOD_FUNCTIONAL,
	ARCSAS_MOD_STARTED,
	ARCSAS_MOD_DEINIT,	/* extension released, be gone soon */
	ARCSAS_MOD_GONE,
};
/*
************************************************************************
**Resource type
************************************************************************
*/
enum Resource_Type
{
	RESOURCE_CACHED_MEMORY = 0,
	RESOURCE_DISCARDABLE_MEMORY,
	RESOURCE_UNCACHED_MEMORY
};
/*
************************************************************************
**Module event type
************************************************************************
*/
enum Module_Event
{
	ARCSAS_EVENT_MODULE_ALL_STARTED = 0,
	ARCSAS_EVENT_DEVICE_CACHE_MODE_CHANGED,
	ARCSAS_EVENT_SPECIFY_RUNTIME_DEVICE,
	ARCSAS_EVENT_DISCARD_RESOURCE,
	ARCSAS_EVENT_DEVICE_ARRIVAL,
	ARCSAS_EVENT_DEVICE_REMOVAL,
	ARCSAS_EVENT_LOG_GENERATED,
};
/*
************************************************************************
**Error_Handling_State
************************************************************************
*/
enum EH_State
{
	EH_NONE = 0,
	EH_ABORT_REQUEST,
	EH_LU_RESET,
	EH_DEVICE_RESET,
	EH_PORT_RESET,
	EH_CHIP_RESET,
	EH_SET_DISK_DOWN
};
enum _SAS_EH_TIMEOUT_STATE
{
	SAS_EH_TIMEOUT_STATE_NONE = 0,
	SAS_EH_TIMEOUT_STATE_ABORT_REQUEST = 1,
	SAS_EH_TIMEOUT_STATE_LU_RESET = 2,
	SAS_EH_TIMEOUT_STATE_DEVICE_RESET = 3,
	SAS_EH_TIMEOUT_STATE_PORT_RESET = 4,
	SAS_EH_TIMEOUT_STATE_CHIP_RESET = 5,
	SAS_EH_TIMEOUT_STATE_SET_DISK_DOWN = 6,
};
enum _SATA_EH_TIMEOUT_STATE
{
	SATA_EH_TIMEOUT_STATE_NONE = 0,
	SATA_EH_TIMEOUT_STATE_SOFT_RESET_1 = 1,
	SATA_EH_TIMEOUT_STATE_SOFT_RESET_WAIT = 2,
	SATA_EH_TIMEOUT_STATE_SOFT_RESET_0 = 3,
	SATA_EH_TIMEOUT_STATE_HARD_RESET_WAIT = 4,
	SATA_EH_TIMEOUT_STATE_HARD_RESET = 5,
	SATA_EH_TIMEOUT_STATE_SET_DISK_DOWN = 6,
};
enum _SATA_EH_MEDIA_STATE
{
	SATA_EH_MEDIA_STATE_NONE = 0,
	SATA_EH_MEDIA_STATE_READ_LOG_EXTENT = 1,
	SATA_EH_MEDIA_STATE_RETRY = 2,
	SATA_EH_MEDIA_STATE_SOFT_RESET_1 = 3,
	SATA_EH_MEDIA_STATE_SOFT_RESET_0 = 4,
};
/*
************************************************************************
**
************************************************************************
*/
typedef enum
{
	EH_REQ_NOP = 0,
	EH_REQ_ABORT_REQUEST,
	EH_REQ_HANDLE_TIMEOUT,
	EH_REQ_RESET_BUS,
	EH_REQ_RESET_CHANNEL,
	EH_REQ_RESET_DEVICE,
	EH_REQ_RESET_ADAPTER
}eh_req_type_t;
/*
************************************************************************
**Request Type is the type of struct _CCB.
************************************************************************
*/
enum
{
	CCB_TYPE_CORE = 0,
	CCB_TYPE_OS = 1,
	CCB_TYPE_CACHE = 2,
	CCB_TYPE_RAID = 3,
	CCB_TYPE_MUTIPATH = 4,
	CCB_TYPE_CORE_ERROR_HANDLE = 5,
};
/*
************************************************************************
**  SAS/SATA configuration port registers, aka phy registers
************************************************************************
*/
enum
{
	/* Port Config Registers PORT_CONFIG_ADDR, PORT_CONFIG_DATA */
	CONFIG_DEV_INFO = 0x00, /* port device info register for IDENTIFY frame */
	CONFIG_DEV_ADDR_LO = 0x04, /* HBA Port device SAS addr lo register */
	CONFIG_DEV_ADDR_HI = 0x08, /* HBA Port device SAS addr hi register */
	CONFIG_ATT_DEV_INFO = 0x0c, /* attached device info register */
	CONFIG_ATT_DEV_ADDR_LO = 0x10, /* attached device SAS addr lo reg */
	CONFIG_ATT_DEV_ADDR_HI = 0x14, /* attached device SAS addr hi reg */
	CONFIG_SATA_CONTROL = 0x18, /* port SATA control register */
	CONFIG_PHY_STATUS = 0x1c, /* port phy status register */
	CONFIG_SATA_SIG0 = 0x20, /* port SATA signature FIS(Byte 0-3) */
	CONFIG_SATA_SIG1 = 0x24, /* port SATA signature FIS(Byte 4-7) */
	CONFIG_SATA_SIG2 = 0x28, /* port SATA signature FIS(Byte 8-11) */
	CONFIG_SATA_SIG3 = 0x2c, /* port SATA signature FIS(Byte 12-15)*/
	CONFIG_R_ERR_COUNT = 0x30, /* port R_ERR count register */
	CONFIG_CRC_ERR_COUNT = 0x34, /* port CRC error count register */
	CONFIG_WIDE_PORT = 0x38,  /* wide port participating register */
	CONFIG_PHYR_CURRENT0 = 0x80,	/* current connection info 0 */
	CONFIG_PHYR_CURRENT1 = 0x84,	/* current connection info 1 */
	CONFIG_PHYR_CURRENT2 = 0x88,	/* current connection info 2 */
	CONFIG_ID_FRAME0 = 0x100, /* Port device ID frame register DWORD0 */
	CONFIG_ID_FRAME1 = 0x104, /* Port device ID frame register DWORD1 */
	CONFIG_ID_FRAME2 = 0x108, /* Port device ID frame register DWORD2 */
	CONFIG_ID_FRAME3 = 0x10c, /* Port device ID frame register DWORD3 */
	CONFIG_ID_FRAME4 = 0x110, /* Port device ID frame register DWORD4 */
	CONFIG_ID_FRAME5 = 0x114, /* Port device ID frame register DWORD5 */
	CONFIG_ID_FRAME6 = 0x118, /* Port device ID frame register DWORD6 */
	CONFIG_ATT_ID_FRAME0 = 0x11c, /* attached device ID frame register DWORD0 */
	CONFIG_ATT_ID_FRAME1 = 0x120, /* attached device ID frame register DWORD1 */
	CONFIG_ATT_ID_FRAME2 = 0x124, /* attached device ID frame register DWORD2 */
	CONFIG_ATT_ID_FRAME3 = 0x128, /* attached device ID frame register DWORD3 */
	CONFIG_ATT_ID_FRAME4 = 0x12c, /* attached device ID frame register DWORD4 */
	CONFIG_ATT_ID_FRAME5 = 0x130, /* attached device ID frame register DWORD5 */
	CONFIG_ATT_ID_FRAME6 = 0x134, /* attached device ID frame register DWORD6 */
	/* CONFIG_DEV_INFO/CONFIG_ATT_DEV_INFO (0x00) bits */
	PORT_DEV_TYPE_MASK = (0x7 << 0),
	PORT_DEV_INIT_MASK = (0x7 << 9),
	PORT_DEV_TRGT_MASK = (0x7 << 17),
	PORT_DEV_STP_INIT = ARCSAS_BIT(9),
	PORT_DEV_SMP_INIT = ARCSAS_BIT(10),
	PORT_DEV_SSP_INIT = ARCSAS_BIT(11),
	PORT_DEV_STP_TRGT = ARCSAS_BIT(17),
	PORT_DEV_SMP_TRGT = ARCSAS_BIT(18),
	PORT_DEV_SSP_TRGT = ARCSAS_BIT(19),
	//PORT_PHY_ID_MASK = (0xFF << 24),
};
/*
************************************************************************
**
************************************************************************
*/
enum
{
	/* PORT_IRQ_STAT/MASK (R160h) bits */
	PHY_RDY_CHNG_MASK	= ARCSAS_BIT(0),
	HRD_RES_DONE_MASK	= ARCSAS_BIT(1),
	PHY_ID_DONE_MASK	= ARCSAS_BIT(2),
	PHY_ID_FAIL_MASK	= ARCSAS_BIT(3),
	PHY_ID_TIMEOUT		= ARCSAS_BIT(4),
	HARD_RESET_RCVD_MASK	= ARCSAS_BIT(5),
	PORT_SEL_PRESENT_MASK	= ARCSAS_BIT(6),
	COMWAKE_RCVD_MASK	= ARCSAS_BIT(7),
	BRDCST_CHNG_RCVD_MASK	= ARCSAS_BIT(8),
	UNKNOWN_TAG_ERR		= ARCSAS_BIT(9),
	IU_TOO_SHRT_ERR		= ARCSAS_BIT(10),
	IU_TOO_LNG_ERR		= ARCSAS_BIT(11),
	PHY_RDY_CHNG_1_TO_0	= ARCSAS_BIT(12),
	SIG_FIS_RCVD_MASK	= ARCSAS_BIT(16),
	BIST_ACTVT_FIS_RCVD_MASK = ARCSAS_BIT(17),
	ASYNC_NTFCN_RCVD_MASK	= ARCSAS_BIT(18),
	UNASSOC_FIS_RCVD_MASK	= ARCSAS_BIT(19),
	STP_SATA_RX_ERR_MASK	= ARCSAS_BIT(20),
	STP_SATA_TX_ERR_MASK	= ARCSAS_BIT(21),
	STP_SATA_CRC_ERR_MASK	= ARCSAS_BIT(22),
	STP_SATA_DCDR_ERR_MASK	= ARCSAS_BIT(23),
	STP_SATA_PHY_DEC_ERR_MASK = ARCSAS_BIT(24),
	STP_SATA_SYNC_ERR_MASK	= ARCSAS_BIT(25),

	/* PORT_PHY_CONTROL/STATUS bits */
	ARCSAS_STP_LINK_RESET		= ARCSAS_BIT(0), /* phy reset */
	ARCSAS_PHY_HARD_RESET_SEQ	= ARCSAS_BIT(1), /* hard reset + phy reset */
	ARCSAS_PHY_BRDCST_CHNG_NOTIFY	= ARCSAS_BIT(2),
	ARCSAS_SSP_LINK_RESET		= ARCSAS_BIT(3),
	ARCSAS_SAS_LINK_EN		= ARCSAS_BIT(4),

	ARCSAS_MIN_SPP_PHYS_LINK_RATE_MASK_1300	= (0xF << 8),
	ARCSAS_MAX_SPP_PHYS_LINK_RATE_MASK_1300	= (0xF << 12),
	ARCSAS_NEG_SPP_PHYS_LINK_RATE_MASK_OFFSET_1300 = 16,
	ARCSAS_NEG_SPP_PHYS_LINK_RATE_MASK_1300	= (0xF << ARCSAS_NEG_SPP_PHYS_LINK_RATE_MASK_OFFSET_1300),

	ARCSAS_MIN_SPP_PHYS_LINK_RATE_MASK_1320	= (0x7 << 8),
	ARCSAS_MAX_SPP_PHYS_LINK_RATE_MASK_1320	= (0x7 << 12),
	ARCSAS_NEG_SPP_PHYS_LINK_RATE_MASK_OFFSET_1320 = 16,
	ARCSAS_NEG_SPP_PHYS_LINK_RATE_MASK_1320	= (0x3 << ARCSAS_NEG_SPP_PHYS_LINK_RATE_MASK_OFFSET_1320),

	ARCSAS_PHY_READY_MASK	= ARCSAS_BIT(20),
	/* Command Port Registers COMMON_CMD_ADDR, COMMON_CMD_DATA */
	/* command port issue register $i (slot 0-31) to (slot 480-511) */
	CMD_PORT_ISS0 = 0x00,
	CMD_PORT_ISS1 = 0x04,
	CMD_PORT_ISS2 = 0x08,
	CMD_PORT_ISS3 = 0x0c,
	CMD_PORT_ISS4 = 0x10,
	CMD_PORT_ISS5 = 0x14,
	CMD_PORT_ISS6 = 0x18,
	CMD_PORT_ISS7 = 0x1c,
	CMD_PORT_ISS8 = 0x20,
	CMD_PORT_ISS9 = 0x24,
	CMD_PORT_ISS10 = 0x28,
	CMD_PORT_ISS11 = 0x2c,
	CMD_PORT_ISS12 = 0x30,
	CMD_PORT_ISS13 = 0x34,
	CMD_PORT_ISS14 = 0x38,
	CMD_PORT_ISS15 = 0x3c,

	/* cmd port active register $i (slot 0-31) to (slot 480-511) */
	COMMAND_ACTIVE0_1300 = 0x40,
	CMD_PORT_ACTIVE0 = 0x40,
	CMD_PORT_ACTIVE1 = 0x44,
	CMD_PORT_ACTIVE2 = 0x48,
	CMD_PORT_ACTIVE3 = 0x4c,
	CMD_PORT_ACTIVE4 = 0x50,
	CMD_PORT_ACTIVE5 = 0x54,
	CMD_PORT_ACTIVE6 = 0x58,
	CMD_PORT_ACTIVE7 = 0x5c,
	CMD_PORT_ACTIVE8 = 0x60,
	CMD_PORT_ACTIVE9 = 0x64,
	CMD_PORT_ACTIVE10 = 0x68,
	CMD_PORT_ACTIVE11 = 0x6c,
	CMD_PORT_ACTIVE12 = 0x70,
	CMD_PORT_ACTIVE13 = 0x74,
	CMD_PORT_ACTIVE14 = 0x78,
	CMD_PORT_ACTIVE15 = 0x7c,

	/* SATA register set $i task file data register */
	SRS_TASK_FILE_DATA_1300 = 0x80,
	CMD_SATA_TFDATA0 = 0x80,
	CMD_SATA_TFDATA1 = 0x84,
	CMD_SATA_TFDATA2 = 0x88,
	CMD_SATA_TFDATA3 = 0x8c,
	CMD_SATA_TFDATA4 = 0x90,
	CMD_SATA_TFDATA5 = 0x94,
	CMD_SATA_TFDATA6 = 0x98,
	CMD_SATA_TFDATA7 = 0x9c,
	CMD_SATA_TFDATA8 = 0xa0,
	CMD_SATA_TFDATA9 = 0xa4,
	CMD_SATA_TFDATA10 = 0xa8,
	CMD_SATA_TFDATA11 = 0xac,
	CMD_SATA_TFDATA12 = 0xb0,
	CMD_SATA_TFDATA13 = 0xb4,
	CMD_SATA_TFDATA14 = 0xb8,
	CMD_SATA_TFDATA15 = 0xbc,

	/* SATA register set $i association reg */
	SRS_ASSOCIATION_1300 = 0xC0,
	CMD_SATA_ASSOC0 = 0xc0,
	CMD_SATA_ASSOC1 = 0xc4,
	CMD_SATA_ASSOC2 = 0xc8,
	CMD_SATA_ASSOC3 = 0xcc,
	CMD_SATA_ASSOC4 = 0xd0,
	CMD_SATA_ASSOC5 = 0xd4,
	CMD_SATA_ASSOC6 = 0xd8,
	CMD_SATA_ASSOC7 = 0xdc,
	CMD_SATA_ASSOC8 = 0xe0,
	CMD_SATA_ASSOC9 = 0xe4,
	CMD_SATA_ASSOC10 = 0xe8,
	CMD_SATA_ASSOC11 = 0xec,
	CMD_SATA_ASSOC12 = 0xf0,
	CMD_SATA_ASSOC13 = 0xf4,
	CMD_SATA_ASSOC14 = 0xf8,
	CMD_SATA_ASSOC15 = 0xfc,

	CMD_CMRST_OOB_DET	= 0x100, /* COMRESET OOB detect register */
	CMD_CMWK_OOB_DET	= 0x104, /* COMWAKE OOB detect register */
	CMD_CMSAS_OOB_DET	= 0x108, /* COMSAS OOB detect register */
	CMD_BRST_OOB_DET	= 0x10c, /* burst OOB detect register */
	CMD_OOB_SPACE		= 0x110, /* OOB space control register */
	CMD_OOB_BURST		= 0x114, /* OOB burst control register */
	CMD_PHY_TIMER		= 0x118, /* PHY timer control register */
	CMD_PHY_CONFIG0		= 0x11c, /* PHY config register 0 */
	CMD_PHY_CONFIG1		= 0x120, /* PHY config register 1 */
	CMD_SAS_CONTROL0	= 0x124, /* SAS control register 0 */
	CMD_SAS_CONTROL1	= 0x128, /* SAS control register 1 */
	CMD_SAS_CONTROL2	= 0x12c, /* SAS control register 2 */
	CMD_SAS_CONTROL3	= 0x130, /* SAS control register 3 */
	CMD_ID_TEST		= 0x134, /* ID test register */
	CMD_PL_TIMER		= 0x138, /* PL timer register */
	CMD_WD_TIMER		= 0x13c, /* WD timer register */
	CMD_PORT_SEL_COUNT	= 0x140, /* port selector count register */
	CMD_APP_MEM_CONTROL	= 0x144, /* Application Memory Control */
	CMD_XOR_MEM_CONTROL	= 0x148, /* XOR Block Memory Control */
	CMD_DMA_MEM_CONTROL	= 0x14c, /* DMA Block Memory Control */
	CMD_PORT_MEM_CONTROL0	= 0x150, /* Port Memory Control 0 */
	CMD_PORT_MEM_CONTROL1	= 0x154, /* Port Memory Control 1 */
	CMD_SATA_PORT_MEM_CONTROL0 = 0x158, /* SATA Port Memory Control 0 */
	CMD_SATA_PORT_MEM_CONTROL1 = 0x15c, /* SATA Port Memory Control 1 */
	CMD_XOR_MEM_BIST_CONTROL = 0x160, /* XOR Memory BIST Control */
	CMD_XOR_MEM_BIST_STATUS = 0x164, /* XOR Memroy BIST Status */
	CMD_DMA_MEM_BIST_CONTROL = 0x168, /* DMA Memory BIST Control */
	CMD_DMA_MEM_BIST_STATUS = 0x16c, /* DMA Memory BIST Status */
	CMD_PORT_MEM_BIST_CONTROL = 0x170, /* Port Memory BIST Control */
	CMD_PORT_MEM_BIST_STATUS0 = 0x174, /* Port Memory BIST Status 0 */
	CMD_PORT_MEM_BIST_STATUS1 = 0x178, /* Port Memory BIST Status 1 */
	CMD_STP_MEM_BIST_CONTROL = 0x17c, /* STP Memory BIST Control */
	CMD_STP_MEM_BIST_STATUS0 = 0x180, /* STP Memory BIST Status 0 */
	CMD_STP_MEM_BIST_STATUS1 = 0x184, /* STP Memory BIST Status 1 */
	CMD_RESET_COUNT		= 0x188, /* Reset Count */
	CMD_MONTR_DATA_SEL	= 0x18C, /* Monitor Data/Select */
	CMD_PLL_PHY_CONFIG	= 0x190, /* PLL/PHY Configuration */
	CMD_PHY_CONTROL		= 0x194, /* PHY Control and Status */
	CMD_PHY_TEST_COUNT0	= 0x198, /* Phy Test Count 0 */
	CMD_PHY_TEST_COUNT1	= 0x19C, /* Phy Test Count 1 */
	CMD_PHY_TEST_COUNT2	= 0x1A0, /* Phy Test Count 2 */
	CMD_APP_ERR_CONFIG	= 0x1A4, /* Application Error Configuration */
	CMD_PND_FIFO_CONTROL0	= 0x1A8, /* Pending FIFO Control 0 */
	CMD_HOST_CONTROL	= 0x1AC, /* Host Control Status */
	CMD_HOST_WR_DATA	= 0x1B0, /* Host Write Data */
	CMD_HOST_RD_DATA	= 0x1B4, /* Host Read Data */
	CMD_PHY_MODE_21		= 0x1B8, /* Phy Mode 21 */
	CMD_SL_MODE0		= 0x1BC, /* SL Mode 0 */
	CMD_SL_MODE1		= 0x1C0, /* SL Mode 1 */
	CMD_PND_FIFO_CONTROL1	= 0x1C4, /* Pending FIFO Control 1 */
	CMD_PORT_ACTIVE16	= 0x240, /* Command Active 16 */
	CMD_PORT_ACTIVE17	= 0x244, /* Command Active 17 */
	CMD_PORT_ACTIVE18	= 0x248, /* Command Active 18 */
	CMD_PORT_ACTIVE19	= 0x24C, /* Command Active 19 */
	CMD_PORT_ACTIVE20	= 0x250, /* Command Active 20 */
	CMD_PORT_ACTIVE21	= 0x254, /* Command Active 21 */
	CMD_PORT_ACTIVE22	= 0x258, /* Command Active 22 */
	CMD_PORT_ACTIVE23	= 0x25C, /* Command Active 23 */
	CMD_PORT_ACTIVE24	= 0x260, /* Command Active 24 */
	CMD_PORT_ACTIVE25	= 0x264, /* Command Active 25 */
	CMD_PORT_ACTIVE26	= 0x268, /* Command Active 26 */
	CMD_PORT_ACTIVE27	= 0x26C, /* Command Active 27 */
	CMD_PORT_ACTIVE28	= 0x270, /* Command Active 28 */
	CMD_PORT_ACTIVE29	= 0x274, /* Command Active 29 */
	CMD_PORT_ACTIVE30	= 0x278, /* Command Active 30 */
	CMD_PORT_ACTIVE31	= 0x27C, /* Command Active 31 */
	CMD_SATA_TFDATA16	= 0x280, /* SATA Register Set 16 Task File Data */
	CMD_SATA_TFDATA17	= 0x284, /* SATA Register Set 17 Task File Data */
	CMD_SATA_TFDATA18	= 0x288, /* SATA Register Set 18 Task File Data */
	CMD_SATA_TFDATA19	= 0x28C, /* SATA Register Set 19 Task File Data */
	CMD_SATA_TFDATA20	= 0x290, /* SATA Register Set 20 Task File Data */
	CMD_SATA_TFDATA21	= 0x294, /* SATA Register Set 21 Task File Data */
	CMD_SATA_TFDATA22	= 0x298, /* SATA Register Set 22 Task File Data */
	CMD_SATA_TFDATA23	= 0x29C, /* SATA Register Set 23 Task File Data */
	CMD_SATA_TFDATA24	= 0x2A0, /* SATA Register Set 24 Task File Data */
	CMD_SATA_TFDATA25	= 0x2A4, /* SATA Register Set 25 Task File Data */
	CMD_SATA_TFDATA26	= 0x2A8, /* SATA Register Set 26 Task File Data */
	CMD_SATA_TFDATA27	= 0x2AC, /* SATA Register Set 27 Task File Data */
	CMD_SATA_TFDATA28	= 0x2B0, /* SATA Register Set 28 Task File Data */
	CMD_SATA_TFDATA29	= 0x2B4, /* SATA Register Set 29 Task File Data */
	CMD_SATA_TFDATA30	= 0x2B8, /* SATA Register Set 30 Task File Data */
	CMD_SATA_TFDATA31	= 0x2BC, /* SATA Register Set 31 Task File Data */
	CMD_SATA_ASSOC16	= 0x2C0, /* SATA Reg Set 16 Association */
	CMD_SATA_ASSOC17	= 0x2C4, /* SATA Reg Set 17 Association */
	CMD_SATA_ASSOC18	= 0x2C8, /* SATA Reg Set 18 Association */
	CMD_SATA_ASSOC19	= 0x2CC, /* SATA Reg Set 19 Association */
	CMD_SATA_ASSOC20	= 0x2D0, /* SATA Reg Set 20 Association */
	CMD_SATA_ASSOC21	= 0x2D4, /* SATA Reg Set 21 Association */
	CMD_SATA_ASSOC22	= 0x2D8, /* SATA Reg Set 22 Association */
	CMD_SATA_ASSOC23	= 0x2DC, /* SATA Reg Set 23 Association */
	CMD_SATA_ASSOC24	= 0x2E0, /* SATA Reg Set 24 Association */
	CMD_SATA_ASSOC25	= 0x2E4, /* SATA Reg Set 25 Association */
	CMD_SATA_ASSOC26	= 0x2E8, /* SATA Reg Set 26 Association */
	CMD_SATA_ASSOC27	= 0x2EC, /* SATA Reg Set 27 Association */
	CMD_SATA_ASSOC28	= 0x2F0, /* SATA Reg Set 28 Association */
	CMD_SATA_ASSOC29	= 0x2F4, /* SATA Reg Set 29 Association */
	CMD_SATA_ASSOC30	= 0x2F8, /* SATA Reg Set 30 Association */
	CMD_SATA_ASSOC31	= 0x2FC, /* SATA Reg Set 31 Association */
	COMMAND_ACTIVE0_1320	= 0x300,
	SRS_TASK_FILE_DATA_1320	= 0x800,
	SRS_ASSOCIATION_1320	= 0xA00,
};
/*
************************************************************************
**
************************************************************************
*/
enum
{
	/* COMMON_COAL_CONFIG (R148h) bits */
	INT_COAL_COUNT_MASK	= (0x1FF << 0),
	INT_COAL_ENABLE		= ARCSAS_BIT(16),

	/* COMMON_COAL_TIMEOUT (R14Ch) bits ,(R2014Ch)*/
	COAL_TIMER_MASK		= (0xFFFF << 0),
	COAL_TIMER_UNIT_1MS	= ARCSAS_BIT(16),   /* 0: 6.67 ns, 1: 1 us */

	/* COMMON_INT_CAUSE/ENABLE (R150h) bits */
	INT_CMD_CMPL		= ARCSAS_BIT(0), /* cmd completion */
	INT_CMD_CMPL_MASK	= ARCSAS_BIT(0),
	INT_CMD_ISSUE_STOPPED	= ARCSAS_BIT(1), /* cmd issue stopped */
	INT_SRS_EVENT		= ARCSAS_BIT(3), /* SRS event */

	INT_PORT_MASK_OFFSET	= 8,
	INT_PORT_MASK		= (0xFF << INT_PORT_MASK_OFFSET),

	INT_PORT_STOP_MASK_OFFSET = 16,
	INT_PORT_STOP_MASK	= (0xFF << INT_PORT_STOP_MASK_OFFSET),

	INT_PHY_MASK_OFFSET	= 4,
	INT_PHY_MASK		= (0x0F << INT_PHY_MASK_OFFSET),

	INT_NON_SPCFC_NCQ_ERR_1300	= ARCSAS_BIT(24),	/* Non-specific NCQ error */
	INT_NON_SPCFC_NCQ_ERR_1320	= ARCSAS_BIT(25),	/* Non-specific NCQ error */
	INT_I2C_SLAVE_EVENT		= ARCSAS_BIT(25),	/* slave I2C event */
	INT_MEM_PAR_ERR			= ARCSAS_BIT(26),	/* int mem parity err */
	INT_DMA_PCIE_TIMEOUT		= ARCSAS_BIT(27),	/* DMA to PCIE timeout */
	INT_PRD_BC_READ_ERROR		= ARCSAS_BIT(28),	/* PRD BC err for read cmd */
	INT_SOFTWARE1_EVENT		= ARCSAS_BIT(29),	/* software event 1 */
	INT_SOFTWARE0_EVENT		= ARCSAS_BIT(30),	/* software event 0 */
	//INT_I2C_MASTER_EVENT		= ARCSAS_BIT(31),	/* master I2C event */
};

/*
************************************************************************
**
************************************************************************
*/
enum
{
	/* global controller registers */
	HBA_CAP_REG			= 0x00,		/* host capabilities */
	/* HOST_CAP_REG bits */
	//ARCSAS_HBA_CAP_64		= ARCSAS_BIT(31),	/* PCI DAC (64-bit DMA) support */

	HBA_CONTROL_1300_REG		= 0x04,		/* global host control */
	HBA_CONTROL_1320_REG		= 0x10204,	/* global host control */
	HBA_CHIP_CONFIG_1320_REG	= 0x10104,	/* global host control */

	/* HBA_CONTROL bits */
	ARCSAS_HBA_RESET		= ARCSAS_BIT(0),	/* reset controller; self-clear */
	ARCSAS_HBA_INT_ENABLE		= ARCSAS_BIT(1),	/* global IRQ enable */
	ARCSAS_HBA_DONEQ_ENABLE		= ARCSAS_BIT(2),	/* global done queue enable */

	HBA_IRQ_STATE_1300_REG		= 0x08,		/* global irq status, interrupt status */
	HBA_IRQ_STATE_1320_REG		= 0x10200,	/* global irq status, interrupt status */
	HBA_1320_MAIN_INT_CAUSE		= 0x10200,	/* global irq status, interrupt status */
	HBA_1320_MAIN_INT_ENABLE	= 0x10204,	/* global host control */
	HBA_1320_F0_INT_ENABLE		= 0x1020C,
	HBA_1320_F1_INT_ENABLE		= 0x10210,
	HBA_1320_F2_INT_ENABLE		= 0x10214,
	HBA_1320_F3_INT_ENABLE		= 0x10218,

	IRQ_COM_IN_I2O_IOP0_1320	= ARCSAS_BIT(0),
	IRQ_COM_IN_I2O_IOP1_1320	= ARCSAS_BIT(1),
	IRQ_COM_IN_I2O_IOP2_1320	= ARCSAS_BIT(2),
	IRQ_COM_IN_I2O_IOP3_1320	= ARCSAS_BIT(3),
	IRQ_COM_OUT_I2O_HOS0_1320	= ARCSAS_BIT(4),
	IRQ_COM_OUT_I2O_HOS1_1320	= ARCSAS_BIT(5),
	IRQ_COM_OUT_I2O_HOS2_1320	= ARCSAS_BIT(6),
	IRQ_COM_OUT_I2O_HOS3_1320	= ARCSAS_BIT(7),
	IRQ_PCIF_TO_CPU_DRBL0_1320	= ARCSAS_BIT(8),
	IRQ_PCIF_TO_CPU_DRBL1_1320	= ARCSAS_BIT(9),
	IRQ_PCIF_TO_CPU_DRBL2_1320	= ARCSAS_BIT(10),
	IRQ_PCIF_TO_CPU_DRBL3_1320	= ARCSAS_BIT(11),
	IRQ_PCIF_DRBL0_1320		= ARCSAS_BIT(12),
	IRQ_PCIF_DRBL1_1320		= ARCSAS_BIT(13),
	IRQ_PCIF_DRBL2_1320		= ARCSAS_BIT(14),
	IRQ_PCIF_DRBL3_1320		= ARCSAS_BIT(15),
	IRQ_XOR_A_1320			= ARCSAS_BIT(16),
	IRQ_XOR_B_1320			= ARCSAS_BIT(17),
	IRQ_SAS_A_1320			= ARCSAS_BIT(18),
	IRQ_SAS_B_1320			= ARCSAS_BIT(19),
	IRQ_CPU_CNTRL_1320		= ARCSAS_BIT(20),
	IRQ_GPIO_1320			= ARCSAS_BIT(21),
	IRQ_UART_1320			= ARCSAS_BIT(22),
	IRQ_SPI_1320			= ARCSAS_BIT(23),
	IRQ_I2C_1320			= ARCSAS_BIT(24),
	IRQ_SGPIO_1320			= ARCSAS_BIT(25),
	IRQ_COM_ERR_1320		= ARCSAS_BIT(29),
	IRQ_I2O_ERR_1320		= ARCSAS_BIT(30),
	//IRQ_PCIE_ERR_1320 		= ARCSAS_BIT(31),
	IRQ_SAS_AB_1320			= ARCSAS_BIT(18) | ARCSAS_BIT(19),

	/* HBA_IRQ_STAT_1300 (0x08) bits */
	ARCSAS_SAS_SATA_IRQ_PENDING	= ARCSAS_BIT(0),
	ARCSAS_XOR_IRQ_PENDING		= ARCSAS_BIT(4),

	HBA_PORTS_IMPL_REG		= 0x0C,	/* bitmap of implemented ports ,ports implemented bitmask */
	HBA_SOC_PHY_CTL_REG		= 0x40,	/* SOC PHY Control */
	HBA_SOC_PORTS_IMP_REG		= 0x9C,	/* SOC Port Implemented */
	HBA_GBL_PORT_TYPE_REG		= 0xA0,	/* port type HBA_GBL_PORT_TYPE_REG=VENDOR_SPECIFIC_REG_START=VSR_PORT_TYPE_REG */

	HOST_PORTS_IMPL0	= ARCSAS_BIT(0),	/* HOST port0 existing  */
	HOST_PORTS_IMPL1	= ARCSAS_BIT(1),	/* HOST port1 existing  */
	HOST_PORTS_IMPL2	= ARCSAS_BIT(2),	/* HOST port2 existing  */
	HOST_PORTS_IMPL3	= ARCSAS_BIT(3),	/* HOST port3 existing  */
	HOST_PORTS_IMPL4	= ARCSAS_BIT(4),	/* HOST port0 existing  */
	HOST_PORTS_IMPL5	= ARCSAS_BIT(5),	/* HOST port1 existing  */
	HOST_PORTS_IMPL6	= ARCSAS_BIT(6),	/* HOST port2 existing  */
	HOST_PORTS_IMPL7	= ARCSAS_BIT(7),	/* HOST port3 existing  */
	HOST_XOR_IMPL		= ARCSAS_BIT(8),	/* HOST XOR port existing  */

	/* VENDOR_SPECIFIC */
	/* vendor specific registers */
	VSR_PORT_TYPE_REG	= VENDOR_SPECIFIC_REG_START, /* port type register */

	/* VSR_PORT_TYPE bits */
	MODE_SAS_PORT0_MASK	= ARCSAS_BIT(0),  /* SATA if 0 is set */
	MODE_SAS_PORT1_MASK	= ARCSAS_BIT(1),
	MODE_SAS_PORT2_MASK	= ARCSAS_BIT(2),
	MODE_SAS_PORT3_MASK	= ARCSAS_BIT(3),
	MODE_SAS_PORT4_MASK	= ARCSAS_BIT(4),
	MODE_SAS_PORT5_MASK	= ARCSAS_BIT(5),
	MODE_SAS_PORT6_MASK	= ARCSAS_BIT(6),
	MODE_SAS_PORT7_MASK	= ARCSAS_BIT(7),
	MODE_SAS_SATA		= (MODE_SAS_PORT0_MASK | MODE_SAS_PORT1_MASK | MODE_SAS_PORT2_MASK | MODE_SAS_PORT3_MASK | MODE_SAS_PORT4_MASK | MODE_SAS_PORT5_MASK |	MODE_SAS_PORT6_MASK | MODE_SAS_PORT7_MASK),

	MODE_AUTO_DET_PORT0	= ARCSAS_BIT(8),
	MODE_AUTO_DET_PORT1	= ARCSAS_BIT(9),
	MODE_AUTO_DET_PORT2	= ARCSAS_BIT(10),
	MODE_AUTO_DET_PORT3	= ARCSAS_BIT(11),
	MODE_AUTO_DET_PORT4	= ARCSAS_BIT(12),
	MODE_AUTO_DET_PORT5	= ARCSAS_BIT(13),
	MODE_AUTO_DET_PORT6	= ARCSAS_BIT(14),
	MODE_AUTO_DET_PORT7	= ARCSAS_BIT(15),
	MODE_AUTO_DET_EN	= (MODE_AUTO_DET_PORT0 | MODE_AUTO_DET_PORT1 | MODE_AUTO_DET_PORT2 | MODE_AUTO_DET_PORT3 | MODE_AUTO_DET_PORT4 | MODE_AUTO_DET_PORT5 | MODE_AUTO_DET_PORT6 | MODE_AUTO_DET_PORT7),
	/*
	************************************************
	**  SAS/SATA port common (A/B)registers
	************************************************
	*/
	COMMON_CONFIG		= 0x100, /* configuration register, SAS/SATA port configuration */
	COMMON_PORT_CONFIG	= 0x100,
	COMMON_CONTROL		= 0x104, /* control register, SAS/SATA port control/status */
	COMMON_PORT_CONTROL	= 0X104,
	COMMON_PORT_STATUS	= 0X104,
	COMMON_LST_ADDR		= 0x108, /* command list DMA addr */
	COMMON_LST_ADDR_HI	= 0x10c, /* command list DMA addr hi */
	COMMON_FIS_ADDR		= 0x110, /* FIS rx buf addr */
	COMMON_FIS_ADDR_HI	= 0x114, /* FIS rx buf addr hi */

	COMMON_POST_Q_CONFIG	= 0x120, /* delivery queue configuration */
	COMMON_POST_Q_ADDR	= 0x124, /* delivery queue base address */
	COMMON_POST_Q_ADDR_HI	= 0x128, /* delivery queue base address hi */
	COMMON_POST_Q_WR_PTR	= 0x12c, /* delivery queue write pointer */
	COMMON_POST_Q_RD_PTR	= 0x130, /* delivery queue read pointer */
	COMMON_DONE_Q_CONFIG	= 0x134, /* completion queue configuration */
	COMMON_DONE_Q_ADDR	= 0x138, /* completion queue base address */
	COMMON_DONE_Q_ADDR_HI	= 0x13c, /* completion queue base address hi */
	COMMON_DONE_Q_WR_PTR	= 0x140, /* completion queue write pointer */
	COMMON_DONE_Q_RD_PTR	= 0x144, /* completion queue read pointer */
	COMMON_COAL_CONFIG	= 0x148, /* interrupt coalescing config */
	COMMON_COAL_TIMEOUT	= 0x14c, /* interrupt coalescing time wait */
	COMMON_INT_CAUSE	= 0x150, /* interrupt status */
	COMMON_INT_ENABLE	= 0x154, /* interrupt enable/disable mask */
	COMMON_SRS_IRQ_STAT_0	= 0x158, /* 1300 1320 SATA register set status interrupt status */
	COMMON_SRS_IRQ_MASK_0	= 0x15c, /* 1300 1320 SATA register set intr enable/disable mask Enable SRS interrupt */
	COMMON_SRS_IRQ_STAT_1	= 0x160, /* 1320 SATA register set status interrupt status */
	COMMON_SRS_IRQ_MASK_1	= 0x164, /* 1320 SATA register set intr enable/disable mask */
	/*
	***************************************
	**
	***************************************
	*/
	COMMON_1300_WORK_ADDR		= 0x118, /* workarea buf addr */
	COMMON_1300_WORK_ADDR_HI	= 0x11c, /* workarea buf addr hi */

	ARC1300_NON_SPECIF_NCQ_ERR_0	= 0x1A0, /* SRS Non-specific NCQ Error */

	COMMON_CMD_ADDR_1300		= 0x1B8, /* Command Address */
	COMMON_CMD_DATA_1300		= 0x1BC, /* Command Data */
	PORT_IRQ_STATE0_1300		= 0x160, /* Port 0 interrupt status */
	PORT_IRQ_MASK0_1300		= 0x164, /* Port 0 interrupt enable/disable mask */
	/* ports 1-3 follow after this 0x168,0x16c,0x170,0x174,0x178,0x17c */
	PORT_IRQ_STATE4_1300		= 0x200, /* Port 4 interrupt status */
	PORT_IRQ_MASK4_1300		= 0x204, /* Port 4 interrupt enable/disable mask */
	/* ports 5-7 follow after this 0x208,0x20c,0x210,0x214,0x218,0x21c */
	PORT_PHY_CONTROL0_1300		= 0x180, /* port 0 serial status/control */
	/* ports 1-3 follow after this 0x184,0x188,0x18c */
	PORT_PHY_CONTROL4_1300		= 0x220, /* port 4 serial status/control */
	/* ports 5-7 follow after this 0x224,0x228,0x22c*/
	PORT_CONFIG_ADDR0_1300		= 0x1c0, /* Port 0 config address */
	PORT_CONFIG_DATA0_1300		= 0x1c4, /* Port 0 config data */
	/* ports 1-3 follow after this 0x1c8,0x1cc,0x1d0,0x1d4,0x1d8,0x1dc */
	PORT_CONFIG_ADDR4_1300		= 0x230, /* Port 4 config address */
	PORT_CONFIG_DATA4_1300		= 0x234, /* Port 4 config data */
	/* ports 5-7 follow after this 0x238,0x23c,0x240,0x244,0x248,0x24c */
	PORT_VSR_ADDR0_1300		= 0x1e0, /* port 0 Vendor Specific Register addr */
	PORT_VSR_DATA0_1300		= 0x1e4, /* port 0 Vendor Specific Register Data */
	/* ports 1-3 follow after this 0x1e8,0x1ec,0x1f0,0x1f4,0x1f8,0x1fc */
	PORT_VSR_ADDR4_1300		= 0x250, /* port 4 Vendor Specific Register addr */
	PORT_VSR_DATA4_1300		= 0x254, /* port 4 Vendor Specific Register Data */
	/* ports 5-7 follow after this 0x258,0x25c,0x260,0x264,0x268,0x26c */
	/*
	***************************************
	**
	***************************************
	*/
	COMMON_1320_STP_REG_SET_0	= 0x118, /* STP/SATA Register Set Enable */
	COMMON_1320_STP_REG_SET_1	= 0x11C,

	ARC1320_NON_SPECIF_NCQ_ERR_0	= 0x168, /* SRS Non-specific NCQ Error */
	ARC1320_NON_SPECIF_NCQ_ERR_1	= 0x16C,

	COMMON_CMD_ADDR_1320		= 0x170, /* Command Address */
	COMMON_CMD_DATA_1320		= 0x174, /* Command Data */
	PORT_IRQ_STATE0_1320		= 0x180, /* Port 0 interrupt status */
	PORT_IRQ_MASK0_1320		= 0x184, /* Port 0 interrupt enable/disable mask */
	/* ports 1-3 follow after this 0x188,0x18C,0x190,0x194,0x198,0x19C */
	PORT_IRQ_STATE4_1320		= 0x1A0, /* Port 4 interrupt status */
	PORT_IRQ_MASK4_1320		= 0x1A4, /* Port 4 interrupt enable/disable mask */
	/* ports 5-7 follow after this 0x1A8,0x1AC,0x1B0,0x1B4,0x1B8,0x1BC */
	PORT_ALL_INT_STATUS_1320	= 0x1C0, /* all port int status */
	PORT_PHY_CONTROL0_1320		= 0x1D0, /* port 0 serial status/control */
	/* ports 1-3 follow after this 0x1D4,0x1D8,0x1DC*/
	PORT_PHY_CONTROL4_1320		= 0x1E0, /* port 4 serial status/control */
	/* ports 5-7 follow after this 0x1E4,0x1E8,0x1EC*/
	PORT_CONFIG_ADDR0_1320		= 0x200, /* Port 0 config address */
	PORT_CONFIG_DATA0_1320		= 0x204, /* Port 0 config data */
	/* ports 1-3 follow after this 0x208,0x20C,0x210,0x214,0x218,0x21C*/
	PORT_CONFIG_ADDR4_1320		= 0x220, /* Port 4 config address */
	PORT_CONFIG_DATA4_1320		= 0x224, /* Port 4 config data */
	/* ports 5-7 follow after this 0x228,0x22C,0x230,0x234,0x238,0x23C */
	PORT_VSR_ADDR0_1320		= 0x250, /* port 0 Vendor Specific Register addr */
	PORT_VSR_DATA0_1320		= 0x254, /* port 0 Vendor Specific Register Data */
	/* ports 1-3 follow after this 0x258,0x25C,0x260,0x264,0x268,0x26C */
	/* multiplexing !!!!!!!!!!!! */
	PORT_VSR_ADDR4_1320		= 0x250, /* port 4 Vendor Specific Register addr */
	PORT_VSR_DATA4_1320		= 0x254, /* port 4 Vendor Specific Register Data */
	/* ports 5-7 follow after this 0x258,0x25c,0x260,0x264,0x268,0x26C*/
	PORT_VSR_ADDR_ALL_1320		= 0x290, /* All port Vendor Specific Register addr */
	PORT_VSR_DATA_ALL_1320		= 0x294, /* All port Vendor Specific Register Data */

	ARC1320_NON_NCQ_ERR_0		= 0x168, /* SRS Non-specific NCQ Error */
	ARC1320_NON_NCQ_ERR_1		= 0x16C,
	ARC1320_MEM_PARITY_ERR		= 0x178, /* Memory parity error */
	/*
	***************************************
	**
	***************************************
	*/
	/* COMMON_CONFIG register bits */
	ARCSAS_CMD_TBL_BE	= ARCSAS_BIT(0),
	ARCSAS_OPEN_ADDR_BE	= ARCSAS_BIT(1),
	ARCSAS_RSPNS_FRAME_BE	= ARCSAS_BIT(2),
	ARCSAS_DATA_BE		= ARCSAS_BIT(3),
	ARCSAS_SAS_SATA_RST	= ARCSAS_BIT(5),
	EN_SATA_REG_16		= ARCSAS_BIT(16),
	EN_SATA_REG_17		= ARCSAS_BIT(17),
	EN_SATA_REG_18		= ARCSAS_BIT(18),
	EN_SATA_REG_19		= ARCSAS_BIT(19),
	EN_SATA_REG_20		= ARCSAS_BIT(20),
	EN_SATA_REG_21		= ARCSAS_BIT(21),
	EN_SATA_REG_22		= ARCSAS_BIT(22),
	EN_SATA_REG_23		= ARCSAS_BIT(23),
	EN_SATA_REG_24		= ARCSAS_BIT(24),
	EN_SATA_REG_25		= ARCSAS_BIT(25),
	EN_SATA_REG_26		= ARCSAS_BIT(26),
	EN_SATA_REG_27		= ARCSAS_BIT(27),
	EN_SATA_REG_28		= ARCSAS_BIT(28),
	EN_SATA_REG_29		= ARCSAS_BIT(29),
	EN_SATA_REG_30		= ARCSAS_BIT(30),
	//EN_SATA_REG_31	= ARCSAS_BIT(31),
	/* pci config register */
	ARCSAS_PCI_REG_CMD		= 0x04,
	ARCSAS_PCI_REG_DEV_CTRL_1300	= 0xE8,
	ARCSAS_PCI_REG_DEV_CTRL_1320	= 0x78,
	ARCSAS_PCI_REG_LINK_STAT_1300	= 0xF2,
	ARCSAS_PCI_REG_LINK_STAT_1320	= 0x82,
	ARCSAS_PCI_REG_PHY_CTRL1_1300	= 0x40,
	ARCSAS_PCI_REG_MSI_CAP_ID	= 0x50,
	ARCSAS_PCI_REG_MSI_CTRL		= 0x52,
	ARCSAS_PCI_REG_VEN_UNIQ3	= 0x60,
	ARCSAS_PCI_REG_PHY_CTRL2_1300	= 0x90,
	/* pci config register bit */
	ARCSAS_PCI_IO_EN		= ARCSAS_BIT(0),
	ARCSAS_PCI_MEM_EN		= ARCSAS_BIT(1),
	ARCSAS_PCI_BM_EN		= ARCSAS_BIT(2),	/* enable bus master */
	ARCSAS_PCI_INT_DIS		= ARCSAS_BIT(10),	/* disable INTx for MSI_EN */
	ARCSAS_PCI_DEV_EN_1300		= ARCSAS_PCI_IO_EN | ARCSAS_PCI_MEM_EN | ARCSAS_PCI_BM_EN,
	ARCSAS_PCI_DEV_EN_1320		= ARCSAS_PCI_MEM_EN | ARCSAS_PCI_BM_EN,
	ARCSAS_PCI_MSI_EN		= ARCSAS_BIT(0),
	ARCSAS_PCI_RD_REQ_SIZE		= 0x4000,
	ARCSAS_PCI_RD_REQ_MASK		= 0x00007000,
	//ARCSAS_PCI_PAD_TEST_MASK	= 0xFF000000, /* Test Pad bits located in Vendor Unique 3 */
	ARCSAS_PCI_PHY_OFF		= (0xF << 12),
	ARCSAS_PCI_PHY_PWR_ON		= (0xF << 24),
	ARCSAS_PCI_NEG_LINK_WD		= (0x3F << 4),
	ARCSAS_PCI_NEG_LINK_WD_OFFS 	= 4,
	ARCSAS_PCI_LINK_SPD		= (0x0F << 0),
	ARCSAS_PCI_LINK_SPD_OFFS	= 0,

	/* COMMON_CONTROL : port control/status bits (R104h) */
	EN_CMD_ISSUE		= ARCSAS_BIT(0), /* enable cmd issue */
	RESET_CMD_ISSUE		= ARCSAS_BIT(1), /* reset cmd issue */
	ERR_STOP_CMD_ISSUE	= ARCSAS_BIT(3), /* cmd stop-on-err enable */
	EN_FIS_RCV		= ARCSAS_BIT(4), /* FIS rx enable */
	CMD_CMPL_SELF_CLEAR	= ARCSAS_BIT(5), /* self-clearing int mode */
	CMD_CMPL_IRQ_MODE	= ARCSAS_BIT(5), /* self-clear CMD_CMPL */
	EN_SATA_RETRY_2		= ARCSAS_BIT(6), /* for 1320 */
	EN_RSPNS_RCV		= ARCSAS_BIT(7), /* raw response rx */
	EN_SATA_RETRY_1		= ARCSAS_BIT(8), /* for 1300 */
	EN_PORT_XMT_START_1320	= 8,	/* EN_PORT_0_XMT= ARCSAS_BIT(08),for 1320 */
	EN_PORT_0_XMT_1320	= ARCSAS_BIT(8), /* for 1300 */
	EN_PORT_1_XMT_1320	= ARCSAS_BIT(9), /* for 1300 */
	EN_PORT_2_XMT_1320	= ARCSAS_BIT(10), /* for 1300 */
	EN_PORT_3_XMT_1320	= ARCSAS_BIT(11), /* for 1300 */
	EN_PORT_XMT_START_1300	= 12,	/* EN_PORT_0_XMT= ARCSAS_BIT(12),for 1300 */
	EN_PORT_0_XMT_1300	= ARCSAS_BIT(12), /* for 1300 */
	EN_PORT_1_XMT_1300	= ARCSAS_BIT(13), /* for 1300 */
	EN_PORT_2_XMT_1300	= ARCSAS_BIT(14), /* for 1300 */
	EN_PORT_3_XMT_1300	= ARCSAS_BIT(15), /* for 1300 */
	EN_SATA_REG_0		= ARCSAS_BIT(16),
	EN_SATA_REG_1		= ARCSAS_BIT(17),
	EN_SATA_REG_2		= ARCSAS_BIT(18),
	EN_SATA_REG_3		= ARCSAS_BIT(19),
	EN_SATA_REG_4		= ARCSAS_BIT(20),
	EN_SATA_REG_5		= ARCSAS_BIT(21),
	EN_SATA_REG_6		= ARCSAS_BIT(22),
	EN_SATA_REG_7		= ARCSAS_BIT(23),
	EN_SATA_REG_8		= ARCSAS_BIT(24),
	EN_SATA_REG_9		= ARCSAS_BIT(25),
	EN_SATA_REG_10		= ARCSAS_BIT(26),
	EN_SATA_REG_11		= ARCSAS_BIT(27),
	EN_SATA_REG_12		= ARCSAS_BIT(28),
	EN_SATA_REG_13		= ARCSAS_BIT(29),
	EN_SATA_REG_14		= ARCSAS_BIT(30),
	//EN_SATA_REG_15	= ARCSAS_BIT(31),

	EN_PORT_XMT_START	= 12, /* EN_PORT_0_XMT= ARCSAS_BIT(12),for 1300 */
	EN_PORT_XMT_START2	= 8, /* EN_PORT_0_XMT= ARCSAS_BIT(08),for 1320 */

	/* COMMON_POST_Q_CONFIG (R120h) bits */
	POST_QUEUE_SIZE_MASK	= (0xFFF << 0),
	POST_QUEUE_ENABLE	= ARCSAS_BIT(16),
};
/*
************************************************************************
**
************************************************************************
*/

/*
************************************************************************
**
************************************************************************
*/
enum
{
	MAP_TGT_COUNT = 0,
	MAP_TGT_INFO
};
/*
************************************************************************
**
************************************************************************
*/
enum
{
	STATUS_REQUEST_OK = 0,
	STATUS_REQUEST_QUEUE_FULL
};

/*
************************************************************************
**
************************************************************************
*/
enum sas_dev_type
{
	NO_DEVICE = 0,		/* protocol */
	SAS_END_DEV = 1,	/* protocol */
	EDGE_DEV = 2,		/* protocol */
	FANOUT_DEV = 3,		/* protocol */
	SAS_HA = 4,
	SATA_DEV = 5,
	SATA_PM = 7,
	SATA_PM_PORT = 8,
};
/*
************************************************************************
**
************************************************************************
*/
enum sas_phy_linkrate
{
	PHY_LINKRATE_NONE = 0,
	PHY_LINKRATE_UNKNOWN = 0,
	PHY_DISABLED,
	PHY_RESET_PROBLEM,
	PHY_SPINUP_HOLD,
	PHY_PORT_SELECTOR,
	PHY_LINKRATE_1_5 = 0x08,
	PHY_LINKRATE_G1 = PHY_LINKRATE_1_5,
	PHY_LINKRATE_3 = 0x09,
	PHY_LINKRATE_G2 = PHY_LINKRATE_3,
	PHY_LINKRATE_6 = 0x0A,
	PHY_LINKRATE_G3 = PHY_LINKRATE_6,
};
/*
************************************************************************
**
************************************************************************
*/
enum sas_oob_mode
{
	OOB_NOT_CONNECTED,
	SATA_OOB_MODE,
	SAS_OOB_MODE
};
/*
************************************************************************
**
************************************************************************
*/
enum sas_proto
{
	SATA_PROTO = 1,
	SAS_PROTO_SMP = 2,		/* protocol */
	SAS_PROTO_STP = 4,		/* protocol */
	SAS_PROTO_SSP = 8,		/* protocol */
	SAS_PROTO_ALL = 0xE,
};
/*
************************************************************************
**definitions for discovery algorithm use
************************************************************************
*/
enum
{
	SAS_SIMPLE_LEVEL_DESCENT = 0,
	SAS_UNIQUE_LEVEL_DESCENT
};
/*
************************************************************************
**
************************************************************************
*/
enum
{
	SAS_10_COMPATIBLE = 0,
	SAS_11_COMPATIBLE
};
/*
************************************************************************
**definitions for SMP function results
************************************************************************
*/
enum SMPFunctionResult
{
	SMP_REQUEST_ACCEPTED = 0,
	SMP_FUNCTION_ACCEPTED = 0,
	SMP_UNKNOWN_FUNCTION,
	SMP_FUNCTION_FAILED,
	SMP_INVALID_REQUEST_FRAME_LENGTH,
	SMP_PHY_DOES_NOT_EXIST = 0x10,
	SMP_INDEX_DOES_NOT_EXIST,
	SMP_PHY_DOES_NOT_SUPPORT_SATA,
	SMP_UNKNOWN_PHY_OPERATION,
	SMP_UNKNOWN_PHY_TEST_FUNCTION,
	SMP_UNKNOWN_PHY_TEST_FUNCTION_IN_PROGRESS,
	SMP_PHY_VACANT,
	SMP_PHY_EVENT_INFORMATION_SOURCE_NOT_SUPPORTED,
	SMP_ZONE_VIOLATION = 0x20,
	SMP_PHYSICAL_PRESENCE_NOT_ASSERTED,
	SMP_UNKNOWN_ENABLE_DISABLE_ZONING_VALUE
};
/*
************************************************************************
**RoutingAttribute
************************************************************************
*/
enum RoutingAttribute
{
	DIRECT = 0,
	SUBTRACTIVE,
	TABLE,
	/*
		this attribute is a psuedo attribute, used to reflect the function
		result of SMP_PHY_VACANT in a fabricated discover response
	*/
	PHY_NOT_USED = 15
};
/*
************************************************************************
**ConnectorType
************************************************************************
*/
enum ConnectorType
{
	UNKNOWN_CONNECTOR = 0,
	SFF_8470_EXTERNAL_WIDE,
	SFF_8484_INTERNAL_WIDE = 0x10,
	SFF_8484_COMPACT_INTERNAL_WIDE,
	SFF_8482_BACKPLANE = 0x20,
	SATA_HOST_PLUG,
	SAS_DEVICE_PLUG,
	SATA_DEVICE_PLUG
};
/*
************************************************************************
**RouteFlag
************************************************************************
*/
enum DisableRouteEntry
{
	ENABLED = 0,
	DISABLED
};
/*
************************************************************************
**PhyOperation
************************************************************************
*/
enum PhyOperation
{
	PHY_NOP = 0,
	LINK_RESET,
	HARD_RESET,
	DISABLE,
	CLEAR_ERROR_LOG = 5,
	CLEAR_AFFILIATION,
	TRANSMIT_SATA_PORT_SELECTION_SIGNAL,
	CLEAR_STP_NEXUS_LOSS
};
/*
************************************************************************
**EnableDisableZoning
************************************************************************
*/
enum EnableDisableZoning
{
	NO_CHANGE = 0,
	ENABLE_ZONING,
	DISABLE_ZONING,
};
/*
************************************************************************
**BroadcastType
************************************************************************
*/
enum BroadcastType
{
	BROADCAST_CHANGE = 0,
	BROADCAST_RESERVED_CHANGE0,
	BROADCAST_RESERVED_CHANGE1,
	BROADCAST_SES,
	BROADCAST_EXPANDER,
	BROADCAST_ASYNCHRONOUS_EVENT,
	BROADCAST_RESERVED_CHANGE3,
	BROADCAST_RESERVED_CHANGE4,
};
/*
************************************************************************
** DescriptorType
************************************************************************
*/
enum DescriptorType
{
	LONG_FORMAT_DESCRIPTOR = 0,
	SHORT_FORMAT_DESCRIPTOR,
};
/*
************************************************************************
** PortType
************************************************************************
*/
enum PortType
{
	PORT_IS_TARGET = 0,
	PORT_IS_INITIATOR
};
/*
************************************************************************
**   The structures assume a char bitfield is valid, this is compiler
** dependent defines would be more portable, but less descriptive
** the Identify frame is exchanged following OOB, for this
** code it contains the identity information for the attached device
** and the initiator application client.
************************************************************************
*/
enum
{
	FRAME_PORT_TYPE_SMP	= ARCSAS_BIT(1), /* 0x02 */
	FRAME_PORT_TYPE_STP	= ARCSAS_BIT(2), /* 0x04 */
	FRAME_PORT_TYPE_SSP	= ARCSAS_BIT(3), /* 0x08 */
	FRAME_ATT_DEV_TYPE_SMP	= ARCSAS_BIT(1), /* 0x02 */
	FRAME_ATT_DEV_TYPE_STP	= ARCSAS_BIT(2), /* 0x04 */
	FRAME_ATT_DEV_TYPE_SSP	= ARCSAS_BIT(3), /* 0x08 */
	FRAME_ATT_DEV_SATA_DEV	= ARCSAS_BIT(0), /* 0x01 */
	FRAME_ATT_DEV_SATA_HOST	= ARCSAS_BIT(0), /* 0x01 */
	FRAME_ATT_DEV_SATA_SELECTOR = ARCSAS_BIT(7), /* 0x80 */
};
/*
*************************************************************
**	DPC
**	defer procedure call
*************************************************************
*/
struct _DPC
{
	void (*dpcfun)(PACB,void *);
	void *arg;
};
/*
*************************************************************
**	system event element structure
*************************************************************
*/
struct _OS_EVENT_ELEMENT
{
	u_int32_t	ErrorCode;
	u_int8_t	Strings[68];
};
/*
*************************************************************
**	discovery element structure
*************************************************************
*/
struct _SMP_ELEMENT
{
	PDiscovery		pDiscovery;
	PDomain_Port		pPort;
	PVOID			pBuffer;

	u_int8_t		nTgt;
	u_int8_t		PhyId;
	u_int8_t		CurrentState;
	u_int8_t		Reserved[5];
};
/*
*************************************************************
**	event structure
*************************************************************
*/
struct _EVENT_ELEMENT   /* 32BYTES */
{
/*
********************************************************
** <second> bit 05,04,03,02,01,00: 0 - 59
** <minute> bit 11,10,09,08,07,06: 0 - 59
** <month>  bit       15,14,13,12: 1 - 12
** <hour>   bit 21,20,19,18,17,16: 0 - 59
** <day>    bit    26,25,24,23,22: 1 - 31
** <year>   bit    31,30,29,28,27: 0=2000,31=2031
********************************************************
*/
	u_int32_t	TimeStamp;	/* 4bytes: y.d.h.m.m.s */
	u_int16_t	DeviceID;	/* 2bytes: scsi id, scsi lun */
	u_int8_t	EventID;	/* 1bytes: 0...31 */
	u_int8_t	EventType;	/* 1bytes: slot type */
#define ARCSAS_EVENT_TYPE_MESSAGE_ONLY		0
#define ARCSAS_EVENT_TYPE_PM_SLOT 		1
#define ARCSAS_EVENT_TYPE_EXPANDER_SLOT		2
#define ARCSAS_EVENT_TYPE_HBA_SLOT		3
#define ARCSAS_EVENT_TYPE_PM			4
#define ARCSAS_EVENT_TYPE_EXPANDER		5
#define ARCSAS_EVENT_TYPE_ENCLOSURE		6
#define ARCSAS_EVENT_TYPE_HBA			7

	/*
	********************************************************
	**
	********************************************************
	*/
	u_int32_t	ErrorCode;	/* 4bytes: */
	u_int16_t	ParentIndexChildSlot;	/* 2bytes: Parent,Child */
	u_int16_t	EventFlag;	/* 2bytes: */
#define ARCSAS_EVENT_FLAG_ERROR_INFO_RECORD	ARCSAS_BIT(0)	/* EventScratchPad:"ERR_INFO_RECORD" */
#define	ARCSAS_EVENT_FLAG_DEVICE_ARRIVAL	ARCSAS_BIT(1)	/* EventScratchPad:Enc#1 Slot#1,Pm#1 Dev#1, Dev#1 */
#define	ARCSAS_EVENT_FLAG_DEVICE_REMOVAL	ARCSAS_BIT(2)	/* EventScratchPad:Enc#1 Slot#1,Pm#1 Dev#1, Dev#1 */
#define ARCSAS_EVENT_FLAG_DEVICE_FAILED		ARCSAS_BIT(3)	/* EventScratchPad:Enc#1 Slot#1,Pm#1 Dev#1, Dev#1 */
#define ARCSAS_EVENT_FLAG_DEVICE_READING_ERROR	ARCSAS_BIT(4)	/* EventScratchPad:Enc#1 Slot#1,Pm#1 Dev#1, Dev#1 */
#define ARCSAS_EVENT_FLAG_HW_FAILED		ARCSAS_BIT(5)	/* EventScratchPad:RTC Battery,... */
#define ARCSAS_EVENT_FLAG_RAID			ARCSAS_BIT(6)	/* EventScratchPad:CREATE VOLUME */
								/* EventScratchPad:DELETE VOLUME */
								/* EventScratchPad:ABORT REBUILDING */
								/* EventScratchPad:START REBUILDING */
								/* EventScratchPad:COMPLETE REBUILD */
								/* EventScratchPad:ABORT INIT */
								/* EventScratchPad:START INIT */
								/* EventScratchPad:COMPLETE INIT */
								/* EventScratchPad:STOP INIT */
								/* EventScratchPad:VOLUME DEGRADED */
#define ARCSAS_EVENT_FLAG_INVALID_SLOT_NUMBER	ARCSAS_BIT(7)	/* EventScratchPad:Invalid slot number */

	u_int8_t	EventScratchPad[16];	/* 16bytes: scratch pad for EventFlag description */
};
/*
************************************************************
**	Device ID
************************************************************
*/
struct _PCI_DEVICE_ID
{
	u_int8_t	pci_device_id[4];
};
/*
************************************************************
**	Black name
************************************************************
*/
struct _BLACK_NAME
{
	u_int8_t	black_name[16];
};
/*
************************************************************************
**	Primary Data Type
************************************************************************
*/
union _ARCSAS_U64
{
	struct {
		u_int32_t low;
		u_int32_t high;
	} parts;
	u_int64_t value;
};
/*
************************************************************************
**
************************************************************************
*/
struct _NDI_DEVI_NOTIFY
{
	PACB		pACB;
	u_int16_t	EntryIndex;
	u_int16_t	NOTIFY_Flag;
};
/*
************************************************************************
**
************************************************************************
*/
struct _TdList
{
	TdList		*flink;
	TdList		*blink;
};
/*
************************************************************************
**
************************************************************************
*/
struct _Timer_Request
{
	PVOID			timerData;
	Timer_CBFunc		timerCBFunc;
	struct _TdList		timerLink;
	u_int32_t		timerRunning;
	int32_t			timeout;
};
/*
************************************************************************
**
************************************************************************
*/
struct _Unmap_Block_Descriptor
{
	ARCSAS_U64	block;		/* byte 0,1,2,3,4,5,6,7 */
	u_int32_t	n_block;	/* byte 08,09,10,11 */
	u_int8_t	Reserved[4];	/* byte 12,13,14,15 */
};
/*
************************************************************************
**
************************************************************************
*/
struct _PRDTableWalkCtx
{
	PVOID		pPRDEntry;
	int		avail;
	int		prd_entry_count;
};
/*
************************************************************************
**
************************************************************************
*/
struct mod_notif_param
{
	PVOID		p_param;
	u_int16_t	hi;
	u_int16_t	lo;

	/* for event processing */
	u_int32_t	event_id;
	u_int16_t	dev_id;
	u_int8_t	severity_lvl;
	u_int8_t	param_count;
};
/*
*********************************************************************************************
** ARC1300 PRD Table:	DWord0: Data Base Address Lower 32 bits
**			DWord1: Data Base Address Upper 32 bits
**			DWord2: reserved (31:0 reserved)
**			DWord3: Transfer bytes count (31:22 reserved,21:0 Transfer bytes count)
*********************************************************************************************
*/
struct _sgd_3g_prd
{
	ARCSAS_U64	baseAddr;	/* DWord0,DWord1 */
	u_int32_t	Reserved;	/* DWord2:this field value always zero in Marvell PRD table */
	u_int32_t	size;		/* Dword3 */
};
/*
************************************************************************
** ARC1320 PRD Table:	DWord0: Data Base Address Lower 32 bits
**			DWord1: Data Base Address Upper 32 bits
**			DWord2: struct size_ctl_is
************************************************************************
*/
struct size_ctl_is
{
	u_int32_t	size:22;		/* bit0...21-transfer byte count,little endian */
	u_int32_t	Reserved:2;		/* bit22..23-reserved */
	u_int32_t	sgl_chained:4;		/* bit24..27-misc control,bit24 is sgl chained flag */
	u_int32_t	interface_select:4;	/* bit28..31-interface select */
};
//#if _LONG_LONG_ALIGNMENT== 8 && _LONG_LONG_ALIGNMENT_32== 4
#pragma pack(4)
//#endif
struct _sgd_6g_prd
{
	ARCSAS_U64		baseAddr;	/* DWord0,DWord1 */
	struct size_ctl_is	sci;		/* DWord2 */
	/*
	********************************************
	** DWord2:	size:bit0..21-transfer byte count,
	**		reserved:bit22..23-reserved,
	**		mc:bit24..27-misc control,bit24 is chained,
	**		is:bit28..31-interface select
	********************************************
	*/
};
//#if _LONG_LONG_ALIGNMENT== 8 && _LONG_LONG_ALIGNMENT_32== 4
#pragma pack()
//#endif
/*
**********************************
**  Inquiry Data format
** typedef struct _INQUIRYDATA
** {
**	u_int8_t DeviceType : 5;
**	u_int8_t DeviceTypeQualifier : 3;
**	u_int8_t DeviceTypeModifier : 7;
**	u_int8_t RemovableMedia : 1;
**	u_int8_t Versions;
**	u_int8_t ResponseDataFormat : 4;
**	u_int8_t HiSupport : 1;
**	u_int8_t NormACA : 1;
**	u_int8_t ReservedBit : 1;
**	u_int8_t AERC : 1;
**	u_int8_t AdditionalLength;
**	u_int8_t Reserved[2];
**	u_int8_t SoftReset : 1;
**	u_int8_t CommandQueue : 1;
**	u_int8_t Reserved2 : 1;
**	u_int8_t LinkedCommands : 1;
**	u_int8_t Synchronous : 1;
**	u_int8_t Wide16Bit : 1;
**	u_int8_t Wide32Bit : 1;
**	u_int8_t RelativeAddressing : 1;
**	u_int8_t Pci_Ven_ID[8];
**	u_int8_t ProductId[16];
**	u_int8_t ProductRevisionLevel[4];
**	u_int8_t VendorSpecific[20];
**	u_int8_t Reserved3[40];
** } INQUIRYDATA, *PINQUIRYDATA;
**********************************
*/
struct list_head
{
	struct list_head *next, *prev;
};
/*
*****************************************************************************
**
*****************************************************************************
*/
#define MODEPAGE00	0x00
#define MODEPAGE01	0x01
#define MODEPAGE02	0x02
#define MODEPAGE03	0x03
#define MODEPAGE04	0x04
#define MODEPAGE05	0x05
#define MODEPAGE07	0x07
#define MODEPAGE08	0x08
#define MODEPAGE0A	0x0A
#define MODEPAGE0C	0x0C
#define MODEPAGE19	0x19
#define MODEPAGE1A	0x1A
#define MODEPAGE1C	0x1C
#define MODEPAGE3F	0x3F

#define	ARCSAS_CDB_INQUIRY_CMDDT	0x02
#define	ARCSAS_CDB_INQUIRY_EVPD		0x01
#define	ARCSAS_VPD_PAGE_CODE		1
#define	ARCSAS_VPD_PAGE_LENGTH		3
#define	ARCSAS_VPD_PAGE_DATA		4
#define	ARCSAS_VPD_ID_CODESET		0
#define	ARCSAS_VPD_ID_TYPE		1
#define	ARCSAS_VPD_ID_LENGTH		3
#define	ARCSAS_VPD_ID_DATA		4

#define ARCSAS_DIRECT_ACCESS_DEVICE		0x00	// disks
#define ARCSAS_SEQUENTIAL_ACCESS_DEVICE		0x01	// tapes
#define ARCSAS_PRINTER_DEVICE			0x02	// printers
#define ARCSAS_PROCESSOR_DEVICE			0x03	// scanners, printers, etc
#define ARCSAS_WRITE_ONCE_READ_MULTIPLE_DEVICE	0x04	// worms
#define ARCSAS_READ_ONLY_DIRECT_ACCESS_DEVICE	0x05	// cdroms
#define ARCSAS_SCANNER_DEVICE			0x06	// scanners
#define ARCSAS_OPTICAL_DEVICE			0x07	// optical disks
#define ARCSAS_MEDIUM_CHANGER			0x08	// jukebox
#define ARCSAS_COMMUNICATION_DEVICE		0x09	// network
// 0xA and 0xB are obsolete
#define ARCSAS_ARRAY_CONTROLLER_DEVICE		0x0C
#define ARCSAS_SCSI_ENCLOSURE_DEVICE		0x0D
#define ARCSAS_REDUCED_BLOCK_DEVICE		0x0E	// e.g., 1394 disk
#define ARCSAS_OPTICAL_CARD_READER_WRITER_DEVICE 0x0F
#define ARCSAS_BRIDGE_CONTROLLER_DEVICE		0x10
#define ARCSAS_OBJECT_BASED_STORAGE_DEVICE	0x11	// OSD
#define ARCSAS_LOGICAL_UNIT_NOT_PRESENT_DEVICE	0x7F
/*
************************************************************************
**inquiry Vital product data page code
************************************************************************
*/
struct _EVPD_INQUIRYDATA
{
	u_int8_t DeviceType : 5;
	u_int8_t DeviceTypeQualifier : 3;

	u_int8_t EVPD_PageCode;
	u_int8_t Reserved;
	u_int8_t EVPD_PageLength;
};
struct _SCSI_MODE_HEADER_6
{
	u_int8_t datalen;
	u_int8_t medium_type;
	u_int8_t dev_specific;
	u_int8_t block_descr_len;
};
/*==============================================*/
struct _SCSI_MODE_HEADER_10
{
	u_int8_t datalen[2];
	u_int8_t medium_type;
	u_int8_t dev_specific;
	u_int8_t reserved[2];
	u_int8_t block_descr_len[2];
};
/*==============================================*/
struct _SCSI_MODE_BLOCK_DESCRIPTOR/*for direct access type*/
{
	u_int8_t num_blocks[4];
	u_int8_t density_code;
	u_int8_t block_len[3];
};
/*==============================================*/
struct _MODEPAGE00_VENDOR_UNIQUE_PAGE
{
	u_int8_t PageCode : 6;			/* 0x80 */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;			/* 0x0E */

	u_int8_t QPE_SSM_UAI_MRG_ARHES;		/* 0x51 */
	u_int8_t ASDPE_CMDAC_RRNDE_CPE;		/* 0x21 */
	u_int8_t Reserved5;
	u_int8_t FDD_CAEN;			/* 0x12 */
	u_int8_t IGRA_AVERP_EQUIET;		/* 0x00 */
	u_int8_t Reserved6;			/* 0x00 */
	u_int8_t ADC_LEDMODE;			/* 0x40 */
	u_int8_t Temperature;			/* 0x00 */
	u_int8_t CommandAgingLimitHi;		/* 0x00 */
	u_int8_t CommandAgingLimitLow;		/* 0x30 */
	u_int8_t QPE_Read_Threshold;		/* 0x0A */
	u_int8_t QPE_Write_Threshold;		/* 0x0A */
	u_int8_t DRRT_FFMT;			/* 0x00 */
	u_int8_t FCERT_IRT_IVR;			/* 0x00 */
};
/*==============================================*/
struct _MODEPAGE01_READWRITE_ERROR_RECOVERY_PAGE
{
	u_int8_t PageCode : 6;		/* 0x81 */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x0A */

	u_int8_t DCRBit : 1;		/* 0xC0 */
	u_int8_t DTEBit : 1;
	u_int8_t PERBit : 1;
	u_int8_t EERBit : 1;
	u_int8_t RCBit : 1;
	u_int8_t TBBit : 1;
	u_int8_t ARRE : 1;
	u_int8_t AWRE : 1;
	u_int8_t ReadRetryCount;	/* 0x00 */
	u_int8_t CorrectionSpan;
	u_int8_t HeadOffsetCount;
	u_int8_t DataStrobeOffsetCount;
	u_int8_t Reserved4;		/* 0x00 */
	u_int8_t WriteRetryCount;	/* 0x00 */
	u_int8_t Reserved5;		/* 0x00 */
	u_int8_t RecoveryTimeLimit[2];	/* 0x0000 */
};
/*==============================================*/
struct _MODEPAGE02_DISCONNECT_RECONNECT_PAGE
{
	u_int8_t PageCode : 6;			/* 0x82 */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;			/* 0x0E */

	u_int8_t ReadBufferFullRatio;		/* 0x00 */
	u_int8_t WriteBufferEmptyRatio;		/* 0x00 */
	u_int8_t BusInactivityLimit[2];		/* 0x0000 */
	u_int8_t BusDisconnectTimeLimit[2];	/* 0x0000 */
	u_int8_t BusConnectTimeLimit[2];	/* 0x0000 */
	u_int8_t MaximumBurstSize[2];		/* 0x0000 */
	u_int8_t DataTransferDisconnect : 2;	/* 0x00 */
	u_int8_t Reserved2[3];			/* 0x000000 */
};
/*==============================================*/
struct _MODEPAGE03_FORMAT_DEVICE_PAGE
{
	u_int8_t PageCode : 6;
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;			/* 0x16 */

	u_int8_t TracksPerZone[2];
	u_int8_t AlternateSectorsPerZone[2];
	u_int8_t AlternateTracksPerZone[2];
	u_int8_t AlternateTracksPerLogicalUnit[2];
	u_int8_t SectorsPerTrack[2];
	u_int8_t BytesPerPhysicalSector[2];
	u_int8_t Interleave[2];
	u_int8_t TrackSkewFactor[2];
	u_int8_t CylinderSkewFactor[2];
	u_int8_t Reserved2 : 4;
	u_int8_t SurfaceFirst : 1;
	u_int8_t RemovableMedia : 1;
	u_int8_t HardSectorFormating : 1;
	u_int8_t SoftSectorFormating : 1;
	u_int8_t Reserved3[3];
};
/*==============================================*/
struct _MODEPAGE04_RIGID_DISKDRIVE_GEOMETRY_PAGE
{
	u_int8_t PageCode : 6;
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;			/* 0x16 */

	u_int8_t NumberOfCylinders[3];
	u_int8_t NumberOfHeads;
	u_int8_t StartingCylinderWritePrecompensation[3];
	u_int8_t StartingCylinderReducedWriteCurrent[3];
	u_int8_t DriveStepRate[2];
	u_int8_t LandingZoneCyclinder[3];
	u_int8_t RotationalPositionLock : 2;
	u_int8_t Reserved2 : 6;
	u_int8_t RotationOffset;
	u_int8_t Reserved3;
	u_int8_t MediumRoataionRateInRPM[2];
	u_int8_t Reserved4[2];
};
/*==============================================*/
struct _MODEPAGE05_FLEXIBLE_DISK_PAGE
{
	u_int8_t PageCode : 6;
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x1E */

	u_int8_t TransferRate[2];
	u_int8_t NumberOfHeads;
	u_int8_t SectorsPerTrack;
	u_int8_t BytesPerSector[2];
	u_int8_t NumberOfCylinders[2];
	u_int8_t StartWritePrecom[2];
	u_int8_t StartReducedCurrent[2];
	u_int8_t StepRate[2];
	u_int8_t StepPluseWidth;
	u_int8_t HeadSettleDelay[2];
	u_int8_t MotorOnDelay;
	u_int8_t MotorOffDelay;

	u_int8_t Reserved2 : 5;
	u_int8_t MotorOnAsserted : 1;
	u_int8_t StartSectorNumber : 1;
	u_int8_t TrueReadySignal : 1;

	u_int8_t StepPlusePerCyclynder : 4;
	u_int8_t Reserved3 : 4;

	u_int8_t WriteCompenstation;
	u_int8_t HeadLoadDelay;
	u_int8_t HeadUnloadDelay;

	u_int8_t Pin2Usage : 4;
	u_int8_t Pin34Usage : 4;

	u_int8_t Pin1Usage : 4;
	u_int8_t Pin4Usage : 4;

	u_int8_t MediumRotationRate[2];
	u_int8_t Reserved4[2];
};
/*==============================================*/
struct _MODEPAGE07_VERIFY_ERROR_RECOVERY_PAGE
{
	u_int8_t PageCode : 6;		/* 0x87 */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x0A */

	u_int8_t EER_PER_DTE_DCR;	/* 0x00 */
	u_int8_t VerifyRetryCount;	/* 0x01 */
	u_int8_t CorrectionSpan;	/* 0x00 */
	u_int8_t Reserved5[5];		/* 0x0000000000 */
	u_int8_t VerifyRecoveryTime[2];	/* 0x0000 */
};
/*==============================================*/
struct _MODEPAGE08_CACHING_PAGE
{
	u_int8_t PageCode : 6;			/* 0x88 */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;			/* 0x12 */

	u_int8_t ReadDisableCache : 1;		/* 0x04 */
	u_int8_t MultiplicationFactor : 1;
	u_int8_t WriteCacheEnable : 1;
	u_int8_t Reserved2 : 5;
	u_int8_t WriteRetensionPriority : 4;	/* 3.3,3.2,3.1,3.0,0x00 */
	u_int8_t ReadRetensionPriority : 4;	/* 3.7,3.6,3.5,3.4 */
	u_int8_t DisablePrefetchTransfer[2];	/* 0xFFFF */
	u_int8_t MinimumPrefetch[2];		/* 0x0000 */
	u_int8_t MaximumPrefetch[2];		/* 0xFFFF */
	u_int8_t MaximumPrefetchCeiling[2];	/* 0x0000 */
	u_int8_t FSW_LBCSS_RDA;
	u_int8_t NumberofCacheSegments;		/* 0x0E */
	u_int8_t CacheSegmentSize[2];		/* 0x0000 */
	u_int8_t Reserved16;			/* 0x00 */
	u_int8_t NonCacheSegmentSize[3];	/* 0x000000 */
};
/*==============================================*/
struct _MODEPAGE0A_CONTROL_MODE_PAGE
{
	u_int8_t PageCode : 6;		/* 0x8A */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x0A */

	u_int8_t RLEC;			/* 0x00 */
#define SCB_RLEC			0x01	/* Report Log Exception Cond */
	u_int8_t Queue_flags;		/* 0x00 */
#define SCP_QUEUE_ALG_MASK		0xF0
#define SCP_QUEUE_ALG_RESTRICTED	0x00
#define SCP_QUEUE_ALG_UNRESTRICTED	0x10
#define SCP_QUEUE_ERR			0x02	/* Queued I/O aborted for CACs */
#define SCP_QUEUE_DQUE			0x01	/* Queued I/O disabled */
	u_int8_t EECA_RAENP_UAAENP_EAENP;	/* 0x00 */
#define SCP_EECA			0x80	/* Enable Extended CA */
#define SCP_RAENP			0x04	/* Ready AEN Permission */
#define SCP_UAAENP			0x02	/* UA AEN Permission */
#define SCP_EAENP			0x01	/* Error AEN Permission */
	u_int8_t Reserved5;		/* 0x00 */
	u_int8_t Ready_AEN_Holdoff_Period[2];	/* 0x0000 */
	u_int8_t Busy_Timeout_Period[2];
	u_int8_t Extended_Selftest_Routine_Completion_Time[2];
};
/*==============================================*/
struct _MODEPAGE0C_NOTCH_PARTITION_PAGE
{
	u_int8_t PageCode : 6;		/* 0x8C */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x16 */

	u_int8_t ND_LPN;		/* 0x10 */
	u_int8_t Reserved3;		/* 0x00 */
	u_int8_t MaxinumNumberofNotches[2];	/* 0x000B */
	u_int8_t ActiveNotch[2];
	u_int8_t StartingBoundary[4];
	u_int8_t EndingBoundary[4];
	u_int8_t PagesNotched[8];		/* 0x0000000000000100 */
};
/*==============================================*/
struct _MODEPAGE19_PORT_CONTROL_PAGE
{
	u_int8_t PageCode : 6;			/* 0x99 */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;			/* 0x06 */

	u_int8_t Reserved2;
	u_int8_t ProtocolIdentifier;		/* 0x01 */
	u_int8_t SynchronousTransferTimeout[2];	/* 0x00 */
	u_int8_t Reserved6[2];			/* 0x00 */
};
/*==============================================*/
struct _MODEPAGE1A_POWER_CONTROL_PAGE
{
	u_int8_t PageCode : 6;		/* 0x1A */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x0A */

	u_int8_t Reserved2;
	u_int8_t Standby : 1;
	u_int8_t Idle : 1;
	u_int8_t Reserved3 : 6;

	u_int8_t IdleTimer[4];		/* [0]=MSB, [3]=LSB */
	u_int8_t StandbyTimer[4];	/* [0]=MSB, [3]=LSB */
};
/*==============================================*/
struct _MODEPAGE1C_INFORMATION_EXCEPTION_CONTROL_PAGE
{
	u_int8_t PageCode : 6;		/* 0x1C */
	u_int8_t Reserved : 1;
	u_int8_t PageSavable : 1;
	u_int8_t PageLength;		/* 0x0A */

	u_int8_t LogErr : 1;		/* 0x00 */
	u_int8_t Reserved2 : 1;
	u_int8_t Test : 1;
	u_int8_t Dexcpt : 1;
	u_int8_t Reserved3 : 3;
	u_int8_t Perf : 1;

	u_int8_t ReportMethod : 4;	/* 0x00 */
	u_int8_t Reserved4 : 4;

	u_int8_t IntervalTimer[4];	/* 0x00 [0]=MSB, [3]=LSB */
	u_int8_t ReportCount[4];	/* 0x00 [0]=MSB, [3]=LSB */
};
/*
************************************************************************
**
************************************************************************
*/
struct Identify
{
/* byte 0 */
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t RestrictedByte0Bit7	: 1;
	u_int8_t DeviceType		: 3;
	u_int8_t AddressFrameType	: 4;
#else
	/* 	0x0: ADDRESS_IDENTIFY_FRAME */
	u_int8_t AddressFrameType	: 4;
	/*  001b: End device
	 *  010b: Edge expander device
	 *  011b: Fanout expander device
	 *  Others: Reserved.
	 */
	u_int8_t DeviceType		: 3;
	u_int8_t RestrictedByte0Bit7	: 1;
#endif /*  __ARCSAS_BIG_ENDIAN_BITFIELD__ */
/* byte 1 */
	u_int8_t RestrictedByte1;
/* byte 2 */
	u_int8_t InitiatorBits;
/* byte 3 */
	u_int8_t TargetBits;
/* byte 4-11 */
	u_int8_t DeviceName[8];
/*  byte 12-19  */
	ARCSAS_U64 SASAddress;
/* byte 20 */
	u_int8_t PhyIdentifier;
/* byte 21 */
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t ReservedByte21Bit1_7	: 7;
	u_int8_t BreakReplyCapable	: 1;
#else
	u_int8_t BreakReplyCapable	: 1;
	u_int8_t ReservedByte21Bit1_7	: 7;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
/* byte 22-27 */
	u_int8_t ReservedByte22_27[6];
/* byte 28-31 */
	u_int32_t CRC;
}; /* struct Identify */
/*
************************************************************************
**request specific bytes for a general input function
************************************************************************
*/
struct SMPRequestGeneralInput
{
	/* byte 4-7 */
	u_int32_t CRC;
};
/*
************************************************************************
**request specific bytes for a phy input function
************************************************************************
*/
struct SMPRequestPhyInput
{
	/* byte 4-7 */
	u_int8_t IgnoredByte4_7[4];
	/* byte 8 */
	u_int8_t ReservedByte8;
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10 */
	u_int8_t IgnoredByte10;
	/* byte 11 */
	u_int8_t ReservedByte11;
	/* byte 12-15 */
	u_int32_t CRC;
}; /* struct SMPRequestPhyInput */
/*
************************************************************************
**request specific bytes for a self configuration expander function
************************************************************************
*/
struct SMPRequestSelfConfigurationInput
{
	/* byte 4-6 */
	u_int8_t IgnoredByte4_6[3];
	/* byte 7 */
	u_int8_t StartSelfConfigurationStatusDescriptorIndex;
	/* byte 8-11 */
	u_int32_t CRC;
}; /* struct SMPRequestSelfConfigurationInput */
/*
************************************************************************
**request specific bytes for a request route function
************************************************************************
*/
struct SMPRequestRouteInformationInput
{
	/* byte 4-5 */
	u_int8_t IgnoredByte4_5[2];
	/* byte 6-7 */
	u_int8_t ExpanderRouteIndex[2];
	/* byte 8 */
	u_int8_t ReservedByte8;
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10 */
	u_int8_t IgnoredByte10;
	/* byte 11 */
	u_int8_t ReservedByte11;	
	/* byte 12-15 */
	u_int32_t CRC;
}; /* struct SMPRequestRouteInformationInput */
/*
************************************************************************
**request specific bytes for SMP DISCOVER LIST function
************************************************************************
*/
struct SMPRequestDiscoverList
{
	/* byte 4-7 */
	u_int8_t ReservedByte4_7[4];
	/* byte 8 */
	u_int8_t StartingPhyIdentifier;
	/* byte 9 */
	u_int8_t MaximumNumberOfDescriptors;

	/* byte 10 */
	u_int8_t PhyFilter:4;
	u_int8_t IgnoredByte10Bit4_6:3;
	u_int8_t IgnoreZoneGroup:1;

	/* byte 11 */
	u_int8_t DescriptorType:4;
	u_int8_t IgnoredByte11Bit4_7:4;

	/* byte 12-15 */
	u_int8_t IgnoredByte12_15[4];

	/* byte 16-27 */
	u_int8_t VendorSpecific[12];

	/* byte 28-31 */
	u_int32_t CRC;
}; /* struct SMPRequestDiscoverList */
/*
************************************************************************
**request specific bytes for SMP REPORT EXPANDER ROUTE TABLE function
************************************************************************
*/
struct SMPRequestReportExpanderRouteTable
{
	/* byte 4-7 */
	u_int8_t ReservedByte4_7[4];
	/* byte 8-9 */
	u_int8_t MaximumNumberOfDescriptors[2];
	
	/* byte 10-15 */
	u_int8_t StartingRoutedSASAddressIndex[6];

	/* byte 16-18 */
	u_int8_t IgnoredByte16_18[3];

	/* byte 19 */
	u_int8_t StartingPhyIdentifier;

	/* byte 20-27 */
	u_int8_t IgnoredByte20_27[8];

	/* byte 28-31 */
	u_int32_t CRC;
}; /* struct SMPRequestReportExpanderRouteTable */
/*
************************************************************************
**request specific bytes for SMP CONFIGUARE GENERAL function
************************************************************************
*/
struct SMPRequestConfigureGeneral
{
	/* byte 4-5 */
	u_int8_t ExpectedExpanderChangeCount[2];
	/* byte 6-7 */
	u_int8_t IgnoredByte6_7[2];

	/* byte 8 */
	u_int8_t UpdateSTPBusInactivityTimeLimit:1;
	u_int8_t UpdateSTPMaxConnectTimeLimit:1;
	u_int8_t UpdateSTPSMPNexusLossTime:1;
	u_int8_t IgnoredByte8Bit3_7:5;

	/* byte 9 */
	u_int8_t IgnoredByte9;

	/* byte 10-11 */
	u_int8_t STPBusInactivityTimeLimit[2];
	/* byte 12-13 */
	u_int8_t STPMaxConnectTimeLimit[2];

	/* byte 14-15 */
	u_int8_t STPSMPNexusLossTime[2];

	/* byte 16-19 */
	u_int32_t CRC;
}; /* struct SMPRequestConfigureGeneral */
/*
************************************************************************
**request specific bytes for ENABLE DISABLE ZONING function
************************************************************************
*/
struct SMPRequestEnableDisableZoning
{
	/* byte 4-5 */
	u_int8_t ExpectedExpanderChangeCount[2];

	/* byte 6-7 */
	u_int8_t IgnoredByte4_5[2];

	/* byte 8 */
	u_int8_t EnableDisableZoning:1;
	u_int8_t ReservedByte8Bit1_7:7;

	/* byte 9-11 */
	u_int8_t IgnoredByte9_11;

	/* byte 12-15 */
	u_int32_t CRC;
}; /* struct SMPRequestEnableDisableZoning */
/*
************************************************************************
**request specific bytes for SMP ZONED BROADCAST function
************************************************************************
*/
struct SMPRequestZonedBroadcast
{
	/* byte 4-5 */
	u_int8_t RestrictByte4_5[2];
	/* byte 6 */
	u_int8_t BroadcastType:3;
	u_int8_t ReservedByte6Bit3_7:5;
	/* byte 7 */
	u_int8_t NumberOfBroadcastSourceZoneGroups;
	/* byte 8-135 */
	u_int8_t BroadcastSourceZoneGroup[0x80];	//TBD
	/* value between 0 and 127 */
	/*
		byte 135 -n: PAD field
		Contains zero,one,two or three bytes set to 0x00 such that
		total length of the SMP request is a multiple of four
	*/
	u_int8_t Pad[3];
	/* byte n-4-n */
	u_int32_t CRC;
}; /* struct SMPRequestZonedBroadcast */
/*
************************************************************************
**request specific bytes for SMP ConfigureRouteInformation function
************************************************************************
*/
struct SMPRequestConfigureRouteInformation
{
	/* byte 4-5 */
	u_int8_t ExpectedExpanderChangeCount[2];
	/* byte 6-7 */
	u_int8_t ExpanderRouteIndex[2];
	/* byte 8 */
	u_int8_t ReservedByte8;
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10-11 */
	u_int8_t ReservedByte10_11[2];
	/* byte 12 */
	u_int8_t IgnoredByte12Bit0_6:7;
	u_int8_t DisableRouteEntry:1;
	/*
		if a routing error is detected
		then the route is disabled by
		setting this bit
	*/
	/* byte 13-15 */
	u_int8_t IgnoredByte13_15[3];
	/* byte 16-23 */
	u_int8_t RoutedSASAddress[8];
	/*
		identical to the AttachedSASAddress
		found through discovery
	*/
	/* byte 24-39 */
	u_int8_t ReservedByte24_39[16];
	/* byte 40-43 */
	u_int32_t CRC;
}; /* struct SMPRequestConfigureRouteInformation */
/*
************************************************************************
**request specific bytes for SMP Phy Control function
************************************************************************
*/
struct SMPRequestPhyControl
{
	/* byte 4-5 */
	u_int8_t ExpectedExpanderChangeCount[2];
	/* byte 6-8 */
	u_int8_t IgnoredByte6_8[3];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10 */
	u_int8_t PhyOperation;
	/* byte 11 */
	u_int8_t UpdatePartialPathwayTimeoutValue:1;
	u_int8_t ReservedByte11Bit1_7:7;
	/* byte 12-31 */
	u_int8_t IgnoredByte12_31[20];
	/* byte 32 */
	u_int8_t HardwareMinimumPhysicalLinkRate0_3:4;
	u_int8_t ProgrammedMinimumPhysicalLinkRate4_7:4;
	/* byte 33 */
	u_int8_t HardwareMaximumPhysicalLinkRate0_3:4;
	u_int8_t ProgrammedMaximumPhysicalLinkRate4_7:4;
	/* byte 34-35 */
	u_int8_t IgnoredByte34_35[2];
	/* byte 36 */
	u_int8_t PartialPathwayTimeoutValue:4;
	u_int8_t ReservedByte36Bit4_7:4;
	/* byte 37-39 */
	u_int8_t ReservedByte37_39[3];
	/* byte 40-43 */
	u_int32_t CRC;
}; /* struct SMPRequestPhyControl */
/*
************************************************************************
**request specific bytes for SMP Phy Test function
************************************************************************
*/
struct SMPRequestPhyTest
{
	/* byte 4-5 */
	u_int8_t ExpectedExpanderChangeCount[2];
	/* byte 6-8 */
	u_int8_t IgnoredByte6_8[3];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10 */
	u_int8_t PhyTestFunction;
	/* byte 11 */
	u_int8_t PhyTestPattern;
	/* byte 12-14 */
	u_int8_t ReservedByte12_14[3];
	/* byte 15 */
	u_int8_t PhyTestPatternPhysicalLinkRate:4;
	u_int8_t ReservedByte15Bit4_7:4;
	/* byte 16-18 */
	u_int8_t ReservedByte16_18[3];
	/* byte 19 */
	u_int8_t PhyTestPatternDwordsControl;
	/* byte 20-27 */
	u_int8_t PhyTestPatternDwords[8];
	/* byte 28-39 */
	u_int8_t ReservedByte28_39[12];
	/* byte 40-43 */
	u_int32_t CRC;
}; /* struct SMPRequestPhyTest */
/*
************************************************************************
**request specific bytes for SMP CONFIGUARE PHY EVENT INFORMATION function
************************************************************************
*/
struct SMPRequestConfigurePhyEventInformation
{
	/* byte 4-5 */
	u_int8_t ExpectedExpanderChangeCount[2];
	/* byte 6 */
	u_int8_t ClearPeaks:1;
	u_int8_t ReservedByte6Bit1_7:6;
	/* byte 7-8 */
	u_int8_t ReservedByte7_8[2];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10 */
	u_int8_t ReservedByte10;
	/* byte 11 */
	u_int8_t NumberOfPhyEventConfigurationDescriptors;
	/* byte 11-138 */
	u_int8_t PhyEventConfigurationDescriptors[0x80];	//TBD
	u_int32_t CRC;
}; /* struct SMPRequestConfigurePhyEventInformation */
/*
************************************************************************
**	Signal lines of the SGPIO bus
** ===================================================
** SClock
**	The SGPIO bus has a dedicated clock line driven by the initiator
**	(its maximum clock rate is 100 kHz),
**	although many implementations use slower ones (typically 48 kHz).
**
** SLoad
**	This line is synchronous to the clock and is used to indicate the start of a new frame of data;
**	a new SGPIO frame is indicated by SLoad being high at a rising edge of a clock
**	after having been low for at least 5 clock cycles.
**	The following 4 falling clock edges after a start condition is used to carry a 4-bit value
**	from the HBA to the backplane;
**	the definition of this value is proprietary and varies between system vendors.
**
** SDataOut
**	This line carries 3 bits of data from the HBA to the backplane:
**	the first bit typically carries activity;
**	the second bit carries locate;
**	and the third bit carries fail.
**	A low value for the first bit indicates no activity and a high value indicates activity.
**
** SDataIn
**	This line is used by the backplane and indicates some condition on the backplane back to the HBA.
**	The first bit being high commonly indicates the presence of a drive.
**	The two following bits are typically unused, and driven low.
**	Because this line would be high for all 3 bits when no backplane is connected,
**	an HBA can detect the presence of a backplane by the second or third bit of the SDataIn being driven low.
**
**	The SDataIn and SdataOut then repeats with 3 clocks per drive until the last drive is reached,
**	and the cycle starts over again.
************************************************************************
************************************************************************
** ARC1300 chip SGPIO Defines
** Register reside in PCI Configuration
************************************************************************
*/
/* SGPIO Registers that are available */
#define SGPIO_Vendor_Unique2_1300	0x44 /* Register name used in Spec */
#define SGPIO_Init_1300			SGPIO_Vendor_Unique2_1300 /* Name as appeared in code */
#define SGPIO_Control_1300		0x64
#define SGPIO_Data_Out_L_1300		0x68
#define SGPIO_Data_Out_H_1300		0x6C
#define SGPIO_Data_In_L_1300		0x70
#define SGPIO_Data_In_H_1300		0x74
/* For setting SGPIO mode during initializaton */
#define SGPIO_Mode_1300			ARCSAS_BIT(7)
/* For setting SGPIO_Control Register */
#define SGPIO_TRANSFER_LEN_1300(x)	((x-1)<<4)
#define SGPIO_SELECT_SPEED_1300(x)	(x<<1)
#define SGPIO_START_BIT_1300		ARCSAS_BIT(0)
/* Clk Frequency availabe for SGPIO */
#define SGPIO_1KHz_1300		0
#define SGPIO_10KHz_1300	1
#define SGPIO_50KHz_1300	2
#define SGPIO_100KHz_1300	3

#define	LED_OFFSET		16
/*
**************************************************************
**		Peripherals Registers
**	ARC1320 SGPIO
**  R0C200h/R0C300h
**	AUTO_BIT_LEN[7:0]
**	MAN_BIT_LEN[7:0]
**	RSVD
**	BLNK_GEN_B_SKIP_RATE
**	RSVD
**	BLNK_GEN_A_SKIP_RATE
**	RSVD
**	CPTR_SDATAIN_POS_EDGE
**	CHNG_SDATAOUT_NEG_EDGE
**	CHNG_SLOAD_NEG_EDGE
**	INVRT_SDATAOUT
**	INVRT_SLOAD
**	INVRT_SCLK
**	BLNK_GEN_A_EN
**	BLNK_GEN_B_EN
**	SGPIO_EN
**
**  R0C204h/R0C304h
**	STRTCH_ACTV_OFF
**	STRTCH_ACTV_ON
**	 FORCE_ACTV_OFF
**	MAX_ACTV_ON
**	BLNK_GEN_B_HI_TM
**	BLNK_GEN_B_LO_TM
**	BLNK_GEN_A_HI_TM
**	BLNK_GEN_A_LO_TM
**
**  R0C208h/R0C308h
**	US_CNT
**	SCLK_PERIOD
**
**  R0C20Ch/R0C30Ch
**	RSVD
**	AUTO_MD_SLOA
**	D_PTRN[3:0]
**	MAN_MD_SLOAD_PTRN[3:0]
**	MAN_MODE_NM_REP
**	SDOUT_MODE[1:0]
**	SDIN_CPTR_MODE[1:0]
**
**  R0C210h/R0C310h
**	RSVD
**	 NM_MAN_MODE_REP_REMAIN
**	RSVD
**	MAN_MODE_DON
**	ESDIN_CAPTURE_DONE
**
**  R0C214h/R0C314h
**      RSVD
**      SGPIO_IRQ_EN
**
**  R0C220h/R0C320h
**	DRIVE_3_SOURCE
**	DRIVE_2_SOURCE
**	DRIVE_1_SOURCE
**	DRIVE_0_SOURCE
**
**  R0C224h/R0C324h
**	DRIVE_7_SOURCE
**	DRIVE_6_SOURCE
**	DRIVE_5_SOURCE
**	DRIVE_4_SOURCE
**
**  R0C228h/R0C328h
**	DRIVE_11_SOURCE
**	DRIVE_10_SOURCE
**	DRIVE_9_SOURCE
**	DRIVE_8_SOURCE
**
**  R0C22Ch/R0C32Ch
**	DRIVE_15_SOURCE
**	DRIVE_14_SOURCE
**	DRIVE_13_SOURCE
**	DRIVE_12_SOURCE
**
**  R0C230h/R0C330h
**	DRIVE_19_SOURCE
**	DRIVE_18_SOURCE
**	DRIVE_17_SOURCE
**	DRIVE_16_SOURCE
**
**  R0C234h/R0C334h
**	DRIVE_23_SOURCE
**	 DRIVE_22_SOURCE
**	DRIVE_21_SOURCE
**	DRIVE_20_SOURCE
**
**  R0C238h/R0C338h
**	DRIVE_0_ACTV_LED
**	DRIVE_0_LOC_LED
**	DRIVE_0_ERR_LED
**	DRIVE_1_ACTV_LED
**	DRIVE_1_LOC_LED
**	DRIVE_1_ERR_LED
**	DRIVE_2_ACTV_LED
**	DRIVE_2_LOC_LED
**	DRIVE_2_ERR_LED
**	DRIVE_3_ACTV_LED
**	DRIVE_3_LOC_LED
**	DRIVE_3_ERR_LED
**
**  R0C23Ch/R0C33Ch
**	DRIVE_4_ACTV_LED
**	DRIVE_4_LOC_LED
**	DRIVE_4_ERR_LED
**	DRIVE_5_ACTV_LED
**	DRIVE_5_LOC_LED
**	DRIVE_5_ERR_LED
**	DRIVE_6_ACTV_LED
**	DRIVE_6_LOC_LED
**	DRIVE_6_ERR_LED
**	DRIVE_7_ACTV_LED
**	DRIVE_7_LOC_LED
**	DRIVE_7_ERR_LED
**
**  R0C240h/R0C340h
**	DRIVE_8_ACTV_LED
**	DRIVE_8_LOC_LED
**	DRIVE_8_ERR_LED
**	DRIVE_9_ACTV_LED
**	DRIVE_9_LOC_LED
**	DRIVE_9_ERR_LED
**	DRIVE_10_ACTV_LED
**	DRIVE_10_LOC_LED
**	DRIVE_10_ERR_LED
**	DRIVE_11_ACTV_LED
**	DRIVE_11_LOC_LED
**	DRIVE_11_ERR_LED
**
**  R0C244h/R0C344h
**	DRIVE_12_ACTV_LED
**	DRIVE_12_LOC_LED
**	DRIVE_12_ERR_LED
**	DRIVE_13_ACTV_LED
**	DRIVE_13_LOC_LED
**	DRIVE_13_ERR_LED
**	DRIVE_14_ACTV_LED
**	DRIVE_14_LOC_LED
**	DRIVE_14_ERR_LED
**	DRIVE_15_ACTV_LED
**	DRIVE_15_LOC_LED
**	DRIVE_15_ERR_LED
**
**  R0C248h/R0C348h
**	DRIVE_16_ACTV_LED
**	DRIVE_16_LOC_LED
**	DRIVE_16_ERR_LED
**	DRIVE_17_ACTV_LED
**	DRIVE_17_LOC_LED
**	DRIVE_17_ERR_LED
**	DRIVE_18_ACTV_LED
**	DRIVE_18_LOC_LED
**	DRIVE_18_ERR_LED
**	DRIVE_19_ACTV_LED
**	DRIVE_19_LOC_LED
**	DRIVE_19_ERR_LED
**
**  R0C24Ch/R0C34Ch
**	DRIVE_20_ACTV_LED
**	DRIVE_20_LOC_LED
**	DRIVE_20_ERR_LED
**	DRIVE_21_ACTV_LED
**	DRIVE_21_LOC_LED
**	DRIVE_21_ERR_LED
**	DRIVE_22_ACTV_LED
**	DRIVE_22_LOC_LED
**	DRIVE_22_ERR_LED
**	DRIVE_23_ACTV_LED
**	DRIVE_23_LOC_LED
**	DRIVE_23_ERR_LED
**
**  R0C250h/R0C350h
**	SDOUT[31:0]
**
**  R0C254h/R0C354h
**	SDOUT[63:32]
**
**  R0C258h/R0C358h
**	SDOUT[95:64]
**
**  R0C25Ch/R0C35Ch
**	SDIN[31:0]
**
**  R0C260h/R0C360h
**	SDIN[63:32]
**
**  R0C264h/R0C364h
**	SDIN[95:64]
**  =======================================
**  7:0	DRIVE_0_SOURCE	R/W	00h	DRIVE 0 Source
**
**	Determines which physical device is used as the input
**	to the blink pulse shaping logic
**	for the Drive 0 bit positions of the SDataOut bit stream.
**	This field is used
**	when DRIVE_0_ACTV_LED (R0C238h/R0C338h [31:29])
**	SGPIO Drive 0-3 Control register contains a value of 4h or 5h.
**	The contents of this field for SAS mode
**	are defined in Table 5-4,
**	��SRC_SEL[7:0], SAS Mode,�� on page 24.
**	The contents for SATA Direct Connect mode
**	are defined in Table 5-5,
**	��SRC_SEL[7:0], SATA Mode (Direct Connect),�� on page 25.
**	The blink pulse shaping logic
**	is defined in SGPIO Configuration 1
**		and SGPIO Configuration 2 registers
**
**Table 5-4  SRC_SEL[7:0], SAS Mode
**
**	SRC_SEL[7:0]	SAS
**		00	SAS A, PHY 0
**		01	SAS A, PHY 1
**		02	SAS A, PHY 2
**		03	SAS A, PHY 3
**		04	SAS B, PHY 0
**		05	SAS B, PHY 1
**		06	SAS B, PHY 2
**		07	SAS B, PHY 3
**		08	SAS-A, Port 0
**		09	SAS-A, Port 1
**		0A	SAS-A, Port 2
**		0B	SAS-A, Port 3
**		0C	SAS-B, Port 0
**		0D	SAS-B, Port 1
**		0E	SAS-B, Port 2
**		0F	SAS-B, Port 3
**		10	SAS-A, Port 4
**		11	SAS-A, Port 5
**		12	SAS-A, Port 6
**		13	SAS-A, Port 7
**		14	SAS-B, Port 4
**		15	SAS-B, Port 5
**		16	SAS-B, Port 6
**		17	SAS-B, Port 7
**		18	N/A
**		..	...
**		FF	N/A
**-------------------------------------------
**Table 5-5  SRC_SEL[7:0], SATA Mode (Direct Connect)
**
**	SRC_SEL[7:4] SRC_SEL[3:0] SATA Direct Connect
**		X	0	SATA A, PHY 0
**		X	1	SATA A, PHY 1
**		X	2	SATA A, PHY 2
**		X	3	SATA A, PHY 3
**		X	4	SATA B, PHY 0
**		X	5	SATA B, PHY 1
**		X	6	SATA B, PHY 2
**		X	7	SATA B, PHY 3
**		PM	8	SATA A, PHY 0 + PM 1,2
**		PM	9	SATA A, PHY 1 + PM 1,2
**		PM	A	SATA A, PHY 2 + PM 1,2
**		PM	B	SATA A, PHY 3 + PM 1,2
**		PM	C	SATA B, PHY 0 + PM 1,2
**		PM	D	SATA B, PHY 1 + PM 1,2
**		PM	E	SATA B, PHY 2 + PM 1,2
**		PM	F	SATA B, PHY 3 + PM 1,2
**************************************************************
*/
#define SGPIO_REG_CONFIG0_1320			0xC200 /* R0C200h/R0C300h */
#define SGPIO_REG_CONFIG1_1320			0xC204 /* R0C204h/R0C304h */
#define SGPIO_REG_CONFIG2_1320			0xC208 /* R0C208h/R0C308h */
#define SGPIO_REG_CONTROL_1320			0xC20C /* R0C20Ch/R0C30Ch */
#define SGPIO_REG_INT_CAUSE_1320		0xC210 /* R0C210h/R0C310h */
#define SGPIO_REG_INT_ENABLE_1320		0xC214 /* R0C214h/R0C314h */
#define SGPIO_REG_DRIVE_SOURCE_BASE_1320	0xC220 /* R0C220h/R0C320h ,0xC220...0xC234 , 0xC320...0xC334 ,Drive Source  0..23 */
#define SGPIO_REG_DRIVE_CONTROL_BASE_1320	0xC238 /* R0C238h/R0C338h ,0xC238...0xC24C , 0xC338...0xC34C ,Drive Control 0..23 */
#define SGPIO_REG_RAW_DOUT0_1320		0xC250 /* R0C250h/R0C350h ,DOut00..31 */
#define SGPIO_REG_RAW_DOUT1_1320		0xC254 /* R0C254h/R0C354h ,DOut32..63 */
#define SGPIO_REG_RAW_DOUT2_1320		0xC258 /* R0C258h/R0C358h ,DOut64..95 */
#define SGPIO_REG_RAW_DIN0_1320			0xC25C /* R0C25Ch/R0C35Ch ,DIn00...31 */
#define SGPIO_REG_RAW_DIN1_1320			0xC260 /* R0C260h/R0C360h ,DIn32...63 */
#define SGPIO_REG_RAW_DIN2_1320			0xC264 /* R0C264h/R0C364h ,DIn64...95 */
#define SGPIO_REG_ADDR_1320(sgpioX,addrY)	(addrY + sgpioX * 0x100)	/* sgpioX=0(SGPIO0) or 1(SGPIO1) , addrY = SGPIO_REG_CONFIG0_1320,... */
#define SGPIO0				0
#define SGPIO1				1
#define SGPIO_MINIMUM_BIT_STREAM	12
/* SGPIO_REG_CONFIG0_1320 */
#define SGPIO_EN		ARCSAS_BIT(0)
#define BLINK_GEN_EN_B		ARCSAS_BIT(1) /* blink generator A enable */
#define BLINK_GEN_EN_A		ARCSAS_BIT(2) /* blink generator B enable */
#define INVRT_SCLK		ARCSAS_BIT(3)
#define INVRT_SLOAD		ARCSAS_BIT(4)
#define INVRT_SDOUT		ARCSAS_BIT(5)
#define NEG_SLOAD_EDGE		ARCSAS_BIT(6)
#define NEG_SDOUT_EDGE		ARCSAS_BIT(7)
#define POS_SDIN_EDGE		ARCSAS_BIT(8)
#define MANUAL_BIT_LEN		0x00ff0000
#define AUTO_BIT_LEN		0xff000000
#define MANUAL_BIT_LEN_OFFSET	16
#define AUTO_BIT_LEN_OFFSET	24

/* SGPIO_REG_CONFIG1_1320 */
#define BLINK_LOW_TM_A		0x0000000f
#define BLINK_HI_TM_A		0x000000f0
#define BLINK_LOW_TM_B		0x00000f00
#define BLINK_HI_TM_B		0x0000f000
#define MAX_ACTV_ON		0x000f0000
#define FORCE_ACTV_OFF		0x00f00000
#define STRCH_ACTV_ON		0x0f000000
#define STRCH_ACTV_OFF		0xf0000000

/* SGPIO_REG_CONFIG2_1320 */
#define SCLK_SELECT		0x000000ff /* 32Hz..100kHz */

/* SGPIO_REG_CONTROL_1320 */
#define SDIN_MODE_MASK		(0x3<<0)
/*
**********************************************************************************
**SDataIn Capture Mode[1:0] 0h Determines the operating mode of the SGPIO module.
**0h:	Disabled
**1h:	One Shot mode. (SDIN_CPTR_MODE[0] self-clears when capture is complete).
**2h:	Continuous Capture mode. (SDIN_CPTR_MODE[1] does not self clear).
**3h:	Reserved
**********************************************************************************
*/
#define SDOUT_MODE_MASK		(0x3<<2)
/*
**********************************************************************************
**SData Out Mode[3:2] 0h Determines the operating mode of the SGPIO module.
**0h:	Halted. SClock, SLoad, SDataOut are all low (0).
**1h:	Manual mode Only. Output the number of bit-streams
**	indicated by MAN_MODE_NM_REP (R0C20Ch/R0C30Ch [15:4]),
**	and then return to Halted. (SDOUT_MODE[0] is self-clearing).
**2h:	Auto mode. (SDOUT_MODE[1] is not self clearing).
**3h:	Manual mode, followed by Auto mode.
**	Output the number of bit streams
**	indicated by MAN_MODE_NM_REP (R0C20Ch/R0C30Ch [15:4]),
**	and then transition to Auto mode. SDOUT_MODE[0] self-clears when the transition occurs
**********************************************************************************
*/
#define MANUAL_MODE_REP_CNT_MASK	(0xfff<<4)
/*
**********************************************************************************
**MAN_MODE_NM_REP[15:4] 000h Manual Mode Number of Repetitions.
**Determines the number of bit-streams that are generated in Manual mode.
**After this number of bit streams have been generated,
**the SGPIO either transitions to Halted mode, or to Auto mode,
**depending on the value in the SDOUT_MODE[1:0] (R0C20Ch/R0C30Ch [3:2]) field.
**Note: A value of 7FFh in this field indicates an infinite number of repetitions of Manual mode.
**********************************************************************************
*/
#define MANUAL_MODE_SLOAD_PTRN_MASK	(0xf<<16)
/*
**********************************************************************************
**Manual Mode SLoad Pattern[19:16]. 00h
**Determines the value output on the SLoad pin at the beginning of each bit-stream while operating in Manual mode.
**The value in this field is transferred out LSB first.
**Note: The SLoad pin is always asserted (1) during the last bit period of a bit stream.
**The next clock cycle marks the first clock cycle of a new bit-stream.
**Bit 0 of this pattern is output during the first clock cycle of the new bit-stream
**********************************************************************************
*/
#define AUTO_MODE_SLOAD_PTRN_MASK	(0xf<<20)
/*
**********************************************************************************
**Auto Mode SLoad Pattern[23:20] 00h
**Determines the value output on the SLoad pin at the beginning of each bit-stream while operating in Auto mode.
**The values in this field are transferred out LSB first.
**Note: The SLoad pin is always asserted (1) during the last bit period of a bit stream.
**The next clock cycle marks the first clock cycle of a new bit-stream.
**Bit 0 of this pattern is output during the first clock cycle of the new bit-stream
**********************************************************************************
*/
#define MAUNAL_MODE_REP_CNT_OFFSET	4
enum {
	SDOUT_MODE_SCLK_HALT = 0,
	SDOUT_MODE_MANUAL = 1,	/* MANUAL_MODE_REP_CNT count down to stop and halt */
	SDOUT_MODE_AUTO = 2,	/* does not self-clear */
	SDOUT_MODE_MANUAL_AUTO = 3, /* MANUAL_MODE_REP_CNT count down to stop and transition to auto */
	SDIN_MODE_DISABLE = 0,
	SDIN_MODE_ONCE = 1,	/* one shot mode,self-clear when capture is complete */
	SDIN_MODE_CONT = 2,	/* continue mode, does not self-clear */
};
#define SDOUT_MODE_OFFSET	2

/* SGPIO_REG_INT_CAUSE_1320 */
#define SDIN_DONE			ARCSAS_BIT(0)
#define MANUAL_MODE_REP_DONE		ARCSAS_BIT(1)
#define MANUAL_MODE_REP_REMAIN		(0xfff<<8)

/* SGPIO_REG_DRIVE_SOURCE_BASE_1320 */
#define DRIVE_SOURCE_PHY0_A		0x00
#define DRIVE_SOURCE_SAS_PORT0_A	0x08
#define DRIVE_SOURCE_SAS_PORT4_A	0x10
#define DRIVE_SOURCE_PM_PHY0_A		DRIVE_SOURCE_SAS_PORT0_A

/* core_index=0(A) or 1(B), phy_index=phy number 0..3 */
#define DRIVE_SOURCE_PHY(core_index,phy_index)		(DRIVE_SOURCE_PHY0_A+phy_index+core_index*4)
/* core_index=0(A) or 1(B), phy_index=phy number 0..3 */
#define DRIVE_SOURCE_SAS_PORT0_3(core_index,phy_index)	(DRIVE_SOURCE_SAS_PORT0_A+phy_index+core_index*4)
/* core_index=0(A) or 1(B), phy_index=phy number 4..7 */
#define DRIVE_SOURCE_SAS_PORT4_7(core_index,phy_index)	(DRIVE_SOURCE_SAS_PORT4_A+phy_index+core_index*4)
/* core_index=0(A) or 1(B), phy_index=phy number 0..3, pm_port_index=PM port id */
#define DRIVE_SOURCE_PM_PHY(core_index,phy_index,pm_port_index)	(DRIVE_SOURCE_PM_PHY0_A+phy_index+(core_index*4)+(pm_port_index*8))

/* SGPIO_REG_DRIVE_CONTROL_BASE_1320 */
#define MAX_AUTO_CTRL_DWORD		6

#define DRIVE_ACTIVITY_LED_MASK		(0x7<<5)
#define DRIVE_LOCATE_LED_MASK		(0x3<<3)
#define DRIVE_ERROR_LED_MASK		0x7
#define DRIVE_ACTIVITY_LED_OFFSET	5
#define DRIVE_LOCATE_LED_OFFSET		3
#define DRIVE_ERROR_LED_OFFSET		0
/*
********************************************************************
** LED light types
********************************************************************
*/
#define SGPIO_LED_TYPE_ACTIVITY		0
#define SGPIO_LED_TYPE_LOCATE		1
#define SGPIO_LED_TYPE_ERROR		2
#define SGPIO_LED_TYPE_REBUILD		3	/* for Supermicro backplanes */
#define SGPIO_LED_TYPE_HOT_SPARE	4
#define SGPIO_LED_TYPE_ALL_OFF		0xff
#define SGPIO_LED_REBUILD_MASK		0x00000080
#define SGPIO_LED_ERROR_MASK		0x00000040
/*
********************************************************************
** LED light status - the following values are set according to hardware
**	values, do not change unless necessary
********************************************************************
*/
enum {
	SGPIO_LED_STATUS_LOW		= 0,
	SGPIO_LED_STATUS_HIGH		= 1,
	SGPIO_LED_STATUS_BLINK_A	= 2,
	SGPIO_LED_STATUS_BLINK_INVRT_A	= 3, /* above for loc 0..3 */
	SGPIO_LED_STATUS_BLINK_SOF	= 4, /* only on active */
	SGPIO_LED_STATUS_BLINK_EOF	= 5, /* only on active */
	SGPIO_LED_STATUS_BLINK_B	= 6,
	SGPIO_LED_STATUS_BLINK_INVRT_B	= 7,
};

/* pre-set flags for RAID module to use */
#define SES_LED_FLAG_REBUILD		0x01
#define SES_LED_FLAG_HOT_SPARE		0x02
#define SES_LED_FLAG_FAIL_DRIVE		0x03
#define SES_LED_FLAG_ACTIVE		0x04
#define SES_LED_FLAG_WORKING_CHECK	0x10
#define SES_LED_FLAG_REBUILD_OFF	0x11
#define SES_LED_FLAG_HOT_SPARE_OFF	0x12
#define SES_LED_FLAG_FAIL_DRIVE_OFF	0x13
#define SES_LED_FLAG_ALL_OFF		0xff

/* SGPIO_REG_RAW_DIN0_1320 SGPIO_REG_RAW_DOUT0_1320 */
#define MAX_SDIN_DWORD 3
#define MAX_SDOUT_DWORD 3
#define SDIN_BACK_PLAN_PRESENCE_PATTERN		0x492
#define SDIN_DATA_MASK				0xFFF
#define SDIN_DEVICE0_PRESENCE_PATTERN		0x3
#define SDIN_DEVICE1_PRESENCE_PATTERN		0x18
#define SDIN_DEVICE2_PRESENCE_PATTERN		0xC0
#define SDIN_DEVICE3_PRESENCE_PATTERN		0x600
/* application */
enum {
	REG_TYPE_CONFIG = 0,
	REG_TYPE_RX = 1,
	REG_TYPE_RX_GP = 2,
	REG_TYPE_TC = 3,
	REG_TYPE_TC_GP = 4,
};
/*
************************************************************************
**
**	request sent specific to SMP Read SGPIO
**	Corresponds to READ_GPIO_REGISTER define
************************************************************************
*/
struct SMPRequestReadGPIORegister
{
	/* byte 4 */
	u_int8_t RegisterCount;
	/* byte 5-7 */
	u_int8_t ReservedByte[3];
	u_int32_t CRC;
};
/*
************************************************************************
**
**	request sent specific to SMP Write SGPIO
**	Corresponds to WRITE_GPIO_REGISTER define
************************************************************************
*/
struct SMPRequestWriteGPIORegister
{
	/* byte 4 */
	u_int8_t RegisterCount;
	/* byte 5-7 */
	u_int8_t ReservedByte[3];
	/* byte 8-15 */
	u_int8_t Data_Out_Low[8];
	/* byte 16-23 */
	u_int8_t Data_Out_High[8];
	u_int32_t CRC;
};
/*
************************************************************************
**	generic structure referencing an SMP Request, must be initialized
**	before being used
************************************************************************
*/
struct _SMPRequest
{
	/* byte 0 */
	u_int8_t SMPFrameType; /* always SMP_REQUEST_FRAME= 0x40 */
	/* byte 1 */
	u_int8_t Function;
	/* byte 2-3 */
	u_int8_t ReservedByte2_3[2];
	/* bytes 4-n */
	union
	{
/* #define REPORT_GENERAL 				0x00 */
		struct SMPRequestGeneralInput 			ReportGeneral;
/* #define REPORT_MANUFACTURER_INFORMATION 		0x01 */
		struct SMPRequestGeneralInput 			ReportManufacturerInformation;
/* #define READ_GPIO_REGISTER				0x02 */	
		struct SMPRequestReadGPIORegister		ReadGPIORegister;
/* #define REPORT_SELF_CONFGRIGRUATION_STATUS		0x03 */
		struct SMPRequestSelfConfigurationInput		ReportSelfConfigurationStatus;
/* #define DISCOVER 					0x10 */
		struct SMPRequestPhyInput 			Discover;
/* #define REPORT_PHY_ERROR_LOG 			0x11 */
		struct SMPRequestPhyInput 			ReportPhyErrorLog;
/* #define REPORT_PHY_SATA 				0x12 */
		struct SMPRequestPhyInput 			ReportPhySATA;
/* #define REPORT_ROUTE_INFORMATION 			0x13 */
		struct SMPRequestRouteInformationInput 		ReportRouteInformation;
/* #define REPORT_PHY_EVENT_INFORMATION			0x14 */
		struct SMPRequestPhyInput			ReportPhyEventInformation;
/* #define REPORT_PHY_BROADCAST_COUNTS			0x15 */
		struct SMPRequestPhyInput			ReportPhyBroadcaseCounts;
/* #define DISCOVER_LIST				0x16 */
		struct SMPRequestDiscoverList			DiscoverList;
/* #define REPORT_EXPANDER_ROUTE_TABLE			0x17 */
		struct SMPRequestReportExpanderRouteTable	ReportExpanderRouteTable;
/* #define CONFIGURE_GENERAL				0x80 */
		struct SMPRequestConfigureGeneral		ConfigureGeneral;
/* #define ENABLE_DISABLE_ZONING			0x81 */
		struct SMPRequestEnableDisableZoning		EnableDisableZoning;
/* #define WRITE_GPIO_REGISTER				0x82 */	
		struct SMPRequestWriteGPIORegister		WriteGPIORegister;
/* #define ZONED_BROADCAST				0x85 */
		struct SMPRequestZonedBroadcast			ZonedBroadcast;
/* #define CONFIGURE_ROUTE_INFORMATION 			0x90 */
		struct SMPRequestConfigureRouteInformation 	ConfigureRouteInformation;
/* #define PHY_CONTROL 					0x91 */
		struct SMPRequestPhyControl 			PhyControl;
/* #define PHY_TEST 					0x92 */
		struct SMPRequestPhyTest 			PhyTest;
/* #define CONFIGURE_PHY_EVENT_INFORMATION		0x93 */
		struct SMPRequestConfigurePhyEventInformation	ConfigurePhyEventInformation;
	} Request;
}; /* struct SMPRequest */
/*
************************************************************************
**
**	request specific bytes for SMP Report General response, intended to be
**	referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportGeneral
{
/*
	byte 4-5: EXPANDER CHANGE COUNT
	Counts the number of Broadcast (Change)s originated by an expander device.
	Management device servers in expander devices shall support this field.
	Management device servers in other device types (e.g., end devices) shall
	set this field to 0000h. This field shall be set to at least 0001h at power
	on. If the expander device has originated Broadcast (Change) for any reason
	described in 7.11 since transmitting a REPORT GENERAL response, it shall increment
	this field at least once from the value in the previous REPORT GENERAL response.
	It shall not increment this field when forwarding a Broadcast (Change). This field
	shall wrap to at least 0001h after the maximum value (i.e., FFFFh) has been reached.
*/
	u_int8_t ExpanderChangeCount[2];
/*
	byte 6-7: EXPANDER ROUTE INDEXES
	Contains the maximum number of expander route indexes per phy for the expander
	device. Management device servers in externally configurable expander devices
	containing phy-based expander route tables shall support this field. Management
	device servers in other device types (e.g., end devices, externally configurable
	expander devices with expander-based expander route tables, and self-configuring
	expander devices) shall set the EXPANDER ROUTE INDEXES field to zero. Not all
	phys in an externally configurable expander device are required to support the
	maximum number indicated by this field.
*/
	u_int8_t ExpanderRouteIndexes[2];
/*	byte 8: reserved */
	u_int8_t ReservedByte8;
/*
	byte 9:NUMBER OF PHYS
	Contains the number of phys in the device, including any virtual phys and any
	vacant phys
*/
	u_int8_t NumberOfPhys;
/*

	byte 10-bit0:
	EXTERNALLY CONFIGURABLE ROUTE TABLE
	Set to one indicates that the management device server is in an externally
	configurable expander device that has a phy-based expander route table
	that is required to be configured with the SMP CONFIGURE ROUTE INFORMATION
	function. An EXTERNALLY CONFIGURABLE ROUTE TABLE bit set to zero indicates
	that the management device server is not in an externally configurable expander
	device (e.g., it is in an end device, in a self-configuring expander device,
	or in an expander device with no phys with table routing attributes).

	byte 10-bit1:
	CONFIGURING
	Set to one indicates that the management device server is in a self-configuring
	expander device, the self-configuring expander device's management application
	client is currently performing the discover process, and it has identified at
	least one change to its expander routing table. A CONFIGURING bit set to zero
	indicates that the management device server is not in a self-configuring expander
	device currently performing the discover process and changing its expander
	routing table. Changes in this bit from one to zero result in a Broadcast (Change)
	being originated. Management device servers in self-configuring expander
	devices shall support this bit. Management device servers in externally
	configurable expander devices and in other device types shall set the CONFIGURING
	bit to zero.

	byte 10-bit2:
	CONFIGURES OTHERS
	Set to one indicates that the expander device is a self-configuring expander
	device that performs the configuration subprocess. A CONFIGURES OTHERS bit set
	to zero indicates the expander device may or may not perform the configuration
	subprocess. Self-configuring expander devices compliant with this standard
	shall set the CONFIGURES OTHERS bit to one.If the CONFIGURES OTHERS bit is set
	to zero, the expander device may configure all externally configurable expander
	devices in the SAS domain.

	byte 10-bit7:
	TABLE TO TABLE SUPPORTED
	Set to one indicates the expander device is a self-configuring expander
	device that supports its table routing phys being attached to table routing
	phys in other expander devices. The TABLE TO TABLE SUPPORTED bit shall only
	be set to one if the EXTERNALLY CONFIGURABLE ROUTE TABLE bit is set to
	zero. A TABLE TO TABLE SUPPORTED bit set to zero indicates the expander device
	is not a self-configuring expander device that supports its table routing
	phys being attached to table routing phys in other expander devices.

*/
	u_int8_t ConfigurableRouteTable:1;		/* BIT 0*/
	u_int8_t Configuring:1;				/* BIT 1*/
	u_int8_t ConfiguresOthers:1;			/* BIT 2*/
	u_int8_t ReservedByte10Bit3_6:4;		/* BIT 3-6*/
	u_int8_t TableToTableSupported:1;		/* BIT 7*/
/*	byte 11: reserved */
	u_int8_t ReservedByte11;
/*
	byte 12-19:
	ENCLOSURE LOGICAL IDENTIFIER
	Identifies the enclosure, if any, in which the device is located, and is
	defined in SES-2. The ENCLOSURE LOGICAL IDENTIFIER field shall be set to
	the same value reported by the enclosure services process, if any, for
	the enclosure. An ENCLOSURE LOGICAL IDENTIFIER field set to zero indicates
	no enclosure information is available.
*/
	u_int8_t EnclosureLogicalIdentifier[8];
/*	byte 20-29: reserved */
	u_int8_t ReservedByte20_29[10];

/*
	byte 30-31:
	STP BUS INACTIVITY TIME LIMIT
	Contains the bus inactivity time limit for STP connections which is set by
	the CONFIGURE GENERAL function
*/
	u_int8_t STPBusInactivityTimeLimit[2];
/*
	byte 32-33:
	STP MAXIMUM CONNECT TIME LIMIT
	Contains the maximum connect time limit for STP connections
	which is set by the CONFIGURE GENERAL function.
*/
	u_int8_t STPMaxConnectTimeLimit[2];
/*
	byte 34-35:
	STP SMP I_T NEXUS LOSS TIME
	Contains the time that an STP target port and an SMP initiator port retry
	certain connection requests which is set by the CONFIGURE GENERAL function.
*/
	u_int8_t STPSMPNexusLossTime[2];
/*
	byte 36-bit0:
	ZONING ENABLED
	Set to one indicates that zoning is enabled in the expander device. A ZONING
	ENABLED bit set to zero indicates that zoning is disabled in the expander
	device. The ZONING ENABLED bit shall be set to zero if the ZONING SUPPORTED bit
	is set to zero.

	byte 36-bit1:
	ZONING SUPPORTED
	Set to one indicates that zoning is supported by the expander device(i.e., it
	is a zoning expander device). A ZONING SUPPORTED bit set to zero indicates that
	zoning is not supported by the expander device.

	byte 36-bit2:
	PHYSICAL PRESENCE ASSERTED
	Set to one indicates that the expander device is currently detecting
	physical presence. A PHYSICAL PRESENCE ASSERTED bit set to zero indicates that
	the expander device is not currently detecting physical presence. The PHYSICAL
	PRESENCE ASSERTED bit shall be set to zero if the PHYSICAL PRESENCE SUPPORTED
	bit is set to zero.

	byte 36-bit3:
	PHYSICAL PRESENCE SUPPORTED
	Set to one indicates that the expander device supports physical presense
	as a mechanism for allowing zoning to be enabled or disabled from phys in
	zone groups without access to zone group 2. A PHYSICAL PRESENCE SUPPORTED bit
	set to zero indicates that the expander device does not support physical
	presence as a mechanism for allowing zoning to be enabled or disabled.
	
*/
	u_int8_t ZoningEnabled:1;		/* Bit 0*/
	u_int8_t ZoningSupported:1;		/* Bit 1*/
	u_int8_t PhysicalPresenceAsserted:1;	/* Bit 2*/
	u_int8_t PhysicalPresenceSupported:1;	/* Bit 3*/
	u_int8_t ReservedByte36Bit4_7:4;	/* Bit 4-7*/
/*	byte 37: reserved */
	u_int8_t ReservedByte37;
/*
	byte 38-39:
	MAXIMUM NUMBER OF ROUTED SAS ADDRESSES
	Contains the number of routed SAS addresses in an expander-based expander route
	table. Management device servers in expander devices containing expander-based
	expander route tables shall support this field. Management device servers in
	other device types (e.g., end devices and expander devices with phy-based expander
	route tables) shall set this field to 0000h.
*/
	u_int8_t MaxNumRoutedSASAddr[2];
/*	byte 40-43 CRC */
	u_int32_t CRC;
}; /* struct SMPResponseReportGeneral */
/*
************************************************************************
**
**	request specific bytes for SMP Report Manufacturer Information response,
**	intended to be referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportManufacturerInformation
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-7 */
	u_int8_t ReservedByte6_7[2];
	/* byte 8 */
	u_int8_t SAS11Format:1;
	u_int8_t ReservedByte8_Bit1_7:7;
	/* byte 9-11 */
	u_int8_t IgnoredByte9_11[3];
	/* byte 12-19 */
	u_int8_t VendorIdentification[8];
	/* byte 20-35 */
	u_int8_t ProductIdentification[16];
	/* byte 36-39 */
	u_int8_t ProductRevisionLevel[4];
	/* byte 40-47 */
	u_int8_t ComponentVendorIdentification[8];
	/* byte 48-49 */
	u_int8_t ComponentID[2];
	/* byte 50 */
	u_int8_t ComponentRevisionID;
	/* byte 51 */
	u_int8_t ReservedByte51;
	/* byte 52-59 */
	u_int8_t VendorSpecific[8];
	/* byte 60-63 */
	u_int32_t CRC;
}; /* struct SMPResponseReportManufacturerInformation */
/*
************************************************************************
**
**	request specific bytes for SMP Report Self-Configuration Status response,
**	intended to be referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportSelfConfigurationStatus
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6 */
	u_int8_t ReservedByte6;
	/* byte 7 */
	u_int8_t StartingSelfConfigurationStatusDescriptorIndex;
	/* byte 8-12	*/
	u_int8_t ReservedByte8_12[5];
	/* byte 13 */
	u_int8_t MaxSupportedSelfConfigurationStatusDescriptors;
	/* byte 14 */
	u_int8_t TotalNumberOfSelfConfigurationStatusDescriptors;
	/* byte 15 */
	u_int8_t NumberOfSelfConfigurationStatusDescriptors;
	/* byte 16-31 */
	u_int8_t SelfConfigurationStatusDescriptor[16];	//TBD
	/*
	byte SelfConfigurationStatusDescriptor_1[16];
		...
	byte SelfConfigurationStatusDescriptor_n[16];

	*/
	u_int32_t CRC;
}; /* struct SMPResponseReportSelfConfigurationStatus */
/*
************************************************************************
**
**	request specific bytes for SMP Report Phy Error Log response,
**	intended to be referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportPhyErrorLog
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-8 */
	u_int8_t ReservedByte6_8[3];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10-11 */
	u_int8_t ReservedByte10_11[2];
	/* byte 12-15 */
	u_int8_t InvalidDwordCount[4];
	/* byte 16-19 */
	u_int8_t RunningDisparityErrorCount[4];
	/* byte 20-23 */
	u_int8_t LossOfDwordSynchronizationCount[4];
	/* byte 24-27 */
	u_int8_t PhyResetProblemCount[8];
	/* byte 28-31 */
	u_int32_t CRC;
}; /* struct SMPResponseReportPhyErrorLog */
/*
************************************************************************
**
**	Response specific bytes for SMP Discover Descriptor, intended to be
**	referenced by SMPResponseDiscover, SMPResponseDiscoverList
************************************************************************
*/
struct DiscoverLongFormatDescriptor
{
/*	byte 48-49: Reserved */
	u_int8_t ReservedByte48_49[2];
/*	byte 50-51: Vendor specific */
	u_int8_t VendorSpecific[2];
/*
	byte 52-59: ATTACHED DEVICE NAME
	Contains the value of the the device name field received in the IDENTIFY
	address frame during the identification sequence. If the attached port is
	an expander port or a SAS port, the ATTACHED DEVICE NAME field contains the
	device name of the attached expander device or SAS device. If the attached port
	is a SATA device port, the ATTACHED DEVICE NAME field contains 00000000 00000000h.
	The ATTACHED DEVICE NAME field shall be updated:
		a) after the identification sequence completes, if a SAS phy or expander phy is attached; or
		b) after the COMSAS Detect Timeout timer expires, if a SATA phy is attached.
*/
	u_int8_t AttachedDeviceName[8];
/*
	Zone group		Configurable 	Description
					zone permission
					table entries

	0				No				Phys in zone group 0 only have access to
									other phys in zone group 1.

	1				No				Phys in zone group 1 have access to other
									phys in all zone groups.

	2				Yes				Phys in zone group 2 have access to other
									phys based on the zone permission table.
									A management device server in a zoning
									expander device with zoning enabled only
									allows management application clients using
									phys in zone groups with access to zone
									group 2 to perform the following SMP functions:
										a) SMP zoning configuration functions (e.g., CONFIGURE ZONE
										PERMISSION); and
										b) SMP expander configuration functions (i.e., CONFIGURE GENERAL).
									A management device server in a zoning 
									expander device with zoning enabled only
									allows management application clients to
									perform certain SMP phy-based control and
									 configuration functions (i.e., PHY CONTROL,
									PHY TEST FUNCTION, and CONFIGURE PHY EVENT
									INFORMATION) if the zone group of the management
									application client��s phy has access to 
									zone group 2 or the zone group of the specified phy.

	3			Yes					Phys in zone group 3 have access to other phys based
									on the zone permission table.
									A management device server in a zoning expander device
									with zoning enabled only allows management application
									clients using a phy in a zone group with access to
									zone group 3 to perform certain SMP zoning-related
									functions (i.e., ZONED BROADCAST).

	4 to 7 			Reserved

	8 to 127 Yes 					Phys in zone groups 8 through 127 have access to other 
									phys based on the zone permission table.



				Source zone group determination
	Attribute of the expander phy that		Source zone group
	received the OPEN address frame
	ZONE ADDRESS	Routing	INSIDE ZPSDS
	RESOLVED bit	method	bit
	0				Any		0 				Zone group of the receiving expander phy

	0				Any 	1				Source zone group specified by the SOURCE ZONE
											GROUP field in the received OPEN address frame.

	1				Direct	0				Zone group of the receiving expander phy.

	1				Direct	1				Not applicable.


	1				Subtractive 0			Zone group of the receiving expander phy.

	1				Subtractive 1			Not applicable.


	1				Table	0				Zone group stored in the zoning expander route
											table for the source SAS address. If the source
											SAS address is not found in the zoning expander
											route table then the zone group of the receiving
											expander phy.
	1				Table	1				Not applicable.

				Destination zone group determination
	Routing method of the			Destination zone group
	destination expander phy
	Direct 							Zone group of the destination expander phy.

	Subtractive					Zone group of the destination expander phy (i.e., the
									subtractive expander phy).

	Table							Zone group stored in the zoning expander route table for
									the destination SAS address.

	At the completion of a link reset sequence, if a SATA device is attached to an expander phy, the
	zoning expander device with zoning enabled shall set the INSIDE ZPSDS bit to zero for that expander phy.
	At the completion of a link reset sequence, if a SATA device is not attached to an expander phy, the zoning
	expander device with zoning enabled shall update the phy zone information fields based on:
	a) the REQUESTED INSIDE ZPSDS bit and the INSIDE ZPSDS PERSISTENT bit in the zone phy information (i.e.,
	the bits transmitted in the outgoing IDENTIFY address frame); and
	b) the REQUESTED INSIDE ZPSDS bit and INSIDE ZPSDS PERSISTENT bit received in the incoming IDENTIFY
	address frame.

			Phy zone information fields after by a link reset seqeunce
	REQUESTED						INSIDE ZPSDS			Phy zone information field changes
	INSIDE ZPSDS bit				PERSISTENT bit

	Transmitted Received 			Transmitted Received
	0			0 or 1				0 or 1		0 or 1		The zoning expander device shall set the INSIDE
															ZPSDS bit to zero.
															
	1			0					0 or 1		0 or 1		The zoning expander device shall set the INSIDE
															ZPSDS bit to zero.

	1			1					0			0			If the SAS address received in the IDENTIFY
															address frame during the identification
															sequence is different from the SAS address
															prior to the completion of the link reset
	1			1					0			1			sequence, then the zoning expander device
															shall set:
															a) the REQUESTED INSIDE ZPSDS bit to zero; and
	1			1					1			0			b) the INSIDE ZPSDS bit to zero.
															If the SAS address received in the IDENTIFY
															address frame during the identification
															sequence is the same as the SAS address prior
															to the completion of the link reset sequence,
															then the zoning expander device shall set:
															a) the INSIDE ZPSDS bit to one;
															b) the ZONE GROUP field to one; and
															c) the ZONE ADDRESS RESOLVED bit to zero.

	1			1					1			1			The zoning expander device shall set:
															a) the INSIDE ZPSDS bit to one;
															b) the ZONE GROUP field to one; and
															c) the ZONE ADDRESS RESOLVED bit to zero.


	If the ZONE GROUP PERSISTENT bit is set to one, then a link reset sequence shall not cause the zone
	group value of an expander phy to change unless the INSIDE ZPSDS bit changes from zero to one.
	If the ZONE GROUP PERSISTENT bit is set to zero, then table 29 specifies events based on the initial
	condition of an expander phy that shall cause a zoning expander device with zoning enabled to change the
	ZONE GROUP field of the expander phy to its default value (e.g., zero).

		Events that cause the ZONE GROUP field to be set to its default value when the ZONE GROUP
		PERSISTENT bit set to zero
	Initial condition 			Event after the initial condition is established
	Completed link reset		A subsequent link reset sequence completes and:
	sequence with a				a) the SAS address received in the IDENTIFY address frame during
	SAS device attached			the identification sequence is different from the SAS address prior to the
								completion of the link reset sequence; or
								b) a SATA device is attached.
								
	Completed link reset		Either:
	sequence with a				a) A subsequent link reset sequence completes and:
	SATA device						A) a hot-plug timeout occurred between the time of the initial
	attached						condition and the time the link reset sequence completed;
									B) the zoning expander device has detected the possibility that a new SATA
									device has been inserted. The method of detection is outside the scope of
									this standard (e.g., an enclosure services process reports a change in the
									ELEMENT STATUS CODE field in the Device or Array Device element (see
									SES-2), or a change in the WORLD WIDE NAME field in the attached SATA
									device��s IDENTIFY DEVICE or IDENTIFY PACKET DEVICE data (see
									ATA8-ACS)); or
									C) a SAS phy or expander phy is attached;
								or
								b) The expander phy is disabled with the SMP PHY CONTROL function 
								DISABLE phy operation.

	The BPP determines the source zone group(s) of the Broadcast as follows:
	a) if the BPP receives a Broadcast Event Notify message from an expander phy (i.e., a zoning expander
	phy received a BROADCAST), the Broadcast has a single source zone group set to the zone group of
	that expander phy; and
	b) if the BPP receives a message from the management device server indicating that it received an SMP
	ZONED BROADCAST request from an SMP initiator port that has access to zone group 3, the
	Broadcast has each of the source zone groups specified in the SMP ZONED BROADCAST request.
	The BPP forwards the Broadcast to each expander port other than the one on which the Broadcast was
	received (i.e., the expander port that received the BROADCAST or SMP ZONED BROADCAST request) if
	any of the source zone groups have access to the zone group of the expander port.
	To forward a Broadcast to an expander port:
	a) if the expander port��s INSIDE ZPSDS bit is set to one, the BPP shall request that the SMP initiator port
	establish a connection on at least one phy in the expander port to the SMP target port of the attached
	expander device and transmit an SMP ZONED BROADCAST request specifying the source zone
	group(s); and
	b) if the expander port��s INSIDE ZPSDS bit is set to zero, the BPP shall send a Transmit Broadcast
	message to at least one phy in the expander port, causing it to transmit a BROADCAST.


		byte 60-bit0: ZONING ENABLED
		Set to one indicates that zoning is enabled in the expander device.
		 A ZONING ENABLED bit set to zero indicates that zoning is disabled
		in the expander device.

		byte 60-bit1: INSIDE ZPSDS
		Indicates if the phy is inside or on the boundary of a ZPSDS.
		0: The phy is attached to an end device, an expander device that does not support
		zoning, or a zoning expander device with zoning disabled.
		1: The phy is attached a zoning expander device with zoning enabled and is thus
		inside a ZPSDS. 

		The bit is not directly changeable and only changes following a link reset sequence,
		based on the REQUESTED INSIDE ZPSDS bit.

		byte 60-bit2: ZONE GROUP PERSISTENT
		Specifies the method of determining the zone group value of the phy after a link
		reset sequence when the INSIDE ZPSDS is set to zero.

		byte 60-bit3: ZONE ADDRESS RESOLVED
		Specifies the method used to determine the source code group for a connection request
		received by a phy at the boundary of the ZPSDS.
		The bit may be set to one when:
		a) the phy is contained within a zoning expander device; and
		b) the INSIDE ZPSDS bit for the phy is set to zero.
		The bit may be set to zero when:
		a) the phy is contained within a non-zoning expander device; or
		b) the phy is contained within a zoning expander device and the INSIDE ZPSDS for the
		phy is set to one.


		byte 60-bit4: REQUESTED INSIDE ZPSDS
		Used to establish the boundary of the ZPSDS and to determine the value of other zone
		phy information fields after a link reset sequence.

		byte 60-bit5: INSIDE ZPSDS PERSISTENT
		Indicates the method used to determine the value of the INSIDE ZPSDS bit after a
		link reset sequence.

		byte 60-bit6: REQUESTED INSIDE ZPSDS CHANGED BY EXPANDER
		Set to one indicates that the zoning expander device set the REQUESTED INSIDE
		ZPSDS bit to zero in the zone phy information at the completion of the last
		link reset sequence. A REQUESTED INSIDE ZPSDS CHANGED BY EXPANDER bit set to
		zero indicates that the zoning expander device did not set the REQUESTED INSIDE
		ZPSDS bit to zero in the zone phy information at the completion of the last link
		reset sequence.
		The zone manager may use the REQUESTED INSIDE ZPSDS CHANGED BY EXPANDER bit to
		determine why the REQUESTED INSIDE ZPSDS bit has changed in the DISCOVER
		response from the value to which it last set the bit.


		All phys in an expander port shall have the same zone phy information. The zone phy
		information fields should be no-volatile and shall be preserved while zone is
		disabled.
*/
	u_int8_t ZoningEnabled:1;		/* bit 0 */
	u_int8_t InsideZPSDS:1;			/* bit 1 */
	u_int8_t ZoneGroupPersistent:1;		/* bit 2 */
	u_int8_t ZoneAddressResolved:1;		/* bit 3 */
	u_int8_t RequestedInsideZPSDS:1;	/* bit 4 */
	u_int8_t InsideZPSDSPersistent:1;	/* bit 5 */
	u_int8_t RequestedInsideZPSDSChangedbyExpander:1;	/* bit 6 */
	u_int8_t ReservedByte60Bit7:1;
/*	byte 61-62: Reserved */
	u_int8_t ReservedByte61_62[2];
/*
		byte 63: ZONE GROUP
		Contains a value in the range of 0 to 127 that specifies the zone group to which the phy
		blongs. The zone group of the SMP initiator port and SMP target port in a zoning expander
		device shall be 1.

*/
	u_int8_t ZoneGroup;
/*
		byte 64:SELF-CONFIGURATION STATUS
		Indicates the status of a self-configuring expander device pertaining to
		the specified phy.

		Code 	Description
		00h 	Reserved
		01h 	Error not related to a specific layer
		02h 	The expander device currently has a connection or is currently attempting to establish a
			connection with the SMP target port with the indicated SAS address.
		03h 	Expander route table is full. The expander device was not able to add the indicated SAS
			address to the expander route table.
		04h	Expander device is out of resources (e.g., it discovered too many SAS addresses while
			performing the discover process through a subtractive port). This does not affect the expander
			route table.
		05h-1Fh Reserved for status not related to specific layers

		Status reported by the phy layer:
		20h 	Error reported by the phy layer
		21h 	All phys in the expander port containing the indicated phy lost dword synchronication
		22h-3Fh Reserved for status reported by the phy layer

*/
	u_int8_t SelfConfigurationStatus;
/*
		byte 65: SELF-CONFIGURATION LEVELS COMPLETED
		Indicates the number of levels of expander devices beyond the expander port
		containing the specified phy for which the self-configuring expander device��s
		management application client has completed the discover process.

		Code 	Description
		00h	The management application client:
			a) has not begun the discover process through the expander port containing the specified
			phy; or
			b) has not completed the discover process through the expander port containing the
			specified phy.
		01h 	The management application client has completed discovery of the expander device
			attached to the expander port containing the specified phy (i.e., level 1).
		02h		The management application client has completed discovery of the expander devices
			attached to the expander device attached to the expander port containing the specified phy
			(i.e., level 2).
		... ...
		FFh 	The management application client has completed discovery of the expander devices
			attached at level 255.
*/
	u_int8_t SelfConfgurationLevelsCompleted;
/*	byte 66-67: Reserved */
	u_int8_t ReservedByte66_67[2];
/*
		byte 68-75: SELF-CONFIGURATION SAS ADDRESS
		Indicates the SAS address of the SMP target port to which the self-configuring 
		expander device established a connection or attempted to establish a connection
		using the specified phy and resulted in the status indicated by the 
		SELF-CONFIGURATION STATUS field.
*/
	u_int8_t SelfConfigurationSASAddress[8];
}; /* DiscoverLongFormatDescriptor */
/*
************************************************************************
**
** Response specific bytes for SMP Discover, intended to be referenced
** by SMPResponse
************************************************************************
*/
struct SMPResponseDiscover
{
/*
		byte 4-5:
		EXPANDER CHANGE COUNT
		Counts the number of Broadcast (Change)s originated by an expander device.
		Management device servers in expander devices shall support this field.
		Management device servers in other device types (e.g., end devices) shall
		set this field to 0000h. This field shall be set to at least 0001h at power
		on. If the expander device has originated Broadcast (Change) for any reason
		described in 7.11 since transmitting a REPORT GENERAL response, it shall increment
		this field at least once from the value in the previous REPORT GENERAL response.
		It shall not increment this field when forwarding a Broadcast (Change). This field
		shall wrap to at least 0001h after the maximum value (i.e., FFFFh) has been reached.
*/
	u_int8_t ExpanderChangeCount[2];
/*	byte 6-8: Reserved	*/
	u_int8_t ReservedByte6_8[3];
/*	
		byte 9: PHY IDENTIFIER
		Indicates the phy for which physical configuration link information
		is being returned.
*/
	u_int8_t PhyIdentifier;
/*	byte 10-11: Reserved	*/
	u_int8_t ReservedByte10_11[2];
/*
		byte 12-bit4-6:ATTACHED DEVICE TYPE
		001b: No device
		010b: End device
		010b: Expander device
		011b: Expander device compliant with a previous version of this standard
		Others: Reserved
*/
	u_int8_t ReservedByte12Bit0_3:4;	/* Bit0-3 */
	u_int8_t AttachedDeviceType:3;		/* Bit4-6 */
	u_int8_t IgnoredByte12Bit7:1;		/* Bit7 */
/*
		byte 13-bit0-3:	NEGOTIATED PHYSICAL LINK RATE
		0x0: UNKNOW, Phy is enabled; unknown physical link rate.
		0x1: DISABLED, Phy is disabled.
		0x2: PHY_RESET_PROBLEM
		0x3: SPINUP_HOLD, detected a SATA device and entered the SATA spinup hold state.
		0x4: PORT_SELECTOR
		0x5: RESET_IN_PROGRESS
		0x8: G1, Phy is enabled; 1,5 Gbps physical link rate.
		0x9: G2, Phy is enabled; 3,0 Gbps physical link rate.

*/
	u_int8_t NegotiatedPhysicalLinkRate:4;
	u_int8_t ReservedByte13Bit4_7:4;
/*
		byte 14-bit0:ATTACHED SATA HOST
		Set to one indicates a SATA host port is attached. An ATTACHED SATA HOST bit set
		to zero indicates a SATA host port is not attached.
		byte 14-bit1:ATTACHED SMP INITIATOR
		Set to one specifies that an SMP initiator port is present.
		byte 14-bit2:ATTACHED STP INITIATOR 
		Set to one specifies that an STP initiator port is present.
		byte 14-bit3:ATTACHED SSP INITIATOR
		Set to one specifies that an SSP initiator port is present.
*/
	u_int8_t InitiatorBits;
	u_int8_t TargetBits;
/*
		 byte 16-23:SAS ADDRESS
		 Contains the value of the SAS ADDRESS field transmitted in the IDENTIFY address
		frame during the identification sequence. If the phy is an expander phy, the
		SAS ADDRESS field contains the SAS address of the expander device. If the phy
		is a SAS phy, the SAS ADDRESS field contains the SAS address of the SAS port.
*/
	u_int8_t SASAddress[8];
/*
		byte 24-31:ATTACHED SAS ADDRESS
		Contains the value of the SAS ADDRESS field received in the IDENTIFY
		address frame during the identification sequence. If the attached port
		is an expander port, the ATTACHED SAS ADDRESS field contains the SAS address
		of the attached expander device. If the attached port is a SAS port, the
		ATTACHED SAS ADDRESS field contains SAS address of the attached SAS port.
		If the attached port is a SATA device port, the ATTACHED SAS ADDRESS field
		contains the SAS address of the STP/SATA bridge.
		The ATTACHED SAS ADDRESS field shall be updated:
			a) after the identification sequence completes, if a SAS phy or expander
		phy is attached; or
			b) after the COMSAS Detect Timeout timer expires (see 6.8.3.9), if a SATA
		phy is attached.
		An STP initiator port should not make a connection request to the attached SAS address until the ATTACHED
		DEVICE TYPE field is set to a value other than 000b.
*/
	u_int8_t AttachedSASAddress[8];
/*
		byte 32: ATTACHED PHY IDENTIFIER
		Contains a phy identifier for the attached phy:
		a) If the attached phy is a SAS phy or an expander phy, the ATTACHED PHY
		IDENTIFIER field contains the value of the PHY IDENTIFIER field received
		in the IDENTIFY address frame during the identification sequence:
			A) If the attached phy is a SAS phy, the ATTACHED PHY IDENTIFIER field
			contains the phy identifier of the attached SAS phy in the attached SAS device;
			B) If the attached phy is an expander phy, the ATTACHED PHY IDENTIFIER
			field contains the phy identifier of the attached expander phy in the attached
			expander device;
		b) If the attached phy is a SATA device phy, the ATTACHED PHY IDENTIFIER field
		contains 00h;
		c) If the attached phy is a SATA port selector phy and the expander device is
		able to determine the port of the SATA port selector to which it is attached,
		the ATTACHED PHY IDENTIFIER field contains 00h or 01h; and
		d) If the attached phy is a SATA port selector phy and the expander device is not
		able to determine the port of the SATA port selector to which it is attached,
		the ATTACHED PHY IDENTIFIER field contains 00h.

		The ATTACHED PHY IDENTIFIER field shall be updated:
		a) after the identification sequence completes, if a SAS phy or expander phy is attached; or
		b) after the COMSAS Detect Timeout timer expires, if a SATA phy is attached.
*/
	u_int8_t AttachedPhyIdentifier;
/*
		byte 32-bit0:ATTACHED BREAK_REPLY CAPABLE
		Set to one indicate that the phy is capable of responding to received BREAK primitive
		sequences with a BREAK_REPLY primitive sequence.
		byte 32-bit1: ATTACHED REQUESTED INSIDE ZPSDS
		Is used to establish the boundary of ZPSDS. The bit is transmitted in the IDENTIFY
		address frame to the attached phy and is used to determine the value of other zone
		phy information fields after a link reset sequence.
		byte 32-bit2: ATTACHED INSIDE ZPSDS PERSISTENT
		Indicate the method used to determine the value of the INSIZE ZPSDS bit after a link
		reset sequence. The bit is transmitted in the IDENTIFY address frame.
*/
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t ReservedByte32Bit3_7		: 5;
	u_int8_t AttachedInsideZPSDSPersistent	: 1;  /* Bit 2 */
	u_int8_t AttachedRequestedInsideZPSDS	: 1;  /* Bit 1 */
	u_int8_t AttachedBreakReplyCapable	: 1;  /* Bit 0 */
#else
	u_int8_t AttachedBreakReplyCapable	: 1;  /* Bit 0 */
	u_int8_t AttachedRequestedInsideZPSDS	: 1;  /* Bit 1 */
	u_int8_t AttachedInsideZPSDSPersistent	: 1;  /* Bit 2 */
	u_int8_t ReservedByte32Bit3_7		: 5;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
/*	byte 34-39: Reserved */
	u_int8_t ReservedByte34_39[6];
/*
		byte 40-bit0-3:HARDWARE MINIMUM PHYSICAL LINK RATE
		Indicates the minimum physical link rate supported by the phy.
		0x8: 1.5Gbps
		0x9: 3.0Gbps
		Others: Reserved
		byte 40-bit4-7:PROGRAMMED MINIMUM PHYSICAL LINK RATE
		Indicates the minimum physical link rate set by the PHY CONTROL function.
		The default value shall be the value of the HARDWARE MINIMUM PHYSICAL LINK RATE
		field.
		0x0: Not programmable
		0x8: 1.5Gbps
		0x9: 3.0Gbps
		Others: Reserved
*/
	u_int8_t HardwareMinimumPhysicalLinkRate:4;
	u_int8_t ProgrammedMinimumPhysicalLinkRate:4;
/*
		byte 41-bit0-3:HARDWARE MAXIMUM PHYSICAL LINK RATE
		Indicates the maximum physical link rate supported by the phy.
		 0x8: 1.5Gbps
		0x9: 3.0Gbps
		Others: Reserved
		byte 41-bit4-7:PROGRAMMED MAXIMUM PHYSICAL LINK RATE
		Indicates the maximum physical link rate set by the PHY CONTROL function.
		The default value shall be the value of the HARDWARE MINIMUM PHYSICAL LINK RATE
		field.
		0x0: Not programmable
		0x8: 1.5Gbps
		0x9: 3.0Gbps
		Others: Reserved
*/
	u_int8_t HardwareMaximumPhysicalLinkRate:4;
	u_int8_t ProgrammedMaximumPhysicalLinkRate:4;
/*
		byte 42: PHY CHANGE COUNT
		Counts the number of Broadcast(Change)s originated by an expander phy.
		Expander devices shall support this field. Other device types shall not support
		this field. This field shall be set to zero at power on. The expander device shall
		increment this field at least once when it originates a Broadcast (Change) for
		any reason from the specified expander phy and shall not increment this field when
		forwarding a Broadcast (Change).
		After incrementing the PHY CHANGE COUNT field, the expander device is not 
		required to increment the PHY CHANGE COUNT field again unless a DISCOVER response
		is transmitted. The PHY CHANGE COUNT field shall wrap to zero after the maximum
		value (i.e., FFh) has been reached.
		Application clients that use the PHY CHANGE COUNT field should read it often
		enough to ensure that it does not increment a multiple of 256 times between
		reading the field.
*/
	u_int8_t PhyChangeCount;
/*
		byte 43-bit0-3:PARTIAL PATHWAY TIMEOUT VALUE
		Indicates the partial pathway timeout value in microseconds set by the PHY
		CONTROL function. The recommended default value for PARTIAL PATHWAY TIMEOUT
		VALUE is 7 ��s.
		byte 43-bit7: VIRTUAL PHY
		Set to one indicates the phy is part of an internal port and the attached device
		is contained within the expander device. A VIRTUAL PHY bit set to zero indicates
		the phy is a physical phy and the attached device is not contained within the
		expander device.
*/
	u_int8_t PartialPathwayTimeoutValue:4;
	u_int8_t IgnoredByte36Bit4_6:3;
	u_int8_t VirtualPhy:1;
/*
	byte 44-bit0-3: ROUTING ATTRIBUTE
	Indicates the routing attribute supported by the phy.

	Code	Name			Description
	0h		Direct			Direct routing method for attached end devices.
							Attached expander devices are not supported on this phy.

	1h		Subtractive		a) subtractive routing method for attached expander.
							b) direct routing method for attached end devices.

	2h		Table			a) table routing method for attached expander devices;
							b) direct routing method for attached end devices.

	The ROUTING ATTRIBUTE field shall not change based on the attached device type.
*/
	u_int8_t RoutingAttribute:4;
	u_int8_t ReservedByte44Bit4_7:4;
/*
		byte 45-bit0-6:CONNECTOR TYPE
		Indicates the type of connector used to access the phy, as reported by the
		enclosure services process for the enclosure. A CONNECTOR TYPE field set to 00h
		indicates no connector information is available and that the CONNECTOR ELEMENT
		INDEX field and the CONNECTOR PHYSICAL LINK fields are invalid and shall be
		ignored.
*/
	u_int8_t ConnectorType:7;
	u_int8_t ReservedByte45Bit7:1;
/*
		byte 46:CONNECTOR ELEMENT INDEX
		Indicates the element index of the SAS Connector element representing the
		connector used to access the phy, as reported by the enclosure services
		process for the enclosure.
*/
	u_int8_t ConnectorElementIndex;
/*
		byte 47: CONNECTOR PHYSICAL LINK
		Indicates the physical link in the connector used to access the phy, as
		reported by the enclosure services process for the enclosure.
*/
	u_int8_t ConnectorPhysicalLink;
	struct DiscoverLongFormatDescriptor	LongFormatDescriptor;
/*
		byte 76-77: CRC
*/
	u_int32_t CRC;
}; /* struct SMPResponseDiscover */
/*
************************************************************************
**	this structure describes the Register Device to Host FIS defined in the
**	SATA specification
**	struct SMPResponseReportPhySATAbyte ** 24-43 **
**	struct _SATA_FIS_REG_D2H FIS;
**  Type field value Description
**	27h	Register FIS �V Host to Device
**	34h	Register FIS �V Device to Host
**	39h	DMA Activate FIS �V Device to Host
**	41h	DMA Setup FIS �V Bi-directional
**	46h	Data FIS �V Bi-directional
**	58h	BIST Activate FIS �V Bi-directional
**	5Fh	PIO Setup FIS �V Device to Host
**	A1h	Set Device Bits FIS �V Device to Host
**	A6h	Reserved for future Serial ATA definition
**	B8h	Reserved for future Serial ATA definition
**	BFh	Reserved for future Serial ATA definition
**	C7h	Vendor specific
**	D4h	Vendor specific
**	D9h	Reserved for future Serial ATA definition
**  �V FIS type value assignments
************************************************************************
*/
struct _SATA_FIS_REG_D2H
{
	/* byte 24 */
	u_int8_t FIS_Type;		/* FIS type: Device to Host..0x34 */

	/* byte 25 */
	u_int8_t ReservedByte25Bit0_5:6; /* Byte25Bit54:Reserved ,Byte25Bit3210:PM PORT */
	u_int8_t Interrupt:1;		/* Byte25Bit6:INTERRUPT */
	u_int8_t ReservedByte25Bit7:1;	/* Byte25Bit7:Reserved */
	/* byte 26 */
	u_int8_t Status;		/* Byte26:Status */
	/* byte 27 */
	u_int8_t Error;			/* Byte27:Error */
	/* byte 28 */
	u_int8_t SectorNumber;		/* Byte28:LBA (7:0) */
	/* byte 29 */
	u_int8_t CylLow;		/* Byte29:LBA (15:8) */
	/* byte 30 */
	u_int8_t CylHigh;		/* Byte30:LBA (23:16) */
	/* byte 31 */
	u_int8_t DevHead;		/* Byte31:Device */
	/* byte 32 */
	u_int8_t SectorNumberExp;	/* Byte32:LBA (31:24) */
	/* byte 33 */
	u_int8_t CylLowExp;		/* Byte33:LBA (39:32) */
	/* byte 34 */
	u_int8_t CylHighExp;		/* Byte34:LBA (47:40) */
	/* byte 35 */
	u_int8_t ReservedByte35;	/* Byte35:Reserved */
	/* byte 36 */
	u_int8_t SectorCount;		/* Byte36:SECTOR COUNT (7:0) */
	/* byte 37 */
	u_int8_t SectorCountExp;	/* Byte37:SECTOR COUNT (15:8) */
	/* byte 38-43 */
	u_int8_t ReservedByte38_43[6];	/* Byte38_43:Reserved */
}; /* struct _SATA_FIS_REG_D2H */
/* FIS type definition */
#define SATA_FIS_TYPE_REG_H2D		0x27	/* Register FIS - Host to Device */
#define SATA_FIS_TYPE_REG_D2H		0x34	/* Register FIS - Device to Host */
#define SATA_FIS_TYPE_DMA_ACTIVATE	0x39	/* DMA Activate FIS - Device to Host */
#define SATA_FIS_TYPE_DMA_SETUP		0x41	/* DMA Setup FIS - Bi-directional */
#define SATA_FIS_TYPE_DATA		0x46	/* Data FIS - Bi-directional */
#define SATA_FIS_TYPE_BIST_ACTIVATE	0x58	/* BIST Activate FIS - Bi-directional */
#define SATA_FIS_TYPE_PIO_SETUP		0x5F	/* PIO Setup FIS - Device to Host */
#define SATA_FIS_TYPE_SET_DEVICE_BITS	0xA1	/* Set Device Bits FIS - Device to Host */
/*
************************************************************************
**	SATA FIS: Register-Host to Device
************************************************************************
*/
struct _SATA_FIS_REG_H2D
{
	u_int8_t	FIS_Type;	/* 0x27 */
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t	C : 1;
	u_int8_t	Reserved0 : 3;
	u_int8_t	PM_Port : 4;
#else
	u_int8_t	PM_Port : 4;
	u_int8_t	Reserved0 : 3;
	u_int8_t	C : 1;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	Command;
	u_int8_t	Features;

	u_int8_t	LBA_Low;
	u_int8_t	LBA_Mid;
	u_int8_t	LBA_High;
	u_int8_t	Device;

	u_int8_t	LBA_Low_Exp;
	u_int8_t	LBA_Mid_Exp;
	u_int8_t	LBA_High_Exp;
	u_int8_t	Features_Exp;

	u_int8_t	Sector_Count;
	u_int8_t	Sector_Count_Exp;
	u_int8_t	Reserved1;
	u_int8_t	Control;

	u_int8_t	Reserved2[4];
};
/*
************************************************************************
**	request specific bytes for SMP Report PHY SATA response,
**	intended to be referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportPhySATA
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-8 */
	u_int8_t ReservedByte6_8[3];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10 */
	u_int8_t ReservedByte10;
	/* byte 11 */
	u_int8_t AffiliationValid:1;
	u_int8_t AffiliationSupported:1;
	u_int8_t STPNexusLossOccurred:1;
	u_int8_t ReservedByte11Bit3_7:5;
	/* byte 12-15 */
	u_int8_t ReservedByte10_15[4];
	/* byte 16-23 */
	u_int8_t STPSASAddress[8];
	/* 24-43 */
	struct _SATA_FIS_REG_D2H FIS;
	/* byte 44-47 */
	u_int8_t ReservedByte44_47[4];
	/* byte 48-55 */
	u_int8_t AffiliatedSTPInitiatorSASAddress[8];
	/* byte 56-63 */
	u_int8_t STPNexusLossSASAddress[8];
	/* byte 64-67 */
	u_int32_t CRC;
}; /* struct SMPResponseReportPhySATA */
/*
************************************************************************
**	response specific bytes for SMP Report Route Information, intended to be
**	referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportRouteInformation
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-7 */
	u_int8_t ExpanderRouteIndex[2];
	/* byte 8 */
	u_int8_t ReservedByte8;
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10-11 */
	u_int8_t ReservedByte10_11[2];
	/* byte 12 */
	u_int8_t IgnoredByte12Bit0_6:7;
	u_int8_t ExpanderRouteEntryDisabled:1;
	/* byte 13-15 */
	u_int8_t IgnoredByte13_15[3];
	/* byte 16-23 */
	u_int8_t RoutedSASAddress[8];
	/* byte 24-39 */
	u_int8_t ReservedByte24_39[16];
	/* byte 40-43 */
	u_int32_t CRC;
}; /* struct SMPResponseReportRouteInformation */
/*
************************************************************************
**	response specific bytes for SMP Report Phy Event Information, intended to be
**	referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportPhyEventInformation
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-8 */
	u_int8_t ReservedByte6_8[3];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10-14 */
	u_int8_t ReservedByte10_14[5];
	/* byte 15 */
	u_int8_t NumberOfPhyEventDescriptors;
	/* byte 16-27 */
	u_int8_t PhyEventDescriptor[12];	//TBD
/*
	byte PhyEventDescriptor[12];
		...
	byte PhyEventDescriptor[12];

*/
	u_int32_t CRC;
}; /* struct SMPResponseReportPhyEventInformation */
/*
************************************************************************
**	response specific bytes for SMP Report Phy Broadcast Counts, intended to be
**	referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportBroadcastCounts
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-8 */
	u_int8_t ReservedByte6_8[3];
	/* byte 9 */
	u_int8_t PhyIdentifier;
	/* byte 10-11 */
	u_int8_t ReservedByte10_11[2];
	/* byte 12 */
	u_int8_t ChangeCountValid:1;
	u_int8_t ReservedChange0CountValid:1;
	u_int8_t ReservedChange1CountValid:1;
	u_int8_t SESCountValid:1;
	u_int8_t ExpanderCountValid:1;
	u_int8_t AsysnchronousEventCountValid:1;
	u_int8_t Reserved3CountValid:1;
	u_int8_t Reserved4CountValid:1;
	/* byte 13-15 */
	u_int8_t ReservedByte13_15[3];
	/* byte 16 */
	u_int8_t BroadcastChangeCount;
	/* byte 17 */
	u_int8_t BroadcastReserved0ChangeCount;
	/* byte 18 */
	u_int8_t BroadcastReserved1ChangeCount;
	/* byte 19 */
	u_int8_t BroadcastSESCount;
	/* byte 20 */
	u_int8_t BroadcastExpanderCount;
	/* byte 21 */
	u_int8_t BroadcastAsynchronousEventCount;
	/* byte 22 */
	u_int8_t BroadcastReserved3ChangeCount;
	/* byte 23 */
	u_int8_t BroadcastReserved4ChangeCount;
	u_int32_t CRC;
}; /* struct SMPResponseReportBroadcastCounts */
/*
************************************************************************
**	response specific bytes for SMP Discover List Descriptor, intended to be
**	referenced by SMPResponseDiscoverList
************************************************************************
*/
struct DiscoverShortFormatDescriptor
{
	/* byte 48 */
	u_int8_t PhyIdentifier;
	/* byte 49 */
	u_int8_t FunctionResult;
	/* byte 50 */
	u_int8_t ReservedByte50Bit0_3:4;
	u_int8_t AttachedDeviceType:3;
	u_int8_t ReservedByte50Bit7:1;
	/* byte 51 */
	u_int8_t NegotiatedPhysicalLinkRate:4;
	u_int8_t ReservedByte51Bit4_7:4;
	/* byte 52 */
	u_int8_t AttachedSataHost:1;
	u_int8_t AttachedSMPInitiator:1;
	u_int8_t AttachedSTPInitiator:1;
	u_int8_t AttachedSSPInitiator:1;
	u_int8_t ReservedByte52Bit4_7:4;
	/* byte 53 */
	u_int8_t AttachedSataDevice:1;
	u_int8_t AttachedSMPTarget:1;
	u_int8_t AttachedSTPTarget:1;
	u_int8_t AttachedSSPTarget:1;
	u_int8_t ReservedByte53Bit4_6:3;
	u_int8_t AttachedSataPortSelector:1;
	/* byte 54 */
	u_int8_t RoutingAttribute:4;
	u_int8_t ReservedByte54Bit4_6:3;
	u_int8_t VirtualPhy:1;
	/* byte 55 */
	u_int8_t ReservedByte55;
	/* byte 56 */
	u_int8_t ZoneGroup;
	/* byte 57 */
	u_int8_t ReservedByte57Bit0:1;
	u_int8_t InsideZPSDS:1;
	u_int8_t ZoneGroupPersistent:1;
	u_int8_t ZoneAddressResolved:1;
	u_int8_t RequestedInsideZPSDS:1;
	u_int8_t InsideZPSDSPersistent:1;
	u_int8_t ReservedByte57Bit6_7:2;
	/* byte 58 */
	u_int8_t AttachedPhyIdentifier;
	/* byte 59 */
	u_int8_t PhyChangeCount;
	/* byte 60-68 */
	u_int8_t AttachedSASAddress[8];
	/* byte 69-72 */
	u_int8_t ReservedByte68_72[4];
}; /* DiscoverShortFormatDescriptor */
/*
************************************************************************
**
************************************************************************
*/
union DiscoverListDescriptor
{
	struct DiscoverShortFormatDescriptor	ShortFormatDescriptor;
	struct DiscoverLongFormatDescriptor	LongFormatDescriptor;
};
/*
************************************************************************
**	response specific bytes for SMP Discover List, intended to be
**	referenced by SMPResponse
************************************************************************
*/
struct SMPResponseDiscoverList
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-7 */
	u_int8_t ReservedByte6_8[2];
	/* byte 8 */
	u_int8_t StartingPhyIdentifier;
	/* byte 9 */
	u_int8_t NumberOfDescriptors;
	/* byte 10 */
	u_int8_t PhyFilter:4;
	u_int8_t ReservedByte10Bit4_7:4;
	/* byte 11 */
	u_int8_t DescriptorType:4;
	u_int8_t ReservedByte11Bit4_7:4;
	/* byte 12 */
	u_int8_t DescriptorLength;
	/* byte 13-15 */
	u_int8_t ReservedByte13_15[3];
	/* byte 16 */
	u_int8_t ConfigurableRouteTable:1;
	u_int8_t Congiguring:1;
	u_int8_t ReservedByte16Bit2_5:4;
	u_int8_t ZoningEnabled:1;
	u_int8_t ZoningSupported:1;
	/* byte 17-31 */
	u_int8_t ReservedByte17_31[15];
	/* byte 32-47 */
	u_int8_t VendorSpecific[16];
	/* byte 48 - n */
	union DiscoverListDescriptor 	FirstDescriptor;
	/*
	DiscoverListDescriptor 	SecondDescriptor;	//TBD
		...
	DiscoverListDescriptor 	LastDescriptor;

	*/
	u_int32_t CRC;
}; /* struct SMPResponseDiscoverList */
/*
************************************************************************
**	response specific bytes for Expander Route Table Descriptor, intended to be
**	referenced by SMPResponseReportExpanderTable
************************************************************************
*/
struct ExpanderRouteTableDescriptor
{
	/* byte 32-37 */
	u_int8_t PhyBitMap[6];
	/* byte 38 */
	u_int8_t ReservedByte38Bit0_6:7;
	u_int8_t ZoneGroupValid:1;
	/* byte 39 */
	u_int8_t ZoneGroup;
	/* byte 40-48 */
	u_int8_t RoutedSASAddress[8];
};/* ExpanderRouteTableDescriptor */
/*
************************************************************************
**	response specific bytes for SMP Report Expander Route Table, intended to be
**	referenced by SMPResponse
************************************************************************
*/
struct SMPResponseReportExpanderTable
{
	/* byte 4-5 */
	u_int8_t ExpanderChangeCount[2];
	/* byte 6-7 */
	u_int8_t ExpanderRouteTableChangeCount[2];
	/* byte 8 */
	u_int8_t ReservedByte8Bit0:1;
	u_int8_t Configuring:1;
	u_int8_t ReservedByte8Bit2_7:6;
	/* byte 9 */
	u_int8_t ReservedByte9;
	/* byte 10-11 */
	u_int8_t NumberOfDescriptors[2];
	/* byte 12-13 */
	u_int8_t FirstRoutedSASAddressIndex[2];
	/* byte 14-15 */
	u_int8_t LastRoutedSASAddressIndex[2];
	/* byte 13-15 */
	u_int8_t ReservedByte13_15[3];
	/* byte 16-18 */
	u_int8_t ReservedByte16_18[3];
	/* byte 19 */
	u_int8_t StartingPhyIdentifier;
	/* byte 20-31 */
	u_int8_t ReservedByte20_31[12];
	/* byte 32 - n */
	struct ExpanderRouteTableDescriptor	FirstRouteTableDescriptor;
	/*
	ExpanderRouteTableDescriptor 	SecondRouteTableDescriptor;	//TBD
		...
	ExpanderRouteTableDescriptor 	LastRouteTableDescriptor;

	*/
	u_int32_t CRC;
}; /* struct SMPResponseReportExpanderTable */
/*
************************************************************************
**
************************************************************************
*/
struct SMPResponseConfigureFunction
{
	/* byte 4-7 */
	u_int32_t CRC;
};
/*
************************************************************************
**	response specific to SMP Read SGPIO
**	Corresponds to READ_GPIO_REGISTER define
************************************************************************
*/
struct SMPResponseReadGPIORegister
{
	/* byte 4-11 */
	u_int8_t Data_In_Low[8];
	/* byte 12-19 */
	u_int8_t Data_In_High[8];
	u_int32_t CRC;
};
/*
************************************************************************
**	response specific to SMP Read SGPIO
**	Corresponds to WRITE_GPIO_REGISTER define
************************************************************************
*/
struct SMPResponseWriteGPIORegister
{
	u_int32_t CRC;
};
/*
************************************************************************
**	generic structure referencing an SMP Response, must be initialized
**	before being used
************************************************************************
*/
struct _SMPResponse
{
	/* byte 0 */
	u_int8_t SMPFrameType; /* always 41h for SMP responses */
	/* byte 1 */
	u_int8_t Function;
	/* byte 2 */
	u_int8_t FunctionResult;
	/* byte 3 */
	u_int8_t ReservedByte3;
	/* bytes 4-n */
	union
	{
	/* #define REPORT_GENERAL 				0x00 */
		struct SMPResponseReportGeneral ReportGeneral;
	/* #define REPORT_MANUFACTURER_INFORMATION 		0x01 */
		struct SMPResponseReportManufacturerInformation 	ReportManufacturerInformation;
	/* #define READ_GPIO_REGISTER				0x02 */
		struct SMPResponseReadGPIORegister			ReadGPIORegister;
	/* #define REPORT_SELF_CONFGRIGRUATION_STATUS		0x03 */
		struct SMPResponseReportSelfConfigurationStatus		ReportSelfConfigurationStatus;
	/* #define DISCOVER 					0x10 */
		struct SMPResponseDiscover 				Discover;
	/* #define REPORT_PHY_ERROR_LOG 			0x11 */
		struct SMPResponseReportPhyErrorLog 			ReportPhyErrorLog;
	/* #define REPORT_PHY_SATA 				0x12 */
		struct SMPResponseReportPhySATA 			ReportPhySATA;
	/* #define REPORT_ROUTE_INFORMATION 			0x13 */
		struct SMPResponseReportRouteInformation 		ReportRouteInformation;
	/* #define REPORT_PHY_EVENT_INFORMATION			0x14 */
		struct SMPResponseReportPhyEventInformation		ReportPhyEventInformation;
	/* #define REPORT_PHY_BROADCAST_COUNTS			0x15 */
		struct SMPResponseReportBroadcastCounts			ReportBroadcastCounts;
	/* #define DISCOVER_LIST				0x16 */
		struct SMPResponseDiscoverList				DiscoverList;
	/* #define REPORT_EXPANDER_ROUTE_TABLE			0x17 */
		struct SMPResponseReportExpanderTable			ReportExpanderTable;
	/* #define CONFIGURE_GENERAL				0x80 */
		struct SMPResponseConfigureFunction			ConfigureGeneral;
	/* #define ENABLE_DISABLE_ZONING			0x81 */
		struct SMPResponseConfigureFunction			EnableDisableZoning;
	/* #define WRITE_GPIO_REGISTER				0x82 */
		struct SMPResponseWriteGPIORegister			WriteGPIORegister;
	/* #define ZONED_BROADCAST				0x85 */
		struct SMPResponseConfigureFunction			ZonedBroadcast;
	/* #define CONFIGURE_ROUTE_INFORMATION 			0x90 */
		struct SMPResponseConfigureFunction			ConfigureRouteInformation;
	/* #define PHY_CONTROL 					0x91 */
		struct SMPResponseConfigureFunction 			PhyControl;
	/* #define PHY_TEST 					0x92 */
		struct SMPResponseConfigureFunction 			PhyTest;
	/* #define CONFIGURE_PHY_EVENT_INFORMATION		0x93 */
		struct SMPResponseConfigureFunction 			ConfigurePhyEventInformation;
	} Response;
}; /* struct SMPResponse */
/*
************************************************************************
**
************************************************************************
*/
struct _AdapterInfo
{
	u_int32_t	flags;
	u_int16_t	devId;
	u_int32_t	classCode;
	 u_int8_t	revId;
	u_int8_t	bus;
	u_int8_t	devFunc;
	void		*bar[6];
	u_int32_t	ExpRomBaseAddr;
	u_int8_t	version;
	u_int8_t	subVersion;

	u_int16_t	FlashID;
	u_int32_t	FlashSize;
	u_int32_t	FlashSectSize;
};
/*
***********************************************************************
**
***********************************************************************
*/
struct _Route_Table_Entry
{
	u_int32_t	Disabled;
	u_int8_t	SASAddr[8];
};
/*
************************************************************************
** if TagStackType!=FIFO_TAG, use FILO,
** if TagStackType==FIFO_TAG, use FIFO, PtrOut is the next tag to get
**  and Top is the number of available tags in the stack
** when use FIFO, get tag from PtrOut and free tag to (PtrOut+Top)%Size
************************************************************************
*/
struct _Tag_Stack
{
	u_int16_t	*Stack;

	u_int16_t	Top;
	u_int16_t	Size;

	u_int16_t	PtrOut;
	u_int8_t	TagStackType;
	u_int8_t	Reserved[1];

	arcsas_lock_t	tag_mutex;
};
/*
************************************************************************
**		DOMAIN Port (multiple link, logical port) structure
************************************************************************
*/
struct _Domain_Port
{
	PCORE		pCore;

	u_int8_t	Port_Index;	/* sas port device id */
	u_int8_t	Port_State;
	u_int8_t	Type;		/* PORT_TYPE_SAS,PORT_TYPE_SATA,PORT_TYPE_PM */
	u_int8_t	Setting;	/* PORT_SETTING_XXX */

	u_int8_t	MemberPhyMap;		/* record group of phy "WidePort" */
	u_int8_t	Expander_Number;
	u_int8_t	DiscoveryInstance;
	u_int8_t	Workaround;

	volatile u_int8_t	Device_Number;	/* How many devices does this port have now? */
	uint8_t		PostSesPageInstance;
	u_int8_t	Reserved[2];

	PDomain_Phy	pPhy;		/* pointer back to the phy of this port */
	PDomain_PM	pPM;

	struct list_head	Device_List;
	struct list_head	Expander_List;
};
/* Port initialization state */
#define PORT_STATE_IDLE			0x00
#define PORT_STATE_INIT_DONE		0xFF
// Port type
#define PORT_TYPE_SATA			ARCSAS_BIT(0)
#define PORT_TYPE_SAS			ARCSAS_BIT(1)
#define PORT_TYPE_PM			ARCSAS_BIT(2)
// port setting
#define PORT_SETTING_NCQ_RUNNING	ARCSAS_BIT(0)
#define PORT_SETTING_PM_EXISTING	ARCSAS_BIT(1)
#define PORT_SETTING_PM_FUNCTIONAL	ARCSAS_BIT(2)
#define PORT_SETTING_DURING_RETRY	ARCSAS_BIT(3)
#define PORT_SETTING_DURING_RECOVERY	ARCSAS_BIT(4)
/*
********************************************************************
**	Physical Port (PHY based) structure
**	Port has Phy, Phy has Port
********************************************************************
*/
struct _Domain_Phy
{
	PDomain_Port	pPort;
	/* from PORT_CONFIG_ADDR0-3, PhyID/device protocol/sas_addr/SIG/wide_port */
	u_int32_t	DevInfo;
	ARCSAS_U64	DevSASAddr;
	u_int32_t	AttDevInfo;
	ARCSAS_U64	AttDevSASAddr;

	u_int8_t	Type;
//#define PORT_TYPE_SATA	ARCSAS_BIT(0)
//#define PORT_TYPE_SAS		ARCSAS_BIT(1)
//#define PORT_TYPE_PM		ARCSAS_BIT(2)
	u_int8_t	WidePortPhyMap;	/* record group of phy */
	u_int8_t	OOB_Mode;		/* out of band */
//#define	OOB_NOT_CONNECTED	0
//#define	SATA_OOB_MODE		1
//#define	SAS_OOB_MODE		2
	u_int8_t	Reserved;
	/* from PORT_PHY_CONTROL0-3, REG_PORT_PHY_CONTROL, linkrate, current status */
	u_int32_t	PhyStatus;
	/* from PORT_IRQ_MASK0-3 */
	u_int32_t	IRQStatus;
	//PHY_RDY_CHNG_MASK			= ARCSAS_BIT(0),
	//HRD_RES_DONE_MASK			= ARCSAS_BIT(1),
	//PHY_ID_DONE_MASK			= ARCSAS_BIT(2),
	//PHY_ID_FAIL_MASK			= ARCSAS_BIT(3),
	//PHY_ID_TIMEOUT			= ARCSAS_BIT(4),
	//HARD_RESET_RCVD_MASK			= ARCSAS_BIT(5),
	//PORT_SEL_PRESENT_MASK			= ARCSAS_BIT(6),
	//COMWAKE_RCVD_MASK			= ARCSAS_BIT(7),
	//BRDCST_CHNG_RCVD_MASK			= ARCSAS_BIT(8),
	//UNKNOWN_TAG_ERR			= ARCSAS_BIT(9),
	//IU_TOO_SHRT_ERR			= ARCSAS_BIT(10),
	//IU_TOO_LNG_ERR			= ARCSAS_BIT(11),
	//PHY_RDY_CHNG_1_TO_0			= ARCSAS_BIT(12),
	//SIG_FIS_RCVD_MASK			= ARCSAS_BIT(16),
	//BIST_ACTVT_FIS_RCVD_MASK		= ARCSAS_BIT(17),
	//ASYNC_NTFCN_RCVD_MASK			= ARCSAS_BIT(18),
	//UNASSOC_FIS_RCVD_MASK			= ARCSAS_BIT(19),
	//STP_SATA_RX_ERR_MASK			= ARCSAS_BIT(20),
	//STP_SATA_TX_ERR_MASK			= ARCSAS_BIT(21),
	//STP_SATA_CRC_ERR_MASK			= ARCSAS_BIT(22),
	//STP_SATA_DCDR_ERR_MASK		= ARCSAS_BIT(23),
	//STP_SATA_PHY_DEC_ERR_MASK		= ARCSAS_BIT(24),
	//STP_SATA_SYNC_ERR_MASK		= ARCSAS_BIT(25),
};
#define BUG_OF_SUPER_MICRO_IU_TOO_SHORT		0x0B00
#define BUG_OF_SUPER_MICRO_IU_TOO_LONG		0x0700
/* fix expander bug of super micro , no spin up with SATA DISK */
#define BUG_OF_SUPER_MICRO_REPORT_ERROR_MASK	0x0F00 /* 0B00,0700,0B01,0F01,0701,0F00 */
/*
************************************************************************************************
**	Domain of SATA Port Multiplier
************************************************************************************************
*/
struct _Domain_PM
{
	struct list_head	Sent_CCB_List;	/* List of requests that were sent to the device, in order */

	u_int16_t		Pci_Ven_ID;
	u_int16_t		Pci_Dev_ID;
	u_int16_t		PluginNotify;
	u_int16_t		Status;		/* DEVICE_STATUS_XXX */

	u_int8_t		CorePhyNum;
	u_int8_t		ProductRevision;
	u_int8_t		SpecRevision;		/* 10 means 1.0, 11 means 1.1 */
	u_int8_t		NumberOfPorts;
	u_int8_t		wait_Timer_ID;		/* for error handling */
	u_int8_t		EntryIndex;		/* port mutiplier device id */
	u_int8_t		RetryCnt;
	u_int8_t		State;

	struct _Timer_Request	CCB_timer_request;
	struct _Timer_Request	wait_timer_request;

	u_int8_t		register_set;		/* which register set this device is using */
	u_int8_t		Error_Handling_State;
	u_int8_t		CCB_Timer_ID;		/* for error handling */
	u_int8_t		CCB_Timeout_Count;	/* number of times this device has timed out */
	u_int8_t		CheckedPort;
	u_int8_t		ActPortNumber;
	u_int8_t		Feature_Enabled;
	u_int8_t		PlugStatus;

	PDomain_Device		pDevices[ARCSAS_MAX_DEVICE_PER_PM];
	PDomain_Expander	pExpander;
	PDomain_Port		pPort;

	u_int32_t		SError;
	volatile int32_t	Outstanding_CCB;	/* for error handling */
};
// PM status
#define PM_STATUS_NO_DEVICE		0
#define PM_STATUS_INITIATING		ARCSAS_BIT(0)
#define PM_STATUS_STARTED		ARCSAS_BIT(1)
#define PM_STATUS_RESET			ARCSAS_BIT(2)
#define PM_STATUS_DEVICES_INITIATING	ARCSAS_BIT(3)
#define PM_STATUS_DEVICE_REMOVING	ARCSAS_BIT(4)
#define PM_STATUS_DEVICE_HOTPLUG	ARCSAS_BIT(5)
#define PM_STATUS_DEVICE_PHY_CHANGE	ARCSAS_BIT(6)
#define PM_STATUS_GSCR_CHANGE		ARCSAS_BIT(7)
#define PM_STATUS_LINK_RATE_RESET	ARCSAS_BIT(8)
/* PM State definitions */
#define PM_STATE_IDLE			0x00
#define PM_STATE_INIT			0x01
#define PM_STATE_READ_INFO_DONE		0x02
#define PM_STATE_READ_ID_DONE		0x03
#define PM_STATE_READ_REV_DONE		0x04
#define PM_STATE_ENABLE_ASYNOTIFY	0x05
#define PM_STATE_CLEAR_ERROR_INFO	0x06
#define PM_STATE_PORT_ENABLE_1		0x07
#define PM_STATE_PORT_ENABLE_0		0x08
#define PM_STATE_PORT_ENABLED		0x09
#define PM_STATE_READ_PORT_ERROR	0x0A
#define PM_STATE_CLEAR_PORT_ERROR	0x0B
#define PM_STATE_PORT_FINISHED		0x0C
#define PM_STATE_CHECK_HOTPLUG		0x0D
#define PM_STATE_READ_PERROR		0x0E
#define PM_STATE_CLEAR_PERROR		0x0F
#define PM_STATE_READ_PSTATUS		0x10
#define PM_STATE_FLUSH_GERROR		0x11
#define PM_STATE_DEVICE_PLUG_IN		0x12
#define PM_STATE_DEVICE_PLUG_OUT	0x13
#define PM_STATE_PORT_ENABLE_FLUSHED	0x14
#define PM_STATE_PORT_WAITING_PHY_READY	0x15
#define PM_STATE_PORT_SPIN_UP_DEVICE	0x16
#define PM_STATE_PORT_SPIN_UP_DEVICE_DONE	0x17
// plus status
#define PM_DEVICE_PLUG_IN		ARCSAS_BIT(0)
#define PM_DEVICE_PLUG_OUT		ARCSAS_BIT(1)
/*
***********************************************************************
**	Domain of SAS Expander
***********************************************************************
*/
struct _Domain_Expander
{
	struct list_head	Exp_Queue_Pointer;
	struct list_head	Device_List;

	ARCSAS_U64		SASAddr;

	PDomain_Port		pPort;
	PDomain_Expander	pParent;

	u_int16_t		ExpanderChangeCount;
	u_int16_t		ResetPhyCount;

	u_int16_t		ComponentID;
	u_int8_t		ComponentRevisionID;
	u_int8_t		NegotiatedLinkRate;

	/* How many devices this port has now? */
	volatile u_int8_t	Device_Number;
	u_int8_t		Phy_Count;	/* # of phys on this expander */
	u_int8_t		ParentPhyCount;	/* # of phys used to connect this expander to its parent */
	u_int8_t		EntryIndex;	/* sas expander device id */

	u_int8_t		STP_INIT:1;
	u_int8_t		SMP_INIT:1;
	u_int8_t		SSP_INIT:1;
	u_int8_t		STP_TRGT:1;
	u_int8_t		SMP_TRGT:1;
	u_int8_t		SSP_TRGT:1;
	u_int8_t		route_table_configurable:1;
	u_int8_t		Reserved_bit:1;
	u_int8_t		Reserved[3];

	u_int32_t		Route_Index_Count;

	struct _Route_Table_Entry   *Route_Table;

	u_int8_t		ParentPhyId[ARCSAS_MAX_WIDEPORT_PHYS];
	u_int8_t		SelfPhyId[ARCSAS_MAX_WIDEPORT_PHYS]; /* 4 */

	u_int8_t		VendorID[16];
	u_int8_t		ProductID[24];
	u_int8_t		ProductRev[8];
	u_int8_t		ComponentVendorID[16];
};
/*
************************************************************************************************
**	Domain of Device...disk, tape, scanner, mo, CDROM, CDRW......
************************************************************************************************
*/
struct _Domain_Device
{
	struct list_head	Port_Queue_Pointer;
	struct list_head	Exp_Queue_Pointer;
	struct list_head	Sent_CCB_List;		/* List of requests that were sent to the device, in order */
	struct list_head	EH_CCB_Waiting_List;	/* Waiting Request Queue */

	PCORE			pCore;
	PDomain_Expander	pExpander;		/* SAS Expander	*/
	PDomain_Device		pSesDevice;		/* pointer to the SES device if it is a SES element, if not with NULL */
	PDomain_Port		pPort;			/* SAS Port, SATA Port	*/
	PDomain_PM		pPM;			/* SATA Port Multiplier	*/
	PCCB			Consolidate_Root_CCB;	/* Internal request which already consolidate some external requests. */

	ARCSAS_U64		WWN;
	ARCSAS_U64		SASAddr;		/* Enclosure LogicalID:8bytes */
	ARCSAS_U64		Max_LBA;
	ARCSAS_U64		Consolidate_Last_LBA;	/* last LBA */

//	struct _Timer_Request	Consolidate_timer_request;
	struct _Timer_Request	CCB_timer_request;
	struct _Timer_Request	wait_timer_request;

	u_int32_t		SectorSize;
	volatile u_int32_t	NCQTagMask;		/* 32bit for SATA NCQ TAG */
	u_int32_t		TotalFormattedLbaCount;
	volatile int32_t	Outstanding_CCB;	/* for error handling */

	/*
	*********************************************************
	** Different device should have a different struct here.
	** Now it's SATA device only.
	*********************************************************
	*/
	u_int16_t		Setting;		/* The supported features are enabled or not. */
	u_int16_t		EntryIndex;		/* sas device device id ,scsilun-scsiid */
	u_int16_t		Retry_Count;
	u_int16_t		Ability;		/* Be able to support NCQ, 48 bit LBA. */

	u_int8_t		Pm_port_number;
	u_int8_t		PIO_Mode;
	u_int8_t		MDMA_Mode;
	u_int8_t		UDMA_Mode;
	u_int8_t		Current_PIO;
	u_int8_t		Current_MDMA;
	u_int8_t		Current_UDMA;
	u_int8_t		register_set;		/* which register set this device is using */

	u_int8_t		Error_Handling_State;
	/*
	***************************************
	**  EH_NONE= 0,
	**  EH_ABORT_REQUEST,
	**  EH_LU_RESET,
	**  EH_DEVICE_RESET,
	**  EH_PORT_RESET,
	**  EH_CHIP_RESET,
	**  EH_SET_DISK_DOWN
	***************************************
	*/
	u_int8_t		Phy_Id;
	u_int8_t		Queue_Depth;
	u_int8_t		Device_Reset_Count;
	u_int8_t		Is_Waiting;			/* for hibernation serial state machine - which device is waiting to be initialized */
	u_int8_t		NegotiatedLinkRate;
	u_int8_t		CCB_Timer_ID;			/* for error handling */
	u_int8_t		CCB_Timeout_Count;		/* number of times this device has timed out */

//	u_int8_t		Consolidate_Timer_ID;		/* for error handling */
	u_int8_t		wait_Timer_ID;			/* for error handling */
	u_int8_t		MaxOfEnclosureSlotNumber;	/* max slot number in this enclosure */
	u_int8_t		Sibling_phy_cnt;		/* count for testing if it is wide port end device */
	u_int8_t		CmdErrorCount;
	u_int8_t		State;				/* DEVICE_STATE_XXX */
	u_int8_t		Status;				/* DEVICE_STATUS_XXX */
	u_int8_t		Connection;
	u_int8_t		Dev_Type;

	u_int8_t		Need_Notify;			/* BYTE size: added for PM hot plug */
	u_int8_t		Consolidate_scsi_Read;		/* The last request is read or write. */
	u_int8_t		Consolidate_ccbs_count;		/* sequential counter */
	OverallEnclosureStatus	SesOverallEnclosureStatus;	/* BYTE size: could be used as control or status */
	/*
	************************************************************
	**		SES briefing
	**	A device could be a SSP/STP/SATA/ATAPI device
	**	which can be determined by the Device_Type.
	**	A SSP device could be a disk drive or a SES device.
	**	A SSP/STP device could be an elememt of a SES device
	**	(for example, disk drives in an enclosure).
	**	Whether a SSP/STP device is an elememt of a SES device
	**	or not could be determined by the pSesDevice pointer.
	**	If the pSesDevice is NULL, it is not a SES element.
	************************************************************
	*/
	u_int8_t	SesOverallElementIndex; /* include type overall */
	u_int8_t	SesElementIndex;	/* used only if a SES element, not include overall */
	u_int8_t	SesSlotNumber;
	u_int8_t	SesElementType;

	/*
	*************************************************************
	** could be used as control or status,
	** type can be determined by SesElementType (device or array)
	*************************************************************
	*/
	SesEnclosureElement	ses_enclosure_element;	/*4 bytes*/
	uint32_t	ses_pages_supported;
	u_int8_t	Model_Number[40];	/* Enclosure ProductID:16bytes */
	u_int8_t	Serial_Number[20];	/* Enclosure VendorID:8bytes */
	u_int8_t	Firmware_Revision[8];	/* Enclosure Product_Revision:4bytes */
	u_int8_t	saslun[8];
	u_int16_t	Rotation_Rate; /* 0 rpm =0001h, Non-rotating medium (SSD);7200 rpm = 1C20h;10000 rpm = 2710h;15000 rpm = 3A98h */
	u_int8_t	NCQ_error;
	u_int8_t	Reserved1[1];
};
#define	SOLID_STATE_ROTATING_RATE	1
/* Device ability 3G and TCQ */
#define DEVICE_ABILITY_48BIT_SUPPORTED		ARCSAS_BIT(0)
#define DEVICE_ABILITY_SMART_SUPPORTED		ARCSAS_BIT(1)
#define DEVICE_ABILITY_WRITECACHE_SUPPORTED	ARCSAS_BIT(2)
#define DEVICE_ABILITY_NCQ_SUPPORTED		ARCSAS_BIT(3)
#define DEVICE_ABILITY_RATE_1_5G		ARCSAS_BIT(4)
#define DEVICE_ABILITY_RATE_3G			ARCSAS_BIT(5)
#define DEVICE_ABILITY_RATE_6G			ARCSAS_BIT(6)
#define DEVICE_ABILITY_READLOGEXT_SUPPORTED	ARCSAS_BIT(7)
#define DEVICE_ABILITY_READ_LOOK_AHEAD_SUPPORTED	ARCSAS_BIT(8)
#define DEVICE_ABILITY_SMART_SELF_TEST_SUPPORTED	ARCSAS_BIT(9)
#define DEVICE_ABILITY_HAD_FORMAT_UNIT			ARCSAS_BIT(10)
#define DEVICE_ABILITY_DATA_SET_MANAGEMENT_SUPPORTED	ARCSAS_BIT(11)
/* Device initialization state */
#define DEVICE_STATE_IDLE			0x0
#define DEVICE_STATE_PM_ENABLE_1		0x1
#define DEVICE_STATE_PM_ENABLE_0		0x2
#define DEVICE_STATE_SRST_1			0x3
#define DEVICE_STATE_SRST_0			0x4
#define DEVICE_STATE_RESET_DONE			0x5
/* SATA device states */
#define DEVICE_STATE_IDENTIFY_DONE		0x6
#define DEVICE_STATE_SET_UDMA_DONE		0x7
#define DEVICE_STATE_SET_PIO_DONE		0x8
#define DEVICE_STATE_ENABLE_WRITE_CACHE_DONE	0x9
#define DEVICE_STATE_ENABLE_READ_AHEAD_DONE	0xA
/* SAS device states */
#define DEVICE_STATE_INQUIRY_DONE		0xB /* issue read capacity next */
#define DEVICE_STATE_INQUIRY_16_DONE		0xC /* issue read capacity 16 next */
#define DEVICE_STATE_INQUIRY_EVPD_DONE		0xD	/*  */
#define DEVICE_STATE_INQUIRY_16_EVPD_DONE	0xE	/*  */
#define DEVICE_STATE_READ_CAPACITY_DONE		0xF
#define DEVICE_STATE_READ_CAPACITY_DONE_10	0x10
#define DEVICE_STATE_MODE_SENSE_CACHING_PAGE_DONE	0x11
#define DEVICE_STATE_MODE_SENSE_PORT_CONTROL_PAGE_DONE	0x12
#define DEVICE_STATE_MODE_SELECT_DONE			0x13
#define DEVICE_STATE_LOG_SENSE_DONE			0x14
/* Device states */
#define DEVICE_STATE_FORMAT_DONE		0x15
#define DEVICE_STATE_FORMAT_WRITE		0x16
#define DEVICE_STATE_FORMAT_VERIFY		0x17
#define DEVICE_STATE_PM_SOFTRESET		0x18
#define DEVICE_STATE_STARTSTOP_DONE		0x19
#define DEVICE_STATE_REPORT_LUN_DONE		0x1A
/* SES device states */
#define DEVICE_STATE_SUPPORTED_DIAGNOSTICS_DONE		0x59
#define DEVICE_STATE_CONFIGURATION_DONE			0x5A
#define DEVICE_STATE_ENCLOSURE_STATUS_DONE		0x5B
#define DEVICE_STATE_ELEMENT_DESCRIPTOR_DONE		0x5C
#define DEVICE_STATE_ADDITIONAL_ELEMENT_STATUS_DONE	0x5D
#define DEVICE_STATE_SES_STATE_MACHINE_START		0x50
#define DEVICE_STATE_SES_STATE_MACHINE_DONE		0x5F
/* GENERIC device state */
#define DEVICE_STATE_INIT_FAILED		0xFE
#define DEVICE_STATE_INIT_DONE			0xFF
/* Device status */
#define DEVICE_STATUS_NO_DEVICE			ARCSAS_BIT(0)
#define DEVICE_STATUS_EXISTING			ARCSAS_BIT(1)
#define DEVICE_STATUS_FUNCTIONAL		ARCSAS_BIT(2)
#define DEVICE_STATUS_ERROR			ARCSAS_BIT(3)
#define DEVICE_STATUS_DRIVER_KICKOUT		ARCSAS_BIT(4)
#define DEVICE_STATUS_EH_SUCCESS		ARCSAS_BIT(5)
#define DEVICE_STATUS_SLOT_NUMBER_VALID		ARCSAS_BIT(6)
#define DEVICE_STATUS_IO_LOCK_UNLOCK		ARCSAS_BIT(7)
#define	DEVICE_STATUS_NCQ_ERROR			ARCSAS_BIT(8)
/* Device connection */
#define DC_ATA			ARCSAS_BIT(0)
#define DC_SCSI			ARCSAS_BIT(1)
#define DC_SERIAL		ARCSAS_BIT(2)
#define DC_PARALLEL		ARCSAS_BIT(3)
#define DC_ATAPI		ARCSAS_BIT(4)
#define DC_SGPIO		ARCSAS_BIT(5)
/* Device type defined in SCSI-III specification (used by new driver) */
#define DT_DIRECT_ACCESS_BLOCK		0x00
#define DT_SEQ_ACCESS			0x01
#define DT_PRINTER			0x02
#define DT_PROCESSOR			0x03
#define DT_WRITE_ONCE			0x04
#define DT_CD_DVD			0x05
#define DT_OPTICAL_MEMORY		0x07
#define DT_MEDIA_CHANGER		0x08
#define DT_STORAGE_ARRAY_CTRL		0x0C
/* an actual enclosure */
#define DT_ENCLOSURE			0x0D
/* The following are defined by Marvell */
#define DT_EXPANDER			0x20
#define DT_PM				0x21
/* a device that provides some SES services (ie, Luigi) */
#define DT_SES_DEVICE			0x22
#define DT_LOGICAL_UNIT_NOT_PRESENT_DEVICE	0x7F
/* notify */
#define ARCSAS_DEVICE_NO_NEED_NOTIFY			0x00
#define ARCSAS_DEVICE_NEED_NOTIFY			0x01
#define ARCSAS_DEVICE_FAILED_NO_NEED_NOTIFY		0x02
#define ARCSAS_DEVICE_FAILED_DRIVER_KICKOUT_NOTIFY	0x04	/* light on ERROR LED */
#define ARCSAS_DEVICE_UNPLUG_NOTIFY			0x08	/* light off all LED */
#define ARCSAS_DEVICE_FAILED_NO_REMOVE_NOTIFY		0x10
/* SES Element Type */
#define SES_TYPE_UNSPECIFIED		0x00
#define SES_TYPE_DISK_DEVICE		0x01
#define SES_TYPE_POWER_SUPPLY		0x02
#define SES_TYPE_FAN			0x03
#define SES_TYPE_TEMPERATURE_SENSOR	0x04
#define SES_TYPE_DOOR_LOCK		0x05
#define SES_TYPE_SPEAKER		0x06
#define SES_TYPE_ES_CONTROLLER		0x07 /* Enclosure SCC */
#define SES_TYPE_SCC_CONTROLLER		0x08 /* SCC */
#define SES_TYPE_NONVOLATILE_CACHE	0x09
#define SES_TYPE_UPS			0x0B
#define SES_TYPE_DISPLAY		0x0C
#define SES_TYPE_KEYPAD			0x0D
#define SES_TYPE_ENCLOSURE		0x0E
#define SES_TYPE_SCSI_TRANSCEIVER	0x0F
#define SES_TYPE_LANGUAGE		0x10
#define SES_TYPE_COMM_PORT		0x11
#define SES_TYPE_VOLTAGE_SENSOR		0x12
#define SES_TYPE_CURRENT_SENSOR		0x13
#define SES_TYPE_SCSI_TARGET_PORT	0x14
#define SES_TYPE_SCSI_INITIATOR_PORT	0x15
#define SES_TYPE_SIMPLE_SUBENCLOSURE	0x16
#define SES_TYPE_ARRAY_DEVICE		0x17 /* such as ARC8060 in Enclosure */
#define SES_TYPE_VENDOR_SPECIFIC	0x80
/*
*************************************************************
** bit0 :page 0x00 SES_PG_SUPPORTED_DIAGNOSTICS
** bit1 :page 0x01 SES_PG_CONFIGURATION
** bit2 :page 0x02 SES_PG_ENCLOSURE_STATUS/SES_PG_ENCLOSURE_CONTROL
** bit3 :page 0x03 SES_PG_HELP_TEXT
** bit4 :page 0x04 SES_PG_STRING_IN/SES_PG_STRING_OUT
** bit5 :page 0x05 SES_PG_THRESHOLD_IN/SES_PG_THRESHOLD_OUT
** bit6 :page 0x06 SES_PG_ARRAY_DIAGNOSTIC_STATUS/SES_PG_ARRAY_DIAGNOSTIC_CONTROL
** bit7 :page 0x07 SES_PG_ELEMENT_DESCRIPTOR
** bit8 :page 0x08 SES_PG_SHORT_ENCLOSURE_STATUS
** bit9 :page 0x09 SES_PG_ENCLOSURE_BUSY
** bit10:page 0x0A SES_PG_ADDITIONAL_ELEMENT_STATUS
** bit11:page 0x0B SES_PG_SUBENCLOSURE_HELP_TEXT
** bit12:page 0x0C SES_PG_SUBENCLOSURE_STRING_IN/SES_PG_SUBENCLOSURE_STRING_OUT
** bit13:page 0x0D SES_PG_SUPPORTED_SES_DIAGNOSTICS
** bit14:page 0x0E SES_PG_DOWNLOAD_MICROCODE_STATUS/SES_PG_DOWNLOAD_MICROCODE_CONTROL
*************************************************************
*/
/*
********************************************************************
**	must be 64-byte aligned
********************************************************************
*/
#define		ALLOCATE_SLOT_CNT	16
struct _CORE
{
	struct list_head	CCB_Wait_RegisterSet_List;	/* List of CCBs that wait reg set */
	struct list_head	CCB_Waiting_List;		/* Waiting Request Queue */
	struct list_head	CCB_Complete_List;		/* Completed Request Queue */
	struct list_head	Core_CCB_List;			/* list of free internal requests */
	struct list_head	Context_List;			/* list of core context data structure */
	struct list_head	SAS_Scratch_List;		/* list of free scratch buffers for SATA */
	struct list_head	SMP_Scratch_List;		/* list of free scratch buffers for SMP Requests */
	struct list_head	PRD_Buffer_List;		/* list of SG buffers for command table */

	arcsas_lock_t		ccb_waiting_list_mutex;
	arcsas_lock_t		ccb_complete_list_mutex;
	arcsas_lock_t		core_ccb_list_mutex;
	arcsas_lock_t		context_list_mutex;
	arcsas_lock_t		sas_scratch_list_mutex;
	arcsas_lock_t		smp_scratch_list_mutex;
	arcsas_lock_t		prd_buffer_list_mutex;
	arcsas_lock_t		ccb_sent_list_mutex;

	PACB			pACB;
	PVOID			pCmdSlot;		/* command list Vir: Can be PARCSAS_PATA_Command_Header or PARCSAS_Command_Header */
	PVOID			pRX_FIS;		/* received FIS Vir: SATA FIS */
	PVOID			pCmd_Table;		/* 32 command tables Vir: */
	PVOID			pDeliveryQ;		/* delivery queue Vir: */
	PVOID			pCompletionQ;		/* completion queue Vir: */

	ARCSAS_U64		CmdSlot_Phys;		/* command list Phy: */

	/* Received FIS */
	ARCSAS_U64		RX_FIS_Phys;		/* received FIS Phy: */

	/* The 32 command tables. */
	ARCSAS_U64		Cmd_Table_Phys;		/* 32 command tables Phy: */

	/* Delivery Queue */
	ARCSAS_U64		DeliveryQ_Phys;		/* delivery queue Phy: */

	/* Completion Queue */
	ARCSAS_U64		CompletionQ_Phys;	/* completion queue Phy: */

	vm_offset_t		io_map_base;
	vm_offset_t		mem_map_base;
	vm_offset_t		mem_map_base_ext;
	PVOID			pDiscoverBuffer;
	/*
	**************************************************************
	** Because we are supporting performance mode,
	** we cannot use array for Domain_Device
	** user pointer, remember to allocate continuous memory for it
	**************************************************************
	*/
	Domain_Port		Ports[ARCSAS_MAX_CORE_PHYSICAL_PORT_NUMBER];	/*(8) Domain Ports */
	/*
	*******************************************************
	**	new shared DevicesExpandersPMs_EntryIndex system:
	**	0 to ARCSAS_MAX_DEVICE_ID for os real devices=> (0,135)
	**	ARCSAS_MIN_EXPANDER_ID to ARCSAS_MAX_EXPANDER_ID for expanders=> (136,143)
	**	ARCSAS_MIN_PM_ID to ARCSAS_MAX_PM_ID for PM=> (144,151)
	*******************************************************
	*/
	PCCB			*pRunning_CCB;

	u_int32_t		Running_Slot[ALLOCATE_SLOT_CNT];
	u_int32_t		Resetting_Slot[ALLOCATE_SLOT_CNT];
	u_int32_t		Completing_Slot[ALLOCATE_SLOT_CNT];

	u_int16_t		last_DeliveryQ_index;
	u_int16_t		last_DoneQ_index;
	u_int16_t		Max_DeliveryQ_Index;	/* Size of the deliver queue */
	u_int16_t		Max_DoneQ_Index;	/* Size of completion queue, this differs for normal mode and hibernation */

	/* Command List Slot Number Pool */
	Tag_Stack		Tag_Pool_CmdSlot;	/* 512 */
	Tag_Stack		Tag_Pool_Port;		/* 8 */

	/* Phy info */
	Domain_Phy		Phy[ARCSAS_MAX_CORE_PHYSICAL_PORT_NUMBER]; /* (8) */

	u_int8_t		Ports_EntryIndex[ARCSAS_MAX_CORE_PHYSICAL_PORT_NUMBER];		/* (8) must be 4 byte alignment */

	u_int16_t		Reserved;
	u_int8_t		MaxRegisterSet;
	u_int8_t		Core_Flag;		/* Is during dump */

	u_int16_t		Slot_Count_Supported;
	u_int8_t		last_port_index;	/*  */
	u_int8_t		MaxCmdSlotWidth;	/* 9 for 512, 10 for 1024 */

	u_int8_t		Scratch_Count1;		/* used for core API purposes */
	u_int8_t		Scratch_Count2;		/* used for core API purposes */
	u_int8_t		Phy_Num;		/* How much phy ports we have? */
	u_int8_t		State;

	uint32_t		RequestCount;
	uint32_t		ReturnCount;
	uint32_t		cmdDeliveryCount;
	uint32_t		cmdCompletedCount;
	uint32_t		dpcCount;
};
#define ARCSAS_CORE_FLAG_HBA_CORE_ID0	0x01
#define ARCSAS_CORE_FLAG_HBA_CORE_ID1	0x02

#define CORE_STATE_IDLE					0x01
#define CORE_STATE_STARTED				0x02
#define CORE_STATE_NEED_PORT_STATE_MACHINE_INIT		0x04
/*
************************************************************************
**
************************************************************************
*/
struct _SENSE_CODE_SET
{
	u_int16_t	bitMask; /* Status(8..15):Error(0..7) */
	u_int16_t	reserved;
	u_int8_t	RW; /* 1 - write */
	u_int8_t	Key;
	u_int8_t	ASC;
	u_int8_t	ASCQ;
};
/*
************************************************************************
** TgtDevMap structure for core driver.
************************************************************************
*/
struct _Target_Dev
{
	u_int8_t	Connection;
	u_int8_t	DevType;

	u_int8_t	PhyId;		/* If SATA device, set PhyId of expander which attached sata device */
	u_int8_t	TargetBits; /* from Response.Discover.TargetBits */

	u_int8_t	NegotiatedLinkRate:4;
	u_int8_t	MaxLinkRateCapability:4; /* give four bits for Max linkrate */
	u_int8_t	DevDiscState;
	u_int8_t	SmpRetryCount;
	u_int8_t	Reserved0[1];

	u_int8_t	DevSASAddr[SAS_ADDR_SIZE];
};
#define DEVICE_TYPE_NONE		0
#define DEVICE_TYPE_HD			1	// DT_DIRECT_ACCESS_BLOCK
#define DEVICE_TYPE_PM			2
#define DEVICE_TYPE_EXPANDER		3	// DT_EXPANDER
#define DEVICE_TYPE_TAPE		4	// DT_SEQ_ACCESS
#define DEVICE_TYPE_PRINTER		5	// DT_PRINTER
#define DEVICE_TYPE_PROCESSOR		6	// DT_PROCESSOR
#define DEVICE_TYPE_WRITE_ONCE		7	// DT_WRITE_ONCE
#define DEVICE_TYPE_CD_DVD		8	// DT_CD_DVD
#define DEVICE_TYPE_OPTICAL_MEMORY	9	// DT_OPTICAL_MEMORY
#define DEVICE_TYPE_MEDIA_CHANGER	10	// DT_MEDIA_CHANGER
#define DEVICE_TYPE_ENCLOSURE		11	// DT_ENCLOSURE
#define DEVICE_TYPE_PORT		0xFF	// DT_STORAGE_ARRAY_CTRL

#define DEVICE_DISCOVERY_STATE_GOOD		0x00
#define DEVICE_DISCOVERY_STATE_PHY_RESET	0x01
#define DEVICE_DISCOVERY_STATE_ABORT		0x02
/*
************************************************************************
**
************************************************************************
*/
struct _Target_Disc_Info
{
	u_int8_t	TotalDevCounts;	/* Total device(only include SAS/SATA) counts attached behind a dedicated expander */
	u_int8_t	TgtId;			/* dedicated expander ID */
	u_int8_t	PhyCount;
	u_int8_t	TargetBits;		/* from Response.Discover.TargetBits */
	u_int8_t	NegotiatedLinkRate;	/* for SAS speed setting */
	u_int8_t	ParentPhyCount;
	u_int8_t	ComponentRevisionID;
	u_int8_t	PhyIdToContinueDisc;

	u_int8_t	ParentPhyId[ARCSAS_MAX_WIDEPORT_PHYS];
	uint8_t		SelfPhyId[ARCSAS_MAX_WIDEPORT_PHYS]; /* 4 */

	u_int8_t	VendorID[16];
	u_int8_t	ProductID[24];
	u_int8_t	ProductRev[8];
	u_int8_t	ComponentVendorID[16];

	u_int16_t	ComponentID;
	u_int16_t	MaxRouteIndexes;

	u_int8_t	ParentSASAddr[SAS_ADDR_SIZE];
	u_int8_t	SASAddr[SAS_ADDR_SIZE];
};
/*
************************************************************************
**
************************************************************************
*/
struct _Target_Dev_Map
{
	Target_Disc_Info	Info;
	//Target_Dev		TgtDev[0];
	Target_Dev		TgtDev[1];
};

#define	TARGET_DEV_MAP	sizeof(Target_Dev_Map)+ sizeof(Target_Dev) * (ARCSAS_MAX_DEVICE_PER_EXPANDER - 1)
/*
************************************************************************
**
************************************************************************
*/
struct _SMPBuffer_Context
{
	struct _SMPRequest	SMPBuffer;
	u_int8_t		SASAddr[SAS_ADDR_SIZE];
	PDiscovery		pDiscovery;
	SMP_CBFunc		pCallBack;

	u_int8_t		nTgt;
	u_int8_t		phyId;
	u_int8_t		BufferIndex;
	u_int8_t		isBufferFree;
};
/*
************************************************************************
**
************************************************************************
*/
struct _Config_RouteInfo
{
	PDomain_Port	pPort;
	PVOID		pParent;

	u_int16_t	nIndex;
	u_int8_t	phyId;
	u_int8_t	issuedFlag;

	u_int8_t	SASAddr[SAS_ADDR_SIZE];
};
#define CONFIG_ROUTE_INDEX_VALID		0xff
#define CONFIG_ROUTE_INDEX_LOADED		0xf0
#define CONFIG_ROUTE_INDEX_INVALID		0x00
/*
************************************************************************
**
************************************************************************
*/
struct _Discover_PortInfo
{
	PDomain_Port	pPort;
	u_int8_t	DiscoveryReturn;
	u_int8_t	BroadcastReceived;
	Config_RouteInfo	ConfigRouteInfo[ARCSAS_MAX_CONFIG_ROUTES];/*128+8=136*/
};
//	DiscoveryReturn
#define DISCOVERY_PORT_TURN_OFF		0x00
#define DISCOVERY_PORT_TURN_ON		0xff
//	BroadcastReceived
#define BROADCAST_PORT_NOT_YET_RECEIVE	0x00
#define BROADCAST_PORT_RECEIVED		0xff
/*
************************************************************************
**
************************************************************************
*/
struct _Discover_Target /* Target is Expander */
{
	Target_Disc_Info	Info;
	u_int8_t		DiscoveryState;
//#define REPORT_GENERAL 			0x00
//#define REPORT_MANUFACTURER_INFORMATION 	0x01
//#define REPORT_SELF_CONFGRIGRUATION_STATUS	0x03
//#define DISCOVER 				0x10
//#define CONFIGURE_ROUTE_INFORMATION 		0x90
//#define CONTINUEREMAINDER			0xe0
//#define FINDBOUNDARY				0xe1
#define DISCOVERY_STATE_CONTINUE_REMAINDER	0xe0
#define DISCOVERY_STATE_FINDBOUNDARY		0xe1
#define DISCOVERY_STATE_END			0xe2
#define DISCOVERY_STATE_FREE			0xfc
#define DISCOVERY_STATE_ABORT			0xfd
#define DISCOVERY_STATE_EXPANDER_NODE_DONE	0xfe
#define DISCOVERY_STATE_START			0xff
#define TARGET_NOT_YET_DISCOVER			0xff
	u_int8_t		NeedConfigured;
	u_int8_t		PhyId;
	u_int8_t		reserved;

	PVOID			pParent;
	DISC_CBFunc		pCallBack;
	u_int16_t		CurrentIndex[ARCSAS_MAX_ROUTE_INDEX];
	PDomain_Port		pPort;
	Target_Dev		TgtDev[ARCSAS_MAX_DEVICE_PER_EXPANDER];
};
/*
************************************************************************
**
************************************************************************
*/
struct _Discovery
{
	u_int8_t		NumberOfMaxTarget;
	u_int8_t		TargetNumber;
	u_int8_t		SmpRetryCount;
	u_int8_t		reserved0;

	u_int32_t		DiscoverMask;
	u_int16_t		numOfDiscoveryReq;
	u_int16_t		reserved1;

	PDomain_Port		PortsWaitToBeDiscover[ARCSAS_MAX_EXPANDER_SUPPORTED]; /* 8 */
	Discover_PortInfo	PortInfo[ARCSAS_MAX_CORE_PHYSICAL_PORT_NUMBER];
	SMPBuffer_Context	SMPContext[ARCSAS_MAX_DISCOVER_REQUESTS];
	//Discover_Target	Target[0]; /* Target is Expander */
	Discover_Target		Target[1]; /* Target is Expander */
};
/*
************************************************************************
**
************************************************************************
*/
struct _ATA_TaskFile
{
	u_int8_t	Features;
	u_int8_t	Sector_Count;
	u_int8_t	LBA_Low;
	u_int8_t	LBA_Mid;
	u_int8_t	LBA_High;
	u_int8_t	Device;
	u_int8_t	Command;
	u_int8_t	Control;

	/* extension */
	u_int8_t	Feature_Exp;
	u_int8_t	Sector_Count_Exp;
	u_int8_t	LBA_Low_Exp;
	u_int8_t	LBA_Mid_Exp;
	u_int8_t	LBA_High_Exp;
};
/*
************************************************************************
**  ATA device identify frame
************************************************************************
*/
struct _ATA_Identify_Data
{
	u_int16_t General_Config;			/*	0	*/
	u_int16_t Obsolete0;				/*	1	*/
	u_int16_t Specific_Config;			/*	2	*/
	u_int16_t Obsolete1;				/*	3	*/
	u_int16_t Retired0[2];				/*	4-5	*/
	u_int16_t Obsolete2;				/*	6	*/
	u_int16_t Reserved0[2];				/*	7-8	*/
	u_int16_t Retired1;				/*	9	*/
	u_int8_t  Serial_Number[20];			/*	10-19	*/
	u_int16_t Retired2[2];				/*	20-21	*/
	u_int16_t Obsolete3;				/*	22	*/
	u_int8_t  Firmware_Revision[8];			/*	23-26	*/
	u_int8_t  Model_Number[40];			/*	27-46	*/
	u_int16_t Maximum_Block_Transfer;		/*	47	*/
	u_int16_t Reserved1;				/*	48	*/
	u_int16_t Capabilities[2];			/*	49-50	*/
	u_int16_t Obsolete4[2];				/*	51-52	*/
	u_int16_t Fields_Valid;				/*	53	*/
	u_int16_t Obsolete5[5];				/*	54-58	*/
	u_int16_t Current_Multiple_Sector_Setting;	/*	59	*/
	u_int16_t User_Addressable_Sectors[2];		/*	60-61	*/
	u_int16_t ATAPI_DMADIR;				/*	62	*/
	u_int16_t Multiword_DMA_Modes;			/*	63	*/
	u_int16_t PIO_Modes;				/*	64	*/
	u_int16_t Minimum_Multiword_DMA_Cycle_Time;	/*	65	*/
	u_int16_t Recommended_Multiword_DMA_Cycle_Time;	/*	66	*/
	u_int16_t Minimum_PIO_Cycle_Time;		/*	67	*/
	u_int16_t Minimum_PIO_Cycle_Time_IORDY;		/*	68	*/
	u_int16_t Reserved2[2];				/*	69-70	*/
	u_int16_t ATAPI_Reserved[4];			/*	71-74	*/
	u_int16_t Queue_Depth;				/*	75	*/
	u_int16_t SATA_Capabilities;			/*	76	*/
	u_int16_t SATA_Capabilities_addition;		/*	77	*/
	u_int16_t SATA_Feature_Supported;		/*	78	*/
	u_int16_t SATA_Feature_Enabled;			/*	79	*/
	u_int16_t Major_Version;			/*	80	*/
	u_int16_t Minor_Version;			/*	81	*/
	u_int16_t Command_Set_Supported[2];		/*	82-83	*/
	u_int16_t Command_Set_Supported_Extension;	/*	84	*/
	u_int16_t Command_Set_Enabled[2];		/*	85-86	*/
	u_int16_t Command_Set_Default;			/*	87	*/
	u_int16_t UDMA_Modes;				/*	88	*/
	u_int16_t Time_For_Security_Erase;		/*	89	*/
	u_int16_t Time_For_Enhanced_Security_Erase;	/*	90	*/
	u_int16_t Current_Advanced_Power_Manage_Value;	/*	91	*/
	u_int16_t Master_Password_Revision;		/*	92	*/
	u_int16_t Hardware_Reset_Result;		/*	93	*/
	u_int16_t Acoustic_Manage_Value;		/*	94	*/
	u_int16_t Stream_Minimum_Request_Size;		/*	95	*/
	u_int16_t Stream_Transfer_Time_DMA;		/*	96	*/
	u_int16_t Stream_Access_Latency;		/*	97	*/
	u_int16_t Stream_Performance_Granularity[2];	/*	98-99	*/
	u_int16_t Max_LBA[4];				/*	100-103	*/
	u_int16_t Stream_Transfer_Time_PIO;		/*	104	*/
	u_int16_t Reserved3;				/*	105	*/
	u_int16_t Physical_Sector_Size;			/*	106	*/
	u_int16_t Delay_Acoustic_Testing;		/*	107	*/
	u_int16_t WWN0;					/*	108	*/
	u_int16_t WWN1;					/*	109	*/
	u_int16_t WWN2;					/*	110	*/
	u_int16_t WWN3;					/*	111	*/
	u_int16_t Reserved4[4];				/*	112-115	*/
	u_int16_t Reserved5;				/*	116	*/
	u_int16_t Words_Per_Logical_Sector[2];		/*	117-118	*/
	u_int16_t Reserved6[8];				/*	119-126	*/
	u_int16_t Removable_Media_Status_Notification;	/*	127	*/
	u_int16_t Security_Status;			/*	128	*/
	u_int16_t Vendor_Specific[31];			/*	129-159	*/
	u_int16_t CFA_Power_Mode;			/*	160	*/
	u_int16_t Reserved7[7];				/*	161-167 */
	u_int16_t Device_Nominal_Form_Factor;		/*  168 bit3:0-form factor => Block Device Characteristics VPD Page:NOMINAL FORM FACTOR */
	u_int16_t Data_Set_Management_Supported;	/*  169 bit0-data set management supported */
	u_int16_t Additional_Product_ID[4];		/*	170-173 */
	u_int16_t Reserved8[2];				/*	174-175 */
	u_int16_t Current_Media_Serial_Number[30];	/*	176-205	*/
	u_int16_t Reserved9[11];			/*	206-216	*/
	u_int16_t Rotation_Rate;			/*  217 => Block Device Characteristics VPD Page:MEDIUM ROTATION RATE */
	u_int16_t Reserved10[37];			/*	218-254	*/
	u_int16_t Integrity_Word;			/* 255 */
};
#define	LOGICAL_SECTOR_SIZE_LARGER_512	ARCSAS_BIT(12)
#define	WORLD_WIDE_NAME_SUPPORTED	ARCSAS_BIT(8)
//Word 76
#define	SUPPORTED_SATA_GEN1_1_5G	ARCSAS_BIT(1)
#define	SUPPORTED_SATA_GEN2_3G		ARCSAS_BIT(2)
#define	SUPPORTED_SATA_GEN3_6G		ARCSAS_BIT(3)
#define	FEATURE_SUPPORTED_NCQ		ARCSAS_BIT(8)
//Word 77
#define	CURRENT_NEGOTIATED_SPEED	(ARCSAS_BIT(1)|ARCSAS_BIT(2)|ARCSAS_BIT(3))
#define	CURRENT_SPEED_1_5G		ARCSAS_BIT(1)
#define	CURRENT_SPEED_3G		ARCSAS_BIT(2)
#define	CURRENT_SPEED_6G		(ARCSAS_BIT(1)|ARCSAS_BIT(2))
#define	CURRENT_SPEED_12G		ARCSAS_BIT(3)
//Word 82
#define	FEATURE_SUPPORTED_SMART		ARCSAS_BIT(0)
#define	FEATURE_SUPPORTED_SECURITY	ARCSAS_BIT(1)
#define	FEATURE_SUPPORTED_WRITE_CACHE	ARCSAS_BIT(5)
#define	FEATURE_SUPPORTED_READ_LOOK_AHEAD	ARCSAS_BIT(6)
//Word 83
#define	COMMAND_SUPPORTED_DOWN_LOAD_uCODE	ARCSAS_BIT(0)
#define	FEATURE_SUPPORTED_48BIT_ADDRESS		ARCSAS_BIT(10)
//Word 84
#define	FEATURE_SUPPORTED_SMART_ERROR_LOG	ARCSAS_BIT(0)
#define	FEATURE_SUPPORTED_SMART_SELF_TEST	ARCSAS_BIT(1)
#define	FEATURE_SUPPORTED_MEDIA_SERIAL_NO	ARCSAS_BIT(2)
#define	FEATURE_SUPPORTED_GPL			ARCSAS_BIT(5)
#define	FEATURE_SUPPORTED_64BIT_WWW		ARCSAS_BIT(8)
//Word 85
#define	FEATURE_ENABLED_SMART			ARCSAS_BIT(0)
#define	FEATURE_ENABLED_SECURITY		ARCSAS_BIT(1)
#define	FEATURE_ENABLED_WRITE_CACHE		ARCSAS_BIT(5)
#define	FEATURE_ENABLED_READ_LOOK_AHEAD		ARCSAS_BIT(6)

/*
************************************************************************
**  SAS device identify frame
**  R100h	ID FRAME: CONFIG_ID_FRAME0-CONFIG_ID_FRAME7 ,DWORD0-DWORD7
**  R11Ch ATTACHED ID FRAME: CONFIG_ATT_ID_FRAME0-CONFIG_ATT_ID_FRAME7 ,DWORD0-DWORD7
************************************************************************
*/
struct _SAS_Identify_Data
{
	/* Byte 0 */
	u_int8_t  frame_type:4;
	u_int8_t  dev_type:3;
	u_int8_t  Reserved0:1;
	/* Byte 1 */
	u_int8_t  Reserved1;
	/* Byte 2 */
	union {
		struct {
			u_int8_t  Reserved20:1;
			u_int8_t  smp_iport:1;
			u_int8_t  stp_iport:1;
			u_int8_t  ssp_iport:1;
			u_int8_t  Reserved24567:4;
		}ibs;
		u_int8_t initiator_bits;
	}u2;
	/* Byte 3 */
	union {
		struct {
			u_int8_t  Reserved30:1;
			u_int8_t smp_tport:1;
			u_int8_t stp_tport:1;
			u_int8_t ssp_tport:1;
			u_int8_t Reserved34567:4;
		}tbs;
		u_int8_t target_bits;
	}u3;
	/* Byte 4 - 11 */
	u_int8_t DeviceName[8];
	/* Byte 12 - 19 */
	u_int8_t sas_addr[SAS_ADDR_SIZE];
	/* Byte 20 */
	u_int8_t phy_id;
	/* Byte 21 - 27 */
	u_int8_t Reserved2127[7];
	/* Byte 28 - 31 */
	u_int32_t crc; /* big endian */
};
/*
************************************************************************
**CONFIG_PHY_STATUS bits
************************************************************************
*/
struct _REG_CONFIG_PHY_STATUS
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int32_t	Reserved2:13;
	u_int32_t	TXIMP:4;
	u_int32_t	RXIMP:4;
	u_int32_t	PLL_CAL_DONE:1;
	u_int32_t	PHY_PLL_LOCK:1;
	u_int32_t	KVCO:3;
	u_int32_t	IMP_CAL_DONE:1;
	u_int32_t	NGTD_SPEED:1;
	u_int32_t	Reserved1:1;
	u_int32_t	PHY_RDY:1;
	u_int32_t	DW_SYNC:1;
	u_int32_t	OOB_DTCTD:1;
#else
	u_int32_t	OOB_DTCTD:1;
	u_int32_t	DW_SYNC:1;
	u_int32_t	PHY_RDY:1;
	u_int32_t	Reserved1:1;
	u_int32_t	NGTD_SPEED:1;
	u_int32_t	IMP_CAL_DONE:1;
	u_int32_t	KVCO:3;
	u_int32_t	PHY_PLL_LOCK:1;
	u_int32_t	PLL_CAL_DONE:1;
	u_int32_t	RXIMP:4;
	u_int32_t	TXIMP:4;
	u_int32_t	Reserved2:13;
#endif
};
/*
************************************************************************
**  Hardware related format. Never change their size. Must follow hardware
**  specification.
**  for command list SSP port,SMP port,STP port
************************************************************************
*/
struct _ARCSAS_Command_Header
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
/* DWORD 0 */
	u_int32_t	PRD_Entry_Count : 16;	/* 1300:(31..16),1320:(23..16)PRD table length */

	u_int32_t	SSP_FrameType : 3;		/* SSP only, 0-frame type set by HW, 1-frame type given by SSP_FrameType */
	u_int32_t	SSP_PassThru : 1;
	u_int32_t	SSP_FirstBurst : 1;		/* SSP only, generate Burst without waiting for XFER-RDY */
	u_int32_t	SSP_VerifyDataLen : 1;	/* SSP only, verify Data length */
	u_int32_t	SSP_Retry : 1;		/* SSP only, set if enabling SSP transport layer retry */
	u_int32_t	ProtectInfoRecord : 1;	/* SSP only, set if protection information record present */
	u_int32_t	Reset: 1;		/* SATA only, set if it is for device reset */
	u_int32_t	First_DMA : 1;	/* SATA only, set if it is a first party DMA command */
	u_int32_t	ATAPI : 1;		/* SATA only, set if it is a ATAPI PIO */
	u_int32_t	BIST : 1;		/* SATA only, set if it is a BIST FIS */
	u_int32_t	PM_Port : 4;	/* Port Multiplier field in command FIS */

/* DWORD 1 */
	u_int32_t	Reserved2 : 7;
	u_int32_t	MaxRspFrameLength : 9;  /* max response frame length in DW, HW will put in status buffer structure */
	u_int32_t	Reserved1 : 6;
	u_int32_t	FrameLength : 10;	/* 1300:(9..0),1320:(8..0) command frame length in DW, including frame length, excluding CRC */
/* DWORD 2 */
	u_int32_t	TargetTag : 16;	/* Target Port Transfer Tag, for target to tag multiple XFER_RDY */
	u_int32_t	Tag : 16;		/* command tag */
#else /*  __ARCSAS_LITTLE_ENDIAN_BITFIELD__ */
/* DWORD 0 */
	u_int32_t	PM_Port : 4;	/* Port Multiplier field in command FIS */
	u_int32_t	BIST : 1;		/* SATA only, set if it is a BIST FIS */
	u_int32_t	ATAPI : 1;		/* SATA only, set if it is a ATAPI PIO */
	u_int32_t	First_DMA : 1;	/* SATA only, set if it is a first party DMA command */
	u_int32_t	Reset: 1;		/* SATA only, set if it is for device reset */
	u_int32_t	ProtectInfoRecord : 1;  /* SSP only, set if protection information record present */
	u_int32_t	SSP_Retry : 1;	/* SSP only, set if enabling SSP transport layer retry */
	u_int32_t	SSP_VerifyDataLen : 1;  /* SSP only, verify Data length */
	u_int32_t	SSP_FirstBurst : 1;	/* SSP only, generate Burst without waiting for XFER-RDY */
	u_int32_t	SSP_PassThru : 1;	
	u_int32_t	SSP_FrameType : 3;	/* SSP only, 0-frame type set by HW, 1-frame type given by SSP_FrameType */
	u_int32_t	PRD_Entry_Count : 16;
/* DWORD 1 */
	u_int32_t	FrameLength : 10;	/* command frame length in DW, including frame length, excluding CRC */
	u_int32_t	Reserved1 : 6;

	u_int32_t	MaxRspFrameLength : 9;  /* max response frame length in DW, HW will put in status buffer structure */
	u_int32_t	Reserved2 : 7;
/* DWORD 2 */
	u_int32_t	Tag : 16;		/* command tag */
	u_int32_t	TargetTag : 16;	/* Target Port Transfer Tag, for target to tag multiple XFER_RDY */
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */

/* DWORD 3 */
	u_int32_t	DataXferLen;	/* in bytes */
/* DWORD 4 */
	u_int32_t	Cmd_Table_Address;
/* DWORD 5 */
	u_int32_t	Cmd_Table_Address_High;
/* DWORD 6 */
	u_int32_t	OpenAddrFrame_Address;
/* DWORD 7 */
	u_int32_t	OpenAddrFrame_Address_High;
/* DWORD 8 */
	u_int32_t	StatusBuff_Address;
/* DWORD 9 */
	u_int32_t	StatusBuff_Address_High;
/* DWORD 10 */
	u_int32_t	PRD_Table_Address;
/* DWORD 11 */
	u_int32_t	PRD_Table_Address_High;
/* DWORD 12-15 */
	u_int32_t	Reserved[4]; /* 1300:(DWORD0..DWORD11,no used:DWORD12..DWORD15),1320:(DWORD0..DWORD13, be used DWORD12..DWORD13) */
};

/* SSP_FrameType */
#define SSP_FRAME_TYPE_COMMAND		0x00
#define SSP_FRAME_TYPE_TASK		0x01
#define SSP_FRAME_TYPE_XFER_RDY		0x04 /* Target mode */
#define SSP_FRAME_TYPE_RESPONSE		0x05 /* Target mode */
#define SSP_FRAME_TYPE_RD_DATA		0x06 /* Target mode */
#define SSP_FRAME_TYPE_RD_DATA_RESPONSE	0x07 /* Target mode, read data after response frame */

/*
************************************************************************
**for command table SSP frame header  24 byte
************************************************************************
*/
struct _SSP_Frame_Header
{
	u_int8_t	Frame_Type;
	u_int8_t	Hashed_Dest_SAS_Addr[3];
	u_int8_t	Reseved1;
	u_int8_t	Hashed_Src_SAS_Addr[3];
	u_int8_t	Reseved2[2];
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t	Reserved3:5;
	u_int8_t	RetryData:1;	/* set in XFER_RDY to allow ReTx Data frames */
	u_int8_t	ReTxed:1;	/* set in TASK/XFER_RDY/RESPONSE frames indicating this is a re-txed */
	u_int8_t	CDP:1;	/* Change Data Pointer */

	u_int8_t	Reserved4:6;
	u_int8_t	NumberOfFillBytes:2;
#else /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	CDP:1;		/* Change Data Pointer */
	u_int8_t	ReTxed:1;		/* set in TASK/XFER_RDY/RESPONSE frames indicating this is a re-txed */
	u_int8_t	RetryData:1;		/* set in XFER_RDY to allow ReTx Data frames */
	u_int8_t	Reserved3:5;

	u_int8_t	NumberOfFillBytes:2;
	u_int8_t	Reserved4:6;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	Reserved5[4];
	u_int16_t	Tag;		/* command tag */
	u_int16_t	TargetTag;	/* Target Port Transfer Tag, for target to tag multiple XFER_RDY */
	u_int32_t	DataOffset;
};
/*
************************************************************************
**SSP Command IU  28 bytes
************************************************************************
*/
struct _SSP_COMMAND_IU
{
	u_int8_t	LUN[8];
	u_int8_t	Reserved1;
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t	AddCDBLen:6;		/* in DW */
	u_int8_t	Reserved4:2;
	u_int8_t	Reserved3;
	u_int8_t	FirstBurst:1;
	u_int8_t	Reserved2:4;
	u_int8_t	TaskAttrib:3;
#else
	u_int8_t	TaskAttrib:3;
	u_int8_t	Reserved2:4;
	u_int8_t	FirstBurst:1;
	u_int8_t	Reserved3;
	u_int8_t	Reserved4:2;
	u_int8_t	AddCDBLen:6;		/* in DW */
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	CDB[16];
/*	u_int8_t	AddCDB[n] */
};
/*
************************************************************************
**SSP TASK IU
************************************************************************
*/
struct _SSP_TASK_IU
{
	u_int8_t	LUN[8];
	u_int8_t	Reserved1[2];
	u_int8_t	TaskFunction;
	u_int8_t	Reserved2;
	u_int16_t	Tag;
	u_int8_t	Reserved3[14];
};
/*
************************************************************************
**SSP XFER_RDY IU
************************************************************************
*/
struct _SSP_XFERRDY_IU
{
	u_int32_t	DataOffset;
	u_int32_t	DataLen;
	u_int8_t	Reserved3[4];
};
/*
************************************************************************
**	sense data for response codes 70h or 71h
************************************************************************
*/
struct _ARCSAS_Sense_Data
{
	u_int8_t ResponseCode:7;
	u_int8_t Valid:1;

	u_int8_t SegmentNumber;

	u_int8_t SenseKey:4;
	u_int8_t SenseDataOverflow:1;
	u_int8_t IncorrectLength:1;
	u_int8_t EndOfMedia:1;
	u_int8_t FileMark:1;

	u_int8_t Information[4];
	u_int8_t AdditionalSenseLength;
	u_int8_t CommandSpecificInformation[4];
	u_int8_t AdditionalSenseCode;
	u_int8_t AdditionalSenseCodeQualifier;
	u_int8_t FieldReplaceableUnitCode;
	u_int8_t SenseKeySpecific[3];
};
#define	CURRENT_INFO_FIXED_FMT		0x70
#define	DEFERRED_ERRORS_FIXED_FMT	0x71

#define	ARCSAS_SILI	ARCSAS_BIT(1)
#define	ARCSAS_FIXED	ARCSAS_BIT(0)
/*
************************************************************************
**	sense data for response codes 72h or 73h
************************************************************************
*/
struct _ARCSAS_Descriptor_Sense_Data
{
	u_int8_t ResponseCode:7;
	u_int8_t Reserved0:1;

	u_int8_t SenseKey:4;
	u_int8_t Reserved1:4;

	u_int8_t AdditionalSenseCode;
	u_int8_t AdditionalSenseCodeQualifier;

	u_int8_t Reserved2:7;
	u_int8_t SenseDataOverflow:1;

	u_int8_t Reserved3[2];
	u_int8_t AdditionalSenseLength;
};

struct	_Information_Sense_Data
{
	u_int8_t DescriptorType;
	u_int8_t AdditionalLength;

	u_int8_t Reserved0:7;
	u_int8_t Valid:1;

	u_int8_t Reserved1;

	u_int8_t Information[8];
};

#define	CURRENT_INFO_DESCRIPTOR_FMT	0x72
#define	DEFERRED_ERRORS_DESCRIPTOR_FMT	0x73
#define	INFORMATION_DESCRIPTOR		0
/*
************************************************************************
**SSP RESPONSE IU
************************************************************************
*/
struct _SSP_RESPONSE_IU
{
	u_int8_t	Reserved1[8];
	u_int16_t	StatusQualifier;
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t	Reserved2:6;
	u_int8_t	DataPres:2;
#else  /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	DataPres:2;
	u_int8_t	Reserved2:6;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	Status;
	u_int32_t	Reserved3;
	u_int32_t	SenseDataLen;
	u_int32_t	RespDataLen;
	u_int8_t	Data[MAX_SSP_RESP_SENSE_SIZE];
};
#define		RSPN_NO_DATA		0
#define		RSPN_RESPONSE_DATA	1
#define		RSPN_SENSE_DATA		2

/*
************************************************************************
**SSP Protection Information Record
************************************************************************
*/
struct _PROTECT_INFO_RECORD
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int32_t Reserved2:4;
	u_int32_t USR_DT_SZ:12;
	u_int32_t Reserved1:10;
	u_int32_t CHK_DSBL_MD:1;
	u_int32_t GRD_CHK:1;
	u_int32_t APP_CHK:1;
	u_int32_t REF_CHK:1;
	u_int32_t RMV_PROT:1;
	u_int32_t INSRT_PROT:1;

	u_int32_t LBRT;		/* Logical Block Reference Tag */

	u_int32_t LBAT_MASK:16;
	u_int32_t LBAT:16;	/* Logical Block Application Tag */
#else
	u_int32_t INSRT_PROT:1;
	u_int32_t RMV_PROT:1;
	u_int32_t REF_CHK:1;
	u_int32_t APP_CHK:1;
	u_int32_t GRD_CHK:1;
	u_int32_t CHK_DSBL_MD:1;
	u_int32_t Reserved1:10;
	u_int32_t USR_DT_SZ:12;
	u_int32_t Reserved2:4;

	u_int32_t LBRT;		/* Logical Block Reference Tag */

	u_int32_t LBAT:16;	/* Logical Block Application Tag */
	u_int32_t LBAT_MASK:16;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
};
/*
************************************************************************
**SSP Command Table
************************************************************************
*/
struct _ARCSAS_SSP_Command_Table
{
	SSP_Frame_Header Frame_Header;
	union
	{
		struct {
			struct _SSP_COMMAND_IU	commandIU;
			PROTECT_INFO_RECORD	PIR;
		} command;
		struct _SSP_TASK_IU	task;
		struct _SSP_XFERRDY_IU	xfer_rdy;
		struct _SSP_RESPONSE_IU	response;
	} data;
};
/*
************************************************************************
**SATA STP Command Table
************************************************************************
*/
struct _ARCSAS_SATA_STP_Command_Table
{
	u_int8_t	FIS[64];	/* Command FIS */
	u_int8_t	ATAPI_CDB[32];	/* ATAPI CDB */
};
/*
************************************************************************
**Open Address Frame
************************************************************************
*/
struct _OPEN_ADDRESS_FRAME
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int8_t	Initiator:1;
	/*
	******************************************************************************************************
	** An INITIATOR PORT bit set to one specifies that the source port is acting as a SAS initiator port.
	** An INITIATOR PORT bit set to zero specifies that the source port is acting as a SAS target port
	******************************************************************************************************
	*/
	u_int8_t	Protocol:3;
	u_int8_t	Frame_Type:4;

	u_int8_t	Feature:4;
	u_int8_t	Connect_Rate:4;
#else	/* __ARCSAS_LITTLE_ENDIAN_BITFIELD__ */
	u_int8_t	Frame_Type:4;

	u_int8_t	Protocol:3;
	u_int8_t	Initiator:1;

	u_int8_t	Connect_Rate:4;
	u_int8_t	Feature:4;
#endif	/* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
	u_int8_t	Connect_Tag[2];		/* byte2..byte3:INITIATOR CONNECTION TAG */
	u_int8_t	Dest_SAS_Addr[8];	/* byte4..byte11:DESTINATION SAS ADDRESS */
	/* HW will generate Byte 12 after... */
	u_int8_t	Src_SAS_Addr[8];	/* byte12..byte19:SOURCE SAS ADDRESS */
	u_int8_t	Cmp_Features1;		/* byte20:COMPATIBLE FEATURES */
	u_int8_t	Blocked_Count;		/* byte21:PATHWAY BLOCKED COUNT */
	u_int8_t	AWT[2];			/* byte22..byte23:ARBITRATION WAIT TIME */
	u_int8_t	Cmp_Features2[4];	/* byte24..byte27:MORE COMPATIBLE FEATURES */
	u_int32_t	FirstBurstSize;		/* byte28..byte31:CRC for hardware use */
};
#define PROTOCOL_SMP	0x0
#define PROTOCOL_SSP	0x1
#define PROTOCOL_STP	0x2
/* defines for address frame types */
#define ADDRESS_IDENTIFY_FRAME		0x00
#define ADDRESS_OPEN_FRAME		0x01
/*
************************************************************************
**Error Information Record
************************************************************************
*/
struct _ERR_INFO_RECORD
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	/* Error Information Record 0 */
	u_int32_t	CMD_ISS_STPD:1;
	u_int32_t	PI_ERR:1;
	u_int32_t	RESP_BFFR_OFLW:1;
	u_int32_t	RTRY_LMT_ERR:1;
	u_int32_t	UNKNWN_FIS_ERR:1;
	u_int32_t	DMAT_RCVD:1;
	u_int32_t	SYNC_ERR:1;
	u_int32_t	TFILE_ERR:1;

	u_int32_t	R_ERR:1;
	u_int32_t	TX_EDONE:1;		/* TX Early done */
	u_int32_t	Reserved2:1;
	u_int32_t	RD_DATA_OFFST_ERR:1;
	u_int32_t	XFR_RDY_OFFST_ERR:1;
	u_int32_t	UNEXP_XFER_RDY_ERR:1;
	u_int32_t	Reserved1:1;
	u_int32_t	DATA_OVR_UNDR_FLW_ERR:1;

	u_int32_t	INTRLCK_ERR:1;
	u_int32_t	NAK_ERR:1;
	u_int32_t	ACK_NAK_TO:1;
	u_int32_t	CNCTN_CLSD_ERR:1;
	u_int32_t	OPEN_TMOUT_ERR:1;
	u_int32_t	PTH_BLKD_ERR:1;
	u_int32_t	NO_DEST_ERR:1;
	u_int32_t	STP_RSRCS_BSY_ERR:1;

	u_int32_t	BRK_RCVD_ERR:1;
	u_int32_t	BAD_DEST_ERR:1;
	u_int32_t	PRTCL_NOT_SPRTD_ERR:1;
	u_int32_t	CNCTN_RT_NT_SPRTD_ERR:1;
	u_int32_t	WRONG_DEST_ERR:1;
	u_int32_t	CREDIT_TO_ERR:1;
	u_int32_t	WD_TMR_TO_ERR:1;
	u_int32_t	BFFR_PERR:1;
	/* Error Information Record 1 */
	u_int32_t	SLOT_BSY_ERR:1;
	u_int32_t	Reserved3:16;
	u_int32_t	GRD_CHK_ERR:1;
	u_int32_t	APP_CHK_ERR:1;
	u_int32_t	REF_CHK_ERR:1;
	u_int32_t	USR_BLK_NM:12;
#else /* __ARCSAS_LITTLE_ENDIAN_BITFIELD__ */
	/* Error Information Record 0 :DW0*/
	u_int32_t	BFFR_PERR:1;		/* buffer parity error */
	u_int32_t	WD_TMR_TO_ERR:1;	/* watch dog timeout occurred */
	u_int32_t	CREDIT_TO_ERR:1;	/* credit timeout occurred */
	u_int32_t	WRONG_DEST_ERR:1;	/* wrong destination errror */
	u_int32_t	CNCTN_RT_NT_SPRTD_ERR:1; /* connection rate not support */
	u_int32_t	PRTCL_NOT_SPRTD_ERR:1;	/* protocol not support */
	u_int32_t	BAD_DEST_ERR:1;		/* bad destination */
	u_int32_t	BRK_RCVD_ERR:1;		/* break recived */

	u_int32_t	STP_RSRCS_BSY_ERR:1;	/* STP resource busy error */
	u_int32_t	NO_DEST_ERR:1;		/* No destination error */
	u_int32_t	PTH_BLKD_ERR:1;		/* pathway blocked error */
	u_int32_t	OPEN_TMOUT_ERR:1;	/* open connection timeout */
	u_int32_t	CNCTN_CLSD_ERR:1;	/* connection closed without ack */
	u_int32_t	ACK_NAK_TO:1;		/* ACK/NAK timeout */
	u_int32_t	NAK_ERR:1;		/* NAK received */
	u_int32_t	INTRLCK_ERR:1;		/* interlock error */

	u_int32_t	DATA_OVR_UNDR_FLW_ERR:1; /* data underflow/overflow error */
	u_int32_t	Reserved1:1;
	u_int32_t	UNEXP_XFER_RDY_ERR:1;	/* unexcept XFER_RDY error */
	u_int32_t	XFR_RDY_OFFST_ERR:1;	/* XFER_RDY offset error */
	u_int32_t	RD_DATA_OFFST_ERR:1;	/* read data offset error */
	u_int32_t	Reserved2:1;
	u_int32_t	TX_EDONE:1;		/* TX Early done */
	u_int32_t	R_ERR:1;		/* R_ERR while STP/SATA respone frame */

	u_int32_t	TFILE_ERR:1;		/* task file error */
	u_int32_t	SYNC_ERR:1;		/* SYNC error while STP/SATA xfer frame */
	u_int32_t	DMAT_RCVD:1;		/* DMA terminate primitive received */
	u_int32_t	UNKNWN_FIS_ERR:1;	/* unknow fis error */
	u_int32_t	RTRY_LMT_ERR:1;		/* retry limit exceeded */
	u_int32_t	RESP_BFFR_OFLW:1;	/* response buffer error */
	u_int32_t	PI_ERR:1;		/* protection information error */
	u_int32_t	CMD_ISS_STPD:1;		/* command issue stopped */
	/* Error Information Record 1 :DW1 */
	u_int32_t	USR_BLK_NM:12;		/* user block number */
	u_int32_t	REF_CHK_ERR:1;		/* reference error */
	u_int32_t	APP_CHK_ERR:1;		/* application error */
	u_int32_t	GRD_CHK_ERR:1;		/* guard check error */
	u_int32_t	Reserved3:16;
	u_int32_t	SLOT_BSY_ERR:1;		/* slot busy */
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
};
#define	ERRINFO_WD_TMR_TO_ERR	ARCSAS_BIT(1)
/*
************************************************************************
**Status Buffer
************************************************************************
*/
struct _STATUS_BUFFER
{
	struct _ERR_INFO_RECORD Err_Info;		/* 000h..007h:Error Information Record */
	union
	{
		struct _SSP_RESPONSE_IU SSP_Resp;	/* SSP Response IU */
		u_int8_t   SMP_Resp[MAX_SMP_RESP_SIZE];	/* SMP Response Frame */
	} data;						/* 008h...407h:Response Frame Buffer */
};
/*
************************************************************************
**Command Table
************************************************************************
*/
struct _ARCSAS_Command_Table
{
	OPEN_ADDRESS_FRAME	Open_Addr_Frame;
	STATUS_BUFFER		Status_Buff;

	union
	{
		ARCSAS_SSP_Command_Table      SSP_CMD_Table;
		ARCSAS_SMP_Command_Table      SMP_CMD_Table;
		ARCSAS_SATA_STP_Command_Table STP_CMD_Table;
	} table;
};
/*
************************************************************************
**Delivery Queue Entry
************************************************************************
*/
struct _DELIVERY_Q_ENTRY
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int32_t CMD:3;
	u_int32_t MODE:1;
	u_int32_t PRIORITY:1;
	u_int32_t SATA_REG_SET:7;
	u_int32_t PHY:8;
	u_int32_t SLOT_NM:12;
#else
	u_int32_t SLOT_NM:12;		/* 11,10,09,08,07,06,05,04,03,02,01,00 */
	u_int32_t PHY:8;		/* 19,18,17,16,15,14,13,12 */
	u_int32_t SATA_REG_SET:7;	/* 26,25,24,23,22,21,20: SRS */
	u_int32_t PRIORITY:1;		/* 27: 1:hi 0:low */
	u_int32_t MODE:1;		/* 28: initiator / target */
	u_int32_t CMD:3;		/* 31,30.29: 1:SSP ,2:SMP ,3:STP/SATA 4:SSP target free List ,7:slot reset */
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
};
/*
************************************************************************
**		Completion Queue Entry DWORD,
**	32 bit,include SLOT_NM:12 for complete Q tag number
************************************************************************
*/
struct _DONE_Q_ENTRY
{
#if __ARCSAS_BIG_ENDIAN_BITFIELD__
	u_int32_t Reserved2:9;
	u_int32_t RSPNS_GOOD:1;
	u_int32_t SLOT_RST_CMPL:1;
	u_int32_t CMD_RCVD:1;	/* target mode */
	u_int32_t ATTENTION:1;
	u_int32_t RSPNS_XFRD:1;
	u_int32_t ERR_RCRD_XFRD:1;
	u_int32_t CMD_CMPL:1;

	u_int32_t Reserved1:4;
	u_int32_t SLOT_NM:12;
#else
	u_int32_t SLOT_NM:12;
	u_int32_t Reserved1:4;

	u_int32_t CMD_CMPL:1;
	u_int32_t ERR_RCRD_XFRD:1;
	u_int32_t RSPNS_XFRD:1;
	u_int32_t ATTENTION:1;
	u_int32_t CMD_RCVD:1;	/* target mode */
	u_int32_t SLOT_RST_CMPL:1;
	u_int32_t RSPNS_GOOD:1;
	u_int32_t Reserved2:9;
#endif /* __ARCSAS_BIG_ENDIAN_BITFIELD__ */
};
/*
************************************************************************
**  For obtaining WWN, inquiry EVPD data structures
************************************************************************
*/
typedef struct _DesignationDescriptor
{
	u_int8_t CodeSet:4;
	u_int8_t ProtocolIdentifier:4;
	/*byte0*/
	u_int8_t DesignatorType:4;
	u_int8_t Association:2;
	u_int8_t Reserved1:1;
	u_int8_t PIV:1;
	/*byte1*/
	u_int8_t Reserved2;
	/*byte2*/
	u_int8_t DesignatorLength;
	/*byte3*/
} DesignationDescriptor, *PDesignationDescriptor;
/*
************************************************************************
**
************************************************************************
*/
struct _SAS_Scratch_Buffer
{
	struct list_head	Queue_Pointer;	/* 64:2X8bytes,32:2X4bytes */
	PVOID			Scratch_Virt;	/* 64:8bytes  ,32:4bytes  */
	ARCSAS_U64		Scratch_Phys;	/* 64:8bytes  ,32:8bytes  */
};
/*
************************************************************************
**
************************************************************************
*/
struct _SMP_Scratch_Buffer
{
	struct list_head	Queue_Pointer;
	SMPRequest		SMP_Req;
};
/*
************************************************************************
**
************************************************************************
*/
struct _PRD_Buffer
{
	struct list_head	Queue_Pointer;
	PVOID			PRD_VIRTUAL;
	ARCSAS_U64		PRD_PHYSICAL;
};
/*
************************************************************************
**
************************************************************************
*/
struct _CORE_CONTEXT
{
	struct list_head Queue_Pointer;
	/*
	** Should move the Scratch_Buffer variable here.
	** But so far CSMI also use it.
	*/
	u_int8_t Context_Type;
	union	{

		struct {
			u_int8_t Original_CDB[MAX_CDB_SIZE];
			PVOID	Data_Buffer;
		}cdb;

		struct	{
			u_int16_t	start;
			u_int16_t	end;
			u_int32_t	remaining;
			PVOID		pointer;
		}api_req;
	}hcmd;
};
/*
************************************************************************
**
************************************************************************
*/
struct _CSMI_SAS_FIRMWARE_DOWNLOAD
{
	u_int32_t	uBufferLength;
	u_int32_t	uDownloadFlags;
	u_int8_t	bReserved[32];
	u_int16_t	usStatus;
	u_int16_t	usSeverity;
};
/*
************************************************************************
**
************************************************************************
*/
struct _ARCSAS_SGENTRY
{
	ARCSAS_U64	baseAddr;	/* DWord0,DWord1 */
	u_int32_t	flags;		/* DWord2:this field value always zero in Marvell PRD table */
	u_int32_t	size;		/* Dword3 */
};
/*
************************************************************************
**
************************************************************************
*/
struct _ARCSAS_SG_Table
{
	u_int16_t		Valid_Entry_Count;
	u_int16_t		Max_Entry_Count;
	u_int32_t		Byte_Count;

	PARCSAS_SGENTRY		pSGEntry;
};
/*
************************************************************************
**
************************************************************************
*/
union _SAS_ADDR
{
	struct {
		u_int32_t	low;
		u_int32_t	high;
	} parts;
	u_int8_t		b[8];
	u_int16_t		w[4];
	u_int32_t		d[2];
};
/*
************************************************************************
**
************************************************************************
*/
struct _PHY_TUNING
{
	u_int8_t	AMP:4;			/* 4 bits,  amplitude  */
	u_int8_t	Pre_Emphasis:3;		/* 3 bits,  pre-emphasis */
	u_int8_t	Reserved_1bit_1:1;	/* 1 bit,   reserved space */
	u_int8_t	Drive_En:6;		/* 6 bits,	drive enable */
	u_int8_t	Pre_Half_En:1;		/* 1 bit,	Half Pre-emphasis Enable*/
	u_int8_t	Reserved_1bit_2:1;	/* 1 bit, 	reserved space */
	u_int8_t	Reserved[2];		/* 2 bytes, reserved space */
};
/*
************************************************************************
**
************************************************************************
*/
typedef struct _Domain_SGPIO
{
	u_int8_t	Data_In_Low[8];
	u_int8_t	Data_In_High[8];
	u_int32_t	CRC;
}Domain_SGPIO, *PDomain_SGPIO;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _sgpio_config_reg
{
	u_int8_t	sup_dev_cnt;
	u_int8_t	gp_reg_cnt:4;
	u_int8_t	cfg_reg_cnt:3;
	u_int8_t	sgpio_enable:1;
	u_int8_t	version:4;
	u_int8_t	rsrv_byte2_bit4_7:4;
	u_int8_t	rsrv_byte3;
}sgpio_config_reg, *psgpio_config_reg;
/*
************************************************************************
**	BIOS_Info_Page is saved in Flash/NVRAM, total 256 bytes.
**	The data area is valid only Signature="MRVL".
**	If any member fills with 0xFF, the member is invalid.
************************************************************************
*/
struct _BIOS_Info_Page
{
	// Dword 0
	u_int8_t	Signature[4];		/* 4 bytes, structure signature,should be "MRVL" at first initial */

	// Dword 1
	u_int8_t	MinorRev;		/* 2 bytes, NVRAM data structure version */
	u_int8_t	MajorRev;
	u_int16_t	Next_Page;		/* 2 bytes, For future data structure expansion, 0 is for NULL pointer and current page is the last page. */

	// Dword 2
	u_int8_t	Major;			/* 1 byte,  BIOS major version */
	u_int8_t	Minor;			/* 1 byte,	BIOS minor version */
	u_int8_t	OEM_Num;		/* 1 byte,  OEM number */
	u_int8_t	Build_Num;		/* 1 byte,  Build number */

	// Dword 3
	u_int8_t	Page_Code;		/* 1 byte,  eg. 0 for the 1st page  */
	u_int8_t	Max_PHY_Num;		/* 1 byte,   maximum PHY number */
	u_int8_t	Reserved2[2];

	// Dword 4
	u_int32_t	BIOS_Flag;		/* 4 bytes, should be 0x0000,0000 at first initial */

	// Dword 5
	u_int32_t	Boot_Device;		/* 4 bytes, select boot device */
						/* for ata device, it is CRC of the serial number + model number. */
						/* for sas device, it is CRC of sas address */
						/* for VD, it is VD GUI */

	// Dword 6-8
	u_int32_t	Reserved3[3];		/* 12 bytes, reserved	*/

	// Dword 9-13
	u_int8_t	Serial_Num[20];		/* 20 bytes, controller serial number */

	// Dword 14-29
	SAS_ADDR	SAS_Address[8];		/* 64 bytes, SAS address for each port */

	// Dword 30-43
	u_int8_t	Reserved4[56];		/* 56 bytes, reserve space for future,initial as 0xFF */

	// Dword 44-45
	u_int8_t	PHY_Rate[8];		/* 8 bytes,  0:  1.5G, 1: 3.0G, should be 0x01 at first initial */

	// Dword 46-53
	PHY_TUNING	PHY_Tuning[8];		/* 32 bytes, PHY tuning parameters for each PHY */

	// Dword 54-62
	u_int32_t	Reserved5[9];		/* 9 dword, reserve space for future,initial as 0xFF */

	// Dword 63
	u_int8_t	Reserved6[3];		/* 3 bytes, reserve space for future,initial as 0xFF */
	u_int8_t	Check_Sum;		/* 1 byte,  checksum for this structure,Satisfy sum of every 8-bit value of this structure */
};/* total 256 bytes */
/* BIOS_FLAG_XX */
#define BIOS_FLAG_INT13_ENABLE			ARCSAS_BIT(0)	//int 13h enable/disable
#define BIOS_FLAG_SILENT_MODE_ENABLE		ARCSAS_BIT(1)	//silent mode enable/disable
#define BIOS_FLAG_PERSISTENT_MAP_ENABLE  	ARCSAS_BIT(2)	//flash device map function
#define BIOS_FLAG_PERSISTENT_MAP_CLEAR		ARCSAS_BIT(3)	/* clear device persistent map */
#define BIOS_FLAG_ALL_DISKS_WRITE_PROTECT	ARCSAS_BIT(4)	/* all disks write protect */
#define BIOS_FLAG_SATA_NCQ_ENABLE		ARCSAS_BIT(5)	/* SATA drive NCQ enable/disable */
#define BIOS_FLAG_SMART_STATUS_POLL_ENABLE	ARCSAS_BIT(6)	/* SMART status polling enable/disable */
#define BIOS_FLAG_DISK_WRITE_CACHE_ENABLE	ARCSAS_BIT(7)	/* disk write cache enable/disable */
#define BIOS_FLAG_DISK_MAX_LINK_SPEED		(ARCSAS_BIT(10)|ARCSAS_BIT(9)|ARCSAS_BIT(8))
#define BIOS_FLAG_MAX_CMDXFER_LENGTH		(ARCSAS_BIT(13)|ARCSAS_BIT(12)|ARCSAS_BIT(11)) /* MaximumTransferLength=1M,4M,8M,16M */

#define	BIOS_SET_MAX_SPEED_1_5G		ARCSAS_BIT(8)
#define	BIOS_SET_MAX_SPEED_3G		ARCSAS_BIT(9)
#define	BIOS_SET_MAX_SPEED_6G		(ARCSAS_BIT(8) | ARCSAS_BIT(9))
#define	BIOS_SET_MAX_SPEED_12G		ARCSAS_BIT(10)

/*
**(bit10,bit9,bit8) 3 bits maximum disk link speed
**  bit 10  9  8
**	0  0  0 :(AUTO)Maxmum link speed limited by HBA
**	0  0  1 : 1.5G	Maxmum link speed
**	0  1  0 : 3.0G	Maxmum link speed
**	0  1  1 : 6.0G	Maxmum link speed
**	1  0  0 : 12G	Maxmum link speed
**	1  0  1 : reserved Maxmum link speed
**	1  1  0 : reserved Maxmum link speed
**	1  1  1 : reserved Maxmum link speed
**
**MaximumTransferLength=1M,4M,8M,16M,32M
**  bit 13 12 11
**	0  0  0: 1M BYTE
**	0  0  1: 4M BYTE
**	0  1  0: 8M BYTE
**	0  1  1:16M BYTE
**	1  0  0:32M BYTE
**	1  1  1:128K BYTE
*/

/*
************************************************************************
** adapter    Flash_Devices_Map[128];
************************************************************************
*/
//#if _LONG_LONG_ALIGNMENT== 8 && _LONG_LONG_ALIGNMENT_32== 4
#pragma pack(4)
//#endif
	struct _FLASH_DEVICE_MAP
	{
		u_int32_t	Flag;	/*DWord0*/

		ARCSAS_U64	Patern;	/*DWord1,DWord2*/
	};
//#if _LONG_LONG_ALIGNMENT== 8 && _LONG_LONG_ALIGNMENT_32== 4
#pragma pack()
//#endif
/*
************************************************************************
**adapter descriptor
************************************************************************
*/
struct	_ACB
{
	struct _CORE	*pCore[ARCSAS_MAX_CORE_NUMBER];

	u_int32_t	adapter_type;
	u_int32_t	mailBox_size;
	bus_addr_t	mailBox_physAddr;

	PVOID		pAllocatedMem;
	u_int8_t	*pDataBufPtr;
	u_int8_t 	*pMailBoxPtr;
	u_int8_t	*pCacheDataStruct;
	struct cam_devq		*devq;
	struct resource		*sys_res_arcsas[2];
	struct resource		*irqres;
	void			*ihandle;	/* interrupt handle */
	struct	cam_sim 	*psim;
	struct	cam_path 	*ppath;

	arcsas_lock_t	timer_mutex;
	arcsas_lock_t	isr_mutex;
	arcsas_lock_t	device_list_mutex;
	arcsas_lock_t	expander_list_mutex;
	arcsas_lock_t	wait_registerset_mutex;
	arcsas_lock_t	io_mutex;		/* this lock will cause one tran_start each time */
	arcsas_lock_t	generic_dpcQ_mutex;
	arcsas_lock_t	smp_element_mutex;
	arcsas_lock_t	event_mutex;
	Tag_Stack	Tag_Pool_Device;	/* 128 */
	Tag_Stack	Tag_Pool_Expander;	/* 8 */
	Tag_Stack	Tag_Pool_PM;		/* 8 */

	bus_space_tag_t		btag[2];
	bus_space_handle_t	bhandle[2];
	bus_dma_tag_t		parent_dmat;
	bus_dma_tag_t		dataBuf_dmaTag;	/* dmat for buffer I/O */
	bus_dma_tag_t		mailBox_dmaTag;	/* dmat for mail box */
	bus_dmamap_t		mailBox_dmaMap;
	struct callout		timer_handle;
	struct callout		timer_handle2;
	device_t		pci_dev;

#if __FreeBSD_version < 503000
	dev_t		ioctl_dev;
#else
	struct cdev 	*ioctl_dev;
#endif

	int		device_number;
	int		irq_rid;
	int		intr_count;
	int		mtx_init;
	int		dmaMap_loaded;
	int		dataBufMap_created;
	int		error;
	u_int32_t	int_mask;

	bus_size_t	cache_size;
	bus_size_t	noncache_size;

	vm_offset_t	io_map_base;
	vm_offset_t	mem_map_base;

	/* Timer Callback */
	u_int32_t	UsecsPerTick;	/* micro sconds per tick requested to SP */
	TdList		timerlist;

	volatile u_int8_t	DevicesExpandersPMs_EntryIndex[ARCSAS_MAX_PM_ID+1];	/* (0..135,136..143,144..151) must be 4 byte alignment */

	u_int8_t	SPICmd[16]; /* record: MXIC_SPI_CMD or ATMEL_SPI_CMD */
	/* adapter information */
	u_int8_t	SystemIoBusNumber;
	u_int8_t	SlotNumber;
	u_int8_t	Revision_Id;
	u_int8_t		enclosure_mask;

	u_int16_t	system_vendor_id;
	u_int16_t	system_device_id;
	u_int16_t	subsystem_vendor_id;
	u_int16_t	subsystem_device_id;

	u_int32_t	ACB_Flag;
	u_int16_t	FlashID;
	u_int16_t	reserve;

	/* System resource */
	Domain_Device	*pDevices;		/* is scsi id device,0..135,ARCSAS_MAX_DEVICE_ID */
	Domain_Device	*pDevicesLun;		/* is scsi lun device,0..127 */
	Domain_Expander	*pExpanders;		/* is SAS Expander,8,ARCSAS_MAX_EXPANDER_SUPPORTED */
	Domain_PM	*pPMs;			/* is SATA Port Mutiplier,8,ARCSAS_MAX_PM_SUPPORTED */

	volatile u_int32_t	outstanding_CCB;
	volatile u_int32_t	all_device_count;
	volatile u_int32_t	org_all_device_count;
	volatile u_int32_t	enclosure_index;

	u_int64_t		sata_register_set;
	struct _FLASH_DEVICE_MAP	Flash_Devices_Map[128];

	u_int8_t		last_device_mapped_id;
	u_int8_t		last_expander_mapped_id;
	u_int8_t		last_portmutiplier_mapped_id;
	u_int8_t		Device_Count_Supported;		/* 136, port device supported count */

	struct _Timer_Request	SMART_timer_request;		/* for smart polling */

	u_int8_t		SMART_Timer_ID;
	u_int8_t		Expander_Count_Supported;	/* 8, port expander supported count  */
	u_int8_t		PortMutiplier_Count_Supported;	/* 8, port mutiplier supported count */
	u_int8_t		bus_registed;

	u_int8_t		EnclosureElementBuffer[9][SES_STATUS_CONTROL_BUFFER_SIZE];
	struct	callout		devmap_callout;
	struct	callout		timeout_callout;
	Domain_Device		SesSgpioVirtualDevice; /* scsi id 136,ARCSAS_VIRTUAL_DEVICE_ID */

	DPC			generic_dpcQ[ARCSAS_MAX_GENERIC_DPC]; /* normal dpc routines work on HWtimer */
	int			generic_dpcQ_head; /* array index number */
	int			generic_dpcQ_tail; /* array index number */
	int			smp_element_index;
	int			event_element_index;
	int			osevent_element_index;
	SMP_ELEMENT		*SmpElement;
	EVENT_ELEMENT		*EventElement;
	OS_EVENT_ELEMENT	*OsEventElement;
	u_int32_t	BIOS_Flag; /*4 bytes*/
	u_int16_t	dump_timer_count;
	u_int8_t	Hot_plug_map[ARCSAS_MAX_DEVICE_INDEX];
	PVOID		pCLI_chan;
};
#define ACB_FLAG_HIBERNATE_WAKEUP		ARCSAS_BIT(0)
#define ACB_FLAG_CORES_STATE_STARTED		ARCSAS_BIT(1)
#define ACB_FLAG_ALL_DISKS_WRITE_PROTECT	ARCSAS_BIT(2)
#define ACB_FLAG_DUAL_CORE 			ARCSAS_BIT(3)
#define ACB_FLAG_IS_DUMP			ARCSAS_BIT(4)
#define ACB_FLAG_DONE_HBA_SHUTDOWN		ARCSAS_BIT(5)
#define ACB_FLAG_SMART_ON 			ARCSAS_BIT(6)
#define ACB_FLAG_BUS_RESET			ARCSAS_BIT(7)
#define ACB_FLAG_TIMER_RUNNING			ARCSAS_BIT(8)
#define ACB_FLAG_SRB_FUNCTION_POWER		ARCSAS_BIT(9)
#define ACB_FLAG_DOING_HBA_SHUTDOWN		ARCSAS_BIT(10)
#define ACB_FLAG_DOING_DISCOVERY 		ARCSAS_BIT(11)
#define ACB_FLAG_HANDLE_HOTPLUG 		ARCSAS_BIT(12)
#define ACB_FLAG_SYNC_DEVICE_ID			ARCSAS_BIT(13)
#define ACB_FLAG_TYPE_SGPIO_HBA			ARCSAS_BIT(14)
#define ACB_FLAG_LOST_IRQ			ARCSAS_BIT(15)
#define ACB_FLAG_PERSISTENT_MAP_ENABLE		ARCSAS_BIT(16)	/* flash device map function */
#define ACB_FLAG_CAM_DEV_QFRZN			ARCSAS_BIT(17)
#define ACB_FLAG_DEV_MAP_CHANGED		ARCSAS_BIT(18)
#define ACB_FLAG_WAITING_RESCAN			ARCSAS_BIT(19)
#define ACB_FLAG_RESCAN_DEVICES			ARCSAS_BIT(20)
#define ACB_FLAG_PHY_CONTROL			ACB_FLAG_SYNC_DEVICE_ID

#define ODIN2_00_REVISION	0x00
#define VANIR_A0_REVISION	0xA0
#define VANIR_B0_REVISION	0x01
#define VANIR_C0_REVISION	0x02
#define VANIR_C1_REVISION	0x03
#define VANIR_C2_REVISION	0xC2
/*
************************************************************************
** struct _CCB is the general request type passed through different modules.
** Must be 64 byte aligned.
************************************************************************
*/
//#if _LONG_LONG_ALIGNMENT== 8 && _LONG_LONG_ALIGNMENT_32== 4
#pragma pack(8)
//#endif
struct _CCB
{
	struct list_head	Queue_Pointer;
	struct list_head	Complete_Queue_Pointer;
	struct _ARCSAS_SG_Table SG_Table;
	struct _ARCSAS_SGENTRY	sgList[ARCSAS_MAX_OS_SG_ENTRIES];

	PACB			pACB;
	PCORE			pCore;
	union ccb		*pccb;
	PDomain_Device	pDevice;
	PCORE_CONTEXT	pCoreContext;		/* Each module should only use Context to store module information. */
	PPRD_Buffer	PRD_Buffer;
	PVOID		pCmd_Initiator;		/* Which module(extension pointer) creates this request. */
	PVOID		pData_Buffer;		/* os data buffer .. struct buf * */
	PVOID		pSense_Buffer;
	PVOID		pOrg_Req;		/* The original request. os ccb: struct scsi_pkt *pkt, pointer of solaris scsi command */
	PVOID		pScratch_Buffer;	/* pointer to the scratch buffer that this request used */

	bus_dma_segment_t	*pSGsegment;

	bus_dmamap_t	dataBuf_dmaMap;

	CCB_CBFunc	Completion;		/* call back function */

	ARCSAS_U64	LBA;

	u_int32_t	DataTransferLength;
	u_int32_t	Sector_Count;
	u_int32_t	Time_Out;		/* how many seconds we should wait before treating request as timed-out */
	u_int32_t	Cmd_Flag;

	uint32_t	Delivery_Q_entry;
	u_int16_t	EntryIndex;		/* sas device device id, scsilun-scsiid */
	u_int16_t	CCB_Flag;		/* Check the CCB_FLAG definition */
	u_int16_t	SlotNo;
	u_int16_t	NCQTAG;			/* for SATA NCQ tag */
	u_int16_t	sgCount;
	u_int16_t	TargetId;
	u_int16_t	Lun;
	u_int16_t	reserve1;

	u_int8_t	Cdb[MAX_CDB_SIZE];	/* 16 */

	u_int8_t	CCB_Status;
	u_int8_t	Tag;			/* Request tag */
	u_int8_t	CCB_Type;		/* Check the CCB_TYPE definition */
	u_int8_t	SenseBufferLength;

	u_int8_t	modePageBuf[28];
	u_int8_t	SenseBuffer[ARCSAS_SENSE_BUF_SIZE];
	struct	callout	ccb_callout;
	uint8_t		phyIndex;
	uint8_t		reserved[3];
};
//#if _LONG_LONG_ALIGNMENT== 8 && _LONG_LONG_ALIGNMENT_32== 4
#pragma pack()
//#endif
/*
***************************************
**	CCB_TYPE_OS= 2,
**	CCB_TYPE_CACHE,
**	CCB_TYPE_RAID,
**	CCB_TYPE_MP,
**	CCB_TYPE_INTERNAL,
***************************************
*/
#define CCB_STATUS_SUCCESS		0x0
#define CCB_STATUS_NOT_READY		0x1
#define CCB_STATUS_MEDIA_ERROR		0x2
#define CCB_STATUS_BUSY			0x3
#define CCB_STATUS_INVALID_REQUEST	0x4
#define CCB_STATUS_INVALID_PARAMETER	0x5
#define CCB_STATUS_NO_DEVICE		0x6
/* Sense data structure is the SCSI "Fixed format sense datat" format. */
#define CCB_STATUS_HAS_SENSE		0x7
#define CCB_STATUS_ERROR		0x8
#define CCB_STATUS_ABORTED		0x9
#define CCB_STATUS_ERROR_WITH_SENSE	0x0A
#define CCB_STATUS_DATA_OVER_RUN	0x0B
/* Request initiator must set the status to CCB_STATUS_PENDING. */
#define CCB_STATUS_PENDING		0x80
#define CCB_STATUS_RETRY		0x81
#define CCB_STATUS_REQUEST_SENSE	0x82
/* Command flag is the flag for the CDB command itself */
/* The first 16 bit can be determined by the initiator. */
#define CMD_FLAG_NON_DATA		ARCSAS_BIT(0)	/* 1-non data, 0-data command */
#define CMD_FLAG_DMA			ARCSAS_BIT(1)	/* 1-DMA */
#define CMD_FLAG_PIO			ARCSAS_BIT(2)	/* 1-PIO */
#define CMD_FLAG_DATA_IN		ARCSAS_BIT(3)	/* 1-host read data */
#define CMD_FLAG_DATA_OUT		ARCSAS_BIT(4)	/* 1-host write data */
#define CMD_FLAG_SMART			ARCSAS_BIT(5)	/* 1-SMART command, 0-non SMART command*/
#define CMD_FLAG_SMART_ATA_12		ARCSAS_BIT(6)	/* SMART ATA_12  */
#define CMD_FLAG_SMART_ATA_16		ARCSAS_BIT(7)	/* SMART ATA_16; */
#define CMD_FLAG_DMA_VALID		ARCSAS_BIT(8)	/* 1-DMA valid */
#define CMD_FLAG_DMA_CONSISTENT		ARCSAS_BIT(9)	/* solaris PKT_CONSISTENT */
#define CMD_FLAG_CCB_BUILT		ARCSAS_BIT(10)	/* TRAN_BUSY...for os pkt retry */
#define	CMD_FLAG_AUTO_SENSE_OK		ARCSAS_BIT(11)	/* return auto sense data is OK if any */
#define	CMD_FLAG_DMAMAP_LOADED		ARCSAS_BIT(12)	/* dma map loaded */
/*
 * The last 16 bit only can be set by the target. Only core driver knows
 * the device characteristic.
*/
#define CMD_FLAG_NCQ			ARCSAS_BIT(16)
#define CMD_FLAG_TCQ			ARCSAS_BIT(17)
#define CMD_FLAG_48BIT			ARCSAS_BIT(18)
#define CMD_FLAG_PACKET			ARCSAS_BIT(19)  /* ATAPI packet cmd */
#define CMD_FLAG_SCSI_PASS_THRU		ARCSAS_BIT(20)
#define CMD_FLAG_ATA_PASS_THRU		ARCSAS_BIT(21)

#define CCB_FLAG_LBA_VALID		ARCSAS_BIT(0)
#define CCB_FLAG_CMD_FLAG_VALID		ARCSAS_BIT(1)
#define CCB_FLAG_RETRY			ARCSAS_BIT(2)
#define CCB_FLAG_INTERNAL_SG		ARCSAS_BIT(3)
#define CCB_FLAG_NCQ_VALID		ARCSAS_BIT(4)
#define CCB_FLAG_TIMER_START		ARCSAS_BIT(5)
#define CCB_FLAG_FLUSH			ARCSAS_BIT(6)
#define CCB_FLAG_CONSOLIDATE		ARCSAS_BIT(8)
#define CCB_FLAG_NO_CONSOLIDATE		ARCSAS_BIT(9)
#define CCB_FLAG_EXTERNAL		ARCSAS_BIT(10)
#define CCB_FLAG_CORE_SUB		ARCSAS_BIT(11)
#define CCB_FLAG_BYPASS_HYBRID		ARCSAS_BIT(12)	/* hybrid disk simulation */
#define CCB_FLAG_REQUEUE		ARCSAS_BIT(13)
/*
************************************************************************
**  total 28 bytes
************************************************************************
*/
struct _Link_Endpoint
{
	u_int16_t	DevID;
	u_int8_t	DevType;	/* Refer to DEVICE_TYPE_xxx, (additional type like EDGE_EXPANDER and FANOUT_EXPANDER might be added). */
//#define DEVICE_TYPE_NONE		0
//#define DEVICE_TYPE_HD		1
//#define DEVICE_TYPE_PM		2
//#define DEVICE_TYPE_EXPANDER		3
//#define DEVICE_TYPE_TAPE		4
//#define DEVICE_TYPE_PRINTER		5
//#define DEVICE_TYPE_PROCESSOR		6
//#define DEVICE_TYPE_WRITE_ONCE	7
//#define DEVICE_TYPE_CD_DVD		8
//#define DEVICE_TYPE_OPTICAL_MEMORY	9
//#define DEVICE_TYPE_MEDIA_CHANGER	10
//#define DEVICE_TYPE_ENCLOSURE		11
//#define DEVICE_TYPE_PORT		0xFF

	u_int8_t	PhyCount;		/* Number of PHYs for this endpoint.  Greater than 1 if it is wide port. */
	uint8_t		PhyId[ARCSAS_MAX_WIDEPORT_PHYS];	/* Assuming wide port has max of 4 PHYs. */
	u_int8_t	SAS_Address[8];		/* Filled with 0 if not SAS device. */
	u_int8_t	Reserved1[12];
};
/*
************************************************************************
** total 64 bytes
************************************************************************
*/
struct _Link_Entity
{
	Link_Endpoint	Parent;
	u_int8_t	Reserved[8];
	Link_Endpoint	Self;
};
/*
************************************************************************
**
************************************************************************
*/
struct _Version_Info
{
	u_int32_t	VerMajor;
	u_int32_t	VerMinor;
	u_int32_t	VerOEM;
	u_int32_t	VerBuild;
};
/*
************************************************************************
** total 104 bytes
************************************************************************
*/
struct _Adapter_Info
{
	Version_Info	DriverVersion;
	Version_Info	BIOSVersion;
	Version_Info	FirmwareVersion;	/* Reserve for firmware */

	u_int32_t	SystemIOBusNumber;
	u_int32_t	SlotNumber;
	u_int32_t	InterruptLevel;
	u_int32_t	InterruptVector;

	u_int16_t	VenID;
	u_int16_t	SubVenID;
	u_int16_t	DevID;
	u_int16_t	SubDevID;

	u_int8_t	PortCount;		/* How many ports, like 4 ports, or 4S1P. */
	u_int8_t	PortSupportType;	/* Like SATA port, SAS port, PATA port, use ARCSAS_BIT */
	u_int8_t	Features;		/* Feature bits.  See FEATURE_XXX. If corresponding bit is set, that feature is supported. */
	u_int8_t	AlarmSupport;

	u_int8_t	RevisionID;		/* Chip revision */
	u_int8_t	Reserved2[11];

	u_int8_t	MaxTotalBlocks;
	u_int8_t	MaxBlockPerPD;
	u_int8_t	MaxHD;
	u_int8_t	MaxExpander;

	u_int8_t	MaxPM;
	u_int8_t	MaxLogicalDrive;
	u_int16_t	LogicalDriverMode;

	u_int8_t	WWN[8];	/* For future VDS use. */
};
/*
************************************************************************
** get host peripheral device infomation,  total 248 bytes
************************************************************************
*/
struct _SD_Info
{
	Link_Entity	Link;		/* Including self DevID & DevType */
	u_int8_t	AdapterID;
	u_int8_t	Status;		/* Refer to SD_STATUS_XXX */
	u_int8_t	HDType;		/* SD_TYPE_xxx, replaced by new driver with ConnectionType & DeviceType */

	u_int8_t	PIOMode;	/* Max PIO mode */
	u_int8_t	MDMAMode;	/* Max MDMA mode */
	u_int8_t	UDMAMode;	/* Max UDMA mode */
	u_int8_t	ConnectionType;	/* DC_XXX, ConnectionType & DeviceType in new driver to replace HDType above */
//#define DC_ATA			ARCSAS_BIT(0)
//#define DC_SCSI			ARCSAS_BIT(1)
//#define DC_SERIAL			ARCSAS_BIT(2)
//#define DC_PARALLEL			ARCSAS_BIT(3)
//#define DC_ATAPI			ARCSAS_BIT(4)

	u_int8_t	DeviceType;	/* DT_XXX */
/* PD's Device type defined in SCSI-III specification (used by new driver) */
//#define DT_DIRECT_ACCESS_BLOCK	0x00
//#define DT_SEQ_ACCESS			0x01
//#define DT_PRINTER			0x02
//#define DT_PROCESSOR			0x03
//#define DT_WRITE_ONCE			0x04
//#define DT_CD_DVD			0x05
//#define DT_OPTICAL_MEMORY		0x07
//#define DT_MEDIA_CHANGER		0x08
//#define DT_STORAGE_ARRAY_CTRL		0x0C
/* an actual enclosure */
//#define DT_ENCLOSURE			0x0D
/* The following are defined by Marvell */
//#define DT_EXPANDER			0x20
//#define DT_PM				0x21
/* a device that provides some SES services (ie, Luigi) */
//#define DT_SES_DEVICE			0x22

	u_int32_t	FeatureSupport;	/* Support 1.5G, 3G, TCQ, NCQ, and etc, ARCSAS_BIT related */

	uint8_t		Model_Number[40];
	uint8_t		Serial_Number[20];
	uint8_t		Firmware_Revision[8];
	ARCSAS_U64	Size;		/* unit: 1KB */
	u_int8_t	WWN[8];		/* ATA/ATAPI-8 has such definitions for the identify buffer */
	u_int8_t	CurrentPIOMode;		/* Current PIO mode */
	u_int8_t	CurrentMDMAMode;	/* Current MDMA mode */
	u_int8_t	CurrentUDMAMode;	/* Current UDMA mode */
	u_int8_t	SesOverallElementIndex;
	u_int32_t	BlockSize;
	u_int8_t	ActivityLEDStatus;
	u_int8_t	LocateLEDStatus;
	u_int8_t	ErrorLEDStatus;
	u_int8_t	SesElementType;
	u_int8_t	SesSlotNumber;
	u_int8_t	HD_SSD_Type;
	u_int16_t	SesEntryIndex;
	u_int16_t	Rotation_Rate;
	u_int8_t	Reserved4[70];
};
#define SD_TYPE_SATA			ARCSAS_BIT(0)
#define SD_TYPE_PATA			ARCSAS_BIT(1)
#define SD_TYPE_SAS			ARCSAS_BIT(2)
#define SD_TYPE_ATAPI			ARCSAS_BIT(3)
#define SD_TYPE_TAPE			ARCSAS_BIT(4)
#define SD_TYPE_SES			ARCSAS_BIT(5)
#define SD_TYPE_MEDIA_CHANGER	ARCSAS_BIT(6)

#define SD_FEATURE_NCQ			ARCSAS_BIT(0)	/* Capability */
#define SD_FEATURE_TCQ			ARCSAS_BIT(1)
#define SD_FEATURE_1_5G			ARCSAS_BIT(2)
#define SD_FEATURE_3G			ARCSAS_BIT(3)
#define SD_FEATURE_6G			ARCSAS_BIT(4)
#define SD_FEATURE_WRITE_CACHE	ARCSAS_BIT(5)
#define SD_FEATURE_48BITS		ARCSAS_BIT(6)
#define SD_FEATURE_SMART		ARCSAS_BIT(7)
#define SD_FEATURE_DATA_SET_MANAGEMENT	ARCSAS_BIT(8)
/*
************************************************************************
**	total 132 bytes
************************************************************************
*/
struct _Expander_Info
{
	Link_Entity	Link; /* Including self DevID & DevType */

	uint8_t		AdapterID;
	uint8_t		Configuring;
	uint8_t		RouteTableConfigurable;
	uint8_t		PhyCount;

	uint16_t	ExpanderChangeCount;
	uint16_t	MaxRouteIndexes;

	uint8_t		VendorID[8+1];
	uint8_t		ProductID[16+1];
	uint8_t		ProductRev[4+1];
	uint8_t		ComponentVendorID[8+1];

	uint16_t	ComponentID;
	uint8_t		ComponentRevisionID;
	uint8_t		Reserved1[17];
};
/*
************************************************************************
**
************************************************************************
*/
struct _PM_Info
{
	Link_Entity	Link;		/* Including self DevID & DevType */
	u_int8_t	AdapterID;
	u_int8_t	ProductRevision;
	u_int8_t	PMSpecRevision; /* 10 means 1.0, 11 means 1.1 */
	u_int8_t	NumberOfPorts;
	u_int16_t	Pci_Ven_ID;
	u_int16_t	Pci_Dev_ID;
	u_int8_t	Reserved1[8];
};
/*
************************************************************************
**
************************************************************************
*/
struct _SD_Config
{
	u_int8_t	WriteCacheOn;	/* 1: enable write cache */
	u_int8_t	SMARTOn;	/* 1: enable S.M.A.R.T */
	u_int8_t	Online;		/* 1: to set HD online */
	u_int8_t	DriveSpeed;	// For SATA & SAS.  SD_SPEED_1_5G, SD_SPEED_3G etc
	u_int8_t	Reserved[2];
	u_int16_t	ScsiDeviceId;
};
/*
************************************************************************
**
************************************************************************
*/
struct  _SD_SmartStatus
{
	u_int8_t	SmartThresholdExceeded;
	u_int8_t	CCB_Status;
	u_int16_t	ScsiDeviceId;
};
/*
************************************************************************
**	add as enclosure
************************************************************************
*/
#define ENC_STATUS_NOT_EXIST	0
#define ENC_STATUS_OK		1
#define ENC_STATUS_UNSTABLE	2
/*
************************************************************************
**
************************************************************************
*/
typedef struct _Enclosure_Info
{
	Link_Entity	Link;
	u_int8_t		AdapterID;
	u_int8_t		Status;		// Refer to ENC_STATUS_XXX 
	u_int8_t		reserved1[2];
	u_int8_t		LogicalID[8+1];
	u_int8_t		VendorID[8+1];
	u_int8_t		ProductID[16+1];
	u_int8_t		RevisionLevel[4+1];
	u_int8_t		reserved2[3];
	// If ExpanderCount > 0, the enclosure might have more than one parant, in this case
	// Link.Parent.DevType will be set to DEVICE_TYPE_NONE and all other Parent fields are meaningless.
	// To get all its parent info, use each of ExpanderIDs[] to find out its individual parent.
	u_int8_t		ExpanderCount;	
	u_int16_t		ExpanderIDs[8];
	u_int8_t		reserved3[24];
}Enclosure_Info, *PEnclosure_Info;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncCooling_Element
{
	u_int16_t	curSpeed;
	u_int8_t	curSpeedcode;
	u_int8_t	reserved[5];
} EncCooling_Element;
#define ENC_COOLING_STOP	0
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncPower_Element
{
	u_int8_t	DCOverVoltage:1;
	u_int8_t	DCUnderVoltage:1;
	u_int8_t	DCOverCurrent:1;
	u_int8_t	hotSwap:1;
	u_int8_t	tempWarn:1;
	u_int8_t	reservedbit:3;
	u_int8_t	reserved[7];
} EncPower_Element;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncTemperatureSensor_Element
{
	u_int8_t	temperature;
	u_int8_t	OTFailure:1;
	u_int8_t	OTWarning:1;
	u_int8_t	UTFailure:1;
	u_int8_t	UTWarning:1;
	u_int8_t	reservedbit:4;
	u_int8_t	reserved[6];
} EncTemperatureSensor_Element;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncDoorLock_Element
{
	u_int8_t	unlocked;
	u_int8_t	reserved[7];
} EncDoorLock_Element;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncAudibleAlarm_Element
{
	u_int8_t	mute:1;
	u_int8_t	remind:1;
	u_int8_t	reservedbit:6;
	u_int8_t	reserved[7];
} EncAudibleAlarm_Element;

#define ENC_DISPLAY_NOCHANGE		0
#define ENC_DISPLAY_ENCCONTROL		1
#define ENC_DISPLAY_CLIENT		2
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncDisplay_Element
{
	u_int8_t	character1;
	u_int8_t	character2;
	u_int8_t	mode;
	u_int8_t	reserved[5];
} EncDisplay_Element;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncVoltageSensor_Element
{
	u_int16_t	voltage;
	u_int8_t	warnOver:1;
	u_int8_t	warnUnder:1;
	u_int8_t	critOver:1;
	u_int8_t	critUnder:1;
	u_int8_t	reservedbit:4;
	u_int8_t	reserved[5];
} EncVoltageSensor_Element;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncDevice_Element
{
	u_int8_t	SlotAddress;

	u_int8_t	Report:1;
	u_int8_t	Ident:1;
	u_int8_t	Rmv:1;
	u_int8_t	ReadyToInst:1;
	u_int8_t	EncBypassedB:1;
	u_int8_t	EncBypassedA:1;
	u_int8_t	DoNotRemove:1;
	u_int8_t	AppClientBypassedA:1;

	u_int8_t	DeviceBypassedB:1;
	u_int8_t	DeviceBypassedA:1;
	u_int8_t	ByPassedB:1;
	u_int8_t	ByPassedA:1;
	u_int8_t	DeviceOff:1;
	u_int8_t	FaultReqstd:1;
	u_int8_t	FaultSensed:1;
	u_int8_t	AppClientBypassedB:1;

	u_int8_t	reserved[5];
} EncDevice_Element;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncArrayDevice_Element
{
	u_int8_t	RrAbort:1;	// Rebuild or Remap Abort
	u_int8_t	RebuildRemap:1;	// Rebuild or Remap
	u_int8_t	InFailedArray:1;
	u_int8_t	InCritArray:1;
	u_int8_t	ConsChk:1;
	u_int8_t	HotSpare:1;
	u_int8_t	RsvdDevice:1;
	u_int8_t	Ok:1;

	u_int8_t	Report:1;
	u_int8_t	Ident:1;
	u_int8_t	Rmv:1;
	u_int8_t	ReadyToInst:1;
	u_int8_t	EncBypassedB:1;
	u_int8_t	EncBypassedA:1;
	u_int8_t	DoNotRemove:1;
	u_int8_t	AppClientBypassedA:1;

	u_int8_t	DeviceBypassedB:1;
	u_int8_t	DeviceBypassedA:1;
	u_int8_t	ByPassedB:1;
	u_int8_t	ByPassedA:1;
	u_int8_t	DeviceOff:1;
	u_int8_t	FaultReqstd:1;
	u_int8_t	FaultSensed:1;
	u_int8_t	AppClientBypassedB:1;

	u_int8_t	reserved[5];
} EncArrayDevice_Element;

#define ENC_ELEMENTTYPE_UNKNOWN			0
#define ENC_ELEMENTTYPE_DEVICE			1
#define ENC_ELEMENTTYPE_POWERSUPPLY		2
#define ENC_ELEMENTTYPE_COOLING			3
#define ENC_ELEMENTTYPE_TEMPERATURE		4
#define ENC_ELEMENTTYPE_DOORLOCK		5
#define ENC_ELEMENTTYPE_AUDIBLEALARM		6
#define ENC_ELEMENTTYPE_ENCSERVICE		7
#define ENC_ELEMENTTYPE_SCCCONTROLLER		8
#define ENC_ELEMENTTYPE_NONVOLATILECACHE	9
#define ENC_ELEMENTTYPE_INVALIDOPERATION	10
#define ENC_ELEMENTTYPE_UNINTERRPOWER		11
#define ENC_ELEMENTTYPE_DISPLAY			12
#define ENC_ELEMENTTYPE_KEYPAD			13
#define ENC_ELEMENTTYPE_ENC			14
#define ENC_ELEMENTTYPE_SCSIPORT		15
#define ENC_ELEMENTTYPE_LANGUAGE		16
#define ENC_ELEMENTTYPE_COMMUNICATIONPORT	17
#define ENC_ELEMENTTYPE_VOLTAGESENSOR		18
#define ENC_ELEMENTTYPE_CURRENTSENSOR		19
#define ENC_ELEMENTTYPE_SCSITARGETPORT		20
#define ENC_ELEMENTTYPE_SCSIINITIATORPORT	21
#define ENC_ELEMENTTYPE_SIMPLESUBENC		22
#define ENC_ELEMENTTYPE_ARRAYDEVICE		23
#define ENC_ELEMENTTYPE_SASEXP			24
#define ENC_ELEMENTTYPE_SASCONNECTOR		25

#define MV_SUPPORT_STATUS_ELEMENT_TYPE(type)	\
	((type==ENC_ELEMENTTYPE_COOLING)||(type==ENC_ELEMENTTYPE_DEVICE) || \
	(type==ENC_ELEMENTTYPE_ARRAYDEVICE) || (type==ENC_ELEMENTTYPE_POWERSUPPLY) || \
	(type==ENC_ELEMENTTYPE_TEMPERATURE) || (type==ENC_ELEMENTTYPE_DOORLOCK) || \
	(type==ENC_ELEMENTTYPE_AUDIBLEALARM) || (type==ENC_ELEMENTTYPE_VOLTAGESENSOR) || \
	(type==ENC_ELEMENTTYPE_ARRAYDEVICE) || (type==ENC_ELEMENTTYPE_DISPLAY))
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncElementType_Info
{
	u_int16_t				enclosureID;
	u_int16_t				magicID;
	u_int8_t				type;
	u_int8_t				status;
	u_int8_t				elementID;
	u_int8_t				reserved;
	union {
		EncDevice_Element		device;
		EncArrayDevice_Element		arrayDevice;
		EncCooling_Element		fan;
		EncPower_Element		power;
		EncTemperatureSensor_Element	temperatureSensor;
		EncDoorLock_Element		doorLock;
		EncAudibleAlarm_Element		alarm;
		EncDisplay_Element		display;
		EncVoltageSensor_Element	voltageSensor;
		u_int8_t			unCode[8];
	}Enc_Element;
} EncElementType_Info, *PEncElementType_Info;

#define ARCSAS_SUPPORT_CONTROL_ELEMENT_TYPE(type)	\
	((type==ENC_ELEMENTTYPE_COOLING)||(type==ENC_ELEMENTTYPE_ARRAYDEVICE) || \
	(type==ENC_ELEMENTTYPE_DEVICE))
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncCooling_Control
{
	u_int8_t	speedcode;
	u_int8_t	reserved[7];
}EncCooling_Control,*PEncCooling_Control;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncDevice_Control
{
	u_int8_t	LedOn;
	u_int8_t	reserved[7];
}EncDevice_Control,*PEncDevice_Control;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncArrayDevice_Control
{
	u_int8_t	LedOn;
	u_int8_t	reserved[7];
}EncArrayDevice_Control,*PEncArrayDevice_Control;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncElementType_Control
{
	u_int16_t		enclosureID;
	u_int8_t		type;
	u_int16_t		magicID;
	u_int8_t		control;
	u_int8_t		elementID;
	u_int8_t		reserved;
	union {
		EncCooling_Control	fan;
		EncDevice_Control	device;
		EncArrayDevice_Control	arrayDevice;
		u_int8_t		unCode[8];
	}Enc_Control;
} EncElementType_Control, *PEncElementType_Control;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _DevElementStatusDescriptorEIP0
{
	u_int8_t config;
	u_int8_t length;
	u_int8_t infomantion[2];
} DevElementStatusDescriptorEIP0, *PDevElementStatusDescriptorEIP0;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _DevElementStatusDescriptorEIP1
{
	u_int8_t config;
	u_int8_t length;
	u_int8_t reserved;
	u_int8_t elementIndex;
	u_int8_t infomantion[4];
} DevElementStatusDescriptorEIP1, *PDevElementStatusDescriptorEIP1;
/*
************************************************************************
**
************************************************************************
*/
typedef union
{
	DevElementStatusDescriptorEIP0 EIP0;
	DevElementStatusDescriptorEIP1 EIP1;
}DevElementStatusDescriptor, *PDevElementStatusDescriptor;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _DevElementStatusPage
{
	u_int8_t			PageCode;
	u_int8_t			Reserved;
	u_int16_t			PageLength;
	u_int8_t			GenerationCode[4];
	DevElementStatusDescriptor	DeviceElementStatusDescriptor;
	u_int8_t			Data[2032];
} DevElementStatusPage, *PDevElementStatusPage;
/*
************************************************************************
**
************************************************************************
*/
typedef struct _SasPhyDescriptor
{
	u_int8_t Reserved1:4;
	u_int8_t DeviceType:3;
	u_int8_t Reserved2:1;

	u_int8_t Reserved3;

	u_int8_t Reserved4:1;
	u_int8_t SMPInitiatorPort:1;
	u_int8_t STPInitiatorPort:1;
	u_int8_t SSPInitiatorPort:1;
	u_int8_t Reserved5:4;

	u_int8_t Reserved6:1;
	u_int8_t SMPTargetPort:1;
	u_int8_t STPTargetPort:1;
	u_int8_t SSPTargetPort:1;
	u_int8_t Reserved7:4;

	u_int8_t AttachedSASAddress[8];
	u_int8_t SASAddress[8];
	u_int8_t PhyIdentifier;
	u_int8_t Reserved8[7];
} SasPhyDescriptor, *PSasPhyDescriptor;

#define HIGH_CRITICAL_THRESHOLD ARCSAS_BIT(0)
#define HIGH_WARNING_THRESHOLD  ARCSAS_BIT(1)
#define LOW_CRITICAL_THRESHOLD  ARCSAS_BIT(2)
#define LOW_WARNING_THRESHOLD   ARCSAS_BIT(3)


#define ARCSAS_ELEMENTTHRESHOLD_TYPE(type)	((type==ENC_ELEMENTTYPE_TEMPERATURE)||(type==ENC_ELEMENTTYPE_VOLTAGESENSOR))
/*
************************************************************************
**
************************************************************************
*/
typedef struct _EncElement_Config
{
	u_int16_t		enclosureID;
	u_int16_t		magicID;
	u_int8_t		type;
	u_int8_t		status;
	u_int8_t		elementID;
	u_int8_t		highCriticalThreshold;
	u_int8_t		highWarningThreshold;
	u_int8_t		lowCriticalThreshold;
	u_int8_t		lowWarningThreshold;
	u_int8_t		reserved[5];
} EncElement_Config, *PEncElement_Config;
/*
************************************************************************
**
************************************************************************
*/
struct _PassThrough_Config
{
	/* We put Data_Buffer[] at the very beginning of this structure because SCSI commander did so.*/
	u_int8_t	Data_Buffer[MAX_PASS_THRU_DATA_BUFFER_SIZE];	/* set by driver if read, by application if write */
	u_int8_t	Reserved1[128];
	u_int32_t	Data_Length;		/* set by driver if read, by application if write  */
	u_int16_t	DevId;			/* PD ID (used by application only) */
	u_int8_t	CDB_Type;		/* define a CDB type for each CDB category (used by application only) */
	u_int8_t	Reserved2;
	u_int32_t	lba;
	u_int8_t	Reserved3[64];
};
/*
************************************************************************
**
************************************************************************
*/
struct _Assigned_Uncached_Memory
{
	PVOID		Virtual_Address;
	ARCSAS_U64	Physical_Address;
};
/*
************************************************************************
**
************************************************************************
*/
struct _SCSI_PASS_THROUGH_DIRECT
{
	u_int16_t	Length;
	u_int8_t	ScsiStatus;
	u_int8_t	PathId;
	u_int8_t	TargetId;
	u_int8_t	Lun;
	u_int8_t	CdbLength;
	u_int8_t	SenseInfoLength;
	u_int8_t	DataIn;
	u_int32_t	DataTransferLength;
	u_int32_t	TimeOutValue;
	void		*DataBuffer;
	u_int32_t	SenseInfoOffset;
	u_int8_t	Cdb[16];
};
/*
************************************************************************
**
************************************************************************
*/
struct _SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER
{
	SCSI_PASS_THROUGH_DIRECT	sptd;
	u_int32_t			Filler;
	u_int8_t			Sense_Buffer[SENSE_INFO_BUFFER_SIZE];
};
/*
************************************************************************
**
************************************************************************
*/
enum {
	SlotCount = ARCSAS_MAX_CORE_SLOT_COUNT,
	CoreCCBCount = ARCSAS_MAX_CORE_CCB_COUNT,
	SASScratchCount = ARCSAS_MAX_SAS_SCRATCH_COUNT,
	SMPScratchCount = ARCSAS_MAX_SMP_SCRATCH_COUNT,
	ExpanderCount = ARCSAS_MAX_EXPANDER_SUPPORTED,
	PMCount = ARCSAS_MAX_PM_SUPPORTED,
	CoreSGEntryCount = ARCSAS_MAX_OS_SG_ENTRIES,
	SGBufferCount = ARCSAS_MAX_SG_BUFFER_COUNT,
	DevCount = ARCSAS_MAX_DEVICE_ID+1,
	SmpElementCount = ARCSAS_MAX_SMP_ELEMENT,
	EventElementCount = ARCSAS_MAX_EVENT_ELEMENT,
	DeliveryQSize = ARCSAS_MAX_CORE_SLOT_COUNT,
	DoneQSize = ARCSAS_MAX_CORE_SLOT_COUNT+16,
	ContextCount = ARCSAS_MAX_CORE_CCB_COUNT + ARCSAS_MAX_CORE_SLOT_COUNT, /* not for OS ,128+512=640, ?????? why need so many */
};

/*
************************************************************************
**	H/W Access Routines
************************************************************************
*/
#define READ_PORT_IRQ_STATE( mem_map_base, phy_index)	\
	((phy_index > 3) ? \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_state4+(phy_index-4)*8)) :\
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_state0+phy_index*8)))

#define WRITE_PORT_IRQ_STATE( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_state4+(phy_index-4)*8), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_state0+phy_index*8), temp);

#define READ_PORT_IRQ_MASK( mem_map_base, phy_index)	\
	((phy_index>3) ? \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_mask4+(phy_index-4)*8)) :\
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_mask0+phy_index*8)))

#define WRITE_PORT_IRQ_MASK( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_mask4+(phy_index-4)*8), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_irq_mask0+phy_index*8), temp);

#define READ_PORT_PHY_CONTROL( mem_map_base, phy_index)	\
	((phy_index > 3) ? \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_phy_control4+(phy_index-4)*4)) : \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_phy_control0+phy_index*4)))

#define WRITE_PORT_PHY_CONTROL( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_phy_control4+(phy_index-4)*4), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_phy_control0+phy_index*4),temp);

#define READ_PORT_CONFIG_DATA( mem_map_base, phy_index)	\
	((phy_index > 3) ? \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_config_data4+(phy_index-4)*8)) : \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_config_data0+phy_index*8)))

#define WRITE_PORT_CONFIG_DATA( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_config_data4+(phy_index-4)*8), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_config_data0+phy_index*8),temp);

#define WRITE_PORT_CONFIG_ADDR( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_config_addr4+(phy_index-4)*8), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_config_addr0+phy_index*8), temp);

#define READ_PORT_VSR_DATA( mem_map_base, phy_index)	\
	((phy_index > 3) ? \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_vsr_data4+(phy_index-4)*8)) : \
	CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+\
	port_vsr_data0+phy_index*8)))

#define WRITE_PORT_VSR_DATA( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_vsr_data4+(phy_index-4)*8), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_vsr_data0+phy_index*8), temp);

#define WRITE_PORT_VSR_ADDR( mem_map_base, phy_index, temp)	\
	if (phy_index > 3) \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_vsr_addr4+(phy_index-4)*8), temp);\
	else \
	CHIP_REG_WRITE32( NumToPtr(PtrToNum(mem_map_base)+\
	port_vsr_addr0+phy_index*8),temp);

#define ARCSAS_IS_PHY_READY(mem_map_base, id)	\
(READ_PORT_PHY_CONTROL( mem_map_base, id) & ARCSAS_PHY_READY_MASK)

#define ARCSAS_IS_PHY_CHANGE( mem_map_base, id)	\
(READ_PORT_IRQ_STATE( mem_map_base, id) & PHY_RDY_CHNG_MASK)

#define ARCSAS_IS_ASYNC_NOTIFY( mem_map_base, id)	\
(READ_PORT_IRQ_STATE( mem_map_base, id) & ASYNC_NTFCN_RCVD_MASK)

#define ARCSAS_CLEAR_PORT_IRQ( mem_map_base, id)	\
uint32_t reg;	\
reg = READ_PORT_IRQ_STATE( mem_map_base, id);	\
WRITE_PORT_IRQ_STATE( mem_map_base, id, reg);

#define ARCSAS_IS_BROADCAST_CHANGE( mem_map_base, id)	\
(READ_PORT_IRQ_STATE( mem_map_base, id) & BRDCST_CHNG_RCVD_MASK)

#define ARCSAS_IS_PHY_DEC_ERROR( mem_map_base, id)	\
(READ_PORT_IRQ_STATE( mem_map_base, id) & STP_SATA_PHY_DEC_ERR_MASK)

#define ARCSAS_IS_UNASSOC_FIS( mem_map_base, id)	\
(READ_PORT_IRQ_STATE( mem_map_base, id) & UNASSOC_FIS_RCVD_MASK)

#define ARCSAS_GET_COMMON_INT_CAUSES( mem_map_base, irqs)	\
irqs = CHIP_REG_READ32(NumToPtr(PtrToNum(mem_map_base)+COMMON_INT_CAUSE));

/* offset for D2H FIS in the Received FIS List Structure */
#define SATA_RECEIVED_D2H_FIS_1300(reg_set)	\
(UNASSOCIATED_FIS_POOL_SIZE_1300 + 0x100 * reg_set + 0x40) /* 1300 and 1320 have the same phy number, and fis offset */

#define SATA_RECEIVED_D2H_FIS_1320(reg_set)	\
(UNASSOCIATED_FIS_POOL_SIZE_1320 + 0x100 * reg_set + 0x40) /* 1300 and 1320 have the same phy number, and fis offset */

#define UNASSOC_D2H_FIS(id)	(0x100 *id)

#define _ASECONDS(a)	(a*1000*1000+(pACB->UsecsPerTick-1)) / pACB->UsecsPerTick

#define TDLIST_INIT_HDR(timer_list_header)	\
((TdList *)(timer_list_header))->flink = (TdList *)(timer_list_header);\
((TdList *)(timer_list_header))->blink = (TdList *)(timer_list_header);\

#define TDLIST_GET_PREV(timer_list_header, ptimer_list)	\
(((ptimer_list)->blink== timer_list_header) ? NULL :(ptimer_list)->blink)

#define TDLIST_GET_TAIL(timer_list_header)	\
TDLIST_GET_PREV(timer_list_header, timer_list_header)

#define TDLIST_EMPTY(timer_list_header)	\
(((TdList *)(timer_list_header))->flink == ((TdList *)(timer_list_header)))

#define TDLIST_NOT_EMPTY(timer_list_header)	(!TDLIST_EMPTY(timer_list_header))

#define TDLIST_OBJECT_BASE(baseType, fieldName, fieldPtr)	\
(PVOID)fieldPtr == (PVOID)0 ? (baseType *)0 : \
((baseType *)((uint8_t *)(fieldPtr) - offsetof (baseType, fieldName)))

#define TDLIST_DEQUEUE_THIS(timer_list)	\
((TdList *)(timer_list))->blink->flink = ((TdList *)(timer_list))->flink;\
((TdList *)(timer_list))->flink->blink = ((TdList *)(timer_list))->blink;\
((TdList *)(timer_list))->flink = ((TdList *)(timer_list))->blink = NULL;\

#define TDLIST_ENQUEUE_AT_TAIL(toAddHdr, timer_list_header)	\
((TdList *)(toAddHdr))->flink = (TdList *)(timer_list_header);\
((TdList *)(toAddHdr))->blink = ((TdList *)(timer_list_header))->blink;\
((TdList *)(timer_list_header))->blink->flink = (TdList *)(toAddHdr);\
((TdList *)(timer_list_header))->blink = (TdList *)(toAddHdr);\

#define TDLIST_INSERT(timer_list_header, ptimer_list, ptimer_list_new)	\
(ptimer_list_new)->flink = (ptimer_list);\
(ptimer_list_new)->blink = (ptimer_list)->blink;\
(ptimer_list)->blink->flink = (ptimer_list_new);\
(ptimer_list)->blink =(ptimer_list_new);\

#define TDLIST_INIT_ELEMENT(timer_list_header)	\
((TdList *)(timer_list_header))->flink = (TdList *) NULL;\
((TdList *)(timer_list_header))->blink = (TdList *) NULL;\

#define ARCSAS_LIST_ENTRY(one, type, member)	\
(one==NULL) ? ((type *) NULL):((type *)((caddr_t)(one) - offsetof(type, member)))

#define Get_DevicesExpandersPMs_EntryIndex(pACB, entry_index)	\
(((entry_index & 0xff) <= ARCSAS_MAX_PM_ID) ? \
pACB->DevicesExpandersPMs_EntryIndex[(entry_index & 0xff)] : \
ARCSAS_ID_NOT_MAPPED )

#define Get_Ports_EntryIndex(pCore, port_index)	(pCore->Ports_EntryIndex[port_index])

#define Get_Port_Index(pACB, entry_index)	\
((Get_DevicesExpandersPMs_EntryIndex(pACB, entry_index) == ARCSAS_ID_NOT_MAPPED) ? \
ARCSAS_ID_NOT_MAPPED : \
(((entry_index & 0xff) < ARCSAS_MIN_EXPANDER_ID) ? \
(pACB->pDevices[pACB->DevicesExpandersPMs_EntryIndex[(entry_index & 0xff)]].pPort->Port_Index) : \
(((entry_index & 0xff) < ARCSAS_MIN_PM_ID) ? \
(pACB->pExpanders[pACB->DevicesExpandersPMs_EntryIndex[(entry_index & 0xff)]].pPort->Port_Index) : \
(pACB->pPMs[pACB->DevicesExpandersPMs_EntryIndex[(entry_index & 0xff)]].pPort->Port_Index))))
/*
************************************************
 * When you plug-in this command consolidate sub-module to some module
 * Please define the following the definition.
 * This is maintained by caller.
************************************************
*/
#define DEVICE_ENTRY_INDEX_TO_TARGET_ID(devic_entry_index)	\
((uint8_t)((devic_entry_index) & 0x00FF))

#define DEVICE_ENTRY_INDEX_TO_TARGET_LUN(devic_entry_index)	\
((uint8_t)(((devic_entry_index) & 0xFF00) >> 8))

#define MAKE_DEVICE_ENTRY_INDEX(target_id, target_lun)		\
(((uint16_t)(target_id)) |(((uint16_t)(target_lun)) << 8))

#define SCSI_IS_READ(cmd)	\
(((cmd) == SCSI_CMD_READ_6) || ((cmd) == SCSI_CMD_READ_10) || \
((cmd) == SCSI_CMD_READ_12) || ((cmd) == SCSI_CMD_READ_16))

#define SCSI_IS_WRITE(cmd)	\
(((cmd) == SCSI_CMD_WRITE_6) || ((cmd) == SCSI_CMD_WRITE_10) || \
((cmd) == SCSI_CMD_WRITE_12) || ((cmd) == SCSI_CMD_WRITE_16))

#define SCSI_IS_MODE_SENSE(cmd)	\
(((cmd) == SCSI_CMD_MODE_SENSE_6) || ((cmd) == SCSI_CMD_MODE_SENSE_10))

#define SCSI_IS_REQUEST_SENSE(cmd)	(((cmd) == SCSI_CMD_REQUEST_SENSE))

#define SCSI_IS_VERIFY(cmd)	\
(((cmd) == SCSI_CMD_VERIFY_10) || ((cmd) == SCSI_CMD_VERIFY_16))

/* SCSI command CDB helper functions. */
#define SCSI_CDB10_GET_LBA(cdb)	\
((uint32_t)(((uint32_t) cdb[2] << 24) | ((uint32_t) cdb[3] << 16) | \
((uint32_t) cdb[4] << 8) | (uint32_t) cdb[5]))

#define SCSI_CDB10_SET_LBA(cdb, lba)	\
{cdb[2] = (uint8_t)(lba >> 24);	\
cdb[3] = (uint8_t)(lba >> 16);	\
cdb[4]=(uint8_t)(lba >> 8);	\
cdb[5]=(uint8_t)lba;}

#define SCSI_CDB10_GET_SECTOR(cdb)		((cdb[7] << 8) | cdb[8])
#define SCSI_CDB10_SET_SECTOR(cdb, sector)	\
{cdb[7] = (uint8_t)(sector >> 8);  cdb[8] = (uint8_t)sector;}

#define ARCSAS_SWAP_16(x)	\
(((uint16_t)((uint8_t)(x))) << 8 | (uint16_t)((uint8_t)((x) >> 8)))

#define ARCSAS_SWAP_32(x)	\
(((uint32_t)((uint8_t)(x))) << 24 | ((uint32_t)((uint8_t)((x) >> 8))) << 16 | \
((uint32_t)((uint8_t)((x) >> 16))) << 8 | ((uint32_t)((uint8_t)((x) >> 24))))

#define ARCSAS_SWAP_64(x)	\
(((uint64_t)(ARCSAS_SWAP_32((x).parts.low))) << 32 | ARCSAS_SWAP_32((x).parts.high))

#define IS_A_SMP_REQ(pCCB)	\
((pCCB->Cdb[0] == SCSI_CMD_ARECA_SPECIFIC) && \
(pCCB->Cdb[1] == CDB_CORE_MODULE) && \
(pCCB->Cdb[2] == CDB_CORE_SMP))

#define IS_A_TSK_REQ(pCCB)	\
((pCCB->Cdb[0] == SCSI_CMD_ARECA_SPECIFIC) && \
(pCCB->Cdb[1] == CDB_CORE_MODULE) && \
(pCCB->Cdb[2] == CDB_CORE_TASK_MGMT))

#define IS_SOFT_RESET_REQ(pCCB)	\
((pCCB->Cdb[0] == SCSI_CMD_ARECA_SPECIFIC) && \
(pCCB->Cdb[1] == CDB_CORE_MODULE) && \
(pCCB->Cdb[2] == CDB_CORE_SOFT_RESET_1 || pCCB->Cdb[2] == CDB_CORE_SOFT_RESET_0))

#define IS_PM_REQ(pCCB)	\
((pCCB->Cdb[0] == SCSI_CMD_ARECA_SPECIFIC) && \
(pCCB->Cdb[1] == CDB_CORE_MODULE) && \
(pCCB->Cdb[2] == CDB_CORE_PM_READ_REG || pCCB->Cdb[2] == CDB_CORE_PM_WRITE_REG))

#define IS_A_SATA_ENABLE_READ_AHEAD_REQ(pCCB)	\
((pCCB->Cdb[0] == SCSI_CMD_ARECA_SPECIFIC) && \
(pCCB->Cdb[1] == CDB_CORE_MODULE) && \
(pCCB->Cdb[2] == CDB_CORE_ENABLE_READ_AHEAD))

#define IS_A_SATA_READ_LOG_EXT_REQ(pCCB)	\
((pCCB->Cdb[0] == SCSI_CMD_ARECA_SPECIFIC) && \
(pCCB->Cdb[1] == CDB_CORE_MODULE) && (pCCB->Cdb[2] == CDB_CORE_READ_LOG_EXT))

/* The SHA f()-functions.  */
#define f1(x,y,z)	(z ^ (x & (y ^ z)))		/* x ? y : z */
#define f2(x,y,z)	(x ^ y ^ z)			/* XOR */
#define f3(x,y,z)	((x & y) + (z & (x ^ y)))	/* majority */
/* The SHA Mysterious Constants */
#define K1	0x5A827999L	/* Rounds  0-19: sqrt(2) * 2^30 */
#define K2	0x6ED9EBA1L	/* Rounds 20-39: sqrt(3) * 2^30 */
#define K3	0x8F1BBCDCL	/* Rounds 40-59: sqrt(5) * 2^30 */
#define K4	0xCA62C1D6L	/* Rounds 60-79: sqrt(10) * 2^30 */

#define I2C_DATA_LINE		0
#define I2C_CLOCK_LINE		1
#define GPCNTL				0x47   /* General Purpose Control R/W */
#define GPREG				0x07   /* General Purpose Bits R/W */
#define SATA_SIGNATURE_STATUS_MASK	0xc0
#define SATA_DEVICE_READY 	0x40

#define	_BIT_FIELDS_LTOH

#define	SCMD_INQUIRY		0x12
#define	SCMD_GDIAG		0x1C	/* receive diagnostic results */
#define	SCMD_SDIAG		0x1D	/* send diagnostic results */
#define	SCMD_WRITE_BUFFER	0x3B
#define	SCMD_READ_BUFFER	0x3c
#define	SCMD_REPORT_LUNS	0xA0


struct block_descriptor {
	u_int8_t density_code;	/* device specific */
	u_int8_t blks_hi;	/* hi  */
	u_int8_t blks_mid;	/* mid */
	u_int8_t blks_lo;	/* low */
	u_int8_t reserved;	/* reserved */
	u_int8_t blksize_hi;	/* hi  */
	u_int8_t blksize_mid;	/* mid */
	u_int8_t blksize_lo;	/* low */
};

#define	MODE_BLK_DESC_LENGTH	(sizeof (struct block_descriptor))

struct mode_header {
	u_int8_t length;		/* number of bytes following */
	u_int8_t medium_type;		/* device specific */
	u_int8_t device_specific;	/* device specific parameters */
	u_int8_t bdesc_length;		/* length of block descriptor(s), if any */
};

#define	MODE_HEADER_LENGTH	(sizeof (struct mode_header))

struct mode_page {
#if defined(_BIT_FIELDS_LTOH)
	u_int8_t	code	:6,	/* page code number */
				:1,	/* reserved */
			ps	:1;	/* 'Parameter Saveable' bit */
#elif defined(_BIT_FIELDS_HTOL)
	u_int8_t	ps	:1,	/* 'Parameter Saveable' bit */
				:1,	/* reserved */
			code	:6;	/* page code number */
#else
#error	One of _BIT_FIELDS_LTOH or _BIT_FIELDS_HTOL must be defined
#endif	/* _BIT_FIELDS_LTOH */
	u_int8_t	length;		/* length of bytes to follow */
	/*
	 * Mode Page specific data follows right after this...
	 */
};

/*
* Page 0x3 - Direct Access Device Format Parameters
*/

struct mode_format {
	struct	mode_page mode_page;	/* common mode page header */
	u_int16_t tracks_per_zone;	/* Handling of Defects Fields */
	u_int16_t alt_sect_zone;
	u_int16_t alt_tracks_zone;
	u_int16_t alt_tracks_vol;
	u_int16_t sect_track;		/* Track Format Field */
	u_int16_t data_bytes_sect;	/* Sector Format Fields */
	u_int16_t interleave;
	u_int16_t track_skew;
	u_int16_t cylinder_skew;
#if defined(_BIT_FIELDS_LTOH)
	u_int8_t		: 3,
		_reserved_ins	: 1,	/* see <scsi/impl/mode.h> */
			surf	: 1,
			rmb	: 1,
			hsec	: 1,
			ssec	: 1;	/* Drive Type Field */
#elif defined(_BIT_FIELDS_HTOL)
	u_int8_t 	ssec	: 1,	/* Drive Type Field */
			hsec	: 1,
			rmb	: 1,
			surf	: 1,
		_reserved_ins	: 1,	/* see <scsi/impl/mode.h> */
				: 3;
#else
#error	One of _BIT_FIELDS_LTOH or _BIT_FIELDS_HTOL must be defined
#endif	/* _BIT_FIELDS_LTOH */
	u_int8_t	reserved[2];
};

/*
* Page 0x4 - Rigid Disk Drive Geometry Parameters
*/

struct mode_geometry {
	struct	mode_page mode_page;	/* common mode page header */
	u_int8_t	cyl_ub;		/* number of cylinders */
	u_int8_t	cyl_mb;
	u_int8_t	cyl_lb;
	u_int8_t	heads;		/* number of heads */
	u_int8_t	precomp_cyl_ub;	/* cylinder to start precomp */
	u_int8_t	precomp_cyl_mb;
	u_int8_t	precomp_cyl_lb;
	u_int8_t	current_cyl_ub;	/* cyl to start reduced current */
	u_int8_t	current_cyl_mb;
	u_int8_t	current_cyl_lb;
	u_int16_t	step_rate;	/* drive step rate */
	u_int8_t	landing_cyl_ub;	/* landing zone cylinder */
	u_int8_t	landing_cyl_mb;
	u_int8_t	landing_cyl_lb;
#if defined(_BIT_FIELDS_LTOH)
	u_int8_t	rpl	: 2,	/* rotational position locking */
				: 6;
#elif defined(_BIT_FIELDS_HTOL)
	u_int8_t	: 6,
		rpl	: 2;		/* rotational position locking */
#else
#error	One of _BIT_FIELDS_LTOH or _BIT_FIELDS_HTOL must be defined
#endif	/* _BIT_FIELDS_LTOH */
	u_int8_t	rotational_offset;	/* rotational offset */
	u_int8_t	reserved;
	u_int16_t	rpm;			/* rotations per minute */
	u_int8_t	reserved2[2];
};

struct scsi_INQUIRY {

	/*
	 * byte 0
	 *
	 * Bits 7-5 are the Peripheral Device Qualifier
	 * Bits 4-0 are the Peripheral Device Type
	 *
	 */

	u_int8_t inq_dtype;

	/* byte 1 */
	u_int8_t inq_qual	: 7,	/* device type qualifier */
		inq_rmb		: 1;	/* removable media */

	/* byte 2 */
	u_int8_t inq_ansi	: 3,	/* ANSI version */
		inq_ecma	: 3,	/* ECMA version */
		inq_iso		: 2;	/* ISO version */

	/* byte 3 */
	u_int8_t inq_rdf	: 4,	/* response data format */
		inq_hisup	: 1,	/* Hierachial support */
		inq_normaca	: 1,	/* setting NACA bit supported */
		inq_trmiop	: 1,	/* TERMINATE I/O PROC msg */
		inq_aenc	: 1;	/* async event notification cap. */

	/* bytes 4-7 */

	u_int8_t inq_len;		/* additional length */

	u_int8_t		: 4,	/* reserved */
		inq_tpgs	: 1,
				: 3;

	u_int8_t inq_addr16	: 1,	/* supports 16 bit wide SCSI addr */
		inq_addr32	: 1,	/* supports 32 bit wide SCSI addr */
		inq_ackqreqq	: 1,	/* data tranfer on Q cable */
		inq_mchngr	: 1,	/* embedded/attached to medium chngr */
		inq_dualp	: 1,	/* dual port device */
		inq_port	: 1,	/* port receiving inquiry cmd */
				: 2;	/* reserved */

	u_int8_t inq_sftre	: 1,	/* supports Soft Reset option */
		inq_cmdque	: 1,	/* supports command queueing */
		inq_trandis	: 1,	/* supports transfer disable messages */
		inq_linked	: 1,	/* supports linked commands */
		inq_sync	: 1,	/* supports synchronous data xfers */
		inq_wbus16	: 1,	/* supports 16 bit wide data xfers */
		inq_wbus32	: 1,	/* supports 32 bit wide data xfers */
		inq_reladdr	: 1;	/* supports relative addressing */

	/* bytes 8-35 */

	u_int8_t	inq_vid[8];		/* vendor ID */
	u_int8_t	inq_pid[16];		/* product ID */
	u_int8_t	inq_revision[4];	/* revision level */

	/*
	 * Bytes 36-47 are reserved:
	 *	For Sun qualified hard disk drives the inq_serial field contains
	 *		two bytes of mfg date year code (ascii)
	 *		two bytes of mfg date week code (ascii)
	 *		six bytes of mfg serial number (ascii)
	 *		two bytes unused
	 */
	u_int8_t	inq_serial[12];

	/*
	 * Bytes 48-95 are reserved.
	 * 96 to 'n' are vendor-specific parameter bytes
	 */
};

typedef  struct scsi_INQUIRY	*PSCSI_INQUIRY;

#define	SLOT_TRANS_RST		ARCSAS_BIT(25)
#define TARGET_FIFO_RST		ARCSAS_BIT(24)
#define CDB_INQUIRY_EVPD	ARCSAS_BIT(0)

#define	SUPPORTED_VPD_PAGES			0
#define	UNIT_SERIAL_NUMBER_VPD_PAGE		0x80
#define	DEVICE_IDENTIFICATION_VPD_PAGE		0x83
#define	EXTENDED_INQUIRY_DATA_VPD_PAGE		0x86
#define	MODE_PAGE_POLICY_VPD_PAGE		0x87
#define	ATA_INFORMATION_VPD_PAGE		0x89
#define	BLOCK_LIMITS_VPD_PAGE			0xB0
#define	BLOCK_DEV_CHARACTERISTICS_VPD_PAGE	0xB1
#define	LOGICAL_BLOCK_PROVISIONING_VPD_PAGE	0xB2

typedef struct _IDEREGS {
u_int8_t	bFeaturesReg;		// Used for specifying SMART "commands".
u_int8_t	bSectorCountReg;	// IDE sector count register
u_int8_t	bSectorNumberReg;	// IDE sector number register
u_int8_t	bCylLowReg;		// IDE low order cylinder value
u_int8_t	bCylHighReg;		// IDE high order cylinder value
u_int8_t	bDriveHeadReg;		// IDE drive/head register
u_int8_t	bCommandReg;		// Actual IDE command.
u_int8_t	bReserved;		// reserved for future use.  Must be zero.
} IDEREGS, *PIDEREGS, *LPIDEREGS;

#define	DISABLE_BLK_DESCRIPTORS		ARCSAS_BIT(3)
#define	MODE_SENSE_PAGE_CODE		0x3F
#define	MODE_PAGE_CODE			0x3F
#define	MODE_SENSE_PAGE_CONTROL		0xC0
#define	PC_CURRENT_VALUES		0
#define	PC_CHANGEABLE_VALUES		0x40
#define	PC_DEFAULT_VALUES		0x80
#define	PC_SAVED_VALUES			0xC0
#define	MODE_SELECT_PAGE_FORMAT		ARCSAS_BIT(4)
#define	READ_WRITE_ERROR_RECOVERY_MODE_PAGE	1
#define	CACHING_MODE_PAGE		8
#define	CONTROL_MODE_PAGE		0x0A
#define	INFORMATIONAL_EXCEPTIONS_CONTROL_MODE_PAGE	0x1C

#define	READ_CACHE_DISABLE		ARCSAS_BIT(0)
#define	WRITEBACK_CACHE_ENABLE		ARCSAS_BIT(2)
#define	DISABLE_READ_AHEAD		ARCSAS_BIT(5)
#define	ARCSAS_PCIR_MSI_CTRL		0x52

