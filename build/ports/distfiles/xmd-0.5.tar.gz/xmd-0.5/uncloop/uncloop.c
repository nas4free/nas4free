/*-
 * Copyright (C) 2015 Daisuke Aoyama <aoyama@peach.ne.jp>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <err.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/endian.h>

#include <lzma.h>
#include <zlib.h>

/* from g_uncompress.c */
#define GEOM_UZIP_MAJVER '2'
#define GEOM_ULZMA_MAJVER '3'
#define CLOOP_MAGIC_LEN 128
static char CLOOP_MAGIC_START[] = "#!/bin/sh\n";
struct cloop_header {
	char magic[CLOOP_MAGIC_LEN];
	uint32_t blksz;
	uint32_t nblocks;
};

#define TYPE_UZIP 2
#define TYPE_ULZMA 3

static void
usage(void)
{
	fprintf(stderr,
	    "usage: uncloop [-v] [<file>]\n");
	exit(1);
}

int
main(int argc, char **argv)
{
	struct cloop_header hdr;
	uint64_t *offsets;
	uint8_t *buffer, *tmpbuf;
	FILE *fp;
	uint32_t blksz, nblocks, tmpsize, compsize;
	size_t size;
	int verbose = 0;
	int ch, type, idx;

	while ((ch = getopt(argc, argv, "hv")) != -1) {
		switch (ch) {
		case 'v':
			verbose = 1;
			break;
		case 'h':
			usage();
		default:
			usage();
		}
	}

	argc -= optind;
	argv += optind;

	if (argc >= 1) {
		fp = fopen(argv[0], "rb");
		if (fp == NULL)
			err(1, "can't open: %s", argv[0]);
	} else
		fp = stdin;

	/* check cloop header */
	type = 0;
	size = fread(&hdr, 1, sizeof(hdr), fp);
	if (size != sizeof(hdr))
		errx(1, "can't read header");
	if (memcmp(hdr.magic, CLOOP_MAGIC_START,
	    sizeof (CLOOP_MAGIC_START) - 1) == 0) {
		if (hdr.magic[0x0b] == 'L' &&
		    hdr.magic[0x0c] >= GEOM_ULZMA_MAJVER) {
			/* GEOM_ULZMA */
			type = TYPE_ULZMA;
		} else if (hdr.magic[0x0b] == 'V' &&
		    hdr.magic[0x0c] >= GEOM_UZIP_MAJVER) {
			/* GEOM_UZIP */
			type = TYPE_UZIP;
		}
	}
	if (type == 0)
		errx(1, "unknown header type");

	/* prepare buffer and offset table */
	blksz = be32toh(hdr.blksz);
	nblocks = be32toh(hdr.nblocks);
	buffer = malloc(blksz);
	if (buffer == NULL)
		err(1, "can't allocate buffer");
	tmpsize = blksz * 2;
	tmpbuf = malloc(tmpsize);
	if (tmpbuf == NULL) {
		free(buffer);
		err(1, "can't allocate tmpbuf");
	}
	offsets = malloc(sizeof(uint64_t) * (nblocks + 1));
	if (offsets == NULL) {
		free(buffer);
		free(tmpbuf);
		err(1, "can't allocate offsets");
	}
	size = fread(offsets, 1, sizeof(uint64_t) * (nblocks + 1), fp);
	if (size != sizeof(uint64_t) * (nblocks + 1)) {
		printf("can't read offsets\n");
		goto errout;
	}
#if 0
	if (verbose)
		fprintf(stderr, "read %d offsets\n", nblocks);
#endif

	/* read compressed data */
	for (idx = 0; idx < nblocks; idx++) {
		/* read from cloop body */
		if (verbose)
			fprintf(stderr, "Reading %d/%d blocks, blksz=%d\r",
			    idx, nblocks - 1, blksz);
		compsize = be64toh(offsets[idx+1]) - be64toh(offsets[idx]);
		if (compsize > tmpsize) {
			printf("compsize > tmpsize\n");
			goto errout;
		}
		size = fread(tmpbuf, 1, compsize, fp);
		if (size != compsize) {
			printf("can't read block\n");
			goto errout;
		}
		/* decompress from tmpbuf to buffer */
		if (type == TYPE_ULZMA) {
			lzma_stream ls = LZMA_STREAM_INIT;
			lzma_ret rv;

			rv = lzma_auto_decoder(&ls,
			    lzma_easy_decoder_memusage(/* max level */9), 0);
			if (rv != LZMA_OK) {
				printf("lzma_auto_decoder error\n");
				goto errout;
			}
			ls.next_in = tmpbuf;
			ls.avail_in = compsize;
			ls.next_out = buffer;
			ls.avail_out = blksz;
			rv = lzma_code(&ls, LZMA_RUN);
			if (rv != LZMA_STREAM_END) {
				if (rv != LZMA_OK) {
					lzma_end(&ls);
					printf("lzma_code error\n");
					goto errout;
				}
			}
			rv = lzma_code(&ls, LZMA_FINISH);
			lzma_end(&ls);
			if (rv != LZMA_STREAM_END) {
				if (rv != LZMA_OK) {
					printf("lzma_code error\n");
					goto errout;
				}
			}
			if (ls.avail_out != 0 || ls.avail_in != 0) {
				printf("lzma_code error\n");
				goto errout;
			}
		} else if (type == TYPE_UZIP) {
			z_stream zs;
			int rv;

			memset(&zs, 0, sizeof(zs));
			rv = inflateInit2(&zs, MAX_WBITS);
			if (rv != Z_OK) {
				printf("inflateInit2 error\n");
				goto errout;
			}
			zs.next_in = tmpbuf;
			zs.avail_in = compsize;
			zs.next_out = buffer;
			zs.avail_out = blksz;
			rv = inflate(&zs, Z_FINISH);
			inflateEnd(&zs);
			if (rv != Z_STREAM_END) {
				printf("inflate error\n");
				goto errout;
			}
		}
		/* write to stdout */
		size = fwrite(buffer, 1, blksz, stdout);
		if (size != blksz) {
			printf("can't write block: %d\n", idx);
			goto errout;
		}
	}
	if (verbose)
		fprintf(stderr, "\n");

	free(offsets);
	free(buffer);
	free(tmpbuf);
	if (fp != stdin)
		fclose(fp);
	return (0);

errout:
	free(offsets);
	free(buffer);
	free(tmpbuf);
	if (fp != stdin)
		fclose(fp);
	return (1);
}
