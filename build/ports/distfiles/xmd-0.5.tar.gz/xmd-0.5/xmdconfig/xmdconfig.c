/*-
 * Copyright (C) 2014-2015 Daisuke Aoyama <aoyama@peach.ne.jp>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <sys/ioctl.h>

#include <err.h>
#include <fcntl.h>
#include <inttypes.h>
#include <libutil.h>
#include <paths.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/endian.h>

#include "xmd.h"

static enum {UNSET, ATTACH, DETACH, MODIFY, IMAGE, LIST} action = UNSET;
static struct xmd_ioctl xmdio;

/* from g_uncompress.c */
#define GEOM_UZIP_MAJVER '2'
#define GEOM_ULZMA_MAJVER '3'
#define CLOOP_MAGIC_LEN 128
static char CLOOP_MAGIC_START[] = "#!/bin/sh\n";
struct cloop_header {
	char magic[CLOOP_MAGIC_LEN];
	uint32_t blksz;
	uint32_t nblocks;
};

#define TYPE_UZIP 2
#define TYPE_ULZMA 3

static void
usage(void)
{
	fprintf(stderr,
	    "usage: xmdconfig -a -s size [-b blocksize] [-t comptype] "
	    "[-c complevel] [-u unit]\n"
	    "       xmdconfig -d -u unit\n"
	    "       xmdconfig -m -u unit [-t comptype] [-c complevel]\n"
	    "       xmdconfig -i -u unit <file>\n"
	    "       xmdconfig -l [-v] [-u unit]\n");
	fprintf(stderr, "\t\tcomptype = {none, lz4, zlib, lzma}\n");
	fprintf(stderr, "\t\tsize = %%dm (MB) or %%dg (GB)\n");
	fprintf(stderr, "\t\tblocksize = %%d or %%dk (KB)\n");
	exit(1);
}

int
main(int argc, char **argv)
{
	struct cloop_header hdr;
	uint64_t *offsets;
	uint8_t *buffer;
	FILE *fp;
	char *p;
	char *imagefile;
	uint32_t blksz, nblocks, bufsize, compsize;
	size_t size;
	int type, idx;
	int verbose = 0;
	int unit = -1;
	int ch, fd, rv;

	memset(&xmdio, 0, sizeof (xmdio));

	/* default values */
	xmdio.xmd_unit = -1;
	xmdio.xmd_size = 0;
	xmdio.xmd_seglen = 0;
	xmdio.xmd_comptype = -1;
	xmdio.xmd_complevel = -1;

	/* used for image r/w */
	fp = NULL;
	buffer = NULL;
	offsets = NULL;
	imagefile = NULL;
	bufsize = 0;
	blksz = nblocks = 0;
	type = 0;

	if (argc == 1)
		usage();

	while ((ch = getopt(argc, argv, "ab:c:dilms:t:u:v")) != -1) {
		switch (ch) {
		case 'a':
			if (action != UNSET)
				errx(1, "only one action can be specified");
			action = ATTACH;
			break;
		case 'd':
			if (action != UNSET)
				errx(1, "only one action can be specified");
			action = DETACH;
			break;
		case 'm':
			if (action != UNSET)
				errx(1, "only one action can be specified");
			action = MODIFY;
			break;
		case 'i':
			if (action != UNSET)
				errx(1, "only one action can be specified");
			action = IMAGE;
			break;
		case 'l':
			if (action != UNSET)
				errx(1, "only one action can be specified");
			action = LIST;
			break;
		case 's':
			xmdio.xmd_size = (uint64_t)strtoumax(optarg, &p, 0);
			if (p == optarg || xmdio.xmd_size == 0)
				errx(1, "invalid size");
			if (p == NULL || *p == '\0')
				xmdio.xmd_size <<= 20;
			else if (*p == 'm' || *p == 'M')
				xmdio.xmd_size <<= 20;
			else if (*p == 'g' || *p == 'G')
				xmdio.xmd_size <<= 30;
			else if (*p == 't' || *p == 'T')
				xmdio.xmd_size <<= 40;
			else
				errx(1, "unknown size suffix");
			break;
		case 'u':
			if (!strncmp(optarg, _PATH_DEV, sizeof(_PATH_DEV) - 1))
				optarg += sizeof(_PATH_DEV) - 1;
			if (!strncmp(optarg, XMD_NAME, sizeof(XMD_NAME) - 1))
				optarg += sizeof(XMD_NAME) - 1;
			unit = xmdio.xmd_unit = (int)strtoul(optarg, &p, 0);
			if (p == optarg || p == NULL || *p != '\0')
				errx(1, "invalid unit number");
			break;
		case 'b':
			xmdio.xmd_seglen = (uint64_t)strtoumax(optarg, &p, 0);
			if (p == optarg || xmdio.xmd_seglen == 0)
				errx(1, "invalid blocksize");
			if (p == NULL || *p == '\0')
				; /* no suffix */
			else if (*p == 'k' || *p == 'K')
				xmdio.xmd_seglen <<= 10;
			else if (*p == 'm' || *p == 'M')
				xmdio.xmd_seglen <<= 20;
			else
				errx(1, "unknown size suffix");
			if ((xmdio.xmd_seglen % 1024) != 0)
				errx(1, "invalid blocksize");
			break;
		case 't':
			if (!strcmp(optarg, "none"))
				xmdio.xmd_comptype = XMD_TYPE_NONE;
			else if (!strcmp(optarg, "lz4"))
				xmdio.xmd_comptype = XMD_TYPE_LZ4;
			else if (!strcmp(optarg, "zlib"))
				xmdio.xmd_comptype = XMD_TYPE_ZLIB;
			else if (!strcmp(optarg, "lzma"))
				xmdio.xmd_comptype = XMD_TYPE_LZMA;
			else
				errx(1, "unknown type: %s", optarg);
			break;
		case 'c':
			xmdio.xmd_complevel = (int)strtoul(optarg, &p, 0);
			if (p == optarg || p == NULL || *p != '\0')
				errx(1, "invalid compression level");
			if (xmdio.xmd_complevel < 1 || xmdio.xmd_complevel > 9)
				errx(1, "compression level is from 1 to 9");
			break;
		case 'v':
			verbose = 1;
			break;
		default:
			usage();
		}
	}

	argc -= optind;
	argv += optind;

	if (action == UNSET)
		action = ATTACH;

	if (action == ATTACH) {
		if (xmdio.xmd_size == 0)
			errx(1, "must specify non zero size");
		if (verbose != 0)
			errx(1, "-v can only be used with -l");
	} else {
		if (xmdio.xmd_size != 0)
			errx(1, "-s can only be used with -a");
		if (xmdio.xmd_seglen != 0)
			errx(1, "-b can only be used with -a");
		if (action != MODIFY && action != IMAGE &&
		    (xmdio.xmd_comptype != -1 || xmdio.xmd_complevel != -1))
			errx(1, "-t/-c can only be used with -a/-m");
		if (action == DETACH || action == MODIFY || action == IMAGE) {
			if (xmdio.xmd_unit == -1)
				errx(1, "-d/-m requires -u");
		}
		if (action != IMAGE && action != LIST && verbose != 0)
			errx(1, "-v can only be used with -l");
	}
	if (action == IMAGE) {
		if (argc < 1)
			errx(1, "-i requires image file");
		imagefile = argv[0];
		fp = fopen(imagefile, "rb");
		if (fp == NULL)
			err(1, "open error: %s", imagefile);

		/* check cloop header */
		type = 0;
		size = fread(&hdr, 1, sizeof(hdr), fp);
		if (size != sizeof(hdr))
			errx(1, "can't read header");
		if (memcmp(hdr.magic, CLOOP_MAGIC_START,
			sizeof (CLOOP_MAGIC_START) - 1) == 0) {
			if (hdr.magic[0x0b] == 'L' &&
			    hdr.magic[0x0c] >= GEOM_ULZMA_MAJVER) {
				/* GEOM_ULZMA */
				type = TYPE_ULZMA;
			} else if (hdr.magic[0x0b] == 'V' &&
			    hdr.magic[0x0c] >= GEOM_UZIP_MAJVER) {
				/* GEOM_UZIP */
				type = TYPE_UZIP;
			}
		}
		if (type == 0)
			errx(1, "unknown header type");

		/* prepare buffer and offset table */
		blksz = be32toh(hdr.blksz);
		nblocks = be32toh(hdr.nblocks);
		bufsize = blksz * 2;
		buffer = malloc(bufsize);
		if (buffer == NULL)
			err(1, "can't allocate buffer");
		offsets = malloc(sizeof(uint64_t) * (nblocks + 1));
		if (offsets == NULL) {
			free(buffer);
			err(1, "can't allocate offsets");
		}
		size = fread(offsets, 1, sizeof(uint64_t) * (nblocks + 1), fp);
		if (size != sizeof(uint64_t) * (nblocks + 1)) {
			free(offsets);
			free(buffer);
			errx(1, "can't read offsets");
		}
	}

	xmdio.xmd_version = XMDIOVERSION;

	if (!kld_isloaded("g_xmd") && kld_load("geom_xmd") == -1)
		err(1, "failed to load geom_xmd module");

	fd = open(_PATH_DEV XMDCTL_NAME, O_RDWR, 0);
	if (fd < 0)
		err(1, "open(%s%s)", _PATH_DEV, XMDCTL_NAME);

	if (action == ATTACH) {
		rv = ioctl(fd, XMDCTL_ATTACH, &xmdio);
		if (rv < 0)
			err(1, "ioctl(%s%s)", _PATH_DEV, XMDCTL_NAME);
		if (unit == -1)
			printf("%s%d\n", XMD_NAME, xmdio.xmd_unit);
	} else if (action == DETACH) {
		rv = ioctl(fd, XMDCTL_DETACH, &xmdio);
		if (rv < 0)
			err(1, "ioctl(%s%s)", _PATH_DEV, XMDCTL_NAME);
	} else if (action == MODIFY) {
		rv = ioctl(fd, XMDCTL_MODIFY, &xmdio);
		if (rv < 0)
			err(1, "ioctl(%s%s)", _PATH_DEV, XMDCTL_NAME);
	} else if (action == IMAGE) {
		int progress = 0, oldvalue = -1;
		rv = ioctl(fd, XMDCTL_QUERY, &xmdio);
		if (rv < 0)
			err(1, "ioctl(%s%s)", _PATH_DEV, XMDCTL_NAME);
#if 0
		if (verbose)
			printf("xmd seglen = %d\n", xmdio.xmd_seglen);
#endif
		if (blksz != xmdio.xmd_seglen)
			err(1, "block length mismatch");
		if (type == TYPE_UZIP)
			xmdio.xmd_comptype = XMD_TYPE_ZLIB;
		else if (type == TYPE_ULZMA)
			xmdio.xmd_comptype = XMD_TYPE_LZMA;
		else
			xmdio.xmd_comptype = XMD_TYPE_NONE;
		xmdio.xmd_data = buffer;
		/* read compressed data */
		if (verbose) {
			//printf("Load image: %s\n", imagefile);
			printf("Writing %d blocks, blksz=%d from %s\n",
			    nblocks - 1, blksz, imagefile);
		}
		for (idx = 0; idx < nblocks; idx++) {
			/* read from cloop body */
			if (verbose) {
				progress = (100ULL * idx) / (nblocks - 1);
				if (progress != oldvalue) {
					fprintf(stderr, "%3d%% done\r", progress);
					oldvalue = progress;
				}
			}
			compsize = be64toh(offsets[idx+1]) -
			    be64toh(offsets[idx]);
			if (compsize > bufsize) {
				if (verbose)
					fprintf(stderr, "\n");
				printf("compsize > bufszie\n");
				break;
			}
			size = fread(buffer, 1, compsize, fp);
			if (size != compsize) {
				if (verbose)
					fprintf(stderr, "\n");
				printf("can't read block\n");
				break;
			}
			/* upload segment */
			xmdio.xmd_address = idx;
			xmdio.xmd_length = compsize;
			rv = ioctl(fd, XMDCTL_WRSEG, &xmdio);
			if (rv < 0)
				err(1, "ioctl(%s%s)", _PATH_DEV, XMDCTL_NAME);
		}
		if (verbose)
			fprintf(stderr, "\n");
	} else if (action == LIST) {
		uint64_t ratio, ratio2;
		xmdio.xmd_unit = unit - 1;
		while ((rv = ioctl(fd, XMDCTL_QUERYNEXT, &xmdio)) == 0) {
			if (verbose) {
				/* name */
				printf("%s%d", XMD_NAME, xmdio.xmd_unit);
				printf("\t");

				/* type */
				if (xmdio.xmd_preloaded)
					printf("preload");
				else
					printf("swap");
				printf("\t");

				/* size */
				printf("%6"PRIu64"M", (xmdio.xmd_size >> 20));
				printf("\t");

				/* compression type */
				if (xmdio.xmd_comptype & XMD_TYPE_PRELD) {
					if (xmdio.xmd_comptype == XMD_TYPE_PRERAW)
						printf("none");
					else if (xmdio.xmd_comptype == XMD_TYPE_PRELZ4)
						printf("lz4");
					else if (xmdio.xmd_comptype == XMD_TYPE_PREZS)
						printf("zlib");
					else if (xmdio.xmd_comptype == XMD_TYPE_PRELS)
						printf("lzma");
					else
						printf("unknown");
				} else {
					if (xmdio.xmd_comptype == XMD_TYPE_NONE)
						printf("none");
					else if (xmdio.xmd_comptype == XMD_TYPE_LZ4)
						printf("lz4");
					else if (xmdio.xmd_comptype == XMD_TYPE_ZLIB)
						printf("zlib");
					else if (xmdio.xmd_comptype == XMD_TYPE_LZMA)
						printf("lzma");
					else
						printf("unknown");
				}
				printf("\t");

				/* compression level */
				if (xmdio.xmd_complevel == 0)
					printf("n/a");
				else if (xmdio.xmd_complevel >= 1 &&
				    xmdio.xmd_complevel <= 9)
					printf("%d", xmdio.xmd_complevel);
				else
					printf("unknown");
				printf("\t");

				/* memory usage */
				ratio = ratio2 = 0;
				if (xmdio.xmd_buftotal) {
					ratio = 100 * xmdio.xmd_bufsize;
					ratio /= xmdio.xmd_buftotal;
				}
				if (xmdio.xmd_bufsize) {
					ratio2 = 100 * xmdio.xmd_bufused;
					ratio2 /= xmdio.xmd_bufsize;
				}
				printf("%3"PRIu64"%% (%"PRIu64"/%"PRIu64"/%"PRIu64")",
				    ratio, xmdio.xmd_bufused, xmdio.xmd_bufsize,
				    xmdio.xmd_buftotal);

				printf("\n");
			} else
				printf("%s%d ", XMD_NAME, xmdio.xmd_unit);

			/* specified unit only? */
			if (unit != -1)
				break;
		}
		if (!verbose)
			printf("\n");
	}
	else
		usage();

	if (action == IMAGE) {
		free(offsets);
		free(buffer);
		fclose(fp);
	}
	close(fd);
	return (0);
}
