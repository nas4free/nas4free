/*-
 * Copyright (C) 2014-2015 Daisuke Aoyama <aoyama@peach.ne.jp>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#ifndef _XMD_H_
#define _XMD_H_

#include <sys/cdefs.h>
#include <sys/types.h>
#include <sys/stdint.h>

struct xmd_ioctl {
	int		xmd_version;	/* structure layout version */
	int		xmd_unit;	/* unit number */
	uint64_t	xmd_size;	/* disk size in bytes */
	uint64_t	xmd_blockcnt;	/* LBA block counts */
	uint32_t	xmd_blocklen;	/* LBA block size (usually 512B) */
	uint64_t	xmd_buftotal;	/* uncompress size */
	uint64_t	xmd_bufsize;	/* allocated memory/page */
	uint64_t	xmd_bufused;	/* used size (usually compressed) */
	uint32_t	xmd_nseg;	/* # of segments */
	uint32_t	xmd_seglen;	/* segment length */
	int		xmd_preloaded;	/* whether preloaded image */
	int		xmd_complevel;	/* compression level */
	int		xmd_comptype;	/* compression type */
	int		xmd_options;	/* option flag */
	int		xmd_fwheads;	/* firmware heads (unused) */
	int		xmd_fwsectors;	/* firmware sectors (unused) */

	uint64_t	xmd_address;	/* LBA or segment index */
	uint32_t	xmd_length;	/* data length */
	uint8_t		*xmd_data;	/* data pointer */
};

#define XMD_NAME	"xmd"
#define XMDCTL_NAME	"xmdctl"
#define XMDIOVERSION	0

#define XMDCTL_ATTACH	_IOWR('x', 0, struct xmd_ioctl)
#define XMDCTL_DETACH	_IOWR('x', 1, struct xmd_ioctl)
#define XMDCTL_MODIFY	_IOWR('x', 2, struct xmd_ioctl)
#define XMDCTL_QUERY	_IOWR('x', 3, struct xmd_ioctl)
#define XMDCTL_QUERYNEXT _IOWR('x', 4, struct xmd_ioctl)
#define XMDCTL_RDSEG	_IOWR('x', 5, struct xmd_ioctl)
#define XMDCTL_WRSEG	_IOWR('x', 6, struct xmd_ioctl)

#define XMD_TYPE_ERR	0xffU
#define XMD_TYPE_NONE	0x00U
#define XMD_TYPE_FILL	0x01U
#define XMD_TYPE_LZ4	0x02U
#define XMD_TYPE_ZLIB	0x04U
#define XMD_TYPE_LZMA	0x08U

#define XMD_TYPE_PRELD	0x80U
#define XMD_TYPE_PRERAW	(XMD_TYPE_PRELD | 0)
#define XMD_TYPE_PRELZ4	(XMD_TYPE_PRELD | XMD_TYPE_LZ4)
#define XMD_TYPE_PREZS	(XMD_TYPE_PRELD | XMD_TYPE_ZLIB)
#define XMD_TYPE_PRELS	(XMD_TYPE_PRELD | XMD_TYPE_LZMA)

#endif /* _XMD_H_ */
