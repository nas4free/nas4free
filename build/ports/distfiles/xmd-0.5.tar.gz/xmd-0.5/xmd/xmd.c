/*-
 * Copyright (C) 2014-2015 Daisuke Aoyama <aoyama@peach.ne.jp>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include <sys/cdefs.h>
__FBSDID("$FreeBSD$");

#include "opt_geom.h"
#include "opt_xmd.h"

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/bio.h>
#include <sys/conf.h>
#include <sys/condvar.h>
#include <sys/endian.h>
#include <sys/kernel.h>
#include <sys/kthread.h>
#include <sys/libkern.h>
#include <sys/linker.h>
#include <sys/limits.h>
#include <sys/lock.h>
#include <sys/malloc.h>
#include <sys/mutex.h>
#include <sys/proc.h>
#include <sys/queue.h>
#include <sys/rwlock.h>
#include <sys/sched.h>
#include <sys/sx.h>
#include <sys/uio.h>
#include <sys/sf_buf.h>

#include <vm/vm.h>
#include <vm/vm_param.h>
#include <vm/vm_object.h>
#include <vm/vm_page.h>
#include <vm/vm_pager.h>
#include <vm/swap_pager.h>

#include <geom/geom.h>
#if __FreeBSD_version >= 1100071
#include <sys/zlib.h>
#else
#include <net/zlib.h>
#endif

#include "lz4.h"
#include "lz4hc.h"
#ifdef USE_LZMA
#include "lzma.h"
#endif

#include "xmd.h"

#ifdef DEBUG
#define DPRINTF(fmt, ...) do {			\
	printf("%s:%u: ", __func__, __LINE__);	\
	printf(fmt, ##__VA_ARGS__);		\
} while (0)
#else
#define DPRINTF(fmt, ...)
#endif

#define XMD_VERSION "0.5"
#define XMD_AUTHOR "by NAS4Free Project"

#ifndef XMD_SIZE
#define XMD_SIZE	64		/* MiB */
#endif
#ifndef XMD_ROOT_SIZE
#define XMD_ROOT_SIZE	64		/* MiB */
#endif
#define XMD_MINSIZE	1		/* 1MB */
#define XMD_MINROOTSIZE	8		/* 8MB */
#define XMD_MAXSIZE	262144		/*
					 * 256GB=262144MB/128GB=131027MB
					 * XXX actual limit bytes is
					 * SEGLEN * UINT32_MAX
					 */
#ifndef XMD_COMPLEVEL
#define XMD_COMPLEVEL	6		/* compression level */
#endif
#ifndef XMD_COMPTYPE
#define XMD_COMPTYPE	XMD_TYPE_ZLIB	/* compression type */
#endif

#define XMD_BLOCKLEN	512		/* 512B/sector */

#if 0
#define XMD_NBLOCKS	256		/* 128KiB/seg */
#define XMD_NBLOCKS	128		/* 64KiB/seg */
#endif
#ifndef XMD_NBLOCKS
#define XMD_NBLOCKS	64		/* 32KiB/seg (newfs default size) */
#endif
#define XMD_MINNBLOCKS	8		/* 4KiB/seg */
#define XMD_MAXNBLOCKS	65536		/* limit to 32MiB/seg */

#define XMD_STOP	BIO_CMD0	/* stop worker kthread */
#define XMD_STATUS	BIO_CMD1	/* report usage/etc */
#define XMD_SEGIO	BIO_CMD2	/* direct segment I/O */

#define XMD_1MB		(1024ULL * 1024ULL)

static int verbose = 0;
static int xmd_size = XMD_SIZE;
TUNABLE_INT("hw.xmd.size", &xmd_size);
static int xmd_rootsize = XMD_ROOT_SIZE;
TUNABLE_INT("hw.xmd.rootsize", &xmd_rootsize);
static int xmd_complevel = XMD_COMPLEVEL;
TUNABLE_INT("hw.xmd.complevel", &xmd_complevel);
static int xmd_comptype = XMD_COMPTYPE;
TUNABLE_INT("hw.xmd.comptype", &xmd_comptype);
static int xmd_nblocks = XMD_NBLOCKS;
TUNABLE_INT("hw.xmd.nblocks", &xmd_nblocks);
static int xmd_swap_reserve = 0;
TUNABLE_INT("hw.xmd.swap_reserve", &xmd_swap_reserve);

typedef struct xmd_memory {
	LIST_ENTRY(xmd_memory) list;
	void		*addr;
	uint32_t	size;
} *xmd_memory_t;

struct xmd_segment_header {
	uint32_t	seg;
	vm_object_t	object;
	uint8_t		*addr;
#ifdef USE_CRC32
	uint32_t	crc32;
	uint32_t	zcrc32;
#ifdef DEBUG
	uint8_t		*exp;
#endif
#endif
	uint32_t	bufsize;
	uint32_t	bufused;
	uint8_t		type;
	uint8_t		fill;
	uint16_t	dummy;
} __packed;

struct xmd_softc {
	int		unit;
	LIST_ENTRY(xmd_softc) list;
	struct cv	cv_stop;
	struct bio_queue_head bio_queue;
	struct mtx	queue_mtx;
	struct proc	*procp;
	struct g_geom	*gp;
	struct g_provider *pp;
	struct thread	*td;
	//struct ucred	*cred;

	uint64_t	size;
	uint64_t	blockcnt;
	uint32_t	blocklen;

	int		preloaded;
	int		complevel;
	int		comptype;
	int		options;

	uint32_t	nseg;
	uint32_t	seglen;
	uint32_t	segshift;
	uint32_t	segmask;

	uint32_t	tmpsize;
	uint8_t		*tmpbuf;
	uint8_t		*tmpbuf2;

	void		*lz4_ctx;

	struct xmd_segment_header **index;
};

static char *xmd_ident = "X Memory Disk v" XMD_VERSION;
static struct bio bio_stopcmd;
static struct cdev *xmd_cdev = 0;
static struct sx xmd_sx;
static struct unrhdr *xmd_uh;
static LIST_HEAD(, xmd_softc) xmd_softc_list =
    LIST_HEAD_INITIALIZER(xmd_softc_list);

static struct rwlock xmd_free_rw;
static LIST_HEAD(, xmd_memory) xmd_free_list =
    LIST_HEAD_INITIALIZER(xmd_free_list);

static MALLOC_DEFINE(M_XMD,		"xmd_disk",	"X Memory Disk");
static MALLOC_DEFINE(M_XMD_INDEX,	"xmd_index",	"X Memory Disk Index");
static MALLOC_DEFINE(M_XMD_HEADER,	"xmd_headers",	"X Memory Disk Headers");
static MALLOC_DEFINE(M_XMD_BLOCK,	"xmd_blocks",	"X Memory Disk Blocks");
static MALLOC_DEFINE(M_XMD_LZ4,		"xmd_lz4",	"X Memory Disk LZ4/LZ4HC");
static MALLOC_DEFINE(M_XMD_ZLIB,	"xmd_zlib",	"X Memory Disk ZLIB");
static MALLOC_DEFINE(M_XMD_LZMA,	"xmd_lzma",	"X Memory Disk LZMA");

static void g_xmd_start(struct bio *bp);
static int g_xmd_access(struct g_provider *pp, int r, int w, int e);
static void g_xmd_dumpconf(struct sbuf *sb, const char *indent,
    struct g_geom *gp, struct g_consumer *cp __unused, struct g_provider *pp);
static void g_xmd_init(struct g_class *mp);
static void g_xmd_fini(struct g_class *mp);
static int g_xmd_destroy(struct gctl_req *req, struct g_class *mp,
    struct g_geom *gp);
static d_ioctl_t xmdctl_ioctl;

static struct cdevsw xmdctl_cdevsw = {
	.d_version = D_VERSION,
	.d_ioctl = xmdctl_ioctl,
	.d_name = "xmd",
};

struct g_class g_xmd_class = {
	.name = "XMD",
	.version = G_VERSION,
	.init = g_xmd_init,
	.fini = g_xmd_fini,
	.start = g_xmd_start,
	.access = g_xmd_access,
	.dumpconf = g_xmd_dumpconf,
	.destroy_geom = g_xmd_destroy,
};

DECLARE_GEOM_CLASS(g_xmd_class, g_xmd);
MODULE_DEPEND(g_xmd, zlib, 1, 1, 1);

#if __FreeBSD_version >= 1000000
#define VMOBJ_LOCK(obj)		VM_OBJECT_WLOCK(obj)
#define VMOBJ_UNLOCK(obj)	VM_OBJECT_WUNLOCK(obj)
#else /* __FreeBSD_version < 1000000 */
#define VMOBJ_LOCK(obj)		VM_OBJECT_LOCK(obj)
#define VMOBJ_UNLOCK(obj)	VM_OBJECT_UNLOCK(obj)
#define vm_page_xunbusy(m) do {			\
	/* 9.x have no xunbusy */		\
	vm_page_wakeup(m);			\
} while (0)
#endif /* __FreeBSD_version */

/* from g_uncompress.c */
#define GEOM_UZIP_MAJVER '2'
#define GEOM_ULZMA_MAJVER '3'
#define CLOOP_MAGIC_LEN 128
static char CLOOP_MAGIC_START[] = "#!/bin/sh\n";
struct cloop_header {
	char magic[CLOOP_MAGIC_LEN];
	uint32_t blksz;
	uint32_t nblocks;
};

static int
xmd_lz4_decompress(uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf,
    uint32_t out_len)
{
	int rv;

	/* decompress */
	rv = LZ4_decompress_safe((const char *)in_buf, (char *)out_buf,
	    in_len, out_len);
	/* decompressed size or negative value=error */
	DPRINTF("total=%d/%u\n", rv, in_len);
	return (rv);
}

static int
xmd_lz4_compress(struct xmd_softc *sc, int complevel, uint8_t *in_buf,
    uint32_t in_len, uint8_t *out_buf, uint32_t out_len)
{
	int lz4_ctx_size;
	int lz4_level;
	int rv;

	/* compress */
	lz4_level = 0;
	if (complevel > 3) {
		/* using LZ4HC */
		lz4_ctx_size = LZ4_sizeofStateHC();
		/* reset lz4_ctx */
		memset(sc->lz4_ctx, 0, lz4_ctx_size);

#ifndef LZ4HC_DEFAULT_COMPRESSIONLEVEL
#define LZ4HC_DEFAULT_COMPRESSIONLEVEL 8
#endif
		/* 4->4, 5->6, 6->8, 7->10, 8->12, 9->14 */
		lz4_level = LZ4HC_DEFAULT_COMPRESSIONLEVEL +
		    (complevel - 6) * 2;
#if 0
		/* 4->2, 5->5, 6->8, 7->11, 8->14, 9->17 */
		lz4_level = LZ4HC_DEFAULT_COMPRESSIONLEVEL +
		    (complevel - 6) * 3;
#endif
		if (lz4_level > 16)
			lz4_level = 16;

		/* compress in_buf */
		rv = LZ4_compressHC2_limitedOutput_withStateHC(sc->lz4_ctx,
		    (const char *)in_buf, (char *)out_buf, in_len, out_len,
		    lz4_level);
	} else {
		/* using LZ4 */
		lz4_ctx_size = LZ4_sizeofState();
		/* reset lz4_ctx */
		memset(sc->lz4_ctx, 0, lz4_ctx_size);
		/* compress in_buf */
		rv = LZ4_compress_limitedOutput_withState (sc->lz4_ctx,
		    (const char *)in_buf, (char *)out_buf, in_len, out_len);
	}
	/* compressed size or 0=limited */
	DPRINTF("total=%d/%u\n", rv, in_len);
	return (rv);
}

static void *
z_alloc(void *opaque, uInt items, uInt size)
{

	return (malloc(items * size, M_XMD_ZLIB, M_WAITOK));
}

static void
z_free(void *opaque, void *ptr)
{

	free(ptr, M_XMD_ZLIB);
}

static int
xmd_inflate(z_stream *zs, uint8_t *in_buf, uint32_t in_len, uint8_t *out_buf,
    uint32_t out_len)
{
	int rv;

	/* decompress */
	zs->zalloc = z_alloc;
	zs->zfree = z_free;
	zs->opaque = 0;
	rv = inflateInit2(zs, MAX_WBITS);
	if (rv != Z_OK) {
		DPRINTF("inflateInit2 error\n");
		return (Z_STREAM_ERROR);
	}

	zs->next_in = in_buf;
	zs->avail_in = in_len;
	zs->next_out = out_buf;
	zs->avail_out = out_len;
	rv = inflate(zs, Z_FINISH);
	inflateEnd(zs);
	if (rv != Z_STREAM_END) {
		DPRINTF("inflate error\n");
		return (Z_STREAM_ERROR);
	}
	return (Z_STREAM_END);
}

static int
xmd_deflate(z_stream *zs, int complevel, uint8_t *in_buf, uint32_t in_len,
    uint8_t *out_buf, uint32_t out_len)
{
	int rv;

	/* compress */
	zs->zalloc = z_alloc;
	zs->zfree = z_free;
	zs->opaque = 0;
	rv = deflateInit2(zs, complevel, Z_DEFLATED, MAX_WBITS,
	    MAX_MEM_LEVEL, Z_DEFAULT_STRATEGY);
	if (rv != Z_OK) {
		DPRINTF("deflateInit2 error\n");
		return (Z_STREAM_ERROR);
	}

	zs->next_in = in_buf;
	zs->avail_in = in_len;
	zs->next_out = out_buf;
	zs->avail_out = out_len;
	rv = deflate(zs, Z_FINISH);
	deflateEnd(zs);
	if (rv != Z_STREAM_END) {
		if (zs->total_out != out_len) {
			DPRINTF("deflate error\n");
			DPRINTF("total=%lu/max=%d/rv=%d\n", zs->total_out,
			    out_len, rv);
			return (Z_STREAM_ERROR);
		}
		/* buffer full */
		return (Z_OK);
	}
	return (Z_STREAM_END);
}

#ifdef USE_LZMA
static void *
lz_alloc(void *opaque, size_t items, size_t size)
{

	return (malloc(items * size, M_XMD_LZMA, M_WAITOK));
}

static void
lz_free(void *opaque, void *ptr)
{

	free(ptr, M_XMD_LZMA);
}

static lzma_allocator xmd_lzma_allocator = {
	.alloc = lz_alloc,
	.free = lz_free,
	.opaque = 0,
};

static int
xmd_lzma_decode(lzma_stream *ls, uint8_t *in_buf, uint32_t in_len,
    uint8_t *out_buf, uint32_t out_len)
{
	lzma_stream lstmp = LZMA_STREAM_INIT;
	lzma_ret rv;

	/* decompress */
	*ls = lstmp;
	ls->allocator = &xmd_lzma_allocator;
	rv = lzma_auto_decoder(ls,
	    lzma_easy_decoder_memusage(/* max level */9), 0);
	if (rv != LZMA_OK) {
		DPRINTF("lzma_auto_decoder error\n");
		return (rv);
	}

	ls->next_in = in_buf;
	ls->avail_in = in_len;
	ls->next_out = out_buf;
	ls->avail_out = out_len;
	rv = lzma_code(ls, LZMA_RUN);
	if (rv != LZMA_STREAM_END) {
		if (rv != LZMA_OK) {
			DPRINTF("lzma_code error\n");
			lzma_end(ls);
			return (rv);
		}
		DPRINTF("lzma_code OK\n");
	}
	rv = lzma_code(ls, LZMA_FINISH);
	lzma_end(ls);
	if (rv != LZMA_STREAM_END) {
		if (rv != LZMA_OK) {
			DPRINTF("lzma_code error\n");
			return (rv);
		}
		DPRINTF("lzma_code OK\n");
	}
	if (ls->avail_out != 0 || ls->avail_in != 0) {
		DPRINTF("lzma_code error\n");
		DPRINTF("total=%zu/%u/rv=%d\n", out_len - ls->avail_out,
		    out_len, rv);
		return (rv);
	}
	DPRINTF("total=%zu/%u/rv=%d\n", out_len - ls->avail_out, out_len, rv);
	return (LZMA_STREAM_END);
}

static int
xmd_lzma_encode(lzma_stream *ls, int complevel, uint8_t *in_buf,
    uint32_t in_len, uint8_t *out_buf, uint32_t out_len)
{
	lzma_stream lstmp = LZMA_STREAM_INIT;
	lzma_ret rv;

	/* compress */
	*ls = lstmp;
	ls->allocator = &xmd_lzma_allocator;
	rv = lzma_easy_encoder(ls, complevel, LZMA_CHECK_CRC32);
	if (rv != LZMA_OK) {
		DPRINTF("lzma_easy_encoder error %d\n", rv);
		return (rv);
	}

	ls->next_in = in_buf;
	ls->avail_in = in_len;
	ls->next_out = out_buf;
	ls->avail_out = out_len;

	rv = lzma_code(ls, LZMA_RUN);
	if (rv != LZMA_STREAM_END) {
		if (rv != LZMA_OK) {
			DPRINTF("lzma_code error\n");
			lzma_end(ls);
			return (rv);
		}
	}
	rv = lzma_code(ls, LZMA_FINISH);
	lzma_end(ls);
	if (rv != LZMA_STREAM_END) {
		if (rv != LZMA_OK || ls->avail_out != 0) {
			DPRINTF("lzma_code error\n");
			return (rv);
		}
		/* size over */
		return (LZMA_OK);
	}
	DPRINTF("total=%zu/%u/rv=%d\n", out_len - ls->avail_out, out_len, rv);
	return (LZMA_STREAM_END);
}
#endif /* USE_LZMA */

static int
xmd_get_filled_data(uint8_t *buf, int len)
{
	uint8_t ch;
	int i;

	if (buf == NULL || len < 1)
		return (-1);

	/* return a character(0..255) if all filled it */
	ch = buf[0];
	for (i = 1; i < len; i++) {
		if (ch != buf[i])
			break;
	}
	if (i == len)
		return (ch);

	/* not filled */
	return (-1);
}

static int
xmd_create_preload_memory(uint8_t *addr, uint32_t size)
{
	xmd_memory_t mem;

	if (addr == NULL || size == 0)
		return (-1);

	mem = malloc(sizeof(*mem), M_XMD, M_WAITOK | M_ZERO);
	if (mem == NULL) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("alloc error\n");
		return (-1);
	}
	mem->addr = addr;
	mem->size = size;

	rw_wlock(&xmd_free_rw);
	LIST_INSERT_HEAD(&xmd_free_list, mem, list);
	rw_wunlock(&xmd_free_rw);

	return (0);
}

static int
xmd_alloc_preload_memory(uint8_t **addr, uint32_t *size)
{
	xmd_memory_t mem;
	uint32_t tmpsize;

	if (addr == NULL || size == NULL)
		return (-1);

	tmpsize = *size;
	if (tmpsize < PAGE_SIZE)
		tmpsize = PAGE_SIZE;

	rw_rlock(&xmd_free_rw);
	LIST_FOREACH(mem, &xmd_free_list, list) {
		if (mem->size >= tmpsize)
			break;
	}
	if (mem == NULL) {
		rw_runlock(&xmd_free_rw);
		return (-1);
	}
	if (rw_try_upgrade(&xmd_free_rw) == 0) {
		rw_runlock(&xmd_free_rw);
		rw_wlock(&xmd_free_rw);
	}
	LIST_REMOVE(mem, list);
	rw_wunlock(&xmd_free_rw);

	*addr = mem->addr;
	*size = mem->size;
	free(mem, M_XMD);
	return (0);
}

static struct xmd_segment_header *
xmd_alloc(struct xmd_softc *sc)
{
	struct xmd_segment_header *sh;

	sh = malloc(sizeof(*sh), M_XMD_HEADER, M_WAITOK | M_ZERO);
	if (sh == NULL)
		return (NULL);
	sh->bufsize = 0;
	sh->bufused = 0;
	sh->type = XMD_TYPE_ERR;
	sh->fill = 0;
	sh->seg = 0;
	sh->object = NULL;
	sh->addr = NULL;
#ifdef USE_CRC32
	sh->crc32 = 0;
	sh->zcrc32 = 0;
#ifdef DEBUG
	sh->exp = NULL;
#endif
#endif
	return (sh);
}

static size_t
xmd_mem_avail(void)
{
	vm_ooffset_t avail;

#if __FreeBSD_version >= 1100000
	avail = swap_pager_avail + vm_cnt.v_free_count + vm_cnt.v_cache_count;
#else
	avail = swap_pager_avail + cnt.v_free_count + cnt.v_cache_count;
#endif
	return (avail);
}

static int
xmd_resize_pages(vm_object_t obj, off_t oldsize, off_t newsize)
{
	vm_pindex_t oldpages, newpages, reqpages;
	int error;

	oldpages = OFF_TO_IDX(round_page(oldsize));
	newpages = OFF_TO_IDX(round_page(newsize));

	/* check avail pages */
	if (newpages > oldpages) {
		reqpages = newpages - oldpages;
		if (xmd_mem_avail() < OFF_TO_IDX(reqpages))
			return (-1);
	} else
		reqpages = oldpages - newpages;
	/* OK resize */
	error = 0;
	if (newpages < oldpages) {
		/* shrink pages */
		VMOBJ_LOCK(obj);
		if (xmd_swap_reserve && swap_pager_avail)
			swap_pager_freespace(obj, newpages, reqpages);
		vm_object_page_remove(obj, newpages, 0, 0);
		obj->size = newpages;
		VMOBJ_UNLOCK(obj);
	} else if (newpages > oldpages) {
		/* grow pages */
		VMOBJ_LOCK(obj);
		if (xmd_swap_reserve && swap_pager_avail &&
		    swap_pager_full == 0 &&
		    swap_pager_reserve(obj, oldpages,
		    reqpages) < 0) {
			if (swap_pager_full == 0) {
				printf("swap pager reserve error\n");
				error = -1;
			}
		}
		obj->size = newpages;
		VMOBJ_UNLOCK(obj);
	}
	return (error);
}

static vm_object_t
xmd_alloc_pages(struct xmd_softc *sc, off_t size, off_t offset)
{
	vm_object_t obj;
	struct ucred *ucred;

	ucred = NULL;
	if (xmd_swap_reserve && sc->td != NULL)
		ucred = sc->td->td_ucred;
	obj = vm_pager_allocate(OBJT_SWAP, NULL, size, VM_PROT_DEFAULT,
	    offset, ucred);
	if (obj == NULL)
		return (NULL);
	VMOBJ_LOCK(obj);
	vm_object_clear_flag(obj, OBJ_ONEMAPPING);
	vm_object_set_flag(obj, OBJ_NOSPLIT);
	obj->size = OFF_TO_IDX(round_page(size));
	VMOBJ_UNLOCK(obj);
	if (xmd_swap_reserve && swap_pager_avail &&
	    swap_pager_full == 0 && swap_pager_reserve(obj, 0,
	    OFF_TO_IDX(round_page(size))) < 0) {
		printf("swap pager reserve error\n");
		vm_object_deallocate(obj);
		return (NULL);
	}
	return (obj);
}

static int
xmd_read_page(vm_object_t obj, uint8_t *dst, vm_pindex_t idx)
{
	struct sf_buf *sf;
	uint8_t *src;
	vm_page_t m;
	int rv;

	/* get idx page */
#if __FreeBSD_version >= 1000000
	m = vm_page_grab(obj, idx, VM_ALLOC_NORMAL);
#else
	m = vm_page_grab(obj, idx, VM_ALLOC_NORMAL | VM_ALLOC_RETRY);
#endif
	if (m->valid != VM_PAGE_BITS_ALL) {
		if (vm_pager_has_page(obj, idx, NULL, NULL)) {
			rv = vm_pager_get_pages(obj, &m, 1, 0);
			if (rv == VM_PAGER_ERROR) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("error: vm_pager_get_pages rv=%d\n",
				    rv);
				vm_page_xunbusy(m);
				return (-1);
			} else if (rv == VM_PAGER_FAIL) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("fail: vm_pager_get_pages rv=%d\n", rv);
				vm_page_xunbusy(m);
				return (-1);
			} else if (rv != VM_PAGER_OK) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("unknown: vm_pager_get_pages rv=%d\n",
				    rv);
				vm_page_xunbusy(m);
				return (-1);
			}
		} else {
			DPRINTF("zero page\n");
			vm_page_zero_invalid(m, TRUE);
		}
	}
	vm_page_xunbusy(m);

	/* wired the page */
	vm_page_lock(m);
	vm_page_hold(m);
	vm_page_unlock(m);

	/* read data from the page */
#if 0
	physcopyout(VM_PAGE_TO_PHYS(m), dst, PAGE_SIZE);
	cpu_flush_dcache(dst, PAGE_SIZE);
#else
	sf = sf_buf_alloc(m, 0);
	if (sf == NULL) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("sf_buf == NULL\n");
		vm_page_lock(m);
		vm_page_unhold(m);
		vm_page_unlock(m);
		return (EIO);
	}
	src = (uint8_t *)sf_buf_kva(sf);
	memcpy(dst, src, PAGE_SIZE);
	cpu_flush_dcache(dst, PAGE_SIZE);
	sf_buf_free(sf);
#endif

	/* unwired */
	vm_page_lock(m);
	if (m->queue == PQ_NONE)
		vm_page_deactivate(m);
	else
		vm_page_activate(m);
	vm_page_unhold(m);
	vm_page_unlock(m);

	return (0);
}

static int
xmd_read_pages(vm_object_t obj, uint8_t *dst, int len)
{
	vm_pindex_t idx;
	uint8_t *up;
	int resid;
	int error;

	if (len % PAGE_SIZE) {
		DPRINTF("alignment error\n");
		return (-1);
	}

	up = dst;
	resid = len;
	idx = OFF_TO_IDX(0);
	error = 0;

	VMOBJ_LOCK(obj);
	vm_object_pip_add(obj, 1);
	while (resid > 0) {
		error = xmd_read_page(obj, up, idx);
		if (error != 0)
			break;
		up += PAGE_SIZE;
		resid -= PAGE_SIZE;
		idx++;
	}
	//cpu_flush_dcache(dst, len);
	vm_object_pip_wakeup(obj);
	VMOBJ_UNLOCK(obj);
	return (error);
}

/*
 * read specified segment data to sc->tmpbuf
 * read size = sc->seglen, sc->tmpbuf2 is broken
 */
static int
xmd_read_segment(struct xmd_softc *sc, struct xmd_segment_header *sh)
{
	z_stream zs;
#ifdef USE_LZMA
	lzma_stream ls;
#endif
#ifdef USE_CRC32
	uint32_t crc;
#endif
	int rv;

	if (sc == NULL || sh == NULL)
		return (-1);
	if (sh->object != NULL && sh->bufsize > sc->tmpsize) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("tmpsize error\n");
		return (-1);
	}

	/* no object is special case */
	if (sh->object == NULL) {
		/* preload or FILL or empty */
		switch (sh->type) {
		case XMD_TYPE_PRERAW:
			/* no need decompression */
			memcpy(sc->tmpbuf, sh->addr,
			    min(sc->seglen, sh->bufused));
			if (sh->bufused < sc->seglen) {
				memset(sc->tmpbuf + sh->bufused, 0,
				    sc->seglen - sh->bufused);
			}
			break;
		case XMD_TYPE_PRELZ4:
			/* decompress preload to tmpbuf */
			rv = xmd_lz4_decompress(sh->addr, sh->bufused,
			    sc->tmpbuf, sc->tmpsize);
			if (rv < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("lz4_decompress error (rv=%d)\n", rv);
				return (-1);
			}
			break;
		case XMD_TYPE_PREZS:
			/* decompress preload to tmpbuf */
			rv = xmd_inflate(&zs, sh->addr, sh->bufused,
			    sc->tmpbuf, sc->tmpsize);
			if (rv != Z_STREAM_END) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("inflate error\n");
				return (-1);
			}
			break;
#ifdef USE_LZMA
		case XMD_TYPE_PRELS:
			/* decompress preload to tmpbuf */
			rv = xmd_lzma_decode(&ls, sh->addr, sh->bufused,
			    sc->tmpbuf, sc->tmpsize);
			if (rv != LZMA_STREAM_END) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("decode error\n");
				return (-1);
			}
			break;
#endif
		case XMD_TYPE_FILL:
			/* fill buffer */
			memset(sc->tmpbuf, sh->fill, sc->seglen);
			break;
		default:
			/* not yet allocated, all zeroed */
			memset(sc->tmpbuf, 0, sc->seglen);
			break;
		}
#ifdef USE_CRC32
		/* XXX preload have no crc */
#endif
		return (0);
	}

	/* non-compressed data */
	if (sh->type == XMD_TYPE_NONE) {
		/* no need decompression, read to tmpbuf */
		if (xmd_read_pages(sh->object, sc->tmpbuf,
		    sh->bufsize) != 0) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("read error\n");
			return (-1);
		}
#ifdef USE_CRC32
		/* check raw data */
		crc = crc32(sc->tmpbuf, sc->seglen);
		if (crc != sh->crc32 && sh->crc32 != 0) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("crc32 error seg=%d\n", sh->seg);
			hexdump(sc->tmpbuf, sh->bufused, NULL, 0);
			return (-1);
		}
#endif
		return (0);
	}

	/* get data from pager to tmpbuf2 */
	if (xmd_read_pages(sh->object, sc->tmpbuf2, sh->bufsize) != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("read error\n");
		return (-1);
	}
#ifdef USE_CRC32
	/* check compressed data */
	crc = crc32(sc->tmpbuf2, sh->bufused);
	if (crc != sh->zcrc32) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("crc32 error seg=%d (compressed type=%d)\n",
		    sh->seg, sh->type);

		printf("pager result:\n");
		hexdump(sc->tmpbuf2, sh->bufused, NULL, 0);
#ifdef DEBUG
		if (sh->exp) {
			printf("expected result:\n");
			hexdump(sh->exp, min(PAGE_SIZE * 2, sh->bufused),
			    NULL, 0);
		}
#endif
		return (-1);
	}
#endif

	switch (sh->type) {
	case XMD_TYPE_NONE:
		/* no need decompression */
		memcpy(sc->tmpbuf, sc->tmpbuf2, sc->seglen);
		break;
	case XMD_TYPE_FILL:
		/* fill should not have object... */
		memset(sc->tmpbuf, sh->fill, sc->seglen);
		/* remove it if any */
		if (sh->object != NULL)
			vm_object_deallocate(sh->object);
		sh->object = NULL;
		sh->addr = NULL;
		sh->bufsize = 0;
		sh->bufused = 0;
		break;
	case XMD_TYPE_LZ4:
		/* decompress tmpbuf2 to tmpbuf */
		rv = xmd_lz4_decompress(sc->tmpbuf2, sh->bufused, sc->tmpbuf,
		    sc->tmpsize);
		if (rv < 0) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("lz4_decompress error (rv=%d)\n", rv);
			return (-1);
		}
		break;
	case XMD_TYPE_ZLIB:
		/* decompress tmpbuf2 to tmpbuf */
		rv = xmd_inflate(&zs, sc->tmpbuf2, sh->bufused, sc->tmpbuf,
		    sc->tmpsize);
		if (rv != Z_STREAM_END) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("inflate error\n");
			return (-1);
		}
		break;
#ifdef USE_LZMA
	case XMD_TYPE_LZMA:
		/* decompress tmpbuf2 to tmpbuf */
		rv = xmd_lzma_decode(&ls, sc->tmpbuf2, sh->bufused,
		    sc->tmpbuf, sc->tmpsize);
		if (rv != LZMA_STREAM_END) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("decode error\n");
			return (-1);
		}
		break;
#endif
	case XMD_TYPE_ERR:
		printf("%s:%u: ", __func__, __LINE__);
		printf("internal error when reading\n");
		return (-1);
	default:
		/* unknown type */
		printf("%s:%u: ", __func__, __LINE__);
		printf("unknown data type: %d\n", sh->type);
		return (-1);
	}
#ifdef USE_CRC32
	/* check raw data */
	crc = crc32(sc->tmpbuf, sc->seglen);
	if (crc != sh->crc32 && sh->crc32 != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("crc32 error seg=%d\n", sh->seg);
		return (-1);
	}
#endif
	return (0);
}

static int
xmd_read(struct xmd_softc *sc, uint8_t *dst, off_t offset, long length)
{
	struct xmd_segment_header *sh;
	uint32_t seg, pos, len;

	/* segement and offset position */
	seg = offset >> sc->segshift;
	pos = offset & sc->segmask;
	len = min(sc->seglen - pos, length);

	/* get segment header of the offset */
	if (seg >= sc->nseg) {
		DPRINTF("size end\n");
		return (-1);
	}
	sh = sc->index[seg];
	if (sh == NULL) {
		/* not yet allocated, all zeroed */
		memset(dst, 0, len);
		return (len);
	} else if (sh->object == NULL && (sh->type & XMD_TYPE_PRELD) == 0) {
		/* no object is allocated */
		if (sh->type == XMD_TYPE_FILL) {
			/* fill dst */
			memset(dst, sh->fill, len);
		} else {
			/* not yet allocated, all zeroed */
			memset(dst, 0, len);
		}
		DPRINTF("read(noobj) seg=%d, pos=%d, len=%d\n", seg, pos, len);
		return (len);
	}

	/* generic read operation for sc->tmpbuf */
	if (xmd_read_segment(sc, sh) != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("read error\n");
		return (-1);
	}

	/* finally copy to dst */
	memcpy(dst, sc->tmpbuf + pos, len);
	DPRINTF("read seg=%d, pos=%d, len=%d\n", seg, pos, len);
	return (len);
}

static int
xmd_write_page(vm_object_t obj, uint8_t *src, vm_pindex_t idx)
{
	struct sf_buf *sf;
	uint8_t *dst;
	vm_page_t m;
	int rv;

	/* get idx page */
#if __FreeBSD_version >= 1000000
	m = vm_page_grab(obj, idx, VM_ALLOC_NORMAL);
#else
	m = vm_page_grab(obj, idx, VM_ALLOC_NORMAL | VM_ALLOC_RETRY);
#endif
	/* always write one page */
	if (m->valid != VM_PAGE_BITS_ALL) {
		if (vm_pager_has_page(obj, idx, NULL, NULL)) {
			rv = vm_pager_get_pages(obj, &m, 1, 0);
			if (rv != VM_PAGER_OK) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("error: vm_pager_get_pages rv=%d\n",
				    rv);
				vm_page_xunbusy(m);
				return (-1);
			}
			DPRINTF("new page\n");
		} else {
			DPRINTF("zero page\n");
			vm_page_zero_invalid(m, TRUE);
		}
	}
	vm_page_xunbusy(m);

	/* wired the page */
	vm_page_lock(m);
	vm_page_hold(m);
	vm_page_unlock(m);

	/* write data to the page */
#if 0
	physcopyin(src, VM_PAGE_TO_PHYS(m), PAGE_SIZE);
	wmb();
#else
	sf = sf_buf_alloc(m, 0);
	if (sf == NULL) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("sf_buf == NULL\n");
		vm_page_lock(m);
		vm_page_unhold(m);
		vm_page_unlock(m);
		return (EIO);
	}
	dst = (uint8_t *)sf_buf_kva(sf);
	memcpy(dst, src, PAGE_SIZE);
	wmb();
	sf_buf_free(sf);
#endif

	/* this page is dirty */
	vm_page_dirty(m);
	vm_pager_page_unswapped(m);

	/* unwired */
	vm_page_lock(m);
	if (m->queue == PQ_NONE)
		vm_page_deactivate(m);
	else
		vm_page_activate(m);
	vm_page_unhold(m);
	vm_page_unlock(m);

	return (0);
}

static int
xmd_write_pages(vm_object_t obj, uint8_t *src, int len)
{
	vm_pindex_t idx;
	uint8_t *up;
	int resid;
	int error;

	if (len % PAGE_SIZE) {
		DPRINTF("alignment error\n");
		return (-1);
	}

	up = src;
	resid = len;
	idx = OFF_TO_IDX(0);
	error = 0;

	VMOBJ_LOCK(obj);
	vm_object_pip_add(obj, 1);
	while (resid > 0) {
		error = xmd_write_page(obj, up, idx);
		if (error != 0)
			break;
		up += PAGE_SIZE;
		resid -= PAGE_SIZE;
		idx++;
	}
	vm_object_pip_wakeup(obj);
	VMOBJ_UNLOCK(obj);
	return (error);
}

/*
 * write specified segment data with compression from sc->tmpbuf
 * write size = sc->seglen, sc->tmpbuf2 is broken
 */
static int
xmd_write_segment(struct xmd_softc *sc, struct xmd_segment_header *sh)
{
	z_stream zs;
#ifdef USE_LZMA
	lzma_stream ls;
#endif
	uint8_t *tmpbuf;
	uint32_t size, compsize;
	int type;
	int rv;

	if (sc == NULL || sh == NULL)
		return (-1);

	/* compress modified tmpbuf to tmpbuf2 */
	compsize = 0;
	tmpbuf = sc->tmpbuf2;
	switch (sc->comptype) {
	case XMD_TYPE_LZ4:
		/* compress tmpbuf to tmpbuf2 */
		rv = xmd_lz4_compress(sc, sc->complevel, sc->tmpbuf,
		    sc->seglen, sc->tmpbuf2, sc->tmpsize);
		if (rv <= 0) {
			if (rv < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("lz4_compress error (rv=%d)\n", rv);
				return (-1);
			}
			/* size over, store as uncompress */
			tmpbuf = sc->tmpbuf;
			compsize = sc->seglen;
			type = XMD_TYPE_NONE;
		} else {
			/* LZ4 compressed */
			compsize = rv;
			type = XMD_TYPE_LZ4;
		}
		break;
	case XMD_TYPE_ZLIB:
		/* compress tmpbuf to tmpbuf2 */
		rv = xmd_deflate(&zs, sc->complevel, sc->tmpbuf, sc->seglen,
		    sc->tmpbuf2, sc->tmpsize);
		if (rv != Z_STREAM_END) {
			if (zs.total_out != sc->tmpsize) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("deflate error\n");
				return (-1);
			}
			/* size over, store as uncompress */
			tmpbuf = sc->tmpbuf;
			compsize = sc->seglen;
			type = XMD_TYPE_NONE;
		} else {
			/* zlib compressed */
			compsize = zs.total_out;
			type = XMD_TYPE_ZLIB;
		}
		break;
#ifdef USE_LZMA
	case XMD_TYPE_LZMA:
		/* compress tmpbuf to tmpbuf2 */
		rv = xmd_lzma_encode(&ls, sc->complevel, sc->tmpbuf,
		    sc->seglen, sc->tmpbuf2, sc->tmpsize);
		if (rv != LZMA_STREAM_END) {
			if (ls.avail_out != 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("encode error %d:%zu/%zu \n", rv,
				    ls.avail_in, ls.avail_out);
				return (-1);
			}
			/* size over, store as uncompress */
			tmpbuf = sc->tmpbuf;
			compsize = sc->seglen;
			type = XMD_TYPE_NONE;
		} else {
			/* lzma compressed */
			compsize = sc->tmpsize - ls.avail_out;
			type = XMD_TYPE_LZMA;
		}
		break;
#endif
	case XMD_TYPE_NONE:
		/* uncompress */
		tmpbuf = sc->tmpbuf;
		compsize = sc->seglen;
		type = XMD_TYPE_NONE;
		break;
	default:
		/* unknown type */
		printf("%s:%u: ", __func__, __LINE__);
		printf("unknown compression type: %d\n", sc->comptype);
		return (-1);
	}
#ifdef USE_CRC32
	/* save crc32 of compressed data */
	sh->zcrc32 = crc32(tmpbuf, compsize);
#ifdef DEBUG
	if (sh->exp != NULL)
		free(sh->exp, M_XMD_BLOCK);
	sh->exp = malloc(min(PAGE_SIZE * 2, compsize), M_XMD_BLOCK, M_WAITOK);
	memcpy(sh->exp, tmpbuf, min(PAGE_SIZE * 2, compsize));
#endif
#endif

	/* aligned to PAGE_SIZE, at least one page using */
	size = round_page(compsize);
	if (size == 0)
		size = PAGE_SIZE;

	/* allocate enough buffer */
	if (sh->object != NULL) {
		if (sh->bufsize != size) {
			/* reserve/release swap pages */
			if (xmd_resize_pages(sh->object, sh->bufsize,
			    size) < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("resize pages error\n");
				return (-1);
			}
			sh->bufsize = size;
		}
	} else if (sc->preloaded) {
		/* try to save preload area */
		if (sh->addr != NULL) {
			if (compsize <= sh->bufsize &&
			    (type == XMD_TYPE_NONE || type == XMD_TYPE_LZ4 ||
			    type == XMD_TYPE_ZLIB || type == XMD_TYPE_LZMA)) {
				/* OK save */
				memcpy(sh->addr, tmpbuf, compsize);
				sh->bufused = compsize;
				/* translate type */
				if (type == XMD_TYPE_NONE)
					sh->type = XMD_TYPE_PRERAW;
				else if (type == XMD_TYPE_LZ4)
					sh->type = XMD_TYPE_PRELZ4;
				else if (type == XMD_TYPE_ZLIB)
					sh->type = XMD_TYPE_PREZS;
				else if (type == XMD_TYPE_LZMA)
					sh->type = XMD_TYPE_PRELS;
				return (0);
			}
			/* NG release preload */
			if (sh->bufsize > PAGE_SIZE) {
				if (xmd_create_preload_memory(
				    sh->addr, sh->bufsize) < 0) {
					printf("%s:%u: ", __func__, __LINE__);
					printf("create preload memory error\n");
					sh->bufsize = 0;
					/* DO NOT STOP HERE return (-1);*/
				}
			}
			sh->addr = NULL;
			sh->bufsize = 0;
			sh->bufused = 0;
		}
		/* supported type? */
		if (type == XMD_TYPE_NONE || type == XMD_TYPE_LZ4 ||
		    type == XMD_TYPE_ZLIB || type == XMD_TYPE_LZMA) {
			sh->bufsize = size;
			if (xmd_alloc_preload_memory(&sh->addr,
				&sh->bufsize) == 0) {
				memcpy(sh->addr, tmpbuf, compsize);
				sh->bufused = compsize;
				/* translate type */
				if (type == XMD_TYPE_NONE)
					sh->type = XMD_TYPE_PRERAW;
				else if (type == XMD_TYPE_LZ4)
					sh->type = XMD_TYPE_PRELZ4;
				else if (type == XMD_TYPE_ZLIB)
					sh->type = XMD_TYPE_PREZS;
				else if (type == XMD_TYPE_LZMA)
					sh->type = XMD_TYPE_PRELS;
				return (0);
			}
			sh->bufsize = 0;
		}
		/* not yet allocated */
		sh->object = xmd_alloc_pages(sc, size, 0);
		if (sh->object == NULL) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("alloc pages error\n");
			sh->bufsize = 0;
			return (-1);
		}
		sh->bufsize = size;
	} else {
		/* not yet allocated */
		sh->object = xmd_alloc_pages(sc, size, 0);
		if (sh->object == NULL) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("alloc pages error\n");
			sh->bufsize = 0;
			return (-1);
		}
		sh->bufsize = size;
	}

	/* back to segment */
	if (xmd_write_pages(sh->object, tmpbuf, size) != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("write error\n");
		return (-1);
	}
	sh->bufused = compsize;
	sh->type = type;
	return (0);
}

static int
xmd_write(struct xmd_softc *sc, uint8_t *src, off_t offset, long length)
{
	struct xmd_segment_header *sh;
	uint32_t seg, pos, len;
	int rv;

	/* segement and offset position */
	seg = offset >> sc->segshift;
	pos = offset & sc->segmask;
	len = min(sc->seglen - pos, length);

	/* get segment header of the offset */
	if (seg >= sc->nseg) {
		DPRINTF("size end\n");
		return (-1);
	}
	sh = sc->index[seg];

	/* read and modify tmpbuf */
	if (sh == NULL) {
		/* new buffer */
		sh = xmd_alloc(sc);
		if (sh == NULL) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("alloc error\n");
			return (-1);
		}
		sh->seg = seg;
		sc->index[seg] = sh;
		if (len != sc->seglen) {
			/* zero fill tmpbuf */
			memset(sc->tmpbuf + len, 0, sc->seglen - len);
		}
	} else if (len == sc->seglen) {
		/* all data write */
	} else if (sh->object == NULL && (sh->type & XMD_TYPE_PRELD) == 0) {
		/* not allocated or fill */
		if (sh->type == XMD_TYPE_FILL) {
			/* fill tmpbuf */
			memset(sc->tmpbuf, sh->fill, sc->seglen);
		} else {
			/* not yet allocated, all zeroed */
			memset(sc->tmpbuf, 0, sc->seglen);
		}
	} else {
		/* generic read operation for sc->tmpbuf */
		if (xmd_read_segment(sc, sh) != 0) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("read error\n");
			return (-1);
		}
	}

	/* write operation (for tmpbuf) */
	memcpy(sc->tmpbuf + pos, src, len);
#ifdef USE_CRC32
	/* save crc32 of raw data */
	sh->crc32 = crc32(sc->tmpbuf, sc->seglen);
	sh->zcrc32 = 0;
#endif

	/* filled data is special */
	rv = xmd_get_filled_data(sc->tmpbuf, sc->seglen);
	if (rv >= 0) {
		if (sh->object != NULL)
			vm_object_deallocate(sh->object);
		if (sc->preloaded && sh->addr != NULL &&
		    sh->bufsize > PAGE_SIZE) {
			if (xmd_create_preload_memory(
			    sh->addr, sh->bufsize) < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("create preload memory error\n");
				sh->bufsize = 0;
			}
		}
		sh->object = NULL;
		sh->addr = NULL;
		sh->bufsize = 0;
		sh->bufused = 0;
		sh->type = XMD_TYPE_FILL;
		sh->fill = rv;
		DPRINTF("write(fill) seg=%d, pos=%d, len=%d\n", seg, pos, len);
		return (len);
	}

	/* generic write operation for sc->tmpbuf */
	if (xmd_write_segment(sc, sh) != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("write error\n");
		return (-1);
	}
	DPRINTF("write seg=%d, pos=%d, len=%d\n", seg, pos, len);
	return (len);
}

static int
xmd_delete(struct xmd_softc *sc, uint8_t *src, off_t offset, long length)
{
	struct xmd_segment_header *sh;
	uint32_t seg, pos, len;
	int rv;

	/* segement and offset position */
	seg = offset >> sc->segshift;
	pos = offset & sc->segmask;
	len = min(sc->seglen - pos, length);

	/* get segment header of the offset */
	if (seg >= sc->nseg) {
		DPRINTF("size end\n");
		return (-1);
	}
	sh = sc->index[seg];

	/* read and modify tmpbuf */
	if (sh == NULL) {
		if (len == sc->seglen) {
			/* all data clear */
			return (len);
		}
		/* no need modify, already zeroed */
		return (len);
	} else if (len == sc->seglen) {
		/* all data clear */
		if (sh->object != NULL)
			vm_object_deallocate(sh->object);
		if (sc->preloaded && sh->addr != NULL &&
		    sh->bufsize > PAGE_SIZE) {
			if (xmd_create_preload_memory(
			    sh->addr, sh->bufsize) < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("create preload memory error\n");
				sh->bufsize = 0;
			}
		}
		sh->object = NULL;
		sh->addr = NULL;
		sh->bufsize = 0;
		sh->bufused = 0;
		sh->type = XMD_TYPE_FILL;
		sh->fill = 0;
		return (len);
	} else if (sh->object == NULL && (sh->type & XMD_TYPE_PRELD) == 0) {
		/* not allocated or fill */
		if (sh->type == XMD_TYPE_FILL) {
			/* fill tmpbuf */
			memset(sc->tmpbuf, sh->fill, sc->seglen);
		} else {
			/* not yet allocated, all zeroed */
			memset(sc->tmpbuf, 0, sc->seglen);
		}
	} else {
		/* generic read operation for sc->tmpbuf */
		if (xmd_read_segment(sc, sh) != 0) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("read error\n");
			return (-1);
		}
	}

	/* delete operation (for tmpbuf) */
	memset(sc->tmpbuf + pos, 0, len);
#ifdef USE_CRC32
	/* save crc32 of raw data */
	sh->crc32 = crc32(sc->tmpbuf, sc->seglen);
	sh->zcrc32 = 0;
#endif

	/* filled data is special */
	rv = xmd_get_filled_data(sc->tmpbuf, sc->seglen);
	if (rv >= 0) {
		if (sh->object != NULL)
			vm_object_deallocate(sh->object);
		if (sc->preloaded && sh->addr != NULL &&
		    sh->bufsize > PAGE_SIZE) {
			if (xmd_create_preload_memory(
			    sh->addr, sh->bufsize) < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("create preload memory error\n");
				sh->bufsize = 0;
			}
		}
		sh->object = NULL;
		sh->addr = NULL;
		sh->bufsize = 0;
		sh->bufused = 0;
		sh->type = XMD_TYPE_FILL;
		sh->fill = rv;
		DPRINTF("write(delete/fill) seg=%d, pos=%d, len=%d\n",
		    seg, pos, len);
		return (len);
	}

	/* generic write operation for sc->tmpbuf */
	if (xmd_write_segment(sc, sh) != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("write error\n");
		return (-1);
	}
	DPRINTF("write(delete) seg=%d, pos=%d, len=%d\n", seg, pos, len);
	return (len);
}

static int
xmd_get_status(struct xmd_softc *sc, struct xmd_ioctl *xmdio, size_t size)
{
	struct xmd_segment_header *sh;
	uint32_t seg;

	if (size != sizeof(*xmdio))
		return (EINVAL);

	/* basic info */
	xmdio->xmd_preloaded = sc->preloaded;
	xmdio->xmd_nseg = sc->nseg;
	xmdio->xmd_seglen = sc->seglen;

	/* count bufsize */
	xmdio->xmd_buftotal = 0;
	xmdio->xmd_bufsize = 0;
	xmdio->xmd_bufused = 0;
	for (seg = 0; seg < sc->nseg; seg++) {
		sh = sc->index[seg];
		if (sh != NULL) {
			xmdio->xmd_buftotal += sc->seglen;
			xmdio->xmd_bufsize += sh->bufsize;
			xmdio->xmd_bufused += sh->bufused;
		}
	}
	return (0);
}

static int
xmd_segio(struct xmd_softc *sc, struct xmd_ioctl *xmdio, uint8_t *data,
    off_t offset, long length)
{
	z_stream zs;
#ifdef USE_LZMA
	lzma_stream ls;
#endif
	struct xmd_segment_header *sh;
	uint32_t seg, pos;
	uint32_t size, compsize;
	int type;
	int rv;

	/* segement and offset position */
	seg = offset >> sc->segshift;
	pos = offset & sc->segmask;
	compsize = length;
	type = xmdio->xmd_comptype;

	/* get segment header of the offset */
	if (seg >= sc->nseg) {
		DPRINTF("size end\n");
		return (-1);
	}
	if (pos != 0) {
		DPRINTF("offset error\n");
		return (-1);
	}
	sh = sc->index[seg];
	if (sh == NULL) {
		sh = xmd_alloc(sc);
		if (sh == NULL) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("alloc error\n");
			return (-1);
		}
		sh->seg = seg;
		sc->index[seg] = sh;
	}

	/* try to decompress small size */
	if (compsize < PAGE_SIZE) {
		switch(type) {
		case XMD_TYPE_NONE:
			memset(sc->tmpbuf, 0, sc->seglen);
			memcpy(sc->tmpbuf, data, compsize);
			break;
		case XMD_TYPE_FILL:
			memset(sc->tmpbuf, *data, sc->seglen);
			break;
		case XMD_TYPE_LZ4:
			/* decompress data to tmpbuf */
			rv = xmd_lz4_decompress(data, compsize,
			    sc->tmpbuf, sc->tmpsize);
			if (rv < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("lz4_decompress error (rv=%d)\n", rv);
				return (-1);
			}
			break;
		case XMD_TYPE_ZLIB:
			/* decompress data to tmpbuf */
			rv = xmd_inflate(&zs, data, compsize, sc->tmpbuf,
			    sc->tmpsize);
			if (rv != Z_STREAM_END) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("inflate error\n");
				return (-1);
			}
			break;
#ifdef USE_LZMA
		case XMD_TYPE_LZMA:
			/* decompress data to tmpbuf */
			rv = xmd_lzma_decode(&ls, data, compsize,
			    sc->tmpbuf, sc->tmpsize);
			if (rv != LZMA_STREAM_END) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("decode error\n");
				return (-1);
			}
			break;
#endif
		default:
			/* unknown type */
			printf("%s:%u: ", __func__, __LINE__);
			printf("unknown data type: %d\n", type);
			return (-1);
		}

		/* filled data is special */
		rv = xmd_get_filled_data(sc->tmpbuf, sc->seglen);
		if (rv >= 0) {
			if (sh->object != NULL)
				vm_object_deallocate(sh->object);
			sh->object = NULL;
			sh->addr = NULL;
			sh->bufsize = 0;
			sh->bufused = 0;
			sh->type = XMD_TYPE_FILL;
			sh->fill = rv;
#ifdef USE_CRC32
			sh->crc32 = crc32(sc->tmpbuf, sc->seglen);
			sh->zcrc32 = 0;
#endif
			DPRINTF("segio(fill) seg=%d, pos=%d\n", seg, pos);
			return (0);
		}
	} else if (compsize > sc->seglen) {
		/* back to non-compress if size is over */
		switch(type) {
		case XMD_TYPE_LZ4:
			/* decompress data to tmpbuf */
			rv = xmd_lz4_decompress(data, compsize,
			    sc->tmpbuf, sc->tmpsize);
			if (rv < 0) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("lz4_decompress error (rv=%d)\n", rv);
				return (-1);
			}
			break;
		case XMD_TYPE_ZLIB:
			/* decompress data to tmpbuf */
			rv = xmd_inflate(&zs, data, compsize, sc->tmpbuf,
			    sc->tmpsize);
			if (rv != Z_STREAM_END) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("inflate error\n");
				return (-1);
			}
			break;
#ifdef USE_LZMA
		case XMD_TYPE_LZMA:
			/* decompress data to tmpbuf */
			rv = xmd_lzma_decode(&ls, data, compsize,
			    sc->tmpbuf, sc->tmpsize);
			if (rv != LZMA_STREAM_END) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("decode error\n");
				return (-1);
			}
			break;
#endif
		default:
			/* unknown type */
			printf("%s:%u: ", __func__, __LINE__);
			printf("unknown data type: %d\n", type);
			return (-1);
		}
		data = sc->tmpbuf;
		compsize = sc->seglen;
		type = XMD_TYPE_NONE;
	}

	size = round_page(compsize);
	if (size == 0)
		size = PAGE_SIZE;

	/* allocate enough buffer */
	if (sh->object != NULL)
		vm_object_deallocate(sh->object);
	if (sc->preloaded && sh->addr != NULL &&
	    sh->bufsize > PAGE_SIZE) {
		if (xmd_create_preload_memory(
		    sh->addr, sh->bufsize) < 0) {
			printf("%s:%u: ", __func__, __LINE__);
			printf("create preload memory error\n");
			sh->bufsize = 0;
		}
	}
	sh->addr = NULL;
	sh->object = xmd_alloc_pages(sc, size, 0);
	if (sh->object == NULL) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("alloc pages error\n");
		sh->bufsize = 0;
		return (-1);
	}
	sh->bufsize = size;
#ifdef USE_CRC32
	/* save crc32 of compressed data */
	sh->crc32 = 0;
	sh->zcrc32 = crc32(data, compsize);
#endif
	/* write to segment */
	if (xmd_write_pages(sh->object, data, size) != 0) {
		printf("%s:%u: ", __func__, __LINE__);
		printf("write error\n");
		return (-1);
	}
	sh->bufused = compsize;
	sh->type = type;
	DPRINTF("segio seg=%d, pos=%d, size=%u, type=0x%x\n", seg, pos,
	    compsize, type);
	return (0);
}

static int
xmd_start(struct xmd_softc *sc, struct bio *bp)
{
	struct xmd_ioctl *xmdio;
	uint8_t *dst, *src;
	off_t off;
	long len;
	int error;

	error = EOPNOTSUPP;
	switch (bp->bio_cmd) {
	case BIO_READ:
		dst = (uint8_t *)bp->bio_data;
		off = bp->bio_offset;
		bp->bio_resid = bp->bio_length;
		error = 0;
		while (bp->bio_resid != 0) {
			len = xmd_read(sc, dst, off, bp->bio_resid);
			if (len <= 0) {
				error = EIO;
				bp->bio_completed = bp->bio_length -
				    bp->bio_resid;
				break;
			}
			bp->bio_resid -= len;
			dst += len;
			off += len;
		}
		bp->bio_completed = bp->bio_length - bp->bio_resid;
		break;
	case BIO_WRITE:
		src = (uint8_t *)bp->bio_data;
		off = bp->bio_offset;
		bp->bio_resid = bp->bio_length;
		error = 0;
		while (bp->bio_resid != 0) {
			len = xmd_write(sc, src, off, bp->bio_resid);
			if (len <= 0) {
				error = EIO;
				bp->bio_completed = bp->bio_length -
				    bp->bio_resid;
				break;
			}
			bp->bio_resid -= len;
			src += len;
			off += len;
		}
		bp->bio_completed = bp->bio_length - bp->bio_resid;
		break;
	case BIO_DELETE:
		src = NULL;
		off = bp->bio_offset;
		bp->bio_resid = bp->bio_length;
		error = 0;
		while (bp->bio_resid != 0) {
			len = xmd_delete(sc, src, off, bp->bio_resid);
			if (len <= 0) {
				error = EIO;
				bp->bio_completed = bp->bio_length -
				    bp->bio_resid;
				break;
			}
			bp->bio_resid -= len;
			src += len;
			off += len;
		}
		bp->bio_completed = bp->bio_length - bp->bio_resid;
		break;
	case BIO_GETATTR:
		//DPRINTF("BIO_GETATTR %s\n", bp->bio_attribute);
		error = EJUSTRETURN;
		if (g_handleattr_int(bp, "GEOM::candelete",
			/* TRIM support */ 1))
			break;
		else if (g_handleattr_str(bp, "GEOM::ident", xmd_ident))
			break;
		else
			error = EOPNOTSUPP;
		break;
	case BIO_FLUSH:
		/* nothing to do */
		error = 0;
		break;
	case XMD_SEGIO:
		src = (uint8_t *)bp->bio_data;
		off = bp->bio_offset;
		xmdio = (struct xmd_ioctl *)bp->bio_driver1;
		error = xmd_segio(sc, xmdio, src, off, bp->bio_length);
		if (error == 0)
			bp->bio_completed = bp->bio_length;
		break;
	default:
		DPRINTF("BIO %x\n", bp->bio_cmd);
		error = EOPNOTSUPP;
		break;
	}
	return (error);
}

static void
xmd_bio_done(struct bio *bp)
{

	if (bp != NULL && (bp->bio_flags & BIO_DONE) == 0) {
		DPRINTF("bio done %x, %zu\n", bp->bio_cmd, bp->bio_offset);
		bp->bio_done = NULL;
		biodone(bp);
	}
}

static void
xmd_worker(void *arg)
{
	struct xmd_softc *sc;
	struct bio *bp;
	int error;

	sc = arg;
	/* set priority of the thread */
	thread_lock(curthread);
	sched_prio(curthread, PRIBIO);
	thread_unlock(curthread);

	/* handle BIO request */
	for (;;) {
		mtx_lock(&sc->queue_mtx);
		bp = bioq_takefirst(&sc->bio_queue);
		if (bp == NULL) {
			msleep(sc, &sc->queue_mtx, PRIBIO | PDROP,
			    "xmdwait", 0);
			continue;
		}
		if (bp->bio_cmd == XMD_STOP) {
			/* special command recieved */
			cv_broadcast(&sc->cv_stop);
			mtx_unlock(&sc->queue_mtx);
			kproc_exit(0);
		}
		mtx_unlock(&sc->queue_mtx);
		if (bp->bio_cmd == XMD_STATUS) {
			error = xmd_get_status(sc,
			    (struct xmd_ioctl *)bp->bio_data,
			    bp->bio_length);
			xmd_bio_done(bp);
			continue;
		}
		error = xmd_start(sc, bp);
		if (error != EJUSTRETURN)
			g_io_deliver(bp, error);
	}
}

static struct xmd_softc *
xmd_find_sc(int unit)
{
	struct xmd_softc *sc;

	/* find specified unit */
	LIST_FOREACH(sc, &xmd_softc_list, list) {
		if (sc->unit == unit)
			break;
	}
	return (sc);
}

static int
xmd_get_maxunit(void)
{
	struct xmd_softc *sc;
	int unit = -1;

	/* find max unit */
	LIST_FOREACH(sc, &xmd_softc_list, list) {
		if (sc->unit > unit)
			unit = sc->unit;
	}
	return (unit);
}

static struct xmd_softc *
xmd_find_nextsc(int unit)
{
	struct xmd_softc *sc;
	int maxunit;

	maxunit = INT_MAX;
	if (unit >= maxunit)
		return (NULL);

	/* find next unit */
	LIST_FOREACH(sc, &xmd_softc_list, list) {
		if (sc->unit > unit &&  sc->unit < maxunit)
			maxunit = sc->unit;
	}
	if (maxunit == INT_MAX)
		return (NULL);
	    
	/* maxunit > unit */
	sc = xmd_find_sc(maxunit);
	return (sc);
}

static struct xmd_softc *
xmd_create(int unit, uint32_t size, uint32_t nblocks)
{
	struct xmd_softc *sc;
	uint32_t tmp;
	int lz4_ctx_size;
	int error;

	if (size == 0)
		return (NULL);
	if (size > XMD_MAXSIZE || size < XMD_MINSIZE)
		return (NULL);
	if (nblocks == 0)
		return (NULL);
	if (nblocks > XMD_MAXNBLOCKS || nblocks < XMD_MINNBLOCKS)
		return (NULL);

	/* allocate unit number */
	if (unit < 0)
		unit = alloc_unr(xmd_uh);
	else
		unit = alloc_unr_specific(xmd_uh, unit);
	if (unit == -1)
		return (NULL);

	/* allocate softc for new device */
	sc = malloc(sizeof(*sc), M_XMD, M_WAITOK | M_ZERO);
	sc->td = curthread;
	//sc->cred = crhold(sc->td->td_ucred);
	sc->unit = unit;
	sc->size = size * XMD_1MB;	/* byte */
	sc->blocklen = XMD_BLOCKLEN;
	sc->blockcnt = sc->size / sc->blocklen;
	/* segment parameters */
	sc->nseg = sc->blockcnt / nblocks;
	sc->seglen = sc->blocklen * nblocks;
	sc->segshift = 0;
	/* find MSB of seglen */
	tmp = sc->seglen;
	while (tmp != 1) {
		tmp >>= 1;
		sc->segshift++;
	}
	sc->segmask = (1ULL << sc->segshift) - 1;
	/* check calculated values */
	if (sc->nseg >= UINT32_MAX || sc->seglen == 0 ||
	    (sc->seglen & sc->segmask) != 0) {
		printf("invalid segment config\n");
		//crfree(sc->cred);
		free_unr(xmd_uh, sc->unit);
		free(sc, M_XMD);
		return (NULL);
	}

	/* adjust for segment alignment */
	sc->blockcnt = sc->nseg * nblocks;
	sc->size = sc->blockcnt * sc->blocklen;

	/* default compression level and type */
	sc->complevel = xmd_complevel;
	sc->comptype = xmd_comptype;

	/* compress/decompress buffer */
	sc->tmpsize =sc->seglen;
	sc->tmpbuf = malloc(sc->tmpsize, M_XMD_BLOCK, M_WAITOK | M_ZERO);
	sc->tmpbuf2 = malloc(sc->tmpsize, M_XMD_BLOCK, M_WAITOK | M_ZERO);
	/* LZ4 ctx */
	lz4_ctx_size = LZ4_sizeofState();
	if (lz4_ctx_size < LZ4_sizeofStateHC())
		lz4_ctx_size = LZ4_sizeofStateHC();
	sc->lz4_ctx = malloc(lz4_ctx_size, M_XMD_LZ4, M_WAITOK | M_ZERO);

	/* array of segment header of the device */
	sc->index = malloc(sc->nseg * sizeof(*sc->index), M_XMD_INDEX,
	    M_WAITOK | M_ZERO);

	/* initialize queue, mutex, cond */
	bioq_init(&sc->bio_queue);
	mtx_init(&sc->queue_mtx, "xmd bio queue", NULL, MTX_DEF);
	cv_init(&sc->cv_stop, "xmd stop");

	/* add the disk to list */
	LIST_INSERT_HEAD(&xmd_softc_list, sc, list);

	/* create worker thread */
	error = kproc_create(xmd_worker, sc, &sc->procp, 0, 0,"xmd%d",
	    sc->unit);
	if (error == 0)
		return (sc);

	/* error */
	LIST_REMOVE(sc, list);
	cv_destroy(&sc->cv_stop);
	mtx_destroy(&sc->queue_mtx);
	//crfree(sc->cred);
	free_unr(xmd_uh, sc->unit);
	free(sc->index, M_XMD_INDEX);
	free(sc->tmpbuf, M_XMD_BLOCK);
	free(sc->tmpbuf2, M_XMD_BLOCK);
	free(sc, M_XMD);
	return (NULL);
}

static void
xmd_destroy(struct xmd_softc *sc)
{
	int i;

	if (sc == NULL)
		return;

	/* destory geom and provider */
	if (sc->gp != NULL) {
		sc->gp->softc = NULL;
		g_topology_lock();
		g_wither_geom(sc->gp, ENXIO);
		g_topology_unlock();
		sc->gp = NULL;
		sc->pp = NULL;
	}

	/* stop worker thread */
	mtx_lock(&sc->queue_mtx);
	bioq_insert_head(&sc->bio_queue, &bio_stopcmd);
	wakeup(sc);
	cv_wait(&sc->cv_stop, &sc->queue_mtx);
	mtx_unlock(&sc->queue_mtx);

	/* free memory */
	cv_destroy(&sc->cv_stop);
	mtx_destroy(&sc->queue_mtx);
	LIST_REMOVE(sc, list);
	//if (sc->cred)
	//	crfree(sc->cred);
	free_unr(xmd_uh, sc->unit);
	if (sc->lz4_ctx != NULL)
		free(sc->lz4_ctx, M_XMD_LZ4);
	for (i = 0; i < sc->nseg; i++) {
		if (sc->index[i] != NULL) {
			if (sc->index[i]->object != NULL)
				vm_object_deallocate(sc->index[i]->object);
			free(sc->index[i], M_XMD_HEADER);
		}
	}
	free(sc->index, M_XMD_INDEX);
	free(sc->tmpbuf, M_XMD_BLOCK);
	free(sc->tmpbuf2, M_XMD_BLOCK);
	free(sc, M_XMD);
}

#ifdef XMD_ROOT
/* root device name */
static char xmd_rootfs[32];

static int
xmd_preload_raw(struct xmd_softc *sc, int rootfs, uint8_t *src, size_t size,
    char *name, int type)
{
	struct xmd_segment_header *sh;
	uint8_t *addr;
	uint32_t seg, pos, len;
	size_t resid;
	off_t offset;

	/* using addr for preloaded image (uncompressed) */
	offset = 0;
	addr = src;
	resid = size;
	while (resid >= sc->seglen) {
		seg = offset >> sc->segshift;
		pos = offset & sc->segmask;
		len = sc->seglen;

		/* setup header */
		if (seg >= sc->nseg) {
			printf("preload disk is too small\n");
			return (-1);
		}
		sh = sc->index[seg];
		if (sh == NULL) {
			sh = xmd_alloc(sc);
			if (sh == NULL) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("alloc error\n");
				return (-1);
			}
			sc->index[seg] = sh;
		}

		sh->addr = addr;
		sh->bufsize = sc->seglen;
		sh->bufused = sc->seglen;
		sh->type = type;

		resid -= len;
		offset += len;
		addr += len;
	}

	/* tail blocks are compressed by normal way */
	if (resid != 0) {
		len = xmd_write(sc, addr, offset, resid);
		if (len <= 0 || len != resid) {
			printf("preload write error\n");
			return (-1);
		}
	}

#if 0
	/* first unit is boot device */
	if (sc->unit == 0)
		rootdevnames[0] = "ufs:/dev/xmd0";
#endif
	/* if rootfs is non-zero, it is boot device */
	if (rootfs) {
		snprintf(xmd_rootfs, sizeof xmd_rootfs, "ufs:/dev/xmd%d",
		    sc->unit);
		rootdevnames[0] = xmd_rootfs;
	}

	if (name != NULL) {
		printf("xmd%d: Loaded preload raw image <%s> %zd bytes "
		    "at %p (%uMB disk%s)\n",
		    sc->unit, name, size, src,
		    (uint32_t)(sc->size / XMD_1MB),
#ifdef XMD_ROOT_FORCE_LZ4
		    " w/LZ4"
#else
		    ""
#endif
		    );
	}
	sc->preloaded = 1;
	return (0);
}

static int
xmd_preload_cloop(struct xmd_softc *sc, int rootfs, uint8_t *src, size_t size,
    char *name, int type)
{
	struct xmd_segment_header *sh;
	struct cloop_header *h;
	uint64_t *offsets;
	uint8_t *addr;
	uint64_t compsize;
	uint32_t seg, pos, len;
	size_t resid;
	off_t offset;

	/* check cloop header */
	h = (struct cloop_header *)src;
	offsets = (uint64_t *) (h + 1);
	if (ntohl(h->blksz) != sc->seglen) {
		printf("block size mismatch\n");
		return (-1);
	}
	if (ntohl(h->nblocks) > sc->nseg) {
		printf("blocks is too large\n");
		return (-1);
	}

	/* using addr for preloaded image (mkuzip/mkulzma) */
	offset = 0;
	addr = src;
	resid = ntohl(h->blksz) * ntohl(h->nblocks);
	while (resid >= sc->seglen) {
		seg = offset >> sc->segshift;
		pos = offset & sc->segmask;
		len = sc->seglen;

		/* end of cloop? */
		if (seg >= ntohl(h->nblocks))
			break;

		/* setup header */
		if (seg >= sc->nseg) {
			printf("preload disk is too small\n");
			return (-1);
		}
		sh = sc->index[seg];
		if (sh == NULL) {
			sh = xmd_alloc(sc);
			if (sh == NULL) {
				printf("%s:%u: ", __func__, __LINE__);
				printf("alloc error\n");
				return (-1);
			}
			sc->index[seg] = sh;
		}

		/* convert cloop data */
		addr = src + be64toh(offsets[seg]);
		compsize = be64toh(offsets[seg+1]) - be64toh(offsets[seg]);

		sh->addr = addr;
		sh->bufsize = compsize;
		sh->bufused = compsize;
		sh->type = type;

		resid -= len;
		offset += len;
		addr += len;
	}

	/* cloop have only compressed block */
	if (resid != 0) {
		printf("preload cloop error\n");
		return (-1);
	}

	/* if rootfs is non-zero, it is boot device */
	if (rootfs) {
		snprintf(xmd_rootfs, sizeof xmd_rootfs, "ufs:/dev/xmd%d",
		    sc->unit);
		rootdevnames[0] = xmd_rootfs;
	}

	if (name != NULL) {
		printf("xmd%d: Loaded preload cloop image <%s> %zd bytes "
		    "at %p (%uMB disk%s)\n",
		    sc->unit, name, size, src,
		    (uint32_t)(sc->size / XMD_1MB),
#ifdef XMD_ROOT_FORCE_LZ4
		    " w/LZ4"
#else
		    ""
#endif
		    );
	}
	sc->preloaded = 1;
	return (0);
}

static uint8_t
xmd_get_preload_type(uint8_t *src, size_t size)
{
	struct cloop_header *h;
	uint8_t type;

	type = XMD_TYPE_ERR;

	/* check cloop header */
	h = (struct cloop_header *)src;
	if (memcmp(h->magic, CLOOP_MAGIC_START,
	    sizeof (CLOOP_MAGIC_START) - 1) == 0) {
#ifdef USE_LZMA
		if (h->magic[0x0b] == 'L' &&
		    h->magic[0x0c] >= GEOM_ULZMA_MAJVER) {
			/* GEOM_ULZMA */
			type = XMD_TYPE_PRELS;
		} else
#endif
		if (h->magic[0x0b] == 'V' &&
		    h->magic[0x0c] >= GEOM_UZIP_MAJVER) {
			/* GEOM_UZIP */
			type = XMD_TYPE_PREZS;
		} else {
			printf("unknown cloop version\n");
			return (XMD_TYPE_ERR);
		}
	} else {
		/* unknown header */
		type = XMD_TYPE_PRERAW;
	}
	return (type);
}

static int
xmd_preload(struct xmd_softc *sc, int rootfs, uint8_t *src, size_t size,
    char *name)
{
	uint8_t type;
	int rv;

#if defined(__arm__)
	/* XXX workaround for module info bug */
	if (src < (uint8_t *)preload_addr_relocate ||
	    src >= (uint8_t *)0xe0000000)
		src -= preload_addr_relocate;
#endif

	/* determine preload type */
	type = xmd_get_preload_type(src, size);

	/* load the image */
	if (type == XMD_TYPE_PRELS || type == XMD_TYPE_PREZS) {
		rv = xmd_preload_cloop(sc, rootfs, src, size, name,
		    type);
	} else if (type == XMD_TYPE_PRERAW) {
		rv = xmd_preload_raw(sc, rootfs, src, size, name,
		    type);
	} else {
		printf("unsupported preload type\n");
		return (-1);
	}
	return (rv);
}
#endif

static void
xmd_init(struct xmd_softc *sc)
{
	struct g_geom *gp;
	struct g_provider *pp;

	/* re-check user compression */
	if (sc->complevel < 0)
		sc->complevel = 1;
	if (sc->complevel > 9)
		sc->complevel = 9;
	if (sc->comptype != XMD_TYPE_NONE && sc->comptype != XMD_TYPE_LZ4 &&
	    sc->comptype != XMD_TYPE_ZLIB
#ifdef USE_LZMA
	    && sc->comptype != XMD_TYPE_LZMA
#endif
	    )
		sc->comptype = XMD_TYPE_LZ4;
	if (sc->comptype == XMD_TYPE_NONE)
		sc->complevel = 0;
	if (sc->complevel == 0 && sc->comptype != XMD_TYPE_NONE)
		sc->complevel = 1;

	/* create new provider for the device */
	g_topology_lock();
	gp = g_new_geomf(&g_xmd_class, "xmd%d", sc->unit);
	gp->softc = sc;
	pp = g_new_providerf(gp, "xmd%d", sc->unit);
#if __FreeBSD_version >= 1000500
	pp->flags |= G_PF_DIRECT_SEND | G_PF_DIRECT_RECEIVE;
#endif
	pp->mediasize = (off_t)sc->size;
	pp->sectorsize = sc->blocklen;	/* default 512bytes */
	pp->stripesize = sc->seglen;	/* default 32KiB(512Bx64) */
	pp->stripeoffset = 0;
	sc->gp = gp;
	sc->pp = pp;
	g_error_provider(pp, 0);
	g_topology_unlock();
}

static void
xmd_print_config(struct xmd_softc *sc)
{
	int comptype, complevel;

	if (sc == NULL) {
		printf("xmd: default blocklen %uKB",
		    (uint32_t)((xmd_nblocks * XMD_BLOCKLEN) / 1024));
		comptype = xmd_comptype;
		complevel = xmd_complevel;
	} else {
		printf("xmd%d: size %uMB, blocklen %uKB", sc->unit,
		    (uint32_t)(sc->size / XMD_1MB),
		    (uint32_t)(sc->seglen / 1024));
		comptype = sc->comptype;
		complevel = sc->complevel;
	}

	if (comptype == XMD_TYPE_NONE)
		printf(", compression NONE");
	else if (comptype == XMD_TYPE_LZ4)
		printf(", compression LZ4/LZ4HC");
	else if (comptype == XMD_TYPE_ZLIB)
		printf(", compression ZLIB");
	else if (comptype == XMD_TYPE_LZMA)
		printf(", compression LZMA");
	else
		printf(", compression unknown");
	printf(", level %d\n", complevel);
}

static int
xmdctl_ioctl_locked(struct cdev *dev, u_long cmd, caddr_t data, int fflag,
    struct thread *td)
{
	struct xmd_ioctl *xmdio;
	struct xmd_softc *sc;
	struct bio *bp;
	uint32_t nblocks;
	int error;

	xmdio = (struct xmd_ioctl *)data;
	if (xmdio->xmd_version != XMDIOVERSION)
		return (EINVAL);

	error = 0;
	switch (cmd) {
	case XMDCTL_ATTACH:
		/* expects 1MB aligned disk */
		if ((xmdio->xmd_size % XMD_1MB) != 0 ||
		    xmdio->xmd_size < (XMD_MINSIZE * XMD_1MB))
			return (EINVAL);
		/* block size is specified? */
		if (xmdio->xmd_seglen != 0 && (xmdio->xmd_seglen % XMD_BLOCKLEN) != 0)
			return (EINVAL);
		nblocks = xmdio->xmd_seglen / XMD_BLOCKLEN;
		if (nblocks == 0)
			nblocks = xmd_nblocks;
		if (nblocks > XMD_MAXNBLOCKS || nblocks < XMD_MINNBLOCKS)
			return (EINVAL);
		/* setup structure and create thread */
		if (xmdio->xmd_unit < 0)
			sc = xmd_create(-1, (xmdio->xmd_size / XMD_1MB),
			    nblocks);
		else
			sc = xmd_create(xmdio->xmd_unit,
			    (xmdio->xmd_size / XMD_1MB), nblocks);
		if (sc == NULL)
			return (ENXIO);
		sc->td = td;
		//if (sc->cred)
		//	crfree(sc->cred);
		//sc->cred = crhold(td->td_ucred);
		/* set user selected compression */
		if (xmdio->xmd_comptype >= 0)
			sc->comptype = xmdio->xmd_comptype;
		if (xmdio->xmd_complevel >= 0)
			sc->complevel = xmdio->xmd_complevel;
		/* create geom provider */
		xmd_init(sc);

		/* return created values */
		if (xmdio->xmd_unit < 0)
			xmdio->xmd_unit = sc->unit;
		xmdio->xmd_blockcnt = sc->blockcnt;
		xmdio->xmd_blocklen = sc->blocklen;
		if (verbose)
			xmd_print_config(sc);
		break;
	case XMDCTL_DETACH:
		if (xmdio->xmd_unit < 0)
			return (EINVAL);
		sc = xmd_find_sc(xmdio->xmd_unit);
		if (sc == NULL)
			return (ENOENT);
		xmd_destroy(sc);
		break;
	case XMDCTL_MODIFY:
		if (xmdio->xmd_unit < 0)
			return (EINVAL);
		sc = xmd_find_sc(xmdio->xmd_unit);
		if (sc == NULL)
			return (ENOENT);
		if (xmdio->xmd_comptype >= 0) {
			/* check compression type */
			if (xmdio->xmd_comptype != XMD_TYPE_NONE &&
			    xmdio->xmd_comptype != XMD_TYPE_LZ4 &&
			    xmdio->xmd_comptype != XMD_TYPE_ZLIB
#ifdef USE_LZMA
			    && xmdio->xmd_comptype != XMD_TYPE_LZMA
#endif
			    )
				return (EINVAL);
		}
		/* set user selected compression */
		if (xmdio->xmd_comptype >= 0)
			sc->comptype = xmdio->xmd_comptype;
		if (xmdio->xmd_complevel >= 0)
			sc->complevel = xmdio->xmd_complevel;
		if (sc->comptype == XMD_TYPE_NONE) {
			sc->complevel = 0;
			xmdio->xmd_complevel = 0;
		}
		if (sc->complevel == 0 && sc->comptype != XMD_TYPE_NONE) {
			sc->complevel = 1;
			xmdio->xmd_complevel = 1;
		}
		if (verbose)
			xmd_print_config(sc);
		break;
	case XMDCTL_QUERY:
		if (xmdio->xmd_unit < 0) {
			xmdio->xmd_unit = xmd_get_maxunit();
			break;
		}
		sc = xmd_find_sc(xmdio->xmd_unit);
		if (sc == NULL)
			return (ENOENT);
		xmdio->xmd_size = sc->size;
		xmdio->xmd_blockcnt = sc->blockcnt;
		xmdio->xmd_blocklen = sc->blocklen;
		xmdio->xmd_comptype = sc->comptype;
		xmdio->xmd_complevel = sc->complevel;

		/* compression memory usage */
		bp = g_new_bio();
		if (bp == NULL)
			return (ENOMEM);
		bp->bio_from = NULL;
		bp->bio_to = sc->pp;
		bp->bio_cmd = XMD_STATUS;
		bp->bio_done = NULL;
		bp->bio_data = (caddr_t)xmdio;
		bp->bio_length = sizeof(*xmdio);
		/* send special CMD */
		bp->bio_to->geom->start(bp);
		error = biowait(bp, "xmdcst");
		g_destroy_bio(bp);
		break;
	case XMDCTL_QUERYNEXT:
		sc = xmd_find_nextsc(xmdio->xmd_unit);
		if (sc == NULL)
			return (ENOENT);
		xmdio->xmd_unit = sc->unit;
		xmdio->xmd_size = sc->size;
		xmdio->xmd_blockcnt = sc->blockcnt;
		xmdio->xmd_blocklen = sc->blocklen;
		xmdio->xmd_comptype = sc->comptype;
		xmdio->xmd_complevel = sc->complevel;

		/* compression memory usage */
		bp = g_new_bio();
		if (bp == NULL)
			return (ENOMEM);
		bp->bio_from = NULL;
		bp->bio_to = sc->pp;
		bp->bio_cmd = XMD_STATUS;
		bp->bio_done = NULL;
		bp->bio_data = (caddr_t)xmdio;
		bp->bio_length = sizeof(*xmdio);
		/* send special CMD */
		bp->bio_to->geom->start(bp);
		error = biowait(bp, "xmdcst");
		g_destroy_bio(bp);
		break;
	case XMDCTL_RDSEG:
		error = EINVAL;
		break;
	case XMDCTL_WRSEG:
		if (xmdio->xmd_unit < 0)
			return (EINVAL);
		sc = xmd_find_sc(xmdio->xmd_unit);
		if (sc == NULL)
			return (ENOENT);

		if (xmdio->xmd_data == NULL)
			return (EINVAL);

		/* direct segment I/O */
		bp = g_new_bio();
		if (bp == NULL)
			return (ENOMEM);
		bp->bio_from = NULL;
		bp->bio_to = sc->pp;
		bp->bio_cmd = XMD_SEGIO;
		bp->bio_done = xmd_bio_done;
		//bp->bio_data = (caddr_t)xmdio->xmd_data;
		bp->bio_length = xmdio->xmd_length;
		bp->bio_offset = sc->seglen * xmdio->xmd_address;
		bp->bio_driver1 = (void*)xmdio;
		if (bp->bio_length > (sc->seglen * 2) ||
		    bp->bio_length > sc->size ||
		    bp->bio_offset > sc->size ||
		    bp->bio_offset > sc->size - bp->bio_length) {
			g_destroy_bio(bp);
			return (EINVAL);
		}
		bp->bio_data = malloc(round_page(bp->bio_length),
		    M_XMD_BLOCK, M_WAITOK);
		if (bp->bio_data == NULL) {
			g_destroy_bio(bp);
			return (ENOMEM);
		}
		copyin(xmdio->xmd_data, bp->bio_data, bp->bio_length);
		wmb();
		/* send special CMD */
		bp->bio_to->geom->start(bp);
		error = biowait(bp, "xmdcst");
		free(bp->bio_data, M_XMD_BLOCK);
		g_destroy_bio(bp);
		break;
	default:
		/* not implemented */
		error = ENOIOCTL;
		break;
	}
	return (error);
}

static int
xmdctl_ioctl(struct cdev *dev, u_long cmd, caddr_t data, int fflag,
    struct thread *td)
{
	int error;

	sx_xlock(&xmd_sx);
	error = xmdctl_ioctl_locked(dev, cmd, data, fflag, td);
	sx_xunlock(&xmd_sx);
	return (error);
}

/* geom class functions */
static void
g_xmd_start(struct bio *bp)
{
	struct xmd_softc *sc;

	/* send BIO to worker */
	sc = bp->bio_to->geom->softc;
	mtx_lock(&sc->queue_mtx);
	bioq_disksort(&sc->bio_queue, bp);
	mtx_unlock(&sc->queue_mtx);
	wakeup(sc);
}

static int
g_xmd_access(struct g_provider *pp, int r, int w, int e)
{
	struct xmd_softc *sc;

	sc = pp->geom->softc;
	if (sc == NULL)
		return (ENXIO);
	return (0);
}

static void
g_xmd_dumpconf(struct sbuf *sb, const char *indent, struct g_geom *gp,
    struct g_consumer *cp __unused, struct g_provider *pp)
{
	struct xmd_softc *sc;

	sc = gp->softc;
	if (sc == NULL)
		return;
	/* not implemented */
}

static void
g_xmd_init(struct g_class *mp)
{
	struct xmd_softc *sc;
#ifdef XMD_ROOT
	caddr_t mod;
	uint8_t *preaddr;
	char *name, *type;
	uint32_t presize;
	int rootfs;
	int error;
#endif

	/* normalize specified size */
	if (xmd_size < XMD_MINSIZE)
		xmd_size = XMD_MINSIZE;
	if (xmd_size > XMD_MAXSIZE)
		xmd_size = XMD_MAXSIZE;
	DPRINTF("disk size = %u\n", xmd_size);

	/* compression level (0-9) */
	if (xmd_complevel < 0)
		xmd_complevel = 1;
	if (xmd_complevel > 9)
		xmd_complevel = 9;
	DPRINTF("compression level = %d\n", xmd_complevel);

	/* compression type 0=none, 2=lz4, 4=zlib, 8=lzma */
	if (xmd_comptype != XMD_TYPE_NONE && xmd_comptype != XMD_TYPE_LZ4 &&
	    xmd_comptype != XMD_TYPE_ZLIB
#ifdef USE_LZMA
	    && xmd_comptype != XMD_TYPE_LZMA
#endif
	    )
		xmd_comptype = XMD_TYPE_LZ4;
	DPRINTF("compression type = %d\n", xmd_comptype);

	/* print current setting */
	verbose = bootverbose;
#ifdef DEBUG
	verbose = 2;
#endif
	printf("xmd version %s %s\n", XMD_VERSION, XMD_AUTHOR);
	xmd_print_config(NULL);

	/* initialize lock */
	sx_init(&xmd_sx, "XMD config lock");
	rw_init(&xmd_free_rw, "XMD free list");

	/* initialize unit number allocator */
	xmd_uh = new_unrhdr(0, INT_MAX - 1, NULL);

	/* special bio command for stopping worker */
	memset(&bio_stopcmd, 0, sizeof(bio_stopcmd));
	bio_stopcmd.bio_cmd = XMD_STOP;

	g_topology_unlock();
#ifdef XMD_ROOT
	/* check enough size */
	if (xmd_rootsize < XMD_MINROOTSIZE)
		xmd_rootsize = XMD_MINROOTSIZE;
	if (xmd_rootsize > XMD_MAXSIZE)
		xmd_rootsize = XMD_MAXSIZE;

	/* setup for rootfs */
	mod = NULL;
	while ((mod = preload_search_next_name(mod)) != NULL) {
		name = (char *)preload_search_info(mod, MODINFO_NAME);
		type = (char *)preload_search_info(mod, MODINFO_TYPE);
		if (name == NULL || type == NULL)
			continue;
		if (strcmp(type, "xmd_root") != 0 &&
		    strcmp(type, "xmd_mfs") != 0)
			continue;
		preaddr = preload_fetch_addr(mod);
		presize = preload_fetch_size(mod);
		if (preaddr != NULL && presize != 0) {
			sx_xlock(&xmd_sx);
			sc = xmd_create(-1, xmd_rootsize, xmd_nblocks);
			if (sc != NULL) {
#ifdef XMD_ROOT_FORCE_LZ4
				/* for fast writing */
				sc->complevel = 1;
				sc->comptype = XMD_TYPE_LZ4;
#else
				sc->complevel = 0;
				sc->comptype = XMD_TYPE_NONE;
#endif
				xmd_init(sc);
				rootfs = (strcmp(type, "xmd_root") == 0) ?
				    1 : 0;
				error = xmd_preload(sc, rootfs, preaddr,
				    presize, name);
				if (error)
					xmd_destroy(sc);
			}
			sx_xunlock(&xmd_sx);
		}
	}
#endif

#if 0
	/* setup for /dev/xmd */
	sx_xlock(&xmd_sx);
	sc = xmd_create(-1, xmd_size, xmd_nblocks);
	if (sc != NULL)
		xmd_init(sc);
	sx_xunlock(&xmd_sx);
#endif

	/* create cdev for ioctl */
	xmd_cdev = make_dev(&xmdctl_cdevsw, INT_MAX, UID_ROOT, GID_WHEEL,
	    0600, XMDCTL_NAME);
	g_topology_lock();
}

static void
g_xmd_fini(struct g_class *mp)
{

	/* destroy lock */
	sx_destroy(&xmd_sx);
	rw_destroy(&xmd_free_rw);
	/* destroy ioctl device */
	if (xmd_cdev != NULL)
		destroy_dev(xmd_cdev);
	/* destroy unit number allocator */
	delete_unrhdr(xmd_uh);
}

static int
g_xmd_destroy(struct gctl_req *req, struct g_class *mp, struct g_geom *gp)
{
	struct xmd_softc *sc;

	/* destroy the disk */
	g_topology_assert();
	sc = gp->softc;
	if (sc == NULL)
		return (ENXIO);
#if 0
	if (verbose)
		printf("destroy xmd%d\n", sc->unit);
	xmd_destroy(sc);
	return (0);
#else
	return (EBUSY);
#endif
}
