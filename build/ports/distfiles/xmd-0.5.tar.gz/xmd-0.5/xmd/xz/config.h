/* config for geom_xmd.ko */

#define VERSION "5.2.2"

#define HAVE_VISIBILITY 1
#define HAVE_SYS_ENDIAN_H 1
#ifdef _KERNEL
#include <machine/endian.h>
#if _BYTE_ORDER == _LITTLE_ENDIAN
#undef WORDS_BIGENDIAN
#else
#define WORDS_BIGENDIAN 1
#endif
#endif /* _KERNEL */

#define HAVE_CHECK_CRC32 1
#undef HAVE_CHECK_CRC64
#undef HAVE_CHECK_SHA256

#define HAVE_MF_BT2 1
#define HAVE_MF_BT3 1
#define HAVE_MF_BT4 1
#define HAVE_MF_HC3 1
#define HAVE_MF_HC4 1

#define HAVE_DECODER_LZMA2 1
#define HAVE_ENCODER_LZMA2 1
#undef HAVE_DECODER_LZMA1
#undef HAVE_ENCODER_LZMA1
#undef HAVE_DECODER_DELTA
#undef HAVE_ENCODER_DELTA
#undef HAVE_DECODER_ARM
#undef HAVE_ENCODER_ARM
#undef HAVE_DECODER_X86
#undef HAVE_ENCODER_X86
