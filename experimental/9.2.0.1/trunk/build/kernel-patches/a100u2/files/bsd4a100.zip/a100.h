/*-
 * Copyright (c) 1998 Initio Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY INITIO CORPORATION ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL INITIO CORPORATION BE LIABLE FOR ANY DIRECT,INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *	$Id: a100scsi.h v 1.00 1998/10/08 se Exp $	
 */


#define BYTE	unsigned char
#define WORD	unsigned short
#define DWORD	unsigned long

#define	ULONG	unsigned long
#define ulong	unsigned long
#define uint	unsigned long
#define USHORT	unsigned short
#define ushort	unsigned short
#define UWORD	unsigned short
#define uword	unsigned short
#define UCHAR	unsigned char
#define uchar	unsigned char
#define UBYTE	unsigned char
#define ubyte	unsigned char

#ifndef NULL
#define NULL	0			/* zero				*/
#endif
#ifndef TRUE
#define TRUE	(1)			/* boolean true			*/
#endif
#ifndef FALSE
#define FALSE	(0)			/* boolean false		*/
#endif


#define A100_SG_ENTRY 32 
#define MAX_SUPPORTED_ADAPTERS 8
#define MAX_TARGETS 16
#define MAX_SCB	32 
#define MAX_SG  32	

#define PAGELEN 4096
#define INI_VENDOR_ID 0x1101

typedef struct{
	unsigned short base;
	unsigned short vec;
}a100_config;




typedef struct _NVRAM {
	/*----------header ---------------*/
	UCHAR	SubVendorID0;		/* 00 - Sub Vendor ID		*/
	UCHAR	SubVendorID1;		/* 01 - Sub Vendor ID		*/
	UCHAR	SubSysID0;		/* 02 - Sub System ID		*/
	UCHAR	SubSysID1;		/* 03 - Sub System ID		*/
	UCHAR	SubClass;		/* 04 - Sub Class		*/
	UCHAR	VendorID0;		/* 05 - Vendor ID		*/
	UCHAR	VendorID1;		/* 06 - Vendor ID		*/
	UCHAR	DeviceID0;		/* 07 - Device ID		*/
	UCHAR	DeviceID1;		/* 08 - Device ID		*/
	UCHAR	Reserved0[2];		/* 09 - Reserved		*/
	UCHAR	Revision;		/* 0B - Revision of data structure */
	/* ----Host Adapter Structure ----*/
	UCHAR	NumOfCh;		/* 0C - Number of SCSI channel	*/
	UCHAR	BIOSConfig1;		/* 0D - BIOS configuration 1	*/
	UCHAR	BIOSConfig2;		/* 0E - BIOS boot channel&target ID */
	UCHAR	BIOSConfig3;		/* 0F - BIOS configuration 3	*/
	/* ----SCSI channel Structure ---- */
	/* from "CTRL-I SCSI Host Adapter SetUp menu "  */
	UCHAR	SCSI0Id;		/* 10 - Channel 0 SCSI ID	*/
	UCHAR	SCSI0Config;		/* 11 - Channel 0 SCSI configuration */
	UCHAR	SCSI0MaxTags;		/* 12 - Channel 0 Maximum tags	*/
	UCHAR	SCSI0ResetTime;		/* 13 - Channel 0 Reset recovering time */
	UCHAR	ReservedforChannel0[2];	/* 14 - Reserved		*/

	/* ----SCSI target Structure ----  */
	/* from "CTRL-I SCSI device SetUp menu "			*/
	UCHAR	Target00Config;		/* 16 - Channel 0 Target 0 config */
	UCHAR	Target01Config;		/* 17 - Channel 0 Target 1 config */
	UCHAR	Target02Config;		/* 18 - Channel 0 Target 2 config */
	UCHAR	Target03Config;		/* 19 - Channel 0 Target 3 config */
	UCHAR	Target04Config;		/* 1A - Channel 0 Target 4 config */
	UCHAR	Target05Config;		/* 1B - Channel 0 Target 5 config */
	UCHAR	Target06Config;		/* 1C - Channel 0 Target 6 config */
	UCHAR	Target07Config;		/* 1D - Channel 0 Target 7 config */
	UCHAR	Target08Config;		/* 1E - Channel 0 Target 8 config */
	UCHAR	Target09Config;		/* 1F - Channel 0 Target 9 config */
	UCHAR	Target0AConfig;		/* 20 - Channel 0 Target A config */
	UCHAR	Target0BConfig;		/* 21 - Channel 0 Target B config */
	UCHAR	Target0CConfig;		/* 22 - Channel 0 Target C config */
	UCHAR	Target0DConfig;		/* 23 - Channel 0 Target D config */
	UCHAR	Target0EConfig;		/* 24 - Channel 0 Target E config */
	UCHAR	Target0FConfig;		/* 25 - Channel 0 Target F config */

	UCHAR	SCSI1Id;		/* 26 - Channel 1 SCSI ID	*/
	UCHAR	SCSI1Config;		/* 27 - Channel 1 SCSI configuration */
	UCHAR	SCSI1MaxTags;		/* 28 - Channel 1 Maximum tags	*/
	UCHAR	SCSI1ResetTime;		/* 29 - Channel 1 Reset recovering time */
	UCHAR	ReservedforChannel1[2];	/* 2A - Reserved		*/

	/* ----SCSI target Structure ----  */
	/* from "CTRL-I SCSI device SetUp menu "  */
	UCHAR	Target10Config;		/* 2C - Channel 1 Target 0 config */
	UCHAR	Target11Config;		/* 2D - Channel 1 Target 1 config */
	UCHAR	Target12Config;		/* 2E - Channel 1 Target 2 config */
	UCHAR	Target13Config;		/* 2F - Channel 1 Target 3 config */
	UCHAR	Target14Config;		/* 30 - Channel 1 Target 4 config */
	UCHAR	Target15Config;		/* 31 - Channel 1 Target 5 config */
	UCHAR	Target16Config;		/* 32 - Channel 1 Target 6 config */
	UCHAR	Target17Config;		/* 33 - Channel 1 Target 7 config */
	UCHAR	Target18Config;		/* 34 - Channel 1 Target 8 config */
	UCHAR	Target19Config;		/* 35 - Channel 1 Target 9 config */
	UCHAR	Target1AConfig;		/* 36 - Channel 1 Target A config */
	UCHAR	Target1BConfig;		/* 37 - Channel 1 Target B config */
	UCHAR	Target1CConfig;		/* 38 - Channel 1 Target C config */
	UCHAR	Target1DConfig;		/* 39 - Channel 1 Target D config */
	UCHAR	Target1EConfig;		/* 3A - Channel 1 Target E config */
	UCHAR	Target1FConfig;		/* 3B - Channel 1 Target F config */
	UCHAR	reserved[3];		/* 3C - Reserved		*/
	/* ---------- CheckSum ----------       */
	UCHAR	CheckSum;		/* 3F - Checksum of NVRam	*/
} NVRAM, *PNVRAM;

/* Bios Configuration for nvram->BIOSConfig1				*/
#define NBC_BIOSENABLE	0x01    	/* BIOS enable			*/
#define NBC_CDROM	0x02		/* Support bootable CDROM	*/
#define NBC_REMOVABLE	0x04		/* Support removable drive	*/

/* Bios Configuration for nvram->BIOSConfig2				*/
#define	NBB_TARGET_MASK	0x0F		/* Boot SCSI target ID number	*/
#define	NBB_CHANL_MASK	0xF0		/* Boot SCSI channel number	*/

/* Bit definition for nvram->SCSIConfig					*/
#define NCC_BUSRESET	0x01		/* Reset SCSI bus at power up	*/
#define NCC_PARITYCHK	0x02		/* SCSI parity enable		*/
#define NCC_LVDS	0x10		/* Enable LVDS			*/
#define NCC_ACTTERM1	0x20		/* Enable active terminator 1	*/
#define NCC_ACTTERM2	0x40		/* Enable active terminator 2	*/
#define NCC_AUTOTERM	0x80		/* Enable auto termination	*/

/* Bit definition for nvram->TargetxConfig				*/
#define	NTC_PERIOD	0x07		/* Maximum Sync. Speed		*/
#define NTC_1GIGA	0x08		/* 255 head / 63 sectors (64/32)*/
#define NTC_NO_SYNC	0x10		/* NO SYNC. NEGO		*/
#define NTC_NO_WIDESYNC	0x20		/* NO WIDE SYNC. NEGO		*/
#define	NTC_DISC_ENABLE	0x40		/* Enable SCSI disconnect	*/
#define NTC_SPINUP	0x80		/* Start disk drive		*/

/* Default NVRam values							*/
#define NBC_DEFAULT	(NBC_ENABLE)
#define NCC_DEFAULT	(NCC_BUSRESET | NCC_AUTOTERM | NCC_PARITYCHK)
#define NCC_MAX_TAGS	0x20		/* Maximum tags per target	*/
#define	NCC_RESET_TIME	0x0A		/* SCSI RESET recovering time	*/
#define NTC_DEFAULT	(NTC_1GIGA | NTC_NO_WIDESYNC | NTC_DISC_ENABLE)

#define DISC_ALLOW	0xC0
#define DISC_NOT_ALLOW	0x80


/*------------------------------------------------------------------*/
/*                              PCI                                                             */
/*------------------------------------------------------------------*/
#define PCI_FUNCTION_ID		0xB1
#define PCI_BIOS_PRESENT	0x01
#define FIND_PCI_DEVICE		0x02
#define FIND_PCI_CLASS_CODE	0x03
#define GENERATE_SPECIAL_CYCLE	0x06
#define READ_CONFIG_BYTE	0x08
#define READ_CONFIG_WORD	0x09
#define READ_CONFIG_DWORD	0x0A
#define WRITE_CONFIG_BYTE	0x0B
#define WRITE_CONFIG_WORD	0x0C
#define WRITE_CONFIG_DWORD	0x0D

#define SUCCESSFUL		0x00
#define FUNC_NOT_SUPPORTED	0x81
#define BAD_VENDOR_ID		0x83	/* Bad vendor ID		*/
#define DEVICE_NOT_FOUND	0x86	/* PCI device not found		*/
#define BAD_REGISTER_NUMBER	0x87

#define MAX_PCI_DEVICES		21	/* Maximum devices supportted	*/


typedef struct _BIOS32_ENTRY_STRUCTURE {
	DWORD Signatures;		/* Should be "_32_"	*/
	DWORD BIOS32Entry;		/* 32-bit physical address	*/
	BYTE  Revision;			/* Revision level, should be 0	*/
	BYTE  Length;			/* Multiply of 16, should be 1	*/
	BYTE  CheckSum;			/* Checksum of whole structure	*/
	BYTE  Reserved[5];		/* Reserved			*/
} BIOS32_ENTRY_STRUCTURE, *PBIOS32_ENTRY_STRUCTURE;

typedef struct
   {
   union
	{
	unsigned int eax;
	struct
	    {
	    unsigned short ax;
	    } word;
	struct
	    {
	    unsigned char al;
	    unsigned char ah;
	    } byte;
	} eax;
    union
	{
	unsigned int ebx;
	struct
	    {
	    unsigned short bx;
	    } word;
	struct
	    {
	    unsigned char bl;
	    unsigned char bh;
	    } byte;
	} ebx;
    union
	{
	unsigned int ecx;
	struct
	    {
	    unsigned short cx;
	    } word;
	struct
	    {
	    unsigned char cl;
	    unsigned char ch;
	    } byte;
	} ecx;
    union
	{
	unsigned int edx;
	struct
	    {
	    unsigned short dx;
	    } word;
	struct
	    {
	    unsigned char dl;
	    unsigned char dh;
	    } byte;
	} edx;
    union
	{
	unsigned int edi;
	struct
	    {
	    unsigned short di;
	    } word;
	} edi;
    union
	{
	unsigned int esi;
	struct
	    {
	    unsigned short si;
	    } word;
	} esi;
    } REGS;

typedef union				/* Union define for mechanism 1	*/
    {
    struct
	{
	unsigned char RegNum;
	unsigned char FcnNum:3;
	unsigned char DeviceNum:5;
	unsigned char BusNum;
	unsigned char Reserved:7;
	unsigned char Enable:1;
	}	  sConfigAdr;
    unsigned long lConfigAdr;
    } CONFIG_ADR;

typedef union				/* Union define for mechanism 2	*/
    {
    struct
	{
	unsigned char RegNum;
	unsigned char DeviceNum;
	unsigned short Reserved;
	}	  sHostAdr;
    unsigned long lHostAdr;
    } HOST_ADR;

typedef struct _HCSinfo
    {
    ULONG  base;
    UCHAR  vec;
    UCHAR  bios;			/* High byte of BIOS address	*/
    USHORT BaseAndBios;			/* high byte: pHcsInfo->bios,low byte:pHcsInfo->base */
    } HCSINFO ;

/********************************************************/
/*	 Configuration Register Set		*/
/********************************************************/
#define ORC_PVID	0x00		/* Vendor ID			*/
#define ORC_VENDOR_ID	0x1101		/* Orchid vendor ID		*/
#define ORC_PDID        0x02            /* Device ID                    */
#define ORC_DEVICE_ID	0x1060		/* Orchid device ID		*/
#define ORC_COMMAND	0x04		/* Command			*/
#define BUSMS		0x04		/* BUS MASTER Enable		*/
#define IOSPA		0x01		/* IO Space Enable		*/
#define ORC_STATUS	0x06		/* Status register		*/
#define ORC_REVISION	0x08		/* Revision number		*/
#define ORC_BASE	0x10		/* Base address			*/
#define ORC_BIOS	0x30		/* Expansion ROM base address	*/
#define ORC_INT_NUM	0x3C		/* Interrupt line		*/
#define ORC_INT_PIN	0x3D		/* Interrupt pin		*/


/********************************************************/
/*	 Host Command Set				*/
/********************************************************/
#define ORC_CMD_NOP		0x00	/* Host command - NOP		*/
#define ORC_CMD_VERSION		0x01	/* Host command - Get F/W version */
#define ORC_CMD_ECHO		0x02	/* Host command - ECHO		*/
#define ORC_CMD_SET_NVM		0x03	/* Host command - Set NVRAM	*/
#define ORC_CMD_GET_NVM		0x04	/* Host command - Get NVRAM	*/
#define ORC_CMD_GET_BUS_STATUS	0x05	/* Host command - Get SCSI bus status */
#define ORC_CMD_ABORT_SCB	0x06	/* Host command - Abort SCB	*/
#define ORC_CMD_ISSUE_SCB	0x07	/* Host command - Issue SCB	*/

/********************************************************/
/*	 Register Set			*/
/********************************************************/
#define ORC_GINTS	0xA0		/* Global Interrupt Status	*/
#define QINT		0x04		/* Reply Queue Interrupt	*/
#define ORC_GIMSK	0xA1		/* Global Interrupt MASK	*/
#define MQINT		0x04		/* Mask Reply Queue Interrupt	*/
#define ORC_GCFG	0xA2		/* Global Config 	        */
#define EEPRG		0x01		/* Enable EEPROM programming	*/
#define	ORC_GSTAT	0xA3		/* Global status		*/
#define WIDEBUS		0x20		/* Wide SCSI Devices connected	*/
#define ORC_HDATA	0xA4		/* Host Data			*/
#define ORC_HCTRL	0xA5		/* Host Control			*/
#define SCSIRST		0x80		/* SCSI bus reset		*/
#define HDO		0x40		/* Host data out		*/
#define HOSTSTOP	0x02		/* Host stop RISC engine	*/
#define DEVRST		0x01		/* Device reset			*/
#define ORC_HSTUS	0xA6		/* Host Status			*/
#define HDI		0x02		/* Host data in			*/
#define RREADY		0x01		/* RISC engine is ready to receive */
#define	ORC_NVRAM	0xA7		/* Nvram port address		*/
#define SE2CS		0x008
#define SE2CLK		0x004
#define SE2DO		0x002
#define SE2DI		0x001
#define ORC_PQUEUE	0xA8		/* Posting queue FIFO		*/
#define ORC_RQUEUE	0xAA		/* Reply queue FIFO		*/
#define ORC_RQUEUECNT	0xAB		/* Reply queue FIFO count	*/

#define	ORC_FWBASEADR	0xAC		/* Firmware base address	*/

#define	ORC_EBIOSADR0	0xB0		/* External BIOS address 	*/
#define	ORC_EBIOSADR1	0xB1		/* External BIOS address 	*/
#define	ORC_EBIOSADR2	0xB2		/* External BIOS address 	*/
#define	ORC_EBIOSDATA	0xB3		/* External BIOS data	 	*/

#define	ORC_SCBSIZE	0xB7		/* SCB size register		*/
#define	ORC_SCBBASE0	0xB8		/* SCB base address 0		*/
#define	ORC_SCBBASE1	0xBC		/* SCB base address 1		*/

#define ORC_RISCCTL	0xE0		/* RISC Control			*/
#define PRGMRST		0x02		/* Program Counter Reset	*/
#define DOWNLOAD	0x01		/* Download Firmware		*/

#define ORC_RISCRAM	0xEC

/***********************************************************************
		Scatter-Gather Element Structure
************************************************************************/
typedef struct SG_Struc {
	ULONG	SG_Ptr;			/* Data Pointer			*/
	ULONG	SG_Len;			/* Data Length			*/
} A100_SG;



/************************************************************************
		SCSI Control Block
*************************************************************************/

typedef struct A100_Scsi_Ctrl_Blk 
{					/* Scsi_Ctrl_Blk		*/
	UBYTE	SCB_Opcode;		/*00 SCB command code&residual	*/
	UBYTE	SCB_Flags;		/*01 SCB Flags			*/
	UBYTE	SCB_Target;		/*02 Target Id			*/
	UBYTE	SCB_Lun;		/*03 Lun			*/
	ULONG	SCB_Reserved0;		/*04 Reserved for ORCHID must 0	*/
	ULONG	SCB_XferLen;		/*08 Data Transfer Length	*/
	ULONG	SCB_Reserved1;		/*0C Reserved for ORCHID must 0	*/
	ULONG	SCB_SGLen;		/*10 SG list # * 8		*/
	ULONG	SCB_SGPAddr;		/*14 SG List Buf physical Addr	*/
	ULONG	SCB_SGPAddrHigh;	/*18 SG Buffer high physical Addr */
	UBYTE	SCB_HaStat;		/*1C Host Status		*/
	UBYTE	SCB_TaStat;		/*1D Target Status		*/
	UBYTE	SCB_Status;		/*1E SCB status			*/
	UBYTE	SCB_Link;		/*1F Link pointer, default 0xFF	*/

	UBYTE	SCB_SenseLen;		/*20 Sense Allocation Length	*/
	UBYTE	SCB_CDBLen;		/*21 CDB Length			*/
	UBYTE	SCB_Ident;		/*22 Identify			*/
	UBYTE	SCB_TagMsg;		/*23 Tag Message		*/
	UBYTE	SCB_CDB[14];		/*24 SCSI CDBs			*/
 
 
	UBYTE	SCB_ScbIdx;		/*32 Index for this ORCSCB	*/
	UBYTE	SCB_FreeFlag;		/*33 Free flag for this ORCSCB	*/
	ULONG	SCB_SensePAddr;		/*34 Sense Buffer physical Addr	*/


	ULONG	SCB_ccb;	
	struct A100_Scsi_Ctrl_Blk 	*SCB_NextScb;
    	
} A100_SCB;

/* Opcodes of ORCSCB_Opcode */
#define ExecSCSI	0x00		/* SCSI initiator command with residual */
#define BusDevRst	0x01		/* SCSI Bus Device Reset	*/

/* Status of ORCSCB_Status */
#define SCB_COMPLETE	0x00		/* SCB request completed	*/
#define SCB_POST	0x01		/* SCB is posted by the HOST	*/

/* Bit Definition for ORCSCB_Flags */
#define SCF_NO_DCHK	0x00		/* Direction determined by SCSI	*/
#define SCF_DIN		0x01		/* From Target to Initiator	*/
#define SCF_DOUT	0x10		/* From Initiator to Target	*/
#define SCF_NO_XF	0x11		/* No data transfer		*/
#define SCF_POLL	0x40		/* No interrupt 		*/



/* Error Codes for ORCSCB_HaStat */
#define HOST_OK		0x00
#define HOST_SEL_TOUT	0x11
#define HOST_DO_DU	0x12
#define HOST_BUS_FREE	0x13
#define HOST_BAD_PHAS	0x14
#define HOST_INV_CMD	0x16
#define HOST_ABORTED	0x1A
#define HOST_SCSI_RST	0x1B
#define HOST_DEV_RST	0x1C


/* Error Codes for ORCSCB_TaStat */
#define TARGET_GOOD	0x00
#define TARGET_CHKCOND	0x02
#define TARGET_BUSY	0x08
#define TARGET_QFULL	0x28


/* Queue tag msg: Simple_quque_tag, Head_of_queue_tag, Ordered_queue_tag */
#define MSG_STAG	0x20
#define MSG_HTAG	0x21
#define MSG_OTAG	0x22

#define MSG_IGNOREWIDE	0x23

#define MSG_IDENT	0x80
#define MSG_DISC	0x40		/* Disconnect allowed		*/

/************************************************************************
			  Host Adapter Control Structure
*************************************************************************/

typedef struct A100_Ha_Ctrl_Struc
{					/* Ha_Ctrl_Struc		*/
	ULONG		HCS_Base;
	UBYTE		HCS_MaxTar;
	UBYTE		HCS_HaId;
	UBYTE		HCS_Intr;
	UBYTE		HCS_Unit;
	UBYTE		HCS_Flags;
	UBYTE		HCS_SCSI_ID;

	bus_dma_tag_t	parent_dmat;
	bus_dma_tag_t	buffer_dmat;
	bus_dmamap_t	dmamap;
	struct		cam_sim  *sim;
	struct		cam_path *path;

	A100_SCB	*HCS_FirstAvail;
	A100_SCB	*HCS_LastAvail;
	A100_SCB	*HCS_FirstPend;
	A100_SCB	*HCS_LastPend;



	A100_SCB	*pScbArray;
	ULONG		pPhyScbArray;

	A100_SG		*SGList;
	ULONG		pPhySG;

	UBYTE		TargetFlag[16];
	UBYTE		MaximumTags[16];
	UBYTE		ActiveTags[16];


} A100_HCS;


/* Bit Definition for TargetFlag */

#define TCF_EN_TAG	0x10
#define TCF_BUSY	0x20


/* INI1060 specific port driver device object extension. */
typedef struct A100_Adpt_Struc{
	UWORD ADPT_BIOS;
	UWORD ADPT_BASE;
	UBYTE ADPT_Bus;
	UBYTE ADPT_Device;
	UBYTE ADPT_INTR;
}INI_ADPT_STRUCT;




