
FreeBSD Installation with IOI Controllers

While these procedures are easy, you should thoroughly read and understand 
all the steps before you begin. 

You will now have source code and put them under /usr/src/sys/pci. 
We give source code name as following:
	source code a100.c and a100.h, driver name ihb.

Next,you should do following steps:

1.Add one line in /usr/src/sys/conf/files for IOI-A100U2W respectively:
	pci/a100.c		optional ihb device-driver


2.Enter /usr/src/sys/i386/conf,copy the GENERIC configuration file 
to the name you want to give your kernel,MYA100 in this example.Add
one lines in MYA100:
	device		ihb0

3.Type the following to compile and install your kernel: 
	# /usr/sbin/config MYA100
	# cd ../../compile/MYA100
	# make depend
	# make
	# make install
The new kernel will be copied to the root directory as /kernel and 
the old kernel will be moved to /kernel.old. The new kernel contains 
IOI-A100U2W drivers.

4.Shutdown the system and reboot to use your kernel. In case something 
goes wrong, look information in 
	http://www.freebsd.org/handbook
	http://www.freebsd.org/FAQ/FAQ.html
	
