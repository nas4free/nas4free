/*-
 * Copyright (c) 1998 Initio Corporation
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY INITIO CORPORATION ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL INITIO CORPORATION BE LIABLE FOR ANY DIRECT,INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *	$Id: a100scsi.c v 1.00 1998/10/08 se Exp $	
 */

#include <sys/param.h>

#include <sys/systm.h>
#include <sys/malloc.h>
#include <sys/queue.h>
#include <sys/types.h>
#include <sys/buf.h>
#include <sys/conf.h>
#include <sys/kernel.h>
#include <sys/sysctl.h>
#include <sys/fcntl.h>
#include <vm/vm.h>
#include <vm/pmap.h>

#include <pci/pcivar.h>
#include <pci/pcireg.h>

#include <cam/cam.h>
#include <cam/cam_ccb.h>
#include <cam/cam_sim.h>
#include <cam/cam_xpt.h>
#include <cam/cam_xpt_sim.h>
#include <cam/cam_xpt_periph.h>
#include <cam/cam_debug.h>

#include <cam/scsi/scsi_all.h>
#include <cam/scsi/scsi_message.h>

#include <machine/bus_pio.h>
#include <machine/bus.h>
#include <machine/clock.h>


#include <pci/a100.h>




#define INT32	  int32
#define U_INT32   u_int32

#ifdef __alpha__
/* XXX */
#undef vtophys
#define	vtophys(va)	(pmap_kextract(((vm_offset_t) (va))) \
			 + 1*1024*1024*1024)
#endif

/*==========================================================
**
**	Access to the controller chip.
**
**==========================================================
*/
#define OutB(val, port) 		outb(port, val)
#define OutW(val, port) 		outw(port, val)
#define OutL(val, port) 		outl(port, val)

#define PCI_DEVICE_ID_INIC1060 	0x10601101ul
#define PCI_DEVICE_ID_INIC850 	0x08501101ul
#define PCI_BASEADDR0			0x10

#define ccb_a100_ptr spriv_ptr1

static  void    a100_wakeup(A100_HCS *hcsp, u_long code);

static	char*	a100_probe( pcici_t tag, pcidi_t type);
static	void	a100_attach( pcici_t tag, int unit);

static int orc_waitChipReady(A100_HCS *hcsp);
static int orc_waitFWReady(A100_HCS *hcsp);
static int orc_waitSCSIRSTdone(A100_HCS *hcsp);
static int orc_waitStopOn(A100_HCS *hcsp);
static int orc_waitHDOoff(A100_HCS *hcsp);
static int orc_waitHDIset(A100_HCS *hcsp,UCHAR *pData);

static int orc_get_FW_version(A100_HCS *hcsp, unsigned short *version);
unsigned long orc_get_echo(A100_HCS *hcsp, unsigned long lValue);
static int orc_set_NVRAM(A100_HCS *hcsp, unsigned char address, unsigned char value);
unsigned char orc_get_NVRAM(A100_HCS *hcsp, unsigned char address,unsigned char *pDataIn);
unsigned char orc_get_Bus_Status(A100_HCS *hcsp);
unsigned char orc_abort_SCB(A100_HCS *hcsp, A100_SCB *pScb);
static int orc_push_SCB(A100_HCS *hcsp, A100_SCB *pScb);
static void orc_send_scb(A100_HCS *hcsp, A100_SCB *scbp);


static int orc_rd_all(A100_HCS *hcsp);
void orc_update_all(A100_HCS *hcsp);
void orc_read_eeprom(A100_HCS *hcsp);
static int orc_load_FW(A100_HCS *hcsp);
static void orc_isr (A100_HCS *pHcs);


static void orc_setup_SCBs(A100_HCS *hcsp);

static int orc_init(A100_HCS *hcsp, A100_SCB *pScb,A100_SG *pSG);

static void orc_append_pend_scb(A100_HCS *pHcs, A100_SCB *scbp);

static A100_SCB *orc_abort_srb(A100_HCS *pHcs, ULONG srbp);

static A100_SCB * orc_alloc_scb(A100_HCS *pHcs);
static void orc_release_scb(A100_HCS *pHcs, A100_SCB *pScb);

static void a100_free_scb(A100_HCS *pHcs, A100_SCB *pScb);

static int a100_wait_scb(A100_HCS *pHcs,A100_SCB *pScb,int time);


static void a100_send_scb(A100_HCS *pHcs);
static void a100_exec_scb(void *arg, bus_dma_segment_t *dm_segs, int nseg, int error);
static void a100_timeout( void *arg1);
static void a100_done(A100_HCS *pHcs, A100_SCB *pScb);




static  void a100_action(struct cam_sim *sim, union ccb *ccb);
static  void a100_poll(struct cam_sim *sim);
static	void a100_min_phys( struct buf *pbuf);




/* 
 * The overrun buffer shared amongst all PCI adapters.
 */

static  u_int8_t*	overrun_buf;
bus_dma_tag_t		overrun_dmat;
bus_dmamap_t		overrun_dmamap;
bus_addr_t		overrun_physbase;

static struct intr_config_hook	*a100_config_hook;

static u_long	ihb_count;


struct	pci_device   a100_device = {
	"ihb",
	a100_probe,
	a100_attach,
	&ihb_count,
	NULL
};

/*DATA_SET (pcidevice_set,a100_device);
*/
COMPAT_PCI_DRIVER (ihb,a100_device);






static NVRAM nvram,*nvramp = &nvram;
static UCHAR dftNvRam[64] = {
	0x01,
	0x11,
	0x60,
	0x10,
	0x00,
	0x01,
	0x11,
	0x60,
	0x10,
	0x00,
	0x00,
	0x01,

	0x01,
	0x01,
	0x00,
	0x00,

	0x07,
	0x83,
	0x20,
	0x0A,
	0x00,
	0x00,

	0xC8,0xC8,0xC8,0xC8,
	0xC8,0xC8,0xC8,0xC8,
	0xC8,0xC8,0xC8,0xC8,
	0xC8,0xC8,0xC8,0xC8,

	0x07,
	0x83,
	0x20,
  	0x0A,
	0x00,
	0x00,

	0xC8,0xC8,0xC8,0xC8,
	0xC8,0xC8,0xC8,0xC8,
	0xC8,0xC8,0xC8,0xC8,
	0xC8,0xC8,0xC8,0xC8,

	0x00,
	0x00,
	0x00,
	0x00
};





static int orc_waitChipReady(A100_HCS *hcsp)
{
	int i;
 	for(i = 0;i<2000;i++)
	{
		if(inb(hcsp->HCS_Base+ORC_HCTRL) & HOSTSTOP)
		return (TRUE);
		DELAY(1000);		/* 1 ms */
	}
	return(FALSE);
}
	

static int orc_waitFWReady(A100_HCS *hcsp)
{
	int i;
 	for(i = 0;i<2000;i++)
	{
		if(inb(hcsp->HCS_Base+ORC_HSTUS) & RREADY)
		return (TRUE);
		DELAY(1000);		/* 1 ms */
	}
	return(FALSE);
}


static int orc_waitSCSIRSTdone(A100_HCS *hcsp)
{
	int i;
 	for(i = 0;i<2000;i++)
	{
		if(!(inb(hcsp->HCS_Base+ORC_HCTRL) & SCSIRST))
		return (TRUE);
		DELAY(1000);		/* 1 ms */
	}
	return(FALSE);
}


static int orc_waitStopOn(A100_HCS *hcsp)
{
	int i;
 	for(i = 0;i<2000;i++)
	{
		if(!(inb(hcsp->HCS_Base+ORC_HCTRL) & SCSIRST))
		return (TRUE);
		DELAY(1000);		/* 1 ms */
	}
	return(FALSE);
}


static int orc_waitHDOoff(A100_HCS *hcsp)
{
	int i;
 	for(i = 0;i<2000;i++)
	{
		if(!(inb(hcsp->HCS_Base+ORC_HCTRL) & HDO))
		return (TRUE);
		DELAY(1000);		/* 1 ms */
	}
	return(FALSE);
}



static int orc_waitHDIset(A100_HCS *hcsp,UCHAR *pData)
{
	int i;
 	for(i = 0;i<2000;i++)
	{
		if((*pData = inb(hcsp->HCS_Base+ORC_HSTUS)) & HDI)
		return (TRUE);
		DELAY(1000);		/* 1 ms */
	}
	return(FALSE);
}



static int orc_get_FW_version(A100_HCS *hcsp, unsigned short *version)
{
	UCHAR *pVersion, bData;

	pVersion = (unsigned char *) version;
	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_VERSION);
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pVersion++ = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/

	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pVersion = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/

	return (TRUE);
}


/***************************************************************************/
unsigned long orc_get_echo(A100_HCS *hcsp, unsigned long lValue)
{
	unsigned long lDataIn, *pData;
	UCHAR	bData;

	pData = &lValue;
	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_ECHO);
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, *pData++);	/* Write byte 0	*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, *pData++);	/* Write byte 1	*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, *pData++);	/* Write byte 2	*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, *pData++);	/* Write byte 3	*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	pData = &lDataIn;

	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pData++ = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/


	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pData++ = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/


	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pData++ = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/


	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pData++ = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/

	return (lDataIn);
}

/***************************************************************************/
static int orc_set_NVRAM(A100_HCS *hcsp, unsigned char address, unsigned char value)
{

	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_SET_NVM);/* Write command*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, address);	/* Write address*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, value);		/* Write value	*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	return (TRUE);
}

/***************************************************************************/
unsigned char orc_get_NVRAM(A100_HCS *hcsp, unsigned char address,unsigned char *pDataIn)
{
	unsigned char	 bData;

	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_GET_NVM);/* Write command*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, address);	/* Write address*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);


	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	*pDataIn = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/

	return (TRUE);
}


/***************************************************************************/
unsigned char orc_get_Bus_Status(A100_HCS *hcsp)
{
	unsigned char	bStatus, bData;

	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_GET_BUS_STATUS);/* Write command*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)		/* Wait HDO off	*/
	return (FALSE);


	if (orc_waitHDIset(hcsp, &bData) == FALSE)	/* Wait HDI set	*/
	return (FALSE);
	bStatus = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		/* Clear HDI	*/

	return (bStatus);
}


/***************************************************************************/
unsigned char orc_abort_SCB(A100_HCS *hcsp, A100_SCB *pScb)
{
	unsigned char	bStatus, bData;

	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_ABORT_SCB);/* Write command*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)           	  /* Wait HDO off*/
		return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, pScb->SCB_ScbIdx); /* Write address*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == FALSE)	       	  /* Wait HDO off*/
		return (FALSE);


	if (orc_waitHDIset(hcsp, &bData) == FALSE)	  /* Wait HDI set*/
		return (FALSE);
	bStatus = inb(hcsp->HCS_Base+ORC_HDATA);
	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		  /* Clear HDI	*/

	if(bStatus == 0)
		return (TRUE);
	else
		return (FALSE);
}

/***************************************************************************/
static int orc_push_SCB(A100_HCS *hcsp, A100_SCB *pScb)
{
	UCHAR	bData;

	outb(hcsp->HCS_Base+ORC_HDATA, ORC_CMD_ISSUE_SCB);/* Write command*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == 0)			 /* Wait HDO off*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HDATA, pScb->SCB_ScbIdx);/* Write address*/
	outb(hcsp->HCS_Base+ORC_HCTRL, HDO);
	if (orc_waitHDOoff(hcsp) == 0)			 /* Wait HDO off*/
	return (FALSE);


	if (orc_waitHDIset(hcsp, &bData) == 0)		 /* Wait HDI set*/
	return (FALSE);

	outb(hcsp->HCS_Base+ORC_HSTUS, bData);		 /* Clear HDI	*/

	return (TRUE);
}

/***************************************************************************/
static void orc_send_scb(A100_HCS *hcsp, A100_SCB *scbp)
{
	scbp->SCB_Status = SCB_POST;

	outb(hcsp->HCS_Base+ORC_PQUEUE, scbp->SCB_ScbIdx);

}



/***********************************************************************
 Read SCSI H/A configuration parameters from serial EEPROM
************************************************************************/
static int orc_rd_all(A100_HCS *hcsp)
{
	int i;
	UCHAR *np, chksum = 0;

	np = (UCHAR *) nvramp;
	for (i = 0; i < 64; i++,np++) {
		if(orc_get_NVRAM(hcsp, (unsigned char ) i,np) == FALSE)
		return -1;
	}
					/*------ Is ckecksum ok ? ------*/
	np = (UCHAR *) nvramp;
	for (i = 0; i < 63; i++)
	chksum += *np++;
	if (nvramp->CheckSum != (UCHAR) chksum)
	return -1;
    
	return 1;
}

/************************************************************************
 Update SCSI H/A configuration parameters from serial EEPROM
*************************************************************************/
void orc_update_all(A100_HCS *hcsp)		 /* setup default pattern*/
{
	int i;
	UCHAR *np, *np1, chksum = 0;		 /* Calculate checksum first*/
	np = (UCHAR *) dftNvRam;
	for (i = 0; i < 63; i++)
	chksum += *np++;
	*np = chksum;

	np = (UCHAR *) dftNvRam;
	np1 = (UCHAR *) nvramp;
	for (i = 0; i < 64; i++, np++, np1++) {
		if (*np != *np1) {
		orc_set_NVRAM(hcsp, (unsigned char) i, *np);
		}
	}
	return;
}

/*************************************************************************
 Function name  : read_eeprom
**************************************************************************/
void orc_read_eeprom(A100_HCS *hcsp)
{
	if (orc_rd_all(hcsp) != 1) {
		orc_update_all( hcsp);		/* setup default pattern*/
		orc_rd_all(hcsp);		/* load again		*/
	}
}


/***************************************************************************/
static int orc_load_FW(A100_HCS *hcsp)
{
	unsigned long	dData;
	unsigned short	wBIOSAddress, i;
	unsigned char	*pData, bData;


	bData = inb(hcsp->HCS_Base+ORC_GCFG);
	outb(hcsp->HCS_Base+ORC_GCFG, bData | EEPRG);	/* Enable EEPROM programming */
	outb(hcsp->HCS_Base+ORC_EBIOSADR2, 0x00);
	outw(hcsp->HCS_Base+ORC_EBIOSADR0, 0x00);
	if (inb(hcsp->HCS_Base+ORC_EBIOSDATA) != 0x55) {
		outb(hcsp->HCS_Base+ORC_GCFG, bData);	/* Disable EEPROM programming */
		return (FALSE);
	}
	outw(hcsp->HCS_Base+ORC_EBIOSADR0, 0x01);
	if (inb(hcsp->HCS_Base+ORC_EBIOSDATA) != 0xAA) {
		outb(hcsp->HCS_Base+ORC_GCFG, bData);	/* Disable EEPROM programming */
		return (FALSE);
	}

	outb(hcsp->HCS_Base+ORC_RISCCTL, PRGMRST | DOWNLOAD);/* Enable SRAM programming */
	pData = (UCHAR *) &dData;
	dData = 0;					/* Initial FW address to 0 */
	outw(hcsp->HCS_Base+ORC_EBIOSADR0, 0x10);
	*pData = inb(hcsp->HCS_Base+ORC_EBIOSDATA);	/* Read from BIOS */
	outw(hcsp->HCS_Base+ORC_EBIOSADR0, 0x11);
	*(pData + 1) = inb(hcsp->HCS_Base+ORC_EBIOSDATA);/* Read from BIOS */
	outw(hcsp->HCS_Base+ORC_EBIOSADR0, 0x12);
	*(pData + 2) = inb(hcsp->HCS_Base+ORC_EBIOSDATA);/* Read from BIOS */
	outb(hcsp->HCS_Base+ORC_EBIOSADR2, *(pData+2));
	outl(hcsp->HCS_Base+ORC_FWBASEADR, dData);	/* Write FW address */

	wBIOSAddress = (unsigned short) dData;
	for (i = 0, pData = (unsigned char *) &dData;	/* Download the code*/
	 i < 0x1000;			/* Firmware code size = 4K	*/
	 i++, wBIOSAddress++) {
		outw(hcsp->HCS_Base+ORC_EBIOSADR0, wBIOSAddress);
		*pData++ = inb(hcsp->HCS_Base+ORC_EBIOSDATA);/*Read from BIOS */
		if ((i % 4) == 3) {
			outl(hcsp->HCS_Base+ORC_RISCRAM, dData);	/* Write every 4 bytes */
			pData = (unsigned char *) &dData;
		}
	}

	outb(hcsp->HCS_Base+ORC_RISCCTL, PRGMRST | DOWNLOAD);/* Reset program count 0 */
	wBIOSAddress -= 0x1000;		/* Reset the BIOS adddress	*/
	for (i = 0, pData = (unsigned char *) &dData;	/* Check the code	*/
	 i < 0x1000;			/* Firmware code size = 4K	*/
	 i++, wBIOSAddress++) {
		outw(hcsp->HCS_Base+ORC_EBIOSADR0, wBIOSAddress);
		*pData++ = inb(hcsp->HCS_Base+ORC_EBIOSDATA);/* Read from BIOS */
		if ((i % 4) == 3) {
			if (inl(hcsp->HCS_Base+ORC_RISCRAM) != dData) {
				outb(hcsp->HCS_Base+ORC_RISCCTL, PRGMRST);/* Reset program to 0 */
				outb(hcsp->HCS_Base+ORC_GCFG, bData);	/*Disable EEPROM programming*/
				return (FALSE);
			}
			pData = (unsigned char *) &dData;
		}
	}
	outb(hcsp->HCS_Base+ORC_RISCCTL, PRGMRST);	/* Reset program to 0*/
	outb(hcsp->HCS_Base+ORC_GCFG, bData);	/* Disable EEPROM programming */
	return (TRUE);
}


/***************************************************************************/
static void orc_setup_SCBs(A100_HCS *hcsp)
{
	A100_SCB	*pTmpScb, *pPrevScb;
	int		i;

	pPrevScb = NULL;
	/* Setup SCB Base and SCB Size registers */
	outb(hcsp->HCS_Base+ORC_SCBSIZE, MAX_SCB );		/* Total number of SCBs */
	outl(hcsp->HCS_Base+ORC_SCBBASE0, hcsp->pPhyScbArray);  /* SCB base address 0	*/
	outl(hcsp->HCS_Base+ORC_SCBBASE1, hcsp->pPhyScbArray);	/* SCB base address 1	*/

	for (i = 0, pTmpScb = hcsp->pScbArray; i < MAX_SCB ; i++, pTmpScb++) {
		pTmpScb->SCB_ScbIdx = i;
	 	pTmpScb->SCB_Reserved0 = 0;
		pTmpScb->SCB_Reserved1 = 0;
		pTmpScb->SCB_SGPAddrHigh = 0;
		pTmpScb->SCB_Link = 0xff;
		pTmpScb->SCB_Status = 0;
		pTmpScb->SCB_TagMsg = 0;
		pTmpScb->SCB_FreeFlag = 0;
		if(i != 0)
			pPrevScb->SCB_NextScb = pTmpScb;
		pPrevScb = pTmpScb;
	}

	pPrevScb->SCB_NextScb = NULL;
	hcsp->HCS_FirstAvail = hcsp->pScbArray;
	hcsp->HCS_LastAvail = pPrevScb;


	return;
}

/***************************************************************************/
static int orc_init(A100_HCS *hcsp, A100_SCB *pScb,A100_SG *pSG)
{
	UBYTE	readByte, *readBytep;
	USHORT	revision;
	ULONG	i, j;

	hcsp->pScbArray = pScb;
	hcsp->pPhyScbArray = (ULONG) vtophys(pScb);

	hcsp->SGList = pSG;
	hcsp->pPhySG = (ULONG) vtophys(pSG);

	hcsp->HCS_FirstPend = NULL;
	hcsp->HCS_LastPend = NULL;


	outb(hcsp->HCS_Base+ORC_GIMSK, 0xFF);	/* Disable all interrupt*/
	if (inb(hcsp->HCS_Base+ORC_HSTUS) & RREADY) {
		orc_get_FW_version(hcsp, &revision);
		if (revision == 0xFFFF) {
			outb(hcsp->HCS_Base+ORC_HCTRL, DEVRST);
			if (orc_waitChipReady(hcsp) == FALSE)	/* Wait HOSTSTOP reset	*/
			return (1);
			orc_load_FW(hcsp);			/* Download FW*/
			orc_setup_SCBs(hcsp);			/* Setup SCB Base and SCB Size registers*/

			outb(hcsp->HCS_Base+ORC_HCTRL, 0);	/* clear HOSTSTOP	*/
			if (orc_waitFWReady(hcsp) == FALSE)
			return (1);
		}
		else {
			orc_setup_SCBs(hcsp);			/* Setup SCB Base and SCB Size registers*/
		}
	}
	else {							/* Orchid is not Ready	*/
		outb(hcsp->HCS_Base+ORC_HCTRL, DEVRST);		/* Reset Host Adapter	*/
		if (orc_waitChipReady(hcsp) == FALSE)		/* Wait HOSTSTOP reset	*/
		return (1);
		orc_load_FW(hcsp);				/* Download FW*/
		orc_setup_SCBs(hcsp);				/* Setup SCB Base and SCB Size registers*/
		outb(hcsp->HCS_Base+ORC_HCTRL, HDO);		/* Do Hardware Reset &	*/
		if (orc_waitFWReady(hcsp) == FALSE)
			return (1);

	}

	/*------------- get serial EEProm settting -------*/

	orc_read_eeprom(hcsp);

	if (nvramp->Revision != 1)
	return(-1);

	hcsp->HCS_SCSI_ID = nvramp->SCSI0Id;

	if(inb(hcsp->HCS_Base+ORC_GSTAT) & WIDEBUS)
   		hcsp->HCS_MaxTar = 16;
	else
   		hcsp->HCS_MaxTar = 8;
 
	readBytep = (UCHAR*) &(nvramp->Target00Config);
	for (i = 0; i < 16; readBytep++, i++) {
		hcsp->TargetFlag[i] = (*readBytep) & (~TCF_BUSY);
		hcsp->MaximumTags[i] = MAX_SCB;
		hcsp->ActiveTags[i] = 0;
	}

	if (nvramp->SCSI0Config & NCC_BUSRESET) {		/* Reset SCSI bus*/
		printf("ihb%d:Reset SCSI Bus..\n",hcsp->HCS_Unit);
		outb(hcsp->HCS_Base+ORC_HCTRL, SCSIRST);	/* Do Hardware Reset &	*/
		DELAY(50000);
	}
	outb(hcsp->HCS_Base+ORC_GIMSK, 0xFB);			/* enable Reply FIFO interrupt	*/
	return (0);
}






static void orc_append_pend_scb(A100_HCS *pHcs, A100_SCB *scbp)
{
	int       flags;

	scbp->SCB_NextScb = NULL;

	flags = splsoftcam();
	if (pHcs->HCS_LastPend != NULL) {
		pHcs->HCS_LastPend->SCB_NextScb = scbp;
		pHcs->HCS_LastPend = scbp;
	}
	else {
		pHcs->HCS_FirstPend = scbp;
		pHcs->HCS_LastPend = scbp;
	}
	splx(flags);
}





static A100_SCB *orc_abort_srb(A100_HCS *pHcs, ULONG srbp)
{
    
	A100_SCB	*pScb, *pPrevScb;
	ULONG		i;
	int		flags;
    
	flags = splcam();
	pPrevScb = NULL;
	pScb = pHcs->HCS_FirstPend;		/* Check Pend queue */
	while (pScb != NULL) {
		if (pScb->SCB_ccb == srbp) {
	    	if (pPrevScb == NULL) {
			if ((pHcs->HCS_FirstPend = pScb->SCB_NextScb) == NULL)
			pHcs->HCS_LastPend = NULL;
		}
		else {
			pPrevScb->SCB_NextScb = pScb->SCB_NextScb;
			if (pScb == pHcs->HCS_LastPend)
			pHcs->HCS_LastPend = pPrevScb;
		}
		pScb->SCB_NextScb = NULL;
	        a100_free_scb(pHcs, pScb);
		splx(flags);
		return (pScb);
		}

		pPrevScb = pScb;
		pScb = pScb->SCB_NextScb;
	}

	for (i = 0, pScb = pHcs->pScbArray; i < MAX_SCB ; i++, pScb++) {
		if ((pScb->SCB_Status) && (pScb->SCB_ccb == srbp)) {
	        	orc_abort_SCB(pHcs, pScb);
			a100_free_scb(pHcs, pScb);
			splx(flags);
			return (pScb);
		} 
	}
	splx(flags);
	return (NULL);
}






static A100_SCB * orc_alloc_scb(A100_HCS *pHcs)
{
	A100_SCB	*pScb;
	int		opri;

	opri = splcam();

	if ((pScb = pHcs->HCS_FirstAvail) != NULL) {
		if(pScb->SCB_NextScb == NULL) {
		   	pHcs->HCS_FirstAvail = NULL;
		   	pHcs->HCS_LastAvail = NULL;
		}
		else{
			pHcs->HCS_FirstAvail = pScb->SCB_NextScb;
		}
		pScb->SCB_NextScb = NULL;
		pScb->SCB_FreeFlag  = 1;
	}
	splx(opri);
	return (pScb);
}




/*
 * An scb (and hence an scb entry on the board) is put onto the
 * free list.
 */
static void orc_release_scb(A100_HCS *pHcs, A100_SCB *pScb)
{       

	int opri;

	if(pScb->SCB_FreeFlag == 0)
		return;
	
	pScb->SCB_FreeFlag = 0;
	pScb->SCB_ccb = NULL;
	pScb->SCB_NextScb = NULL;

	opri = splcam();
	if(pHcs->HCS_LastAvail != NULL) {
		pHcs->HCS_LastAvail->SCB_NextScb = pScb;
		pHcs->HCS_LastAvail = pScb;
        }
	else {
		pHcs->HCS_FirstAvail = pScb;
		pHcs->HCS_LastAvail = pScb;
	}		
	splx(opri);
}


static void orc_isr (A100_HCS *pHcs)
{
	ULONG	bScbIdx;

	if(inb(pHcs->HCS_Base+ORC_RQUEUECNT) == 0)
	return ;

	do{
		bScbIdx = (ULONG)inb(pHcs->HCS_Base+ORC_RQUEUE);
		a100_done(pHcs,&(pHcs->pScbArray[bScbIdx]));
	}while(inb(pHcs->HCS_Base+ORC_RQUEUECNT));

}



static void a100_free_scb(A100_HCS *pHcs, A100_SCB *pScb)
{
	orc_release_scb(pHcs, pScb);
	/*
	 * Wake anybody waiting for one to come free.
	 */

	wakeup((caddr_t)&pHcs->pScbArray);
}


/*
 * We have a scb which has been processed by the
 * adaptor, now we look to see how the operation
 * went.
 */
static void
a100_done(A100_HCS *pHcs, A100_SCB *pScb)
{
	union ccb *ccb = (union ccb *)pScb->SCB_ccb;
	
	struct ccb_scsiio *csio = &ccb->csio;
	struct scsi_sense_data *pSense;


	int flags = csio->ccb_h.flags;
	pScb->SCB_Status = 0;
	pScb->SCB_ccb = NULL;
/***
	printf("done:(%d %d)cdb(%d)=%x h=%x t=%x ",pScb->SCB_Target,pScb->SCB_Lun,pScb->SCB_CDBLen,pScb->SCB_CDB[0] ,pScb->SCB_HaStat,pScb->SCB_TaStat);
	printf("--Enter a100_done(%d-%d-%02x)--",pScb->SCB_Target,pScb->SCB_Lun,pScb->SCB_TaStat);***/
	if(pScb->SCB_TagMsg) {
		if(pHcs->ActiveTags[pScb->SCB_Target] <= 1)
			pHcs->ActiveTags[pScb->SCB_Target] = 0;	
		else
			pHcs->ActiveTags[pScb->SCB_Target]--;

		if(pHcs->MaximumTags[pScb->SCB_Target] > pHcs->ActiveTags[pScb->SCB_Target])
			pHcs->TargetFlag[pScb->SCB_Target] &= ~TCF_BUSY;
	}
	else
		pHcs->TargetFlag[pScb->SCB_Target] &= ~TCF_BUSY;

	if((ULONG)ccb == 0) {
		printf("free scb while xs=0 in a100_done \n");
		a100_free_scb(pHcs, pScb);
		return;
	}

	/*
	**	Check the status.
	*/
	if (   (pScb->SCB_HaStat == HOST_OK)
		&& (pScb->SCB_TaStat == TARGET_GOOD)) {
		ccb->ccb_h.status = CAM_REQ_CMP;
		csio->scsi_status = SCSI_STATUS_OK;
	} else if ((pScb->SCB_HaStat== HOST_OK)
		&& (pScb->SCB_TaStat== TARGET_CHKCOND  )) {
	
			
/***		bcopy(&pHcs->SGList[pScb->SCB_ScbIdx << 5], &csio->sense_data, SSD_FULL_SIZE);***/
		/*
		**   Check condition code
		*/
		ccb->ccb_h.status  |= CAM_AUTOSNS_VALID;
		csio->scsi_status = SCSI_STATUS_CHECK_COND;

	} else if ((pScb->SCB_HaStat== HOST_OK)
		&& (pScb->SCB_TaStat== TARGET_BUSY)) {

		/*
		**   Target is busy.
		*/
/***		ccb->ccb_h.status = CAM_SCSI_BUSY;***/
		ccb->ccb_h.status = CAM_SCSI_STATUS_ERROR;
		csio->scsi_status = SCSI_STATUS_BUSY;

	} else if ((pScb->SCB_HaStat== HOST_OK)
		&& (pScb->SCB_TaStat== TARGET_QFULL)) {

		if((pHcs->MaximumTags[pScb->SCB_Target] = pHcs->ActiveTags[pScb->SCB_Target]) < 1)
			pHcs->MaximumTags[pScb->SCB_Target] =  1;
		/*
		**   Target is queue full.
		*/
/***		ccb->ccb_h.status = CAM_SCSI_BUSY;***/
		ccb->ccb_h.status = CAM_SCSI_STATUS_ERROR;
		csio->scsi_status = SCSI_STATUS_QUEUE_FULL;

	} else if (pScb->SCB_HaStat== HOST_SEL_TOUT   ) {

		/*
		**   Device failed selection
		*/
		ccb->ccb_h.status = CAM_SEL_TIMEOUT;

	} else { /*  Other protocol messes */
		ccb->ccb_h.status = CAM_CMD_TIMEOUT;
	}
	

	untimeout(a100_timeout, (caddr_t) pScb,ccb->ccb_h.timeout_ch);
	xpt_done(ccb);

	a100_free_scb(pHcs, pScb);

	/* check pending queue */
	a100_send_scb(pHcs);
}

static void
a100_timeout(void *arg1)
{

	union ccb *ccb;
	A100_HCS *pHcs; 
	int     unit;
	int s;
	A100_SCB *pScb = (A100_SCB*) arg1;
	ccb = (union ccb *)pScb->SCB_ccb;

	if (ccb == NULL) 
		return;

	pHcs = (A100_HCS *)xpt_path_sim(ccb->ccb_h.path)->softc;
/***	pHcs = (A100_HCS *)ccb->ccb_h.ccb_a100_ptr;***/

	s = splcam();
	if (orc_abort_srb(pHcs, (ULONG) ccb)) {
		printf("ihb: timed out\n");
		ccb->ccb_h.status |= CAM_REQ_ABORTED;
		xpt_done(ccb);
	}
	splx(s);
}


static int a100_wait_scb(A100_HCS *pHcs,A100_SCB *pScb,int time)
{
	while(time >0) {
		if(pScb->SCB_Status == 0) {
	 		a100_done(pHcs,pScb);
			return (TRUE);
		}		
		DELAY(1000);	/* 1 ms */
		time--;
	}

	a100_free_scb(pHcs, pScb);
	return (FALSE);

}



static void a100_send_scb(A100_HCS *pHcs)
{
	A100_SCB *pScb, *pPrev;

	pScb = pHcs->HCS_FirstPend;
	pPrev = pScb;
	for (; pScb != NULL; pPrev = pScb, pScb = pScb->SCB_NextScb) {

		if (pHcs->TargetFlag[pScb->SCB_Target] & TCF_BUSY)
		    continue;

		if (pScb->SCB_TagMsg) {
			pHcs->ActiveTags[pScb->SCB_Target]++;
			if(pHcs->MaximumTags[pScb->SCB_Target] <= pHcs->ActiveTags[pScb->SCB_Target])
				pHcs->TargetFlag[pScb->SCB_Target] |= TCF_BUSY;
		}
		else 
			pHcs->TargetFlag[pScb->SCB_Target] |= TCF_BUSY;

		/* unlink pScb */
		if ( pScb == pHcs->HCS_FirstPend) {
			if ((pHcs->HCS_FirstPend = pScb->SCB_NextScb) == NULL)
				pHcs->HCS_LastPend = NULL;
		}
		else if ((pPrev->SCB_NextScb = pScb->SCB_NextScb) == NULL) {
			pHcs->HCS_LastPend = pPrev;
		}

/***		printf("$$$To send scb$$$");***/	
		orc_send_scb(pHcs, pScb);
	}
	
}






void a100_exec_scb(void *arg, bus_dma_segment_t *dm_segs, int nseg, int error)
{
	ULONG	bScbIdx;
	A100_SCB * pScb;
	union ccb *ccb;
	A100_HCS *pHcs;
	A100_SG *sg;
	struct ccb_scsiio *csio;
	int s;

	pScb = (A100_SCB *)arg;
	ccb = (union ccb *)pScb->SCB_ccb;
	csio = &ccb->csio;
	pHcs = (A100_HCS *)xpt_path_sim(ccb->ccb_h.path)->softc;

	if(pScb->SCB_CDB[0] == 0x3) {

		/* disable SCSI DISCONNECT if it is "REQUEST SENSE" command */
		printf("--REQUEST SENSE--");
     		pScb->SCB_Ident &= 0xBF;

	}


	if (error != 0) {
		if (error != EFBIG)
			printf("a100: Unexepected error 0x%x returned from bus_dmamap_load\n", error);
		if (ccb->ccb_h.status == CAM_REQ_INPROG) {
			xpt_freeze_devq(ccb->ccb_h.path, /*count*/1);
			ccb->ccb_h.status = CAM_REQ_TOO_BIG|CAM_DEV_QFRZN;
		}
		a100_free_scb(pHcs, pScb);
		xpt_done(ccb);
		return;
	}


	pScb->SCB_XferLen = 0;
	pScb->SCB_SGLen = 0;

	sg =&pHcs->SGList[pScb->SCB_ScbIdx << 5];
	pScb->SCB_SGPAddr = (ULONG) vtophys(sg); 

	sg->SG_Ptr = 0;
	sg->SG_Len= 0;
/***
	printf("exec:(%d %d)cdb(%d)=%x ",pScb->SCB_Target,pScb->SCB_Lun,pScb->SCB_CDBLen,pScb->SCB_CDB[0]);
	printf("--exec(seg=%d,xferl=%d,cdl=%d,tag=%02x)--",nseg,csio->dxfer_len,pScb->SCB_CDBLen,pScb->SCB_TagMsg);***/	
	if(csio->dxfer_len){
		pScb->SCB_XferLen = csio->dxfer_len;

	
	if (nseg != 0) {
/***
		int		seg;
		vm_size_t	datalen;
		vm_offset_t	vaddr;
		u_int32_t	paddr;
		u_int32_t	nextpaddr;
		
		seg = 0;
		datalen = (vm_size_t)csio->dxfer_len;
		vaddr = (vm_offset_t)csio->data_ptr,
		paddr = vtophys(vaddr);
	
		while ((datalen > 0) && (seg < A100_SG_ENTRY))  {
			sg->SG_Ptr = paddr;
			sg->SG_Len= 0;

			nextpaddr = paddr;

			while ((datalen > 0) && (paddr == nextpaddr)) {
				u_int32_t	size;
				nextpaddr = (paddr & (~PAGE_MASK)) + PAGE_SIZE;

				size = nextpaddr - paddr;
				if (size > datalen)
			        size = datalen;


				sg->SG_Len += size;
				vaddr   += size;
				datalen -= size;
				if (datalen > 0)
					paddr = vtophys(vaddr);
			}
			seg++;
			sg++;
		}

		if (datalen) { 
			printf("ihb_scsi_cmd: more than supposed DMA segs exist \n");
			a100_free_scb(pHcs, pScb);
			xpt_done(ccb);
			return;
		}

		pScb->SCB_SGLen = seg << 3;
***/



		bus_dma_segment_t *end_seg;
		bus_dmasync_op_t op;

		end_seg = dm_segs + nseg;

		while (dm_segs < end_seg) {
			sg->SG_Len = dm_segs->ds_len;
			sg->SG_Ptr = dm_segs->ds_addr;
			sg++;
			dm_segs++;
		}

		pScb->SCB_SGLen = nseg << 3;
		
/***
		if ((ccb->ccb_h.flags & CAM_DIR_MASK) == CAM_DIR_IN)
			op = BUS_DMASYNC_PREREAD;
		else
			op = BUS_DMASYNC_PREWRITE;

		bus_dmamap_sync(pHcs->buffer_dmat, pHcs->dmamap, op);
***/

	} else {
		sg->SG_Len = csio->dxfer_len;
		sg->SG_Ptr = (ULONG)csio->data_ptr;
		pScb->SCB_SGLen = 8;
	}
	}

	s = splcam();
	ccb->ccb_h.timeout_ch = timeout(a100_timeout, (caddr_t)pScb, (ccb->ccb_h.timeout * hz)/1000);
	/* alway append into pending queue */
	orc_append_pend_scb(pHcs, pScb);

	/* check pending queue */
	a100_send_scb(pHcs);
	splx(s);
}


/*==========================================================
**
**
**	Start execution of a SCSI command.
**	This is called from the generic SCSI driver.
**
**
**==========================================================
*/

void a100_action(struct cam_sim *sim, union ccb *ccb)
{
	A100_HCS  *pHcs;
	A100_SCB  *pScb;
	int	  flags,flagio;
	struct cam_path *path;
	struct scsi_inquiry_data *inq_buf;
	
	path = ccb->ccb_h.path;
	inq_buf = NULL;
	pHcs = (A100_HCS  *) cam_sim_softc(sim);

/***	printf("--action(%d-%d-%02x-%08x)--",ccb->ccb_h.target_id,ccb->ccb_h.target_lun,ccb->ccb_h.func_code,ccb->ccb_h.flags);
***/
	switch (ccb->ccb_h.func_code) {
	/* Common cases first */
	case XPT_SCSI_IO:	/* Execute the requested I/O operation */
	case XPT_RESET_DEV:	/* Bus Device Reset the specified SCSI device */
	{
		A100_SG         *sg;
		struct ccb_scsiio *csio = &ccb->csio;

		flags = ccb->ccb_h.flags;
		flagio = csio->ccb_h.flags;


		/*
		 * Last time we need to check if this CCB needs to
		 * be aborted.
		 */
		if ((ccb->ccb_h.status & CAM_STATUS_MASK) != CAM_REQ_INPROG) {
			xpt_done(ccb);
			return;
		}
		ccb->ccb_h.status |= CAM_SIM_QUEUED;

		/*
		 * get an scb to use. 
		 */
		if ((pScb = orc_alloc_scb(pHcs)) == NULL) {
/***			printf("--!pScb--");***/
			ccb->ccb_h.status = CAM_RESRC_UNAVAIL;
			xpt_done(ccb);
			return;
		}


		pScb->SCB_Target = ccb->ccb_h.target_id;
		pScb->SCB_Lun	 = ccb->ccb_h.target_lun;
        
	
		pScb->SCB_HaStat = 0;
		pScb->SCB_TaStat = 0;
		pScb->SCB_Status = 0;
		pScb->SCB_Link   = 0xFF;

		pScb->SCB_Reserved0 = 0;
		pScb->SCB_Reserved1 = 0;

		pScb->SCB_ccb =(ULONG)ccb;

		pScb->SCB_Flags = 0;
		if (ccb->ccb_h.func_code == XPT_RESET_DEV) {
			pScb->SCB_Opcode  = BusDevRst;
		} 
		else{


		pScb->SCB_Opcode  = ExecSCSI;

		if((flagio & CAM_DIR_MASK) == CAM_DIR_NONE)
			pScb->SCB_Flags = SCF_NO_DCHK;
		else if(flagio & CAM_DIR_IN)
			pScb->SCB_Flags = SCF_DIN;
		else if(flagio & CAM_DIR_OUT)
			pScb->SCB_Flags = SCF_DOUT;

		pScb->SCB_Ident     = pScb->SCB_Lun | DISC_ALLOW;
		pScb->SCB_CDBLen = csio->cdb_len;
		if(pScb->SCB_CDBLen > 14)
			pScb->SCB_CDBLen = 14;	


		if ((flagio & CAM_CDB_POINTER) != 0) {
			if ((flagio & CAM_CDB_PHYS) == 0) {
				bcopy(csio->cdb_io.cdb_ptr, pScb->SCB_CDB, pScb->SCB_CDBLen);
			} else {
				ccb->ccb_h.status = CAM_REQ_INVALID;
				a100_free_scb(pHcs, pScb);
				xpt_done(ccb);
				return;
			}
		} else {
			bcopy(csio->cdb_io.cdb_bytes, pScb->SCB_CDB, pScb->SCB_CDBLen);
		}

/***
		inq_buf = &path->device->inq_data;
		printf("*a100inq(%02x %02x %02x %02x %02x)*",inq_buf->device,inq_buf->dev_qual2,inq_buf->version,inq_buf->response_format,inq_buf->flags);
***/


		if((flags & CAM_TAG_ACTION_VALID) != 0 && (csio->tag_action != CAM_TAG_ACTION_NONE)){
		    	pScb->SCB_TagMsg = csio->tag_action;
			pHcs->TargetFlag[pScb->SCB_Target]  |= TCF_EN_TAG;
		}
		else{
		    	pScb->SCB_TagMsg = 0;
			pHcs->TargetFlag[pScb->SCB_Target]  &= ~TCF_EN_TAG;
		}

	        pScb->SCB_SenseLen = csio->sense_len;
		pScb->SCB_SensePAddr = vtophys(&csio->sense_data);

		/*----------------------------------------------------
		**
		**	Build the data descriptors
		**
		**----------------------------------------------------
		*/

	        /* Only use S/G if there is a transfer */
		if ((flagio & CAM_DIR_MASK) != CAM_DIR_NONE) {
		
	
			if ((flagio & CAM_SCATTER_VALID) == 0) {
				/*
				 * We've been given a pointer
				 * to a single buffer.
				 */
				if ((flagio & CAM_DATA_PHYS)==0) {
					int s;
					int error;

/***					printf("--CAM_DATA_PHYS=0--");***/
					s = splsoftvm();
					error = bus_dmamap_load(
					    pHcs->buffer_dmat,
					    pHcs->dmamap,
					    csio->data_ptr,
					    csio->dxfer_len,
					    a100_exec_scb,
					    pScb,
					    /*flags*/0);
					if (error == EINPROGRESS) {
						/*
						 * So as to maintain
						 * ordering, freeze the
						 * controller queue
						 * until our mapping is
						 * returned.
						 */
						xpt_freeze_simq(pHcs->sim,
							1);
						csio->ccb_h.status |=
						    CAM_RELEASE_SIMQ;
					}
					splx(s);
				} else {
					struct bus_dma_segment seg; 

					/* Pointer to physical buffer */
					seg.ds_addr =
					    (bus_addr_t)csio->data_ptr;
					seg.ds_len = csio->dxfer_len;
					a100_exec_scb(pScb,&seg,1,0);
				}
			} else {
				struct bus_dma_segment *segs;
				if ((flagio & CAM_DATA_PHYS) != 0)
					panic("a100action - Physical "
					      "segment pointers "
					      "unsupported");

				if ((flagio&CAM_SG_LIST_PHYS)==0)
					panic("a100action - Virtual "
					      "segment addresses "
					      "unsupported");

				segs = (struct bus_dma_segment *)
					    csio->data_ptr;
				a100_exec_scb(pScb,segs,csio->sglist_cnt,0);

			}
		} else {
			a100_exec_scb(pScb,NULL,0,0);
		}	
		}

		break;
	}


	case XPT_EN_LUN:		/* Enable LUN as a target */
	case XPT_TARGET_IO:		/* Execute target I/O request */
	case XPT_ACCEPT_TARGET_IO:	/* Accept Host Target Mode CDB */
	case XPT_CONT_TARGET_IO:	/* Continue Host Target I/O Connection*/
	case XPT_ABORT:			/* Abort the specified CCB */
		/* XXX Implement */
		ccb->ccb_h.status = CAM_REQ_INVALID;
		xpt_done(ccb);
		break;
	case XPT_SET_TRAN_SETTINGS:
	{
		/* XXX Implement */
		ccb->ccb_h.status = CAM_REQ_CMP;
		xpt_done(ccb);
		break;
	}
	case XPT_GET_TRAN_SETTINGS:
	/* Get default/user set transfer settings for the target */
	{

		struct	ccb_trans_settings *cts;

		cts = &ccb->cts;

		cts->flags = 0;
		cts->flags |= CCB_TRANS_DISC_ENB;

		cts->flags |= CCB_TRANS_TAG_ENB;

		cts->bus_width = MSG_EXT_WDTR_BUS_16_BIT;

		cts->sync_period = scsi_calc_syncparam(80);
/***		cts->sync_period = 80;***/
		cts->sync_offset = 15;

		cts->valid = CCB_TRANS_SYNC_RATE_VALID
			   | CCB_TRANS_SYNC_OFFSET_VALID
			   | CCB_TRANS_BUS_WIDTH_VALID
			   | CCB_TRANS_DISC_VALID
			   | CCB_TRANS_TQ_VALID;


/***		struct	ccb_trans_settings *cts;
		u_int	target_mask;

		cts = &ccb->cts;
		target_mask = 0x01 << ccb->ccb_h.target_id;
		if ((cts->flags & CCB_TRANS_USER_SETTINGS) != 0) {
			cts->flags = 0;
			if ((bt->disc_permitted & target_mask) != 0)
				cts->flags |= CCB_TRANS_DISC_ENB;
			if ((bt->tags_permitted & target_mask) != 0)
				cts->flags |= CCB_TRANS_TAG_ENB;
			if ((bt->wide_permitted & target_mask) != 0)
				cts->bus_width = MSG_EXT_WDTR_BUS_16_BIT;
			else
				cts->bus_width = MSG_EXT_WDTR_BUS_8_BIT;
			if ((bt->ultra_permitted & target_mask) != 0)
				cts->sync_period = 12;
			else if ((bt->fast_permitted & target_mask) != 0)
				cts->sync_period = 25;
			else if ((bt->sync_permitted & target_mask) != 0)
				cts->sync_period = 50;
			else
				cts->sync_period = 0;

			if (cts->sync_period != 0)
				cts->sync_offset = 15;

			cts->valid = CCB_TRANS_SYNC_RATE_VALID
				   | CCB_TRANS_SYNC_OFFSET_VALID
				   | CCB_TRANS_BUS_WIDTH_VALID
				   | CCB_TRANS_DISC_VALID
				   | CCB_TRANS_TQ_VALID;
		} else {
			btfetchtransinfo(bt, cts);
		}
***/

		ccb->ccb_h.status = CAM_REQ_CMP;
		xpt_done(ccb);
		break;
	}
	case XPT_CALC_GEOMETRY:
	{
		struct	  ccb_calc_geometry *ccg;
		u_int32_t size_mb;
		u_int32_t secs_per_cylinder;

		ccg = &ccb->ccg;
		size_mb = ccg->volume_size
			/ ((1024L * 1024L) / ccg->block_size);
		
		if (size_mb >= 1024 ) {
			ccg->heads = 255;
			ccg->secs_per_track = 63;
		} else {
			ccg->heads = 64;
			ccg->secs_per_track = 32;
		}
		secs_per_cylinder = ccg->heads * ccg->secs_per_track;
		ccg->cylinders = ccg->volume_size / secs_per_cylinder;
		ccb->ccb_h.status = CAM_REQ_CMP;
		xpt_done(ccb);
		break;
	}
	case XPT_RESET_BUS:		/* Reset the specified SCSI bus */
	{
		outb(pHcs->HCS_Base+ORC_HCTRL, SCSIRST);	/* Do Hardware Reset &	*/
		ccb->ccb_h.status = CAM_REQ_CMP;
		xpt_done(ccb);
		break;
	}
	case XPT_TERM_IO:		/* Terminate the I/O process */
		/* XXX Implement */
		ccb->ccb_h.status = CAM_REQ_INVALID;
		xpt_done(ccb);
		break;
	case XPT_PATH_INQ:		/* Path routing inquiry */
	{
		struct ccb_pathinq *cpi = &ccb->cpi;
		
		cpi->version_num = 1; /* XXX??? */
		cpi->hba_inquiry = PI_SDTR_ABLE;
		if (ccb->csio.tag_action != 0)
			cpi->hba_inquiry |= PI_TAG_ABLE;
		if(pHcs->HCS_MaxTar == 16)
			cpi->hba_inquiry |= PI_WIDE_16;
			
		cpi->target_sprt = 0;
		cpi->hba_misc = 0;
		cpi->hba_eng_cnt = 0;
		cpi->max_target = pHcs->HCS_MaxTar-1;
		cpi->max_lun = 7;
		cpi->initiator_id = pHcs->HCS_SCSI_ID;
		cpi->bus_id = cam_sim_bus(sim);
		strncpy(cpi->sim_vid, "FreeBSD", SIM_IDLEN);
		strncpy(cpi->hba_vid, "Initio", HBA_IDLEN);
		strncpy(cpi->dev_name, cam_sim_name(sim), DEV_IDLEN);
		cpi->unit_number = cam_sim_unit(sim);
		cpi->ccb_h.status = CAM_REQ_CMP;
		xpt_done(ccb);
		break;
	}
	default:
		ccb->ccb_h.status = CAM_REQ_INVALID;
		xpt_done(ccb);
		break;

	}
}


void a100_poll(struct cam_sim *sim)
{
	A100_HCS  *pHcs;

	pHcs = (A100_HCS  *) cam_sim_softc(sim);

	orc_isr(pHcs);


}


void a100_min_phys( struct buf *bp )
{
	if (bp->b_bcount > ((A100_SG_ENTRY - 1) * PAGELEN))
		bp->b_bcount = ((A100_SG_ENTRY - 1) * PAGELEN);

#if defined(__NetBSD__)
	minphys(bp);
#endif
}


/*==========================================================
**
**
**      Auto configuration:  attach and init a host adapter.
**
**
**==========================================================
*/

void
a100_attach (pcici_t config_id, int unit)
{
	u_int16_t io_port;
	u_int32_t id;
	UCHAR   irq;
	ULONG   wlval;
	A100_HCS    *pHcs;
	A100_SCB    *pScb;
	A100_SG 	*pSG;
	int     s,flags,error,openings;
	struct cam_devq *devq;
	union ccb	*work_ccb;


	if( unit >= MAX_SUPPORTED_ADAPTERS)
		return;


	io_port = 0;
	if (pci_map_port(config_id, PCI_BASEADDR0, &io_port) == 0)
		return;


	pHcs = (A100_HCS *) malloc (sizeof(A100_HCS), M_DEVBUF, M_NOWAIT);
	if( !pHcs ) {
		printf("ihb: cannot allocate HCS !\n");
		return;
	}

	bzero (pHcs, sizeof(A100_HCS));
	pHcs->HCS_Base = io_port;
	pHcs->HCS_Unit = unit;



	switch ((id = pci_conf_read(config_id, PCI_ID_REG))) {

	    case PCI_DEVICE_ID_INIC1060:
		break;

	    case PCI_DEVICE_ID_INIC850:
		break;

	    default:
		free(pHcs, M_DEVBUF);
		return;
	}

	/* Allocate a dmatag for our transfer DMA maps */
	/* XXX Should be a child of the PCI bus dma tag */
	error = bus_dma_tag_create(/*parent*/ NULL,
				    /*alignment*/ 0,
				    /*boundary*/ 0,
				    /*lowaddr*/ (0xFFFFFFFFL),
				    /*highaddr*/ BUS_SPACE_MAXADDR,
				    /*filter*/ NULL,
				    /*filterarg*/ NULL,
				    /*maxsize*/ BUS_SPACE_MAXSIZE_32BIT,
				    /*nsegments*/ BUS_SPACE_UNRESTRICTED,
				    /*maxsegsz*/ (0xFFFFFFL),
				    /*flags*/ 0,
				   &pHcs->parent_dmat);
 
	if (error != 0) {
		printf("ihb: Could not allocate DMA tag - error %d\n",
		       error);
		free(pHcs, M_DEVBUF);
		return;
	}


	pScb = (A100_SCB *) malloc (sizeof(A100_SCB)*MAX_SCB, M_DEVBUF, M_NOWAIT);
	if( !pScb ) {
		printf("ihb: cannot allocate SCB !\n");
		bus_dma_tag_destroy(pHcs->parent_dmat);
		free(pHcs, M_DEVBUF);
		return;
	}
	bzero (pScb, sizeof(A100_SCB)*MAX_SCB);

	pSG = (A100_SG *) malloc (sizeof(A100_SG)*MAX_SCB*MAX_SG, M_DEVBUF, M_NOWAIT);
	if( !pSG ) {
		printf("ihb: cannot allocate SG !\n");
		free(pScb, M_DEVBUF);
		bus_dma_tag_destroy(pHcs->parent_dmat);
		free(pHcs, M_DEVBUF);
		return;
	}
	orc_init(pHcs, pScb,pSG);

	if (!(pci_map_int(config_id, (void *)orc_isr, (void *)pHcs, &cam_imask))) {
		printf("Can't pci_map_int \n");
		bus_dma_tag_destroy(pHcs->parent_dmat);
		free(pHcs, M_DEVBUF);
		return;
	}


	/* DMA tag for mapping buffers into device visible space. */
	if (bus_dma_tag_create(pHcs->parent_dmat, /*alignment*/0, /*boundary*/0,
			       /*lowaddr*/BUS_SPACE_MAXADDR,
			       /*highaddr*/BUS_SPACE_MAXADDR,
			       /*filter*/NULL, /*filterarg*/NULL,
			       /*maxsize*/MAXBSIZE, /*nsegments*/A100_SG_ENTRY,
			       /*maxsegsz*/BUS_SPACE_MAXSIZE_32BIT,
			       /*flags*/BUS_DMA_ALLOCNOW,
			       &pHcs->buffer_dmat) != 0) {
		return;	
	}


	/*
	** Create the device queue.  We only allow MAX_START-1 concurrent
	** transactions so we can be sure to have one element free in our
	** start queue to reset to the idle loop.
	*/
	s = splcam();
	openings = MAX_SCB-1;
	devq = cam_simq_alloc(openings);
	if (devq == NULL){
		return;
		splx(s);
	}

	/*
	**	Now tell the generic SCSI layer
	**	about our bus.
	*/
	pHcs->sim = cam_sim_alloc(a100_action, a100_poll, "ihb", pHcs,
				pHcs->HCS_Unit ,
				1, openings, devq);
	if (pHcs->sim == NULL) {
		cam_simq_free(devq);
		splx(s);
		return;
	}




	if (xpt_bus_register(pHcs->sim, 0) != CAM_SUCCESS) {
		cam_sim_free(pHcs->sim, TRUE);
		splx(s);
		return;
	}



#ifdef __alpha__
	alpha_register_pci_scsi(config_id->bus, config_id->slot, pHcs->sim);
#endif	

	work_ccb = xpt_alloc_ccb();
	if (xpt_create_path(&pHcs->path, NULL,
			    cam_sim_path(pHcs->sim), CAM_TARGET_WILDCARD,
			    CAM_LUN_WILDCARD) != CAM_REQ_CMP) {
		xpt_bus_deregister(cam_sim_path(pHcs->sim));
		cam_sim_free(pHcs->sim, TRUE);
		xpt_free_ccb(work_ccb);
		splx(s);
		return;
	}
/***
	xpt_setup_ccb(&work_ccb->ccb_h, pHcs->path, 1);
	work_ccb->ccb_h.func_code = XPT_SCAN_BUS;
	work_ccb->ccb_h.cbfcnp = NULL;
	xpt_action(work_ccb);
	xpt_finishconfig(NULL, work_ccb);
***/
/***	xpt_config(NULL);***/

	/*
	 * Register a callback for when interrupts are enabled.
	 */
/***
	a100_config_hook = (struct intr_config_hook *)malloc(sizeof(struct intr_config_hook), M_TEMP, M_NOWAIT);
	if (a100_config_hook == NULL) {
		printf("Cannot malloc config hook failing attach\n");
		return;
	}
	bzero(a100_config_hook, sizeof(*a100_config_hook));

	a100_config_hook->ich_func = xpt_config;
	if (config_intrhook_establish(a100_config_hook) != 0) {
		free (a100_config_hook, M_TEMP);
		printf("config_intrhook_establish failed failing attach\n");
	}
***/




	splx(s);
	return;

}


/*----------------------------------------------------------
**
**	Probe the hostadapter.
**
**----------------------------------------------------------
*/

static	char*
a100_probe (pcici_t tag, pcidi_t type)
{
	switch (type) {
	case PCI_DEVICE_ID_INIC1060:
		return ("IOI IOI-A100U2W PCI SCSI adapter");
	case PCI_DEVICE_ID_INIC850:
		return ("IOI IOI-A100UW PCI SCSI adapter");
	}
	return (NULL);
}
