QuiXplorer - Web based file management
======================================

quixplorer is a simple web based file management software. It allows you to:

- upload and download files to your web server using a web interface
- define multible users with different acces permissions (read,write,...)

Take a look at the project's wiki for the [latest news](https://github.com/realtimeprojects/quixplorer/wiki/News "quixplorer news").

Version 2.5.4 released
----------------------

This version contains several bugfixes introduced by previous versions,
thanks to all the people assisted in debugging.
