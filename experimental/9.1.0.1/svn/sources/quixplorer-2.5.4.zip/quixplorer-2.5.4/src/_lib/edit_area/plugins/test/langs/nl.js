editArea.add_lang("nl",{
test_select: "select tag",
test_but: "test button"
});
