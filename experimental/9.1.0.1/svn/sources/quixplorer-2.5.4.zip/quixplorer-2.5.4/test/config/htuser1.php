<?php $GLOBALS["users"]=array(
	array("admin","9628d0d187029e6337baa86780b2abb6",".","http://localhost",1,"",7,1),
	array("guest","fc5e038d38a57032085441e7fe7010b0","./test","http://localhost",0,"",7,1),
); ?>
