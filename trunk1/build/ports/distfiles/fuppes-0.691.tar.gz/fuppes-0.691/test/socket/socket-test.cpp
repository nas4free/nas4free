
#include "../../src/lib/Common/Thread.h"
#include "../../src/lib/Common/Socket.h"
#include "../../src/lib/Common/Exception.h"

#include <sstream>
#include <iostream>
#include <stdio.h>
using namespace std;


class SocketThread: public fuppes::Thread
{
  public:
    SocketThread() : fuppes::Thread("SocketThread") {
    }
    
    ~SocketThread() {  
    }
  
  private:
    void run() {
      cout << "enter socket thread" << endl;
      
      try {
      
        fuppes::TCPSocket socket;
        socket.remoteAddress("192.168.0.2");
        socket.remotePort(5080);

        cout << "socket connect" << endl;
        socket.connect();
        cout << "socket connected" << endl;


        
      }
      catch(fuppes::Exception ex) {
      }

      cout << "exit socket thread" << endl;
    }
};


int main(int argc, char* argv[])
{
  cout << "socket test [enter]" << endl; getchar();
  
  SocketThread* thread = new SocketThread();
  thread->start();
  cout << "socket thread started [enter]" << endl; getchar();


  delete thread;
  cout << "socket thread deleted [enter]" << endl; getchar();
  
  return 0;
}

// ./configure --prefix=/usr --enable-lame --enable-transcoder-ffmpeg --enable-vfolder=no --enable-tests=yes
