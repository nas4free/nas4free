
#include "../../src/lib/Common/Thread.h"
#include "../../src/lib/SSDP/UDPSocket.h"
#include "../../src/lib/Common/Exception.h"

#include <sstream>
#include <iostream>
#include <stdio.h>
using namespace std;

using namespace fuppes;


class MulticastListenerThread: public fuppes::Thread
{
  public:
    MulticastListenerThread() : fuppes::Thread("MulticastListenerThread") {
    }
    
    ~MulticastListenerThread() {  
    }
  
  private:
    void run() {
      cout << "enter multicast listener thread" << endl;
      
      try {
      
       


        
      }
      catch(fuppes::Exception ex) {
      }

      cout << "exit multicast listener thread" << endl;
    }
};





int main(int argc, char* argv[])
{
  cout << "udp test [enter]" << endl; getchar();
  ThreadPool::init();

  

  CUDPSocket* listener = new CUDPSocket();
  listener->SetupSocket(true, "192.168.0.8");
  listener->BeginReceive();
  cout << "udp listener started [enter]" << endl; getchar();


  CUDPSocket* sender = new CUDPSocket();
  sender->SetupSocket(true, "192.168.0.8");
  sender->SendMulticast("dahumm");
  delete sender;

  cout << "multicast message sent [enter]" << endl; getchar();

  

  listener->EndReceive();
  listener->TeardownSocket();
  delete listener;

  cout << "udp listener deleted [enter]" << endl; getchar();


  ThreadPool::uninit();
  return 0;
}

// ./configure --prefix=/usr --enable-lame --enable-transcoder-ffmpeg --enable-vfolder=no --enable-tests=yes
