
#include <iostream>
using namespace std;

#include "../../src/lib/Common/Process.h"
using namespace fuppes;

int main(int argc, char* argv[])
{
	ProcessMgr::init();


	cout << "starting process" << endl;

	Process* proc = new Process();
  
  std::list<std::string> args;
  args.push_back("loop");
  args.push_back("test");
  args.push_back("C:\\Program Files\\Palim Palim\\");
  args.push_back("C:/Program Files/Test Dir/");
  args.push_back("dingens kirchen");
	proc->start("dummy-process", args);

	cout << "process started" << endl;

  //cout << "is running: " << (proc->isRunning() ? "yes" : "no") << endl;

  for(int i = 0; i < 3; i++) {
    #ifndef WIN32
    usleep(1000000);
    #else
    Sleep(1000);
    #endif
    cout << "is running: " << (proc->isRunning() ? "yes" : "no") << endl;
    if(!proc->isRunning())
      break;
  }

  

  if(proc->isRunning()) {
    //cout << "terminating process" << endl;
    //proc->terminate();
    cout << "stopping process" << endl;
    proc->stop();
    cout << "waiting for process" << endl;
	  proc->waitFor();
  }
	
	cout << "process exited" << endl;

	delete proc;

	ProcessMgr::uninit();

	return 0;
}

