
#ifndef _OBJECTTYPES_H
#define _OBJECTTYPES_H

#include <string>
#include "../Common/Exception.h"

typedef enum tagOBJECT_TYPE
{
  OBJECT_TYPE_UNKNOWN = 0,  
  //ITEM = 1,
  
  CONTAINER = 1,
    CONTAINER_STORAGEFOLDER = 2,
  
  CONTAINER_PERSON = 10,
    CONTAINER_PERSON_MUSICARTIST = 11,
    
  /* "object.container.playlistContainer" and "object.item.playlistItem”
     have the same OBJECT_TYPE in the database though the type of representation
     is selected from the configuration at runtime */
  CONTAINER_PLAYLISTCONTAINER = 20,
  
  CONTAINER_ALBUM = 30,
    CONTAINER_ALBUM_MUSICALBUM = 31,
    CONTAINER_ALBUM_PHOTOALBUM = 32,
    
  CONTAINER_GENRE = 40,
    CONTAINER_GENRE_MUSICGENRE = 41,
    CONTAINER_GENRE_MOVIEGENRE = 42,
    
  /*CONTAINER_CHANNEL_GROUP = 50,
    CONTAINER_CHANNEL_GROUP_AUDIO_CHANNEL_GROUP = 51,
    CONTAINER_CHANNEL_GROUP_VIDEO_CHANNEL_GROUP = 52,*/
  
  //CONTAINER_EPG_CONTAINER = 60,
  
  /*CONTAINER_STORAGE_SYSTEM = 70,
  CONTAINER_STORAGE_VOLUME = 80,
  CONTAINER_BOOKMARK_FOLDER = 90*/  

  CONTAINER_MAX = 90,  




  
  ITEM = 100,  
  
  ITEM_IMAGE_ITEM = 110,
    ITEM_IMAGE_ITEM_PHOTO = 111,
	ITEM_IMAGE_ITEM_MAX = 112,
	
  ITEM_AUDIO_ITEM = 120,
    ITEM_AUDIO_ITEM_MUSIC_TRACK     = 121,
    ITEM_AUDIO_ITEM_AUDIO_BROADCAST = 122,
    //ITEM_AUDIO_ITEM_AUDIO_BOOK      = 123,
	ITEM_AUDIO_ITEM_MAX = 123,
  
  ITEM_VIDEO_ITEM = 130,
    ITEM_VIDEO_ITEM_MOVIE            = 131,
    ITEM_VIDEO_ITEM_VIDEO_BROADCAST  = 132,
    ITEM_VIDEO_ITEM_MUSIC_VIDEO_CLIP = 133,
	ITEM_VIDEO_ITEM_MAX = 134,

  ITEM_TEXT_ITEM = 140,
  /*ITEM_BOOKMARK_ITEM = 150,
  
  ITEM_EPG_ITEM = 160,
    ITEM_EPG_ITEM_AUDIO_PROGRAM = 161,
    ITEM_EPG_ITEM_VIDEO_PROGRAM = 162,*/     

  
  ITEM_MAX = 200,



  
  /* we use the values after ITEM_MAX for some special purpose values */
  
  
  /*
   when parsing a playlist and we find a stream url
   we set the type to "unknown broadcast" and try to 
   detect the type (audio or video) of the stream later.
   this is no valid upnp object type!
  */
  ITEM_UNKNOWN_BROADCAST = 201
  
  
}OBJECT_TYPE;


inline std::string typeToString(OBJECT_TYPE type) 
{
  switch(type) {

    case CONTAINER:
      return "object.container";
    case CONTAINER_STORAGEFOLDER:
        return "object.container.storageFolder";

    case CONTAINER_PERSON :
      return "object.container.person";
    case CONTAINER_PERSON_MUSICARTIST :
      return "object.container.person.musicArtist";
      
    case CONTAINER_PLAYLISTCONTAINER :
      return "object.container.playlistContainer";

    case CONTAINER_ALBUM :
		  return "object.container.album";
		case CONTAINER_ALBUM_MUSICALBUM :
		  return "object.container.album.musicAlbum";
    case CONTAINER_ALBUM_PHOTOALBUM :
		  return "object.container.album.photoAlbum";

    case CONTAINER_GENRE :
      return "object.container.genre";
    case CONTAINER_GENRE_MUSICGENRE :
      return "object.container.genre.musicGenre";   
    case CONTAINER_GENRE_MOVIEGENRE :
      return "object.container.genre.movieGenre";


    default:
      throw fuppes::Exception(__FILE__, __LINE__, "unknown object type %d", type);
  }

  return "unknown";
}

inline OBJECT_TYPE stringToType(std::string type) 
{
  if(type.compare("object.container") == 0)
    return CONTAINER;
  else if(type.compare("object.container.storageFolder") == 0)
    return CONTAINER_STORAGEFOLDER;
  
  return OBJECT_TYPE_UNKNOWN;
}


typedef enum {

  upnp_200_ok,

  upnp_401_invalid_action,
  upnp_402_invalid_args,
  
  upnp_701_no_such_object,                                    // Browse()
  
  upnp_708_unsupported_or_invalid_search_criteria,            // Search()
  upnp_709_unsupported_or_invalid_sort_criteria,              // Browse()
  upnp_710_no_such_container,                                 // Search()

  upnp_712_bad_metadata,                                      // CreateObject()
  upnp_713_restricted_parent_object,                          // CreateObject()
  
  upnp_720_cannot_process_the_request                         // BS

} upnp_error_code_t;

#endif // _OBJECTTYPES_H
