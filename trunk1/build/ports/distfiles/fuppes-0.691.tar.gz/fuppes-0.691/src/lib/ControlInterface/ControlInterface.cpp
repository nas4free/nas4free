/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            ControlInterface.cpp
 * 
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2010-2011 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "ControlInterface.h"

#include <iostream>
#include <sstream>
using namespace std;

#include "../Common/XMLParser.h"
#include "../SharedConfig.h"

#include "../ContentDirectory/ContentDatabase.h"
#include "../Fuppes.h"


std::map<std::string, ControlAction*>  ControlInterface::m_actionMap;

void ControlInterface::init() // static
{
  m_actionMap["DatabaseRebuild"] = new ControlAction(FUPPES_CTRL_DATABASE_REBUILD, &ControlInterface::execDatabaseRebuild);
  m_actionMap["DatabaseUpdate"] = new ControlAction(FUPPES_CTRL_DATABASE_UPDATE, &ControlInterface::execDatabaseUpdate);
  m_actionMap["VfolderRebuild"] = new ControlAction(FUPPES_CTRL_VFOLDER_REBUILD, &ControlInterface::execVfolderRebuild);
  
  m_actionMap["GetDir"] = new ControlAction(FUPPES_CTRL_GET_DIR, &ControlInterface::execGetDir);
  
  m_actionMap["GetSharedObjects"] = new ControlAction(FUPPES_CTRL_GET_SHARED_OBJECTS, &ControlInterface::execGetSharedObjects);
  m_actionMap["GetSharedObjectTypes"] = new ControlAction(FUPPES_CTRL_GET_SHARED_OBJECT_TYPES, &ControlInterface::execGetSharedObjectTypes);
  m_actionMap["AddSharedObject"] = new ControlAction(FUPPES_CTRL_ADD_SHARED_OBJECT, &ControlInterface::execAddSharedObject);
  m_actionMap["DelSharedObject"] = new ControlAction(FUPPES_CTRL_DEL_SHARED_OBJECT, &ControlInterface::execDelSharedObject);
  m_actionMap["ModSharedObject"] = new ControlAction(FUPPES_CTRL_MOD_SHARED_OBJECT, &ControlInterface::execModSharedObject);
  

  m_actionMap["GetVersion"] = new ControlAction(FUPPES_CTRL_GET_DIR, &ControlInterface::execGetVersion);
  m_actionMap["GetHostname"] = new ControlAction(FUPPES_CTRL_GET_DIR, &ControlInterface::execGetHostname);
  m_actionMap["GetUptime"] = new ControlAction(FUPPES_CTRL_GET_DIR, &ControlInterface::execGetUptime);


  
/*

     
    else if(sName.compare("SetDeviceConfig") == 0)
	    action = FUPPES_CTRL_SET_DEVICE_CONFIG;
    else if(sName.compare("SetVfolderConfig") == 0)
	    action = FUPPES_CTRL_SET_VFOLDER_CONFIG;

*/

}

void ControlInterface::uninit() // static
{
}

FUPPES_CONTROL_ACTION ControlInterface::getActionFromString(std::string action) // static
{
  std::map<std::string, ControlAction*>::iterator iter = m_actionMap.find(action);
  if(iter != m_actionMap.end())
    return iter->second->action;
  else
    return FUPPES_CTRL_UNKNOWN;
}

ControlAction* ControlInterface::getAction(std::string action) // static
{
  std::map<std::string, ControlAction*>::iterator iter = m_actionMap.find(action);
  if(iter != m_actionMap.end())
    return iter->second;
  else
    return NULL;
}


ControlInterface::ErrorCode ControlInterface::execDatabaseRebuild(const ControlActionParams params, ControlActionParam &result)
{
  if(!CContentDatabase::Shared()->IsRebuilding())
    CContentDatabase::Shared()->RebuildDB();

  return ControlInterface::Ok;
}

ControlInterface::ErrorCode ControlInterface::execDatabaseUpdate(const ControlActionParams params, ControlActionParam &result)
{
  if(!CContentDatabase::Shared()->IsRebuilding())
    CContentDatabase::Shared()->UpdateDB();
  
  return ControlInterface::Ok;
}

ControlInterface::ErrorCode ControlInterface::execVfolderRebuild(const ControlActionParams params, ControlActionParam &result)
{
  std::cout << "ControlInterface::execVfolderRebuild" << std::endl;
  return ControlInterface::Ok;
}


// <dir show-files = [true|false]>[path]</dir>
ControlInterface::ErrorCode ControlInterface::execGetDir(const ControlActionParams params, ControlActionParams &result)
{  
  ControlActionParamsIter iter = params.begin();
  if(iter == params.end() || iter->name != "dir")
    return ControlInterface::MissingInputParam;
  
  string path = iter->value;
  string sFiles;
  if(!iter->attribute("show-files", sFiles))
    return ControlInterface::MissingInputParam;
  
  bool files = (sFiles == "true");

	if(path.empty())
		path = "/";

  #ifdef WIN32
	if(path == "/") {

		std::list<std::string> letters = fuppes::Directory::getDriveLetters();
		std::list<std::string>::iterator iter;

		for(iter = letters.begin(); iter != letters.end(); iter++) {
      ControlActionParam param;
      param.name = "dir";
      param.attributes["name"] = (*iter) + ":";
      param.value = (*iter) + ":";
      result.push_back(param);		
		}
		return ControlInterface::Ok;
	}	
  #endif

	fuppes::Directory dir(path);
	dir.open();
	fuppes::DirEntryList info = dir.dirEntryList();
	fuppes::DirEntryListIterator dirIter;

	if(path != "/") {
    ControlActionParam param;
    param.name = "parent";
    param.value = dir.path() + "..";
    result.push_back(param);
  }
	
	for(dirIter = info.begin(); dirIter != info.end(); dirIter++) {

		if(!files && dirIter->type() != fuppes::DirEntry::Directory)
			continue;

    ControlActionParam param;
    param.name = "dir";
    param.attributes["name"] = dirIter->name();
    param.value = dirIter->path();
    result.push_back(param);
	}

	dir.close();
  return ControlInterface::Ok;
}

ControlInterface::ErrorCode ControlInterface::execGetSharedObjects(const ControlActionParams params, ControlActionParams &result)
{
	SharedObject* obj;
	for(int i = 0;
	    i <	CSharedConfig::sharedObjects()->sharedObjectCount();
	    i++) {

		obj = CSharedConfig::sharedObjects()->sharedObject(i);

    string type;
    switch(obj->type()) {
			case SharedObject::directory:
				type = "directory";
				break;
			case SharedObject::playlist:
        type = "playlist";    
				break;
			/*case SharedObject::itunes:
        type = "itunes";
				break;*/
			case SharedObject::other:
        type = obj->otherType();
				break;
      default:
        continue;
        break;
		}
        
    ControlActionParam param;
    param.name = "shared-object";
    param.attributes["uuid"] = obj->uuid();
    param.attributes["path"] = obj->path();
    param.attributes["name"] = obj->name();
    param.attributes["item-type"] = type; // we can't call it type because mootools can't read a property named type 
    result.push_back(param);
  }
  
  return ControlInterface::Ok;
}

ControlInterface::ErrorCode ControlInterface::execGetSharedObjectTypes(const ControlActionParams params, ControlActionParams &result)
{
  ControlActionParam param;

  // built in types
  param.name = "object-type";
  param.value = "directory"; 
  result.push_back(param);
  
  param.name = "object-type";
  param.value = "playlist"; 
  result.push_back(param);
  
  // source plugins
  std::list<std::string> sources = CPluginMgr::sourceNames();
  std::list<std::string>::iterator iter = sources.begin();
  for(;iter != sources.end(); iter++) {
    param.name = "object-type";
    param.value = *iter; 
    result.push_back(param);
  }
  
  
  return ControlInterface::Ok;
}

// <object type="directory" path="[path]" />
// <object type="[itunes|playlist|...]" path="[path]" name="[name]" />
ControlInterface::ErrorCode ControlInterface::execAddSharedObject(const ControlActionParams params, ControlActionParam &result)
{
  ControlActionParamsIter iter = params.begin();
  if(iter == params.end() || iter->name != "object")
    return ControlInterface::MissingInputParam;
  
  string type;
  string path;
  string name;

  if(!iter->attribute("type", type))
    return ControlInterface::MissingAttribute;

  if(!iter->attribute("path", path))
    return ControlInterface::MissingAttribute;

  iter->attribute("name", name);
    
  SharedObject::SharedObjectType ot = SharedObject::unknown;
  if(type.compare("directory") == 0)
    ot = SharedObject::directory;
  else if(type.compare("playlist") == 0)
    ot = SharedObject::playlist;
  else if(type.compare("itunes") == 0)
    ot = SharedObject::playlist;
  else if(type.length() > 0) {
    ot = SharedObject::other;
  }

  SharedObject* so = CSharedConfig::sharedObjects()->addSharedObject(ot, path, name, type); 
  CContentDatabase::addSharedObject(so);
  
  return ControlInterface::Ok;
}

// <object uuid="[uuid]" />
ControlInterface::ErrorCode ControlInterface::execDelSharedObject(const ControlActionParams params, ControlActionParam &result)
{
  ControlActionParamsIter iter = params.begin();
  if(iter == params.end() || iter->name != "object")
    return ControlInterface::MissingInputParam;

  string uuid;
  if(!iter->attribute("uuid", uuid))
    return ControlInterface::MissingAttribute;

  SharedObject* so = CSharedConfig::sharedObjects()->sharedObject(uuid);
  if(NULL == so)
    return ControlInterface::Error;

  CContentDatabase::removeSharedObject(so);
  CSharedConfig::sharedObjects()->removeSharedObject(uuid); 
  
  return ControlInterface::Ok;
}

// <object uuid="[uuid]" type="[type]" path="[path]" name="[name]" />
ControlInterface::ErrorCode ControlInterface::execModSharedObject(const ControlActionParams params, ControlActionParam &result)
{
  ControlActionParamsIter iter = params.begin();
  if(iter == params.end() || iter->name != "object")
    return ControlInterface::MissingInputParam;

  return ControlInterface::Ok;
}


  
ControlInterface::ErrorCode ControlInterface::execGetVersion(const ControlActionParams params, ControlActionParam &result)
{
  result.name = "Version";
  result.value = CSharedConfig::Shared()->GetAppVersion(); 
  return ControlInterface::Ok;
}

ControlInterface::ErrorCode ControlInterface::execGetHostname(const ControlActionParams params, ControlActionParam &result)
{
  result.name = "Hostname";
  result.value = CSharedConfig::Shared()->networkSettings->GetHostname();
  return ControlInterface::Ok;
}

ControlInterface::ErrorCode ControlInterface::execGetUptime(const ControlActionParams params, ControlActionParam &result)
{
  stringstream uptime;
  fuppes::DateTime now = fuppes::DateTime::now();
  uptime << (now.toInt() - CSharedConfig::Shared()->GetFuppesInstance(0)->startTime().toInt());

  result.name = "Uptime";
  result.value = uptime.str();
  return ControlInterface::Ok;
}
