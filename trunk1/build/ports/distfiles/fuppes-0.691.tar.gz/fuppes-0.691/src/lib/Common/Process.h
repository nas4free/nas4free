/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            Process.h
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2008 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef PROCESS_H
#define PROCESS_H

#ifdef HAVE_CONFIG
#include "../../config.h"
#endif

#include "Common.h"
#include "Thread.h"

#include <map>
#include <list>
#include <string>
#include <signal.h>
#include <unistd.h>
#ifndef WIN32
#include <sys/wait.h>
#else
#include <windows.h>
#endif

namespace fuppes
{

class Process;

class ProcessMgr {
	
	public:
		~ProcessMgr();
	
		static void	init();
 		static void	uninit();
		#ifndef WIN32
		static void signal(pid_t pid, int sig);
		#endif
	
		static void register_proc(fuppes::Process* proc);
		static void unregister_proc(fuppes::Process* proc);
	
	private:
 		ProcessMgr();
		static ProcessMgr* 									m_instance;
	
		#ifndef WIN32
		std::map<pid_t, fuppes::Process*>						m_processes;
		std::map<pid_t, fuppes::Process*>::iterator	m_processesIter;		
		#endif
		fuppes::Mutex											    m_mutex;
};


class Process {
	
	friend class ProcessMgr;
	
	public:
		Process();
		~Process();
		
		//bool	start(std::string cmd);
    bool	start(std::string cmd, std::list<std::string> args);
    bool	isRunning();
    void	stop();
    void  terminate();
		void	waitFor();
	
		#ifndef WIN32
		pid_t	pid() { return m_pid; }
		#endif
	
	private:
		//void parseArgs(std::string cmd);
		
		bool					m_isRunning;
		char const**	m_args;
		int						m_numArgs;
	
#ifndef WIN32
		pid_t	m_pid;
#else
    STARTUPINFO m_StartupInfo;
    PROCESS_INFORMATION m_ProcessInformation;
#endif
		
};

}

#endif // PROCESS_H
