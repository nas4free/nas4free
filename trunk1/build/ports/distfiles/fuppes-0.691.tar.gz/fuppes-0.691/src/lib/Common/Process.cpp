/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            Process.cpp
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2008 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "Process.h"

#include <iostream>
#include <string.h>
using namespace std;

using namespace fuppes;

#ifndef WIN32
void on_signal(int /*signal*/)
{
	pid_t pid;
	int status;
  
  while (1) {
    pid = waitpid (WAIT_ANY, &status, WNOHANG);
    
		if(pid < 0)
      break;
    if (pid == 0)
      break;
		
		ProcessMgr::signal(pid, status);
  }
}
#endif

ProcessMgr* ProcessMgr::m_instance = NULL;

ProcessMgr::ProcessMgr()
{
	//fuppesThreadInitMutex(&m_mutex);
}

ProcessMgr::~ProcessMgr()
{
	//fuppesThreadDestroyMutex(&m_mutex);
}

void ProcessMgr::init()
{
	if(m_instance == 0) {
		m_instance = new ProcessMgr();
	}
	
	#ifndef WIN32
	::signal(SIGCHLD, &on_signal);
	#endif
}

void ProcessMgr::uninit()
{
	if(m_instance == 0)
    return;
  
  delete m_instance;
  m_instance = NULL;
}


#ifndef WIN32
void ProcessMgr::signal(pid_t pid, int /*signal*/)
{
	Process* proc = m_instance->m_processes[pid];	
	if(proc != NULL) {
		proc->m_isRunning = false;
	}
}
#endif
	
void ProcessMgr::register_proc(Process* proc)
{
	//fuppesThreadLockMutex(&m_instance->m_mutex);
  m_instance->m_mutex.lock();
	
	#ifndef WIN32
	m_instance->m_processes[proc->pid()] = proc;
	#endif
	
	//fuppesThreadUnlockMutex(&m_instance->m_mutex);
    m_instance->m_mutex.unlock();
}

void ProcessMgr::unregister_proc(Process* proc)
{
	//fuppesThreadLockMutex(&m_instance->m_mutex);
  m_instance->m_mutex.lock();
	
	#ifndef WIN32
	m_instance->m_processesIter = m_instance->m_processes.find(proc->pid());      
  if(m_instance->m_processesIter != m_instance->m_processes.end()) { 
		m_instance->m_processes.erase(proc->pid());
	}
	#endif
	
	//fuppesThreadUnlockMutex(&m_instance->m_mutex);
  m_instance->m_mutex.unlock();
}



#define MAX_ARGS 31


Process::Process()
{
  m_args = NULL;
	m_numArgs = 0;
	m_isRunning = false;
}

Process::~Process()
{
	ProcessMgr::unregister_proc(this);

	if(m_isRunning) {
		stop();
	}
	
	for(int i = 0; i < m_numArgs; i++) {
		free((void*)m_args[i]);
	}
  free(m_args);
}

bool Process::start(std::string cmd, std::list<std::string> args)
{

#ifndef WIN32

  m_pid =	fork();
	
	// child process
	if(m_pid == 0) {


    int argc = 0;
    char* argv[MAX_ARGS + 1];

    string tmp;
    args.push_front(cmd);
    
    std::list<std::string>::iterator iter;
    for(iter = args.begin(); iter != args.end(); iter++) {

      tmp = *iter;
  		/*if(tmp.compare("%in%") == 0)
			  tmp = m_inFile;      
      else if(tmp.compare("%out%") == 0)
        tmp = m_outFile;*/

      /*if(argc > 1)
        tmp = "\"" + tmp + "\"";*/
      
      argv[argc] = (char*)malloc(tmp.length() + 1 * sizeof(char*));
			strcpy((char*)argv[argc], tmp.c_str());
      argc++;
    }

    argv[argc] = (char*)malloc(sizeof(char*));
    argv[argc] = 0;
    
    for(int i = 0; i < argc; i++) {
      std::cout << "arg " << i << ": " << argv[i] << std::endl;
    }
    
		int ret = execv(argv[0], argv);
    
    // 0 = ok , -1 fail
		cout << "error execv:" << ret << endl;
    _exit(-1);
  }
	// parent process
	else if(m_pid > 0) {
    m_isRunning = true;
    ProcessMgr::register_proc(this);
    std::cout << "started process with PID: " << m_pid << std::endl;
    return true;
  }
	// fork() error
	else {
		m_isRunning = false;
		cout << "fork() failed" << endl;
		return false;
  }
  
  
  return false;
#else

  LPCTSTR lpApplicationName = cmd.c_str();

  std::string tmp;
  std::string commandLine = cmd;
  std::list<std::string>::iterator iter;
  for(iter = args.begin(); iter != args.end(); iter++) {

    tmp = *iter;
  	/*if(tmp.compare("%in%") == 0)
			tmp = m_inFile;      
    else if(tmp.compare("%out%") == 0)
      tmp = m_outFile;*/
    
    cmd += (" \"" + StringReplace(tmp, "\\", "/") + "\"");
  }


  std::cout << "STARTING: " << lpApplicationName << " ARGS: " << cmd << std::endl;
  
  
  LPTSTR lpCommandLine = strdup(cmd.c_str());

  LPCTSTR lpCurrentDirectory = NULL;
  
  ZeroMemory(&m_StartupInfo, sizeof(m_StartupInfo));
  m_StartupInfo.cb = sizeof(m_StartupInfo);

  ZeroMemory(&m_ProcessInformation, sizeof(m_ProcessInformation));

  m_StartupInfo.hStdError = GetStdHandle(STD_OUTPUT_HANDLE);
  m_StartupInfo.hStdOutput = GetStdHandle(STD_OUTPUT_HANDLE);
  m_StartupInfo.dwFlags |= STARTF_USESTDHANDLES;

  BOOL ret = CreateProcess(
                           NULL, //lpApplicationName,
                           lpCommandLine,
                           NULL,
                           NULL,
                           TRUE,
                           0, //CREATE_NO_WINDOW | DETACHED_PROCESS, // CREATE_NEW_CONSOLE
                           NULL,
                           lpCurrentDirectory,
                           &m_StartupInfo,
                           &m_ProcessInformation);

  //std::cout << lpApplicationName << " " << lpCommandLine <<  " " << ret << std::endl;
  

  free(lpCommandLine);

  m_isRunning = (ret != 0);
  return m_isRunning;
  
#endif
}

/*
bool Process::start(std::string cmd)
{
#ifndef WIN32
	m_isRunning = true;
  m_pid =	fork();
	
	// child process
	if(m_pid == 0) {
		parseArgs(cmd);
		execv(m_args[0], (char**)m_args);
		cout << "error execv" << endl;
    _exit(-1);
  }
	// parent process
	else if(m_pid > 0) {
		ProcessMgr::register_proc(this);
    return true;
  }
	// fork() error
	else {
		m_isRunning = false;
		cout << "fork() failed" << endl;
		return false;
  }
#else

  parseArgs(cmd);


  LPCTSTR lpApplicationName = m_args[0];
  
  string params;
  for(int i = 0; i < m_numArgs; i++) {
		params += m_args[i];
    params += " ";
	}
  LPTSTR lpCommandLine = strdup(params.c_str());

  LPCTSTR lpCurrentDirectory = NULL;
  
  ZeroMemory(&m_StartupInfo, sizeof(m_StartupInfo));
  m_StartupInfo.cb = sizeof(m_StartupInfo);

  ZeroMemory(&m_ProcessInformation, sizeof(m_ProcessInformation));
  

  BOOL ret = CreateProcess(
                           lpApplicationName,
                           lpCommandLine,
                           NULL,
                           NULL,
                           false,
                           CREATE_NO_WINDOW | DETACHED_PROCESS,
                           NULL,
                           lpCurrentDirectory,
                           &m_StartupInfo,
                           &m_ProcessInformation);

  std::cout << lpApplicationName <<   std::endl;
  

  free(lpCommandLine);
                           
	return ret;
#endif

BOOL WINAPI CreateProcess(
  __in_opt     LPCTSTR lpApplicationName,
  __inout_opt  LPTSTR lpCommandLine,
  __in_opt     LPSECURITY_ATTRIBUTES lpProcessAttributes,
  __in_opt     LPSECURITY_ATTRIBUTES lpThreadAttributes,
  __in         BOOL bInheritHandles,
  __in         DWORD dwCreationFlags,
  __in_opt     LPVOID lpEnvironment,
  __in_opt     LPCTSTR lpCurrentDirectory,
  __in         LPSTARTUPINFO lpStartupInfo,
  __out        LPPROCESS_INFORMATION lpProcessInformation
);
  
}
*/

bool Process::isRunning()
{
#ifndef WIN32
  return m_isRunning;
#else

  DWORD ExitCode;
  BOOL ret = GetExitCodeProcess(m_ProcessInformation.hProcess, &ExitCode);

  // error
  if(ret == 0) {
    return false;
  }

  //std::cout << "Process::isRunning(): " << ret << " code: " << ExitCode << std::endl;
  
  return (ExitCode == STILL_ACTIVE);
#endif
}

void Process::stop()
{
  if(!isRunning())
    return;

#ifndef WIN32
  kill(m_pid, SIGTERM);
#else
#endif
}

void Process::terminate()
{
  if(!isRunning())
    return;
  
#ifndef WIN32
  kill(m_pid, SIGKILL);
#else  
  UINT ExitCode = 2;
  BOOL ret = TerminateProcess(m_ProcessInformation.hProcess, ExitCode);

  //std::cout << "Process::terminate(): " << ret << " code: " << ExitCode << std::endl;
#endif
}

void Process::waitFor()
{
#ifndef WIN32
	while(isRunning()) {
		fuppesSleep(100);
	}
#else
  if(!isRunning())
    return;
    
  WaitForSingleObject(m_ProcessInformation.hProcess, 1000);
#endif

}


/*
void Process::parseArgs(std::string cmd)
{		
	string arg;
	string tmp;
	string::size_type pos;
	
	bool escape = false;
	bool quote = false;


  if(NULL != m_args) {
    for(int i = 0; i < m_numArgs; i++)
		  free((void*)m_args[i]);
    free(m_args);
    m_numArgs = 0;
  }
  
	m_args = (char const**)malloc(MAX_ARGS + 1 * sizeof(*m_args));
	
	cmd += " ";
	
	while(!cmd.empty()) {
		
		if((pos = cmd.find(" ", 0)) == string::npos)
			break;
		
		tmp = cmd.substr(0, pos);
		if(tmp.compare("%in%") == 0) {
			tmp = m_inFile;
		}
		else if(tmp.compare("%out%") == 0) {
			tmp = m_outFile;
		}
			 
		if(!escape && !quote) {			
			arg = tmp;
		}

		cmd = cmd.substr(pos + 1);
		
		if(escape || quote) {
			arg = arg + " " + tmp;
			escape = false;
		}
		
		// quote start
		if(tmp.substr(0, 1).compare("\"") == 0) {
			quote = true;
			arg = arg.substr(1);
		}
		// quote end
		else if(tmp.substr(tmp.length()-1, 1).compare("\"") == 0) {
			quote = false;
			arg = arg.substr(0, arg.length() - 1);
			
			m_args[m_numArgs] = (char*)malloc(arg.length() + 1 * sizeof(char*));
			strcpy((char*)m_args[m_numArgs++], arg.c_str());
		}
		// escape
		else if(tmp.substr(tmp.length()-1, 1).compare("\\") == 0) {
			escape = true;
			arg = arg.substr(0, arg.length() - 1);
		}
		else {
			m_args[m_numArgs] = (char*)malloc(arg.length() + 1 * sizeof(char*));
			strcpy((char*)m_args[m_numArgs++], arg.c_str());
		}
	}
	
	m_args[m_numArgs] = (char*)0;
	
}
*/
