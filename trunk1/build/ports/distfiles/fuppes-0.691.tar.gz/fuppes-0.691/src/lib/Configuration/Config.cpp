/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            Config.cpp
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2011 Ulrich Völkel <fuppes@ulrich-voelkel.de>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "Config.h"
#include "../Log.h"
#include "../Common/File.h"

using namespace fuppes;

#include <assert.h>
#include <iostream>

Config* Config::m_instance = NULL;

void Config::init() // static
{
  assert(m_instance == NULL);
  m_instance = new Config();
}

void Config::uninit() // static
{
  assert(m_instance != NULL);
  delete m_instance;
  m_instance = NULL;
}




bool Config::load(std::string filename) // static
{
  assert(m_instance != NULL);

  log(Log::config, Log::normal) << "load config: " << filename;

  m_instance->m_doc = xmlReadFile(filename.c_str(), "UTF-8", XML_PARSE_NOBLANKS);

  if(m_instance->m_doc == NULL)
    return false;
  
  m_instance->m_rootNode = xmlDocGetRootElement(m_instance->m_doc);
  
  if(m_instance->m_rootNode == NULL) {
    xmlFreeDoc(m_instance->m_doc);
    return false;
  }


  xmlAttrPtr version = xmlHasProp(m_instance->m_rootNode, BAD_CAST "version");
  if(version == NULL) {
    xmlFreeDoc(m_instance->m_doc);
    return false;    
  }


  log(Log::config, Log::normal) << "version: " << (char*)version->children->content;


  xmlNodePtr section = xmlFirstElementChild(m_instance->m_rootNode);
  std::string name;
  while(section) {

    log(Log::config, Log::normal) << "section: " << (char*)section->name;

    name = (char*)section->name;
    m_instance->m_sections[name] = section;
    
    section = xmlNextElementSibling(section);
  }
    

/*
  std::map<std::string, xmlNodePtr>::iterator iter;
  for(iter = m_instance->m_sections.begin(); iter != m_instance->m_sections.end(); iter++) {
    std::cout << iter->first << " = " << (char*)iter->second->name << std::endl;  
  }
*/
  m_instance->m_filename = filename;
  
  return true;
}

void Config::save()
{  
  if(!File::writable(m_filename)) {
    std::cout << "WARNING: config file: " << m_filename << " is not writable" << std::endl;
    return;
  }
  
  int ret = xmlSaveFormatFileEnc(m_filename.c_str(), m_doc, "UTF-8", 1);
  if(ret == -1)
    std::cout << "WARNING: error writing config file" << std::endl;
}



xmlNodePtr Config::findNode(std::string section, std::string key = "")
{
  // find the section
  std::map<std::string, xmlNodePtr>::iterator iter;
  iter = m_instance->m_sections.find(section);
  if(iter == m_instance->m_sections.end())
    return NULL;

  // no key => return the section
  if(key.empty())
    return iter->second;

  // find the key
  xmlNodePtr node = xmlFirstElementChild(iter->second);
  while(node) {
    if(key.compare((char*)node->name) == 0)
      return node;
    node = xmlNextElementSibling(node);
  }

  return NULL;
}

std::string Config::getValue(const std::string section, const std::string key, const std::string defaultValue /*= ""*/) // static
{
  assert(m_instance != NULL);
  
  std::string value = defaultValue;

  xmlNodePtr node = m_instance->findNode(section, key);
  if(node && node->children && node->children->content && node->children->type == XML_TEXT_NODE) {
    value = (char*)node->children->content;
  }
  
  return value;
}


void Config::setValue(std::string section, std::string key, std::string value) // static
{
  assert(m_instance != NULL);
  
  xmlNodePtr node = m_instance->findNode(section, key);
  if(node == NULL)
    return;

  if(node->children)
    xmlNodeSetContent(node->children, BAD_CAST value.c_str());       
  else
    xmlNodeAddContent(node, BAD_CAST value.c_str());

  m_instance->save();
}

std::string Config::getAttribute(std::string section, std::string attribute) // static
{
  assert(m_instance != NULL);
  
  std::string value;

  // get the section node
  xmlNodePtr sect = m_instance->findNode(section);
  if(sect == NULL)
    return value;

  // find the attribute
  xmlAttrPtr attr = sect->properties;
  while(attr) {

    if(attribute.compare((char*)attr->name) == 0) {
      value = (char*)attr->children->content;
      break;
    }

    attr = attr->next;
  } 
    
  return value;
}


bool Config::getEntries(std::string section, std::string subsection, EntryList& list) // static
{
  assert(m_instance != NULL);
  
  // get the (sub-)section node
  xmlNodePtr sect = m_instance->findNode(section, subsection);
  if(sect == NULL)
    return false;

  ConfigEntry entry;

  // loop through the section's children
  xmlNodePtr node = xmlFirstElementChild(sect);
  while(node) {

    // name
    entry.key = (char*)node->name;

    // value if available
    if(node->children && node->children->content && node->children->type == XML_TEXT_NODE)
      entry.value = (char*)node->children->content;
    
    // attributes
    xmlAttrPtr attr = node->properties;
    while(attr) {
      entry.attributes[(char*)attr->name] = (char*)attr->children->content;           
      attr = attr->next;
    }

    // xml node
    entry.m_node = node;
    
    list.push_back(entry);
    entry.clear();

    node = xmlNextElementSibling(node);
  }
  
  return true;  
}


void Config::setEntry(std::string section, std::string subsection, ConfigEntry& entry) // static
{
  assert(m_instance != NULL);
  
  // get the (sub-)section node
  xmlNodePtr sect = m_instance->findNode(section, subsection);
  if(sect == NULL)
    return;

  xmlNodePtr node = entry.m_node;
  // if it's a new entry (node is NULL) we append it to the (sub-)section
  if(NULL == node) {

    if(entry.value.empty())
      node = xmlNewChild(sect, NULL, BAD_CAST entry.key.c_str(), NULL);
    else  
      node = xmlNewTextChild(sect, NULL, BAD_CAST entry.key.c_str(), BAD_CAST entry.value.c_str());

  }
  // else we update the node
  else if(NULL != node) {

    // set the value if available
    if(!entry.value.empty()) {
      if(node->children)
        xmlNodeSetContent(node->children, BAD_CAST entry.value.c_str());       
      else
        xmlNodeAddContent(node, BAD_CAST entry.value.c_str());
    }

  }
  

  // add/update attributes
  xmlAttrPtr attr;
  std::map<std::string, std::string>::iterator iter;
  for(iter = entry.attributes.begin(); iter != entry.attributes.end(); iter++) {

    attr = xmlHasProp(node, BAD_CAST iter->first.c_str());
    if(NULL == attr)
      attr = xmlNewProp(node, BAD_CAST iter->first.c_str(), BAD_CAST iter->second.c_str());    
    else
      attr = xmlSetProp(node, BAD_CAST iter->first.c_str(), BAD_CAST iter->second.c_str());  

  }

  m_instance->save();
}

void Config::removeEntry(std::string section, std::string subsection, ConfigEntry& entry) // static
{
  assert(m_instance != NULL);
  
  // get the (sub-)section node
  xmlNodePtr sect = m_instance->findNode(section, subsection);
  if(sect == NULL)
    return;

  xmlNodePtr node = entry.m_node;
  if(NULL == node)
    return;

  xmlUnlinkNode(node);
  xmlFreeNode(node);
  entry.m_node = NULL;

  m_instance->save();
}
