/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            UpdateThread.cpp
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2010 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "UpdateThread.h"
#include "FileDetails.h"
#include "ContentDatabase.h"
#include "VirtualContainerMgr.h"
#include "PlaylistParser.h"
#include "../Plugins/Plugin.h"
#include "../SharedConfig.h"

#include "../../../include/fuppes_plugin.h"

using namespace fuppes;

#include <iostream>
using namespace std;



UpdateThread::UpdateThread(FileAlterationHandler* famHandler)
:Thread("UpdateThread")
{
  m_famHandler = famHandler;
}

UpdateThread::~UpdateThread()
{
  close();
}


/*

1. check for "normal" files to update (DEVICE == NULL && REF_ID == 0)
2. check for "referenced" files to update (DEVICE == NULL && REF_ID > 0)
   if we find metadata in the playlist we add this else we set the DETAIL_ID to the same as the referenced object (REF_ID)
3. check "normal" dirs for update (DEVICE == NULL)
   - check for album art
   - set container type to e.g. music.Album if it contains only audio items
 
*/

bool UpdateThread::famEventOccurred() // inline
{
  int diff = DateTime::now().toInt() - m_famHandler->lastEventTime().toInt();
  return (diff < 5);
}

void UpdateThread::run()
{
  //cout << "start update thread" << endl;

  m_sleep = 0;
  m_count = 0;
  
  msleep(1000);

  CDatabaseConnection* connection = CDatabase::connection(true);
  
  SQLQuery qry(connection);
  SQLQuery ins(connection);
  SQLQuery get(connection);
  //DbObject* obj;
  stringstream sql;
  while(!stopRequested()) {

    m_count = 0;

    if(famEventOccurred()) {
      msleep(500);
      continue;
    }

    // 1. update the items metadata
    updateItemsMetadata(connection, &get, &ins);
    if(famEventOccurred())
      continue;
    
    // 2. check for album art and update dirs/files
    updateAlbumArt(&qry, &get, &ins);  
    if(famEventOccurred())
      continue;
    
    // 3. map images or create video thumbnails if enabled
    createVideoThumbnails(&qry, &get, &ins);
    if(famEventOccurred())
      continue;
    
    // 4. parse playlists
    parsePlaylists(&qry, &get, &ins);
    if(famEventOccurred())
      continue;

    
    // let the thread sleep for a while
    // we chunk the sleep time to avoid blocking closing of this thread
    // on shutdown or database update/rebuild
    int tmp = m_sleep;
    do {
      if(tmp > 500) {
        msleep(500);
        tmp -= 500;
      }
      else {
        msleep(tmp);
        tmp = 0;
      }
    } while(tmp > 0 && !stopRequested());
    
  } // !stopRequested


  delete connection;
  
  //cout << "exit update thread" << endl;
  
}



bool UpdateThread::updateItemsMetadata(CDatabaseConnection* connection, SQLQuery* get, SQLQuery* set)
{
  stringstream sql;
  DbObject* obj;

  m_count = 0;
  
  // update metadata
  sql << "select * from OBJECTS where TYPE > " << ITEM << " and (UPDATED_AT is NULL or UPDATED_AT < MODIFIED_AT) and DEVICE is NULL and REF_ID = 0";
  get->select(sql.str());
  if(get->eof()) {
    if(m_sleep < 4000)
      m_sleep += 500;
    return false;
  }
  m_sleep = 500;
  
    
  while(!get->eof() && !stopRequested()) {

    // check if a fam event occured recently
    int diff = DateTime::now().toInt() - m_famHandler->lastEventTime().toInt();
    if(diff < 5) {
      return (m_count > 0);
    }
      
    m_count++;
    obj = new DbObject(get->result());

    cout << "update object " << m_count << " of " << get->size() << " :: " << obj->fileName() << " :: " << obj->type() << endl;
      
    // container
    if(obj->type() < CONTAINER_MAX) {

    } // container
    else if(obj->type() >= ITEM) {

      ObjectDetails oldDetails;
      bool update = (obj->detailId() > 0);
      if(update)
        oldDetails = *obj->details();

      switch(obj->type()) {

        case ITEM_IMAGE_ITEM:
        case ITEM_IMAGE_ITEM_PHOTO:
          updateImageFile(obj, set);
          if(!update)
            VirtualContainerMgr::insertFile(obj);
          else
            VirtualContainerMgr::updateFile(obj, &oldDetails);
          break;

        case ITEM_AUDIO_ITEM:
        case ITEM_AUDIO_ITEM_MUSIC_TRACK:
          updateAudioFile(obj, set);
          if(!update)
            VirtualContainerMgr::insertFile(obj);
          else
            VirtualContainerMgr::updateFile(obj, &oldDetails);
          break;
        case ITEM_AUDIO_ITEM_AUDIO_BROADCAST:
          break;

        case ITEM_VIDEO_ITEM:
        case ITEM_VIDEO_ITEM_MOVIE:
        case ITEM_VIDEO_ITEM_MUSIC_VIDEO_CLIP:
          updateVideoFile(obj, set);
          if(!update)
            VirtualContainerMgr::insertFile(obj);
          else
            VirtualContainerMgr::updateFile(obj, &oldDetails);
          break;
        case ITEM_VIDEO_ITEM_VIDEO_BROADCAST:
          break;


        case ITEM_UNKNOWN_BROADCAST:
          updateBroadcastUrl(obj, set);
          break;
          
        default:
          break;          
      }

    } // item
      
    delete obj;
    get->next();
    msleep(1);
  } // while !eof

  return (m_count > 0);
}






void UpdateThread::updateAudioFile(DbObject* obj, SQLQuery* qry)
{
  string fileName = obj->path() + obj->fileName();
  AudioItem audioItem;
  //cout << "UPDATE AUDIO FILE: " << fileName << endl;

  bool gotMetadata = true;
	gotMetadata = CFileDetails::getMusicTrackDetails(fileName, &audioItem);

  //unsigned int objectId = obj->objectId(); // CContentDatabase::GetObjId();
	//unsigned int imgId;
  
	string imgMimeType;
	if(audioItem.hasImage()) {
		//imgId = objectId;
		imgMimeType = audioItem.imageMimeType();
	}

  ObjectDetails details;
  details.setSize(getFileSize(fileName));
  if(gotMetadata) {
    details = audioItem;
  }

  
  if(audioItem.hasImage()) {
    details.setAlbumArtId(obj->objectId());

    string ext = CDeviceIdentificationMgr::Shared()->DefaultDevice()->extensionByMimeType(audioItem.imageMimeType());
    details.setAlbumArtExt(ext);    
    details.setAlbumArtMimeType(audioItem.imageMimeType());
    details.setAlbumArtWidth(audioItem.imageWidth());
    details.setAlbumArtHeight(audioItem.imageHeight());
  }

  details.save(qry);

  if(!audioItem.title().empty())
    obj->setTitle(audioItem.title());
  obj->setDetailId(details.id());
  obj->save(qry);  
}

void UpdateThread::updateImageFile(DbObject* obj, SQLQuery* qry)
{
  string fileName = obj->path() + obj->fileName();
  cout << "UPDATE IMAGE FILE: " << fileName << endl;

  ImageItem imageItem;
  bool gotMetadata = CFileDetails::getImageDetails(fileName, &imageItem);

  if(!gotMetadata) {
    obj->setUpdated();
    obj->save();
    return;
  }
  
  /*string dlna;
	string mimeType;
	string ext = ExtractFileExt(fileName);
	if(CPluginMgr::dlnaPlugin()) {
		CPluginMgr::dlnaPlugin()->getImageProfile(ext, imageItem.width(), imageItem.height(), &dlna, &mimeType);
	}*/

  ObjectDetails details;
  details = imageItem;
  details.setSize(getFileSize(fileName));
  details.save(qry);
  
  obj->setDetailId(details.id());
  obj->save(qry);
  
	/*stringstream sSql;
	sSql << 
	  "insert into OBJECT_DETAILS " <<
		"(SIZE, IV_WIDTH, IV_HEIGHT, DATE, " <<
		"DLNA_PROFILE, DLNA_MIME_TYPE) " <<
		"values (" <<
		getFileSize(fileName) << ", " <<
		ImageItem.nWidth << ", " <<
		ImageItem.nHeight << ", " <<
   (ImageItem.sDate.empty() ? "NULL" : "'" + ImageItem.sDate + "'") << ", " <<
    "'" << dlna << "', " <<
		"'" << mimeType << "')";
	
  return qry->insert(sSql.str()); */ 
  
}


void UpdateThread::updateVideoFile(DbObject* obj, SQLQuery* qry)
{
  string fileName = obj->path() + obj->fileName();
  cout << "UPDATE VIDEO FILE: " << fileName << endl;
  
  VideoItem videoItem;
	bool gotMetadata = CFileDetails::getVideoDetails(fileName, &videoItem);

  ObjectDetails details;
  details.setSize(getFileSize(fileName));

  // check for subtitles
  if(File::exists(TruncateFileExt(fileName) + ".srt")) {
    details.setHasSubtitlesFile(true);
  }
  
  if(gotMetadata)
    details = videoItem;
  else
    details.setUpdated();
  details.save(qry);
  
  obj->setDetailId(details.id());
  //if(!videoItem.title().empty())
  //  obj->setTitle(videoItem.title());
  obj->setUpdated();
  obj->save(qry);
}

void UpdateThread::updateBroadcastUrl(DbObject* obj, SQLQuery* qry)
{
  //string fileName = obj->path() + obj->fileName();
  cout << "UPDATE BROADCAST URL: " << obj->path() << " " << obj->fileName() << endl;
  
  obj->setType(ITEM_AUDIO_ITEM_AUDIO_BROADCAST);
  //obj->setType(ITEM_AUDIO_ITEM_VIDEO_BROADCAST);
  
  obj->setUpdated();
  obj->save(qry);
}


void UpdateThread::updateAlbumArt(SQLQuery* qry, SQLQuery* get, SQLQuery* ins)
{
    // check for album art and update dirs/files
    m_count = 0;
    stringstream sql;
    DbObject* obj;
    DbObject* parent;
    DbObject* sibling;
    object_id_t lastPid = 0;
    
    // get all visible images that have a certain name
    sql << 
      "select * from OBJECTS where TYPE >= " << ITEM_IMAGE_ITEM << " and TYPE < " << ITEM_IMAGE_ITEM_MAX << " and " <<
      "DEVICE is NULL and REF_ID = 0 and VISIBLE = 1 and lower(FILE_NAME) in ( " <<
      CSharedConfig::getAlbumArtFiles() <<
      ") order by FILE_NAME, PARENT_ID";
   
    qry->select(sql.str());
    while(!qry->eof() && !stopRequested()) {

      // check if a fam event occured recently
      int diff = DateTime::now().toInt() - m_famHandler->lastEventTime().toInt();
      if(diff < 5) {
        break;
      }

      m_count++;
      obj = new DbObject(qry->result());
      
      if(obj->parentId() == lastPid) {
        delete obj;
        qry->next();
        continue;        
      }
            
      parent = DbObject::createFromObjectId(obj->parentId());

      //cout << "ALBUM ART FILE: " << obj->fileName() << " PID: " << obj->parentId() << endl;
      
      if(parent->details()->albumArtId() != 0) {
        delete parent;
        delete obj;
        qry->next();
        continue; 
      }


      
      // set the parent folder album art id      
      string ext = ExtractFileExt(obj->fileName());
      string mime = CDeviceIdentificationMgr::Shared()->DefaultDevice()->MimeType(ext);
      
      parent->details()->setAlbumArtId(obj->objectId());
      parent->details()->setAlbumArtExt(ext);
      parent->details()->setAlbumArtMimeType(mime);      
      
      parent->details()->setAlbumArtWidth(obj->details()->width());
      parent->details()->setAlbumArtHeight(obj->details()->height());
      parent->details()->save(ins);
      parent->setDetailId(parent->details()->id());
      parent->save(ins);
      delete parent;


      // get the audio siblings and set their album art id
      sql.str("");
      sql << 
        "select * from OBJECTS where PARENT_ID = " << obj->parentId() << " and " <<
        "TYPE >= " << ITEM_AUDIO_ITEM << " and TYPE < " << ITEM_AUDIO_ITEM_MAX << " and " <<
        "DEVICE is NULL";
      //cout << sql.str() << endl;
      get->select(sql.str());
      while(!get->eof()) {
        
        sibling = new DbObject(get->result());

        if(sibling->details()->albumArtId() == 0) {
          sibling->details()->setAlbumArtId(obj->objectId());
          sibling->details()->setAlbumArtExt(ext);
          sibling->details()->setAlbumArtMimeType(mime);
          sibling->details()->setAlbumArtWidth(obj->details()->width());
          sibling->details()->setAlbumArtHeight(obj->details()->height());
          sibling->details()->save(ins);
          sibling->setDetailId(sibling->details()->id());
          sibling->save(ins);
        }

        delete sibling;
        get->next();
      }
      

      

      // hide the image object
      lastPid = obj->parentId();      
      obj->setVisible(false);
      obj->save();
      //obj->details()->setAlbumArtExt(ExtractFileExt(obj->fileName()));
      obj->details()->save(ins);
      delete obj;
      qry->next();
      msleep(1);
    } // while !eof (update album art)
  
}


void UpdateThread::createVideoThumbnails(SQLQuery* qry, SQLQuery* get, SQLQuery* ins) {
  
  m_count = 0;
  DbObject* obj;
  DbObject* image;
  stringstream sql;

  CMetadataPlugin* thumbnailer = CPluginMgr::metadataPlugin("ffmpegthumbnailer");
  
  sql << 
      "select * from OBJECTS where TYPE >= " << ITEM_VIDEO_ITEM << " and TYPE < " << ITEM_VIDEO_ITEM_MAX << " and " <<
      "DEVICE is NULL and REF_ID = 0 and " <<
      "DETAIL_ID in (select ID from OBJECT_DETAILS where ALBUM_ART_ID = 0 and ALBUM_ART_EXT is NULL);";
  qry->select(sql.str());
  while(!qry->eof() && !stopRequested()) {

    // check if a fam event occured recently
    int diff = DateTime::now().toInt() - m_famHandler->lastEventTime().toInt();
    if(diff < 5) {
      break;
    }

    m_count++;
    obj = new DbObject(qry->result());
      
    // check if we got an image file with the same name as the video
    sql.str("");
    sql << "select * from OBJECTS where " <<
      "PATH = '" << SQLEscape(obj->path()) << "' and " <<
      "FILE_NAME like '" << SQLEscape(TruncateFileExt(obj->fileName())) << ".%' and " <<
      "TYPE >= " << ITEM_IMAGE_ITEM << " and TYPE < " << ITEM_IMAGE_ITEM_MAX << " and " <<
      "DEVICE is NULL and " <<
      "REF_ID = 0";
    get->select(sql.str());
    if(!get->eof()) {

      image = new DbObject(get->result());

      // set album art
      obj->details()->setAlbumArtId(image->objectId());
      obj->details()->setAlbumArtExt(ExtractFileExt(image->fileName()));
      obj->details()->save(ins);

      // hide image
      image->setVisible(false);
      image->save(ins);
      
      delete image;
      delete obj;
      qry->next();
      msleep(1);
      continue;
    }


    string filename = obj->path() + obj->fileName();
    stringstream tmpfile;
    tmpfile << PathFinder::findThumbnailsDir() << obj->objectId() << ".jpg";
    
                                        
      if(thumbnailer) {

        cout << "create thumbnail " << m_count << " of " << qry->size() << " for: " << filename << endl;

        size_t size = 0;
	    	unsigned char* buffer = (unsigned char*)malloc(1);
	    	char mimeType[100];// = (char*)malloc(1);
	    	//memset(mimeType, 0, 1);

			  thumbnailer->openFile(filename);
        bool hasImage = thumbnailer->readImage(&mimeType[0], &buffer, &size, 300);
    		thumbnailer->closeFile();
			

        if(hasImage) {

          //cout << "HAS IMAGE: " << size << endl;
          
          fuppes::File out(tmpfile.str());
          out.open(File::Write);
          out.write((char*)buffer, size);
          out.close();


          // set the album art id to the same value as the object id
          obj->details()->setAlbumArtId(obj->objectId());
          obj->details()->setAlbumArtExt("jpg");
          obj->details()->setAlbumArtMimeType(mimeType);
          obj->details()->save(ins);
        }
        else {
          obj->details()->setAlbumArtExt("fail");
          obj->details()->save(ins);
        }
        
        free(buffer);
			  //free(mimeType);


      } // if thumbnailer

      delete obj;
      qry->next();
      msleep(1);
    } // while !eof (video thumbnails)
    if(thumbnailer)
      delete thumbnailer;
}


void UpdateThread::parsePlaylists(SQLQuery* qry, SQLQuery* get, SQLQuery* ins)
{
  return;

  stringstream sql;
  sql << "select * from OBJECTS where TYPE = " << CONTAINER_PLAYLISTCONTAINER << " and (UPDATED_AT is NULL or UPDATED_AT < MODIFIED_AT)";

  BasePlaylistParser* parser;
  DbObject* playlist;
  DbObject* existing;
  
  qry->select(sql.str());
  while(!qry->eof() && !famEventOccurred()) {

    parser = BasePlaylistParser::Load(qry->result()->asString("PATH") + qry->result()->asString("FILE_NAME"));
    if(parser == NULL)
      continue;
    
    object_id_t playlistId = qry->result()->asUInt("OBJECT_ID");
    //object_id_t objectId   = 0;  

    playlist = new DbObject(qry->result());
    
    while(!parser->Eof()) {
      if(parser->Entry()->bIsLocalFile && File::exists(parser->Entry()->sFileName)) {       

        log(Log::contentdb, Log::normal) << "PLENTRY: " << parser->Entry()->sFileName;

        existing = DbObject::createFromFileName(parser->Entry()->sFileName, get);
        if(existing == NULL) {
          CContentDatabase::insertFile(parser->Entry()->sFileName, playlistId, ins, false);
          CContentDatabase::incSystemUpdateId();
        }            
        else {
          DbObject* object = new DbObject(existing);
          object->setObjectId(CContentDatabase::GetObjId());
          object->setParentId(playlistId);        
          object->setRefId(existing->objectId());
          object->save(ins);
          delete object;
          delete existing;
        }
      }
      else if(!parser->Entry()->bIsLocalFile) {

        DbObject* object = new DbObject();
        object->setObjectId(CContentDatabase::GetObjId());
        object->setParentId(playlistId);
        object->setTitle(parser->Entry()->sTitle);
        object->setPath(parser->Entry()->sFileName);
        object->setType(ITEM_UNKNOWN_BROADCAST);
        object->save(ins);
        delete object;

      }    
    
      parser->Next();
    }
  
    delete parser;
    
    playlist->setUpdated();
    playlist->save(ins);
    delete playlist;
    
    qry->next();
  }
}
