/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            ItemSource.h
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2011 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _ITEM_SOURCE_H
#define _ITEM_SOURCE_H

#ifdef HAVE_CONFIG_H
#include "../../config.h"
#endif

#include "../../../include/fuppes_plugin.h"
#include "../../../include/fuppes_plugin_types.h"

#include "Plugin.h"

namespace fuppes
{


typedef int		(*itemSourceOpen_t)(plugin_info* plugin, const char* name);
typedef int		(*itemSourceNext_t)(plugin_info* plugin, struct metadata_t* metadata);
typedef void	(*itemSourceClose_t)(plugin_info* plugin);
  
class ItemSource: public CPlugin
{
  public:
    ItemSource(fuppesLibHandle handle, plugin_info* info);
    ItemSource(ItemSource* plugin);
    
    bool initPlugin();

    std::string baseName() { return m_pluginInfo.source_base_name; }

    source_flags_t  flags() { return m_pluginInfo.source_flags; }
    
    bool open(std::string name);
    bool next(struct metadata_t* metadata);
    void close();

  private:
		itemSourceOpen_t				m_open;
    itemSourceNext_t        m_next;
    itemSourceClose_t       m_close;
};

}

#endif // _ITEM_SOURCE_H
