/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            SharedObjects.cpp
 * 
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2010-2011 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "SharedObjects.h"
#include "../SharedConfig.h"

#include "../Common/Common.h"

using namespace std;

SharedObjects::~SharedObjects()
{
  clear();
}

// shared dirs
bool SharedObjects::Read(void)
{  
  clear();  

  SharedObject* obj;

  fuppes::EntryList list;
  fuppes::EntryListIterator iter;
  fuppes::Config::getEntries(SECTION_SHARED_OBJECTS, "", list);
  
  for(iter = list.begin(); iter != list.end(); iter++) {

    fuppes::ConfigEntry cfg = *iter;
    
    if(cfg.key.compare("dir") == 0) {
      obj = new SharedObject();
      obj->m_type = SharedObject::directory;
      obj->m_path = fuppes::Directory::appendTrailingSlash(cfg.value);
      obj->m_configEntry = cfg;
      m_sharedObjects.push_back(obj);
		}
		else if(cfg.key.compare("itunes") == 0) {
      obj = new SharedObject();
      obj->m_type = SharedObject::other;
      obj->m_otherType = "itunes";
      obj->m_path = cfg.value;
      obj->m_configEntry = cfg;
      m_sharedObjects.push_back(obj);
		}
    else if(cfg.key.compare("item") == 0) {
      obj = new SharedObject();
      obj->m_type = SharedObject::other;
      obj->m_otherType = cfg.attributes["type"];
      obj->m_name = cfg.attributes["name"];
      obj->m_path = cfg.value;
      obj->m_configEntry = cfg;
      m_sharedObjects.push_back(obj);
		}

	}

  return true;
}

void SharedObjects::clear()
{
  for(m_sharedObjectsIter = m_sharedObjects.begin();
      m_sharedObjectsIter != m_sharedObjects.end();
      m_sharedObjectsIter++) {
    delete *m_sharedObjectsIter;
  }
  m_sharedObjects.clear();
}

SharedObject* SharedObjects::addSharedObject(SharedObject::SharedObjectType type, std::string path, std::string name /*= ""*/, std::string otherType /*= ""*/)
{
  string tag;
  switch(type) {
    case SharedObject::directory:
      tag = "dir";
      break;
    case SharedObject::playlist:
      tag = "playlist";
      break;
    case SharedObject::other:
      tag = "item";
      break;
    default:
      return NULL;
      break;
  }

  // add the new object to the list  
  SharedObject* result = new SharedObject();
  result->m_type = type;
  result->m_path = ToUTF8(path, CSharedConfig::Shared()->contentDirectory->GetLocalCharset());
  result->m_name = name;
  result->m_otherType = otherType;
  m_sharedObjects.push_back(result);

  // and to the config file
  fuppes::ConfigEntry cfg;
  cfg.key = tag;
  cfg.value = result->path();
  if(type == SharedObject::other) {
    cfg.attributes["name"] = result->name();
    cfg.attributes["type"] = result->otherType();
  }
  fuppes::Config::setEntry(SECTION_SHARED_OBJECTS, "", cfg); 

  // return the new object
  return result;
}

void SharedObjects::removeSharedObject(std::string uuid)
{  
  SharedObject* so = sharedObject(uuid);
  if(NULL == so)
    return;

  // remove from config file
  fuppes::Config::removeEntry(SECTION_SHARED_OBJECTS, "", so->m_configEntry);

  // remove from list
  for(m_sharedObjectsIter = m_sharedObjects.begin();
      m_sharedObjectsIter != m_sharedObjects.end();
      m_sharedObjectsIter++) {
    if((*m_sharedObjectsIter)->uuid() == uuid) {
      m_sharedObjects.erase(m_sharedObjectsIter);
      break;
    }
  }

  delete so;
}

