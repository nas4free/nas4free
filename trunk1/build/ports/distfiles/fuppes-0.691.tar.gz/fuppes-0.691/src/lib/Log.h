/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */

#ifndef _LOG_H
#define _LOG_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "../../include/fuppes_types.h"
#include "UPnPBase.h"
#include "Common/Thread.h"
#include "Common/Common.h"

#include <list>
#include <string>
#include <stdarg.h>
#include <sstream>

namespace fuppes {

  class Log;
	class Exception;


  struct LogEntry
  {
    std::string sender;
    std::string message;
    DateTime    dateTime;

    LogEntry() {
      dateTime = DateTime::now();
    }
  };
  
  /* if active a singleton instance will buffer a configurable amount of log messages
   * which can be read by the webinterface */  
  class LogBuffer 
  {
    public:
      static void init();
      static void uninit();
      //

      
      static void append(const Log* log);
      static bool read(LogEntry &entry);
      static size_t size();
      static void clear();
      
      static bool active() { return instance()->m_active; }
      static void setActive(bool active) { 
        instance()->m_active = active;
        if(!active)
          instance()->clear();
      }

    private:
      LogBuffer();
      static LogBuffer*    instance();
      static LogBuffer*    m_instance;

      Mutex                m_mutex;
      std::list<LogEntry>  m_entries;
      bool                 m_active;
  };

  
  class Log {

		public:
      Log() {
        m_logSenders = 0;
      }

			enum Sender {
				unknown    = 0,
				http       = 1 << 0,
        soap       = 1 << 1,
        gena       = 1 << 2,
				ssdp       = 1 << 3,
				fam        = 1 << 4,
        contentdir = 1 << 5,
        contentdb  = 1 << 6,
        sql        = 1 << 7,
				plugin     = 1 << 8,
        config     = 1 << 9,
        hotplug    = 1 << 10,

        all        = 
          http | soap | gena | ssdp | fam | contentdir | contentdb | sql | plugin | config | hotplug
			};
		
		  enum Level {
		    none			= 0,
		    normal		= 1 << 0,
		    extended	= 1 << 1,
		    debug			= 1 << 2,
        
        warning		= 1 << 3,
        error 		= 1 << 4
		  };

      typedef int Levels;

			static std::string senderToString(Log::Sender sender);
			static Log::Sender stringToSender(std::string sender);
/*
      static void init();
      static void uninit();
 */     
		  static void log_(Log::Sender sender, 
		    Log::Level level, 
		    const std::string fileName, 
		    int lineNo,
		    const char* format,
		    ...);
      
		  static void log_(Log::Sender sender, 
		    Log::Level level, 
		    const std::string fileName, 
		    int lineNo,
		    const char* format,
		    va_list args);
			
			static void log_(Log::Sender sender, 
		    Log::Level level, 
		    const std::string fileName, 
		    int lineNo,
		    const std::string msg);

    static void error_(Log::Sender sender, 
		    Log::Level level, 
		    const std::string fileName, 
		    int lineNo,
		    const char* format,
		    ...);
      
      static bool isActiveSender(Log::Sender sender) {

        return ((m_instance->m_logSenders & sender) == sender);
        
        /*std::list<Log::Sender>::iterator iter;
        for(iter = m_instance->m_logSenders.begin(); 
            iter != m_instance->m_logSenders.end(); 
            iter++) {
          if(*iter == sender)
            return true;
        }
        return false;*/
      }

      static void addActiveSender(Log::Sender sender) {
        if(sender == Log::unknown) return;
        m_instance->m_logSenders |= sender; // even if they are the active one
      }

      static void removeActiveSender(Log::Sender sender) {
        // and with the ones compliment of sender
        m_instance->m_logSenders &= ~sender;
      }

    private:
      static Log* m_instance;
      //std::list<Log::Sender> m_logSenders;
      int m_logSenders;



    public:
      Log(Log::Sender sender, Log::Levels levels, const std::string filename, int lineNo);
      ~Log();

      static void init();
      static void uninit();

      inline Log &space() { m_stream << " "; return *this; }

      inline Log &operator<<(const char* c) { m_stream << c; return space(); }
      inline Log &operator<<(std::string s) { m_stream << s; return space(); }
      
      inline Log &operator<<(bool t) { m_stream << (t ? "true" : "false"); return space(); }

      inline Log &operator<<(int n) { m_stream << n; return space(); }
      inline Log &operator<<(unsigned int n) { m_stream << n; return space(); }

      inline Log &operator<<(fuppes_off_t n) { m_stream << n; return space(); }

      inline Log &operator<<(UPNP_DEVICE_TYPE t) {
        switch(t) {
          case UPNP_DEVICE_UNKNOWN:
            m_stream << "device.unknown";
            break;
          case UPNP_DEVICE_MEDIA_SERVER:
            m_stream << "device.mediaServer";
            break;
          case UPNP_DEVICE_MEDIA_RENDERER:
            m_stream << "device.mediaRenderer";
            break;
          case UPNP_SERVICE_CONTENT_DIRECTORY:
            m_stream << "service.contentDirectory";
            break;
          case UPNP_SERVICE_RENDERING_CONTROL:
            m_stream << "service.renderingControl";
            break;
          case UPNP_SERVICE_CONNECTION_MANAGER:
            m_stream << "service.connectionManager";
            break;
          case UPNP_SERVICE_AV_TRANSPORT:
            m_stream << "service.avTransport";
            break;            
          case UPNP_SERVICE_X_MS_MEDIA_RECEIVER_REGISTRAR:
            m_stream << "service.xmsMediaReceiverRegistrar";
            break;
          case FUPPES_SOAP_CONTROL:
            m_stream << "fuppes.soapControl";
            break;          
        }
        return space(); 
      }
      

      Log &operator<<(fuppes::Exception e);


      std::string toString() const {
        return m_stream.str();
      }
      
    private:
      //static LogMgr* m_mgr;

      
      Log::Sender m_sender;
      Log::Levels m_levels;
      std::string m_filename;
      int m_lineNo;

      std::stringstream   m_stream;
  };


  //#define error(sender, level) Log(sender, level,__FILE__, __LINE__)
}

#define log(sender, level) if(fuppes::Log::isActiveSender(sender))fuppes::Log(sender, level, __FILE__, __LINE__)
#define warning(sender, level) if(fuppes::Log::isActiveSender(sender))fuppes::Log(sender, level | Log::warning, __FILE__, __LINE__)
#define error(sender, level) if(fuppes::Log::isActiveSender(sender))fuppes::Log(sender, level | Log::error, __FILE__, __LINE__)

#endif // _LOG_H
