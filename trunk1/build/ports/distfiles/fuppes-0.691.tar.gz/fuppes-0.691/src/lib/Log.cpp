/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */

#include "Log.h"

#include "Common/Thread.h"
#include "Common/Exception.h"

#include <iostream>
#include <ios>
#include <stdio.h>
#include <assert.h>

using namespace std;
using namespace fuppes;

#define MAX_LOG_ENTRIES 100

std::string Log::senderToString(Log::Sender sender) // static
{
	switch(sender) {
    case Log::unknown:
      return "unknown";
    case Log::http:
      return "http";
    case Log::soap:
      return "soap";
    case Log::gena:
      return "gena";
    case Log::ssdp:
      return "ssdp";
    case Log::fam:
      return "fam";

    case Log::contentdir:
      return "contentdir";
    case Log::contentdb:
      return "contentdb";
    case Log::sql:
      return "sql";

    case Log::plugin:
      return "plugin";

    case Log::config:
      return "config";

    case Log::hotplug:
      return "hotplug";
      
    case Log::all:
      return "all";
		default:
			return "unknown";
	};	
}

Log::Sender Log::stringToSender(std::string sender) // static
{
  if(sender == "unknown")
    return Log::unknown;
  else if(sender == "http")
    return Log::http;
  else if(sender == "soap")
    return Log::soap;
  else if(sender == "gena")
    return Log::gena;
  else if(sender == "ssdp")
    return Log::ssdp;
  else if(sender == "fam")
    return Log::fam;
  
  else if(sender == "contentdir")
    return Log::contentdir;
  else if(sender == "contentdb")
    return Log::contentdb;
  else if(sender == "sql")
    return Log::sql;
  
  else if(sender == "plugin")
    return Log::plugin;

  else if(sender == "config")
    return Log::config;

  else if(sender == "hotplug")
    return Log::hotplug;

  else if(sender == "all")
    return Log::all;
  else
    return Log::unknown;
}



Log* Log::m_instance = NULL;

/*
void Log::init() // static
{
  if(m_instance != NULL)
    return;
  
  m_instance = new Log();
  m_instance->m_logSenders |= Log::hotplug;
}

void Log::uninit() // static
{
  if(m_instance == NULL)
    return;
  
  delete m_instance;
  m_instance = NULL;
}
*/

void Log::log_(Log::Sender sender, Log::Level level, const std::string fileName, int lineNo, const char* format, ...) // static
{
  bool active = isActiveSender(sender);

  if(!active) {
    //cout << "Log sender: " << Log::senderToString(sender) << " not active" << endl;
    return;
  }
  
	va_list args;
  va_start(args, format);
  Log::log_(sender, level, fileName, lineNo, format, args);
	va_end(args);
}


void Log::log_(Log::Sender sender, Log::Level level, const std::string fileName, int lineNo, const char* format, va_list args) // static
{
  bool active = isActiveSender(sender);

  if(!active) {
    //cout << "Log sender: " << Log::senderToString(sender) << " not active" << endl;
    return;
  }
  
	char buffer[8192 * 10];	
 	string out = "[" + Log::senderToString(sender) + "] ";
  vsnprintf(buffer, sizeof(buffer) - 1, format, args);
	
	cout << out << buffer << endl;
}



void Log::log_(Log::Sender sender, Log::Level level, const std::string fileName, int lineNo, const std::string msg) // static
{
  bool active = isActiveSender(sender);

  if(!active) {
    //cout << "Log sender: " << Log::senderToString(sender) << " not active" << endl;
    return;
  }

	string out = "[" + Log::senderToString(sender) + "] " + msg;
	//CSharedLog::Log(0, fileName, lineNo, out);
  cout << out << endl;
}



void Log::error_(Log::Sender sender, Log::Level level, const std::string fileName, int lineNo, const char* format, ...) // static
{
	va_list args;
  va_start(args, format);

  char buffer[8192 * 10];	
 	string out = "[" + Log::senderToString(sender) + "] ";
  vsnprintf(buffer, sizeof(buffer) - 1, format, args);
	va_end(args);
	
	cout << out << buffer << endl;
}


LogBuffer* LogBuffer::m_instance = NULL;

void LogBuffer::init() // static
{
  assert(m_instance == NULL);
  m_instance = new LogBuffer();
}

void LogBuffer::uninit() // static
{
  assert(m_instance != NULL);
  delete m_instance;
  m_instance = NULL;
}

LogBuffer* LogBuffer::instance() // static
{
  assert(m_instance != NULL);
  return m_instance;  
}

LogBuffer::LogBuffer()
{
  m_active = false;
}

void LogBuffer::append(const Log* log) // static
{  
  if(!instance()->m_active)
    return;
  
  m_instance->m_mutex.lock();

  LogEntry entry;
  entry.message = log->toString();
  m_instance->m_entries.push_back(entry);

  // if the list contains too much items we disable log buffering
  if(m_instance->m_entries.size() >= MAX_LOG_ENTRIES) {
    m_instance->m_mutex.unlock();
    setActive(false);
    return;
  }
  
  m_instance->m_mutex.unlock();
}

bool LogBuffer::read(LogEntry &entry) // static
{ 
  instance()->m_mutex.lock();
  if(m_instance->m_entries.empty()) {
    m_instance->m_mutex.unlock();
    return false;
  }

  entry = m_instance->m_entries.front();
  m_instance->m_entries.pop_front();
  m_instance->m_mutex.unlock();
  return true;
}

size_t LogBuffer::size() // static
{
  return instance()->m_entries.size();
}

void LogBuffer::clear() // static
{
  instance()->m_mutex.lock();
  instance()->m_entries.clear();
  instance()->m_mutex.unlock();
}

void Log::init() // static
{
  LogBuffer::init();
  
  m_instance = new Log();
  m_instance->m_logSenders |= (Log::hotplug | Log::contentdb);
}

void Log::uninit() // static
{
  delete m_instance;
  m_instance = NULL;

  LogBuffer::uninit();
}

Log::Log(Log::Sender sender, Log::Levels levels, const std::string filename, int lineNo)
{
  m_sender = sender;
  m_levels = levels;
  m_filename = filename;
  m_lineNo = lineNo;

  Thread* thread = ThreadPool::threadById(Thread::currentThreadId());

  if(thread != NULL) {
    m_stream << "[ Thread: " << thread->name() << " " << std::hex << thread->threadId() << " ] " << std::dec;
  }
  else {
    m_stream << "[ NOTHREAD ] ";
  }
  
  m_stream << filename << " " << lineNo << " :: ";
}

Log::~Log()
{
  /*if(m_instance != NULL)
    LogMgr::instance()->append(m_stream.str());*/

  if(LogBuffer::active()) {
    LogBuffer::append(this);
  }
  else {  
    cout << m_stream.str() << endl;
  }
}



Log &Log::operator<<(fuppes::Exception e)
{ 
  m_stream << "EXCEPTION: " << e.what(); return space(); 
}
