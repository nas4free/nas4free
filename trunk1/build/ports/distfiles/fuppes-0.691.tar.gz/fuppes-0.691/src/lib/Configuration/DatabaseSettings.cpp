#include <cassert>

#include "DatabaseSettings.h"
#include "../SharedConfig.h"

#include "../Common/Common.h"
#include "../Common/Directory.h"
#include "../Common/File.h"

#include "Config.h"

using namespace std;
using namespace fuppes;

#define DBFILE_NAME "fuppes.db"

DatabaseSettings::DatabaseSettings()
{
  m_dbConnectionParams.readonly = false;
  m_dbConnectionParams.filename = "";
  m_dbConnectionParams.type = "sqlite3";
}

DatabaseSettings::~DatabaseSettings()
{
}


bool DatabaseSettings::InitPostRead() {

  // set dbfilename if necessary  
  if(dbConnectionParams().type == "sqlite3" && dbConnectionParams().filename.empty()) {

    // check if there is an existing fuppes.db
    int flags = File::Readable;
    if(!m_dbConnectionParams.readonly)
      flags |= File::Writable;

    string path = PathFinder::instance()->findInDataPath(DBFILE_NAME, flags);
    if(!path.empty()) {
      setDbFilename(path);
      return true;
    }

    // if none exists find the first writable data dir
    path = PathFinder::instance()->findDataPath(Directory::Readable | Directory::Writable);
    if(path.empty()) {
      return false;
    }

    path += DBFILE_NAME;
    setDbFilename(path);

    /*
    #ifdef WIN32
    setDbFilename(string(getenv("APPDATA")) + "\\fuppes\\fuppes.db");
    #else
    if(Directory::writable(Directory::appendTrailingSlash(FUPPES_LOCALSTATEDIR)))
      setDbFilename(Directory::appendTrailingSlash(FUPPES_LOCALSTATEDIR) + "fuppes.db");
    else
      setDbFilename(string(getenv("HOME")) + "/.fuppes/fuppes.db");
    #endif
      */
  }
   
  return true;
}

bool DatabaseSettings::UseDefaultSettings(void) {
  return InitPostRead();
}

bool DatabaseSettings::Read(void) 
{
  m_dbConnectionParams.type = ToLower(Config::getAttribute("database", "type"));
  
  // for sqlite
  m_dbConnectionParams.filename = Config::getValue("database", "file");

  // for mysql
  m_dbConnectionParams.hostname = Config::getValue("database", "hostname");
  m_dbConnectionParams.username = Config::getValue("database", "username");
  m_dbConnectionParams.password = Config::getValue("database", "password");
  m_dbConnectionParams.dbname   = Config::getValue("database", "dbname");
  
  // common
  m_dbConnectionParams.readonly = (Config::getValue("database", "readonly").compare("true") == 0);

  return true;
  
/*
  assert(pStart != NULL);
  m_dbConnectionParams.type = ToLower(pStart->Attribute("type"));
   
  CXMLNode* pTmp;
  for(int i = 0; i < pStart->ChildCount(); i++) {
    pTmp = pStart->ChildNode(i);

    if(pTmp->Name().compare("filename") == 0) {
      m_dbConnectionParams.filename = pTmp->Value();
    }
    
    else if(pTmp->Name().compare("hostname") == 0) {
      m_dbConnectionParams.hostname = pTmp->Value();
    }
    else if(pTmp->Name().compare("username") == 0) {
      m_dbConnectionParams.username = pTmp->Value();
    }
    else if(pTmp->Name().compare("password") == 0) {
      m_dbConnectionParams.password = pTmp->Value();
    }
    else if(pTmp->Name().compare("dbname") == 0) {
      m_dbConnectionParams.dbname = pTmp->Value();
    }
    else if(pTmp->Name().compare("readonly") == 0) {
      m_dbConnectionParams.readonly = (pTmp->Value() == "true");
    }
  }
*/
}

