/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            PageConfig.cpp
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2010 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "PageConfig.h"

#include "../Common/Common.h"
#include "../SharedConfig.h"

std::string PageConfig::content()
{
  std::stringstream result;
  
  result << "<h1>shared objects</h1>";
  result << "<div id=\"shared-objects-result\"></div>";

  result << "<input type=\"button\" id=\"shared-object-add\" onclick=\"dlgAddSharedObject();\" name=\"shared-object-add\" value=\"add shared object\" />";
    

  result << "<div id=\"dlg-shared-object\">";

  result << "<div class=\"framehead\">add shared object</div>" << endl;

  result << "<div id=\"dlg-shared-object-content\">";
  
  result << "<div id=\"dlg-shared-object-types\">";
  result << "</div>";
  
  result << "<div id=\"object-list\"></div>";
  result << "<div id=\"selected-object-type\"></div>";
  result << "<div id=\"selected-object-name\"></div>";
  result << "<div id=\"selected-object-path\"></div>";

  result << "<span><input type=\"button\" id=\"submit\" onclick=\"submit();\" name=\"submit\" value=\"submit\" /></span> ";
  result << "<span><input type=\"button\" id=\"cancel\" onclick=\"cancel();\" name=\"cancel\" value=\"cancel\" /></span>";
  
  result << "</div>";
  result << "</div>";

  // <network> / 
    // <interface />
    // <http_port />
    // <allowed_ips>

  // <database type="sqlite3"> <!-- sqlite3 | mysql -->
    // <file />  <!-- if empty default path will be used -->
    //<hostname />    <username />    <password />    <dbname />
    //readonly>false</readonly>

  // <content_directory>
    // <local_charset>UTF-8</local_charset>

  // <global_settings>
    // <temp_dir/>
    // <use_fixed_uuid>false</use_fixed_uuid>

//	<vfolders enabled="false">
		//<vfolder name="default" enabled="true" />
		//<vfolder name="xbox" enabled="false" />
	
  //<device_mapping>
    //<!--ip value="123.123.123.123" device="xbox" vfolder="xbox" /-->
    //<!--mac value="00:12:5a:f0:59:3f" device="xbox" vfolder="xbox"/-->
  
  return result.str();
}


