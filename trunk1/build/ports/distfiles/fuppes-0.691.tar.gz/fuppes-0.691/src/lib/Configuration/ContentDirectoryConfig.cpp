#include <cassert>

#include "ContentDirectoryConfig.h"
//#include "../SharedConfig.h"
#include "Config.h"


using namespace std;


void ContentDirectory::InitVariables(void) {
  m_localCharset = "UTF-8";
}

bool ContentDirectory::Read(void)
{
  assert(pStart != NULL);

  CXMLNode* pTmp;
  for(int i = 0; i < pStart->ChildCount(); i++) {
    pTmp = pStart->ChildNode(i);
    if(pTmp->Name().compare("local_charset") == 0) {
      m_localCharset = pTmp->Value();
    }
  }

  return true;
}

void ContentDirectory::SetLocalCharset(std::string localCharset)
{
  fuppes::Config::setValue(SECTION_CONTENT_DIRECTORY, "local_charset", localCharset);
  m_localCharset = localCharset;
}
