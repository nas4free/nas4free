/***************************************************************************
 *            ExternalCmdWrapper.cpp
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2008 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef DISABLE_TRANSCODING

#include "ExternalCmdWrapper.h"

#include <iostream>
#include <sstream>

#include "../SharedConfig.h"

#ifdef WIN32
#else
#include <stdlib.h>
#endif

using namespace std;

CExternalCmdWrapper::CExternalCmdWrapper()
{
	m_process = new fuppes::Process();
}

CExternalCmdWrapper::~CExternalCmdWrapper()
{
	delete m_process;
}

bool CExternalCmdWrapper::TranscodeFile(CFileSettings* pFileSettings, std::string p_sInFile, std::string* p_psOutFile)
{    
  string sTmpFileName = CSharedConfig::Shared()->CreateTempFileName() + "." + pFileSettings->Extension();
	*p_psOutFile = sTmpFileName;
	
	string sCmd = pFileSettings->pTranscodingSettings->ExternalCmd();
  std::list<std::string> args;
  
  splitCommandline(sCmd, args, p_sInFile, sTmpFileName);
	if(!m_process->start(sCmd, args)) {
		return false;
	}
	
	cout << "wait" << endl;
	m_process->waitFor();
	cout << "return" << endl;
	return true;
}

void CExternalCmdWrapper::stop()
{
  if(!m_process)
    return;

  m_process->stop();
}

void CExternalCmdWrapper::splitCommandline(std::string &cmd, std::list<std::string> &args, const std::string inFile, const std::string outFile) const
{
  cout << "ExternalCmd::splitCommandLine() : " << cmd << endl;

  size_t pos;
  string tmp = cmd + " ";
  cmd = "";
  while(!tmp.empty()) {

    if((pos = tmp.find(" ", 0)) == string::npos)
			break;

    string arg = tmp.substr(0, pos);
    
    if(cmd.empty())
      cmd = arg;
    else {

      if(arg.compare("%in%") == 0)
        arg = inFile;
      else if(arg.compare("%out%") == 0)
        arg = outFile;
      
      args.push_back(arg);
    }

    tmp = tmp.substr(pos + 1);
  }
  
}

#endif // DISABLE_TRANSCODING
