/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            ControlActions.h
 * 
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2010 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef _CONTROLACTIONS_H
#define _CONTROLACTIONS_H

typedef enum FUPPES_CONTROL_ACTION {
  FUPPES_CTRL_UNKNOWN,

  // rebuild the entire database
  FUPPES_CTRL_DATABASE_REBUILD,
  // update (add new, remove missing) the database
  FUPPES_CTRL_DATABASE_UPDATE,
  // rebuild all enabled vfolder layouts
  FUPPES_CTRL_VFOLDER_REBUILD,

  
  // get directory content from filesystem
  FUPPES_CTRL_GET_DIR,
  // get a list of all shared objects
  FUPPES_CTRL_GET_SHARED_OBJECTS,
  // get a list of all shared objects types (including those provided by plugins)
  FUPPES_CTRL_GET_SHARED_OBJECT_TYPES,
  // add a shared object
  FUPPES_CTRL_ADD_SHARED_OBJECT,
  // delete a shared object
  FUPPES_CTRL_DEL_SHARED_OBJECT,
  // modify a shared object
  FUPPES_CTRL_MOD_SHARED_OBJECT,


  // get the version
  FUPPES_CTRL_GET_VERSION,
  // get the hostname
  FUPPES_CTRL_GET_HOSTNAME,
  // get the uptime
  FUPPES_CTRL_GET_UPTIME,


  // get log level
  FUPPES_CTRL_GET_LOG_LEVEL,
  // set log level
  FUPPES_CTRL_SET_LOG_LEVEL,
  // add log subsystem
  FUPPES_CTRL_ADD_LOG_SUBSYSTEM,
  // delete log subsystem
  FUPPES_CTRL_DEL_LOG_SUBSYSTEM,

  
  // set the device config for a device (in: uuid, in: config)
  FUPPES_CTRL_SET_DEVICE_CONFIG,
  // set the vfolder config for a device (in: uuid, in: config)
  FUPPES_CTRL_SET_VFOLDER_CONFIG,


} FUPPES_CONTROL_ACTION;


#endif // _CONTROLACTIONS_H
