#ifndef _CONTENT_DIRECTORY_SETTINGS_H
#define _CONTENT_DIRECTORY_SETTINGS_H

#ifdef HAVE_CONFIG_H
#include "../../config.h"
#endif

#include <string>
#include "ConfigSettings.h"

class ContentDirectory : public ConfigSettings
{
  public:
    bool Read(void);

    std::string GetLocalCharset() { return m_localCharset; }
    void        SetLocalCharset(std::string localCharset);

  private:
    void InitVariables(void);

    std::string             m_localCharset;
};

#endif // _CONTENT_DIRECTORY_SETTINGS_H
