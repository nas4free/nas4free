/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            HTTPServer.cpp
 * 
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2005-2009 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "HTTPServer.h"
#include "HTTPMessage.h"
#include "HTTPRequestHandler.h"
//#include "CommonFunctions.h"
#include "../SharedLog.h"
#include "../SharedConfig.h"
#include "../Common/RegEx.h"
#include "../Common/Exception.h"
#include "../DeviceSettings/DeviceIdentificationMgr.h"
#include "../DeviceSettings/MacAddressTable.h"

#include <iostream>
#include <sstream>
#ifndef WIN32
#include <errno.h>
#endif


// the max buffer size for files directly served
// from the local file system
#define MAX_BUFFER_SIZE 1048576 // 1 mb

// the max buffer size for transcoded files
#define MAX_TRANSCODING_BUFFER_SIZE 65536 // 64 kbyte

#ifndef WIN32
#include <sys/errno.h>
#endif

using namespace std;
using namespace fuppes;


/** Constructor */
CHTTPServer::CHTTPServer(std::string p_sIPAddress)
:Thread("httpserver")
{
  // init member vars
  m_bIsRunning  = false;
	m_isStarted   = false;
	//accept_thread = (fuppesThread)NULL;
	//fuppesThreadInitMutex(&m_ReceiveMutex);  	


  m_listenSocket.init(p_sIPAddress, CSharedConfig::Shared()->networkSettings->GetHTTPPort());
  
  MacAddressTable::init();
} // CHTTPServer()


/** Destructor */
CHTTPServer::~CHTTPServer()
{
  stop();
  MacAddressTable::uninit();
} // ~CHTTPServer()


/** Start() */
void CHTTPServer::start()
{
  m_bBreakAccept = false;
  
  if(!m_listenSocket.listen())
    throw fuppes::Exception(__FILE__, __LINE__, "failed to listen on socket");

  HTTPSessionStore::init();
  
  // start accept thread
	fuppes::Thread::start();
  m_bIsRunning = true;
  
  CSharedLog::Log(L_EXT, __FILE__, __LINE__, "HTTPServer started");
} // Start()


/** Stop() */
void CHTTPServer::stop()
{   
  if(!m_bIsRunning)
    return;

  // stop accept thread
  m_bBreakAccept = true;

  close(); // stop and close thread
  
	//wait();
  /*if(accept_thread) {
    fuppesThreadCancel(accept_thread);
    fuppesThreadClose(accept_thread);
    accept_thread = (fuppesThread)NULL;    
  }*/
   
  // kill all remaining connections
  //CleanupSessions();

  // close socket
  //fuppesSocketClose(m_Socket);
  m_listenSocket.close();
  m_bIsRunning = false;

  HTTPSessionStore::uninit();
  
  CSharedLog::Log(L_EXT, __FILE__, __LINE__, "HTTPServer stopped");
} // Stop()

std::string CHTTPServer::GetURL()
{
  stringstream result;
  //result << inet_ntoa(local_ep.sin_addr) << ":" << ntohs(local_ep.sin_port);
  result << m_listenSocket.localAddress() << ":" << m_listenSocket.localPort();
  return result.str();
}


/*
bool CHTTPServer::SetReceiveHandler(IHTTPServer* pHandler)
{
  m_pReceiveHandler = pHandler;
  return true;
}

// deprecated :: request are handled asynchronous by CHHTTPRequestHandler
bool CHTTPServer::CallOnReceive(CHTTPMessage* pMessageIn, CHTTPMessage* pMessageOut)
{
  //fuppesThreadLockMutex(&m_ReceiveMutex);  
	m_receiveMutex.lock();

  bool bResult = false;
  if(m_pReceiveHandler != NULL) {
    // Parse message
    bResult = m_pReceiveHandler->OnHTTPServerReceiveMsg(pMessageIn, pMessageOut);
  }
    
  //fuppesThreadUnlockMutex(&m_ReceiveMutex);    
	m_receiveMutex.unlock();
  return bResult;
}*/

/**
 * closes finished session threads
 */
/*void CHTTPServer::CleanupSessions()
{
  if(m_ThreadList.empty())
    return;
 
  // iterate session list ...
  for(m_ThreadListIterator = m_ThreadList.begin(); m_ThreadListIterator != m_ThreadList.end();)
  {
    if(m_ThreadList.empty())
      break;
    */
    // ... and close terminated threads
    /*CHTTPSessionInfo* pInfo = *m_ThreadListIterator;   
    if(pInfo && pInfo->m_bIsTerminated && fuppesThreadClose(pInfo->GetThreadHandle()))
    {           
      std::list<CHTTPSessionInfo*>::iterator tmpIt = m_ThreadListIterator;      
      ++tmpIt;                 
      m_ThreadList.erase(m_ThreadListIterator);
      m_ThreadListIterator = tmpIt;
      delete pInfo; 
      continue;
    } */       
/*
    HTTPSession* pInfo = *m_ThreadListIterator;   
    if(pInfo && pInfo->m_bIsTerminated)
    {           
      std::list<HTTPSession*>::iterator tmpIt = m_ThreadListIterator;      
      ++tmpIt;                 
      m_ThreadList.erase(m_ThreadListIterator);
      m_ThreadListIterator = tmpIt;
      delete pInfo; 
      continue;
    }
		
    m_ThreadListIterator++;    
  }
}*/

/**
 * the HTTPServer's AcceptLoop constantly
 * looks for new incoming connections and 
 * starts a new HTTPSession for each connection
 * the new session registers itself at the http session store
 * which deletes the session when it's done
 */
void CHTTPServer::run()
{                     
	CSharedLog::Log(L_EXT, __FILE__, __LINE__,  "listening on %s", this->GetURL().c_str());
	this->m_isStarted = true;

  TCPRemoteSocket* sock;
   
  // loop	
	while(!this->stopRequested())	{

    sock = m_listenSocket.accept(2000);
    if(sock == NULL)
      continue;

    HTTPSession* session = new HTTPSession(sock, this->GetURL());
		session->start();
	}  

	this->m_isStarted = false;
	
  CSharedLog::Log(L_DBG, __FILE__, __LINE__, "exiting accept loop");
	
} // run()
