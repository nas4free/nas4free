/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            Config.h
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2011 Ulrich Völkel <fuppes@ulrich-voelkel.de>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _CONFIG_H
#define _CONFIG_H

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <string>
#include <map>
#include <list>

#include <libxml/parser.h>
#include <libxml/tree.h>


namespace fuppes
{

#define SECTION_SHARED_OBJECTS      "shared_objects"
#define SECTION_NETWORK             "network"
#define SECTION_DATABASE            "database"
#define SECTION_CONTENT_DIRECTORY   "content_directory"
#define SECTION_GLOBAL              "global_settings"
#define SECTION_VFOLDERS            "vfolders"
#define SECTION_DEVICE_MAPPING      "device_mapping"

class Config;
  
class ConfigEntry
{
  friend class Config;

  public:
    ConfigEntry() {
      m_node = NULL;
    }
    /*
    ConfigEntry& operator=(const ConfigEntry& entry) {

      key         = entry.key;
      value       = entry.value;
      attributes  = entry.attributes;
      m_node      = entry.m_node;

      return *this;
    }
    */

    void clear() {
      key = "";
      value = "";
      attributes.clear();
      m_node = NULL;
    }
    
  public:
    std::string                         key;
    std::string                         value;
    std::map<std::string, std::string>  attributes;

  private:
    xmlNodePtr                          m_node;
};

typedef std::list<ConfigEntry>  EntryList;
typedef std::list<ConfigEntry>::iterator  EntryListIterator;

class Config
{
  public:
    static void init();
    static void uninit();

    static bool load(std::string filename);

    // find a single string value for 'key' in 'section'
    static std::string    getValue(const std::string section, const std::string key, const std::string defaultValue = "");
    // set a the 'value' for 'key' in 'section'
    static void           setValue(std::string section, std::string key, std::string value);

    // get the 'attribute' value for 'section'
    static std::string    getAttribute(std::string section, std::string attribute);

        
    static bool   getEntries(std::string section, std::string subsection, EntryList& list);

    static void   setEntry(std::string section, std::string subsection, ConfigEntry& entry);

    static void   removeEntry(std::string section, std::string subsection, ConfigEntry& entry);
    
  private:
    static Config*    m_instance;

    std::string       m_filename;
    xmlDocPtr         m_doc;
    xmlNodePtr        m_rootNode;

    xmlNodePtr        findNode(std::string section, std::string key);
    void save();
    
    std::map<std::string, xmlNodePtr>   m_sections;
};

}

#endif // _CONFIG_H
