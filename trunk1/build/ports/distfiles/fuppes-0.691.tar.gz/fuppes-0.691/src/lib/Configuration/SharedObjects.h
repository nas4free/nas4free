/* -*- Mode: C++; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            SharedObjects.h
 * 
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2010-2011 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#ifndef _SHARED_OBJECTS_H
#define _SHARED_OBJECTS_H

#ifdef HAVE_CONFIG_H
#include "../../config.h"
#endif

#include <vector>
#include <string>
#include "ConfigSettings.h"
#include "../Common/UUID.h"

class SharedObjects;

class SharedObject
{
  friend class SharedObjects;
  
  public:
    enum SharedObjectType {
      unknown     = 0,
      directory   = 1,
      playlist    = 2,
      other       = 3,
    };

    SharedObject() {
      m_type = SharedObject::unknown;
      m_uuid = GenerateUUID();
    }

    std::string uuid() { return m_uuid; }
    SharedObjectType type() { return m_type; }
    std::string path() { return m_path; }

    std::string name() { return m_name; }
    std::string otherType() { return m_otherType; }
    
  private:
    std::string       m_uuid;
    SharedObjectType  m_type;
    std::string       m_path;

    std::string       m_name;
    std::string       m_otherType;

    // itunes settings
    std::string       m_rewritePathOld;
    std::string       m_rewritePathNew;

    fuppes::ConfigEntry       m_configEntry;
};

class SharedObjects : public ConfigSettings
{
  public:
    virtual ~SharedObjects();
    virtual bool Read(void);

    int sharedObjectCount() { return m_sharedObjects.size(); }
    SharedObject* sharedObject(int idx) { return m_sharedObjects[idx]; }
    SharedObject* sharedObject(std::string uuid) { 
      for(m_sharedObjectsIter = m_sharedObjects.begin();
        m_sharedObjectsIter != m_sharedObjects.end();
        m_sharedObjectsIter++) {
        if((*m_sharedObjectsIter)->uuid() == uuid)
          return *m_sharedObjectsIter;
      }
      return NULL;
    }
    SharedObject* addSharedObject(SharedObject::SharedObjectType type, std::string path, std::string name = "", std::string otherType = "");
    void removeSharedObject(std::string uuid);
    
  private:
    void clear();

    std::vector<SharedObject*>  m_sharedObjects;
    std::vector<SharedObject*>::iterator  m_sharedObjectsIter;
};

#endif // _SHARED_OBJECTS_H
