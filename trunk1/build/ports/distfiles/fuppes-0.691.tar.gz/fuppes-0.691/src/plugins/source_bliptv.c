/* -*- Mode: C; indent-tabs-mode: nil; c-basic-offset: 2; tab-width: 2 -*- */
/***************************************************************************
 *            source_bliptv.c
 *
 *  FUPPES - Free UPnP Entertainment Service
 *
 *  Copyright (C) 2011 Ulrich Völkel <u-voelkel@users.sourceforge.net>
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include "../../include/fuppes_plugin.h"

#include <curl/curl.h>
#include <libxml/parser.h>

#ifdef __cplusplus
extern "C" {
#endif

void register_fuppes_plugin(plugin_info* info)
{
	strcpy(info->plugin_name, "bliptv");
	strcpy(info->plugin_author, "Ulrich Voelkel");
	info->plugin_type = PT_ITEM_SOURCE;

	strcpy(info->source_base_name, "blip.tv");
  info->source_flags = sf_numbered | sf_reverse;
}



CURL* curl;
const char* sourcename;

char* result = NULL;
size_t result_size = 0;

int page = 0;
int item = 0;


xmlDocPtr   current_doc = NULL;

// a pointer to the current assets xml node
xmlNodePtr  first_asset = NULL;
xmlNodePtr  current_asset = NULL;
xmlNodePtr  current_title = NULL;
xmlNodePtr  current_guid  = NULL;

xmlNodePtr  current_media_list = NULL;
xmlNodePtr  current_media = NULL;


// buffer size is size * nmemb
// buffer is NOT terminated by zero
size_t curl_write_data(void *buffer, size_t size, size_t nmemb, void *userp)
{
  printf("curl write data\n");

  if(NULL == result) {
    result = malloc((size * nmemb) + 1);
  }
  else {
    result = realloc(result, result_size + (size * nmemb) + 1);
  }

  memcpy(&result[result_size], buffer, size * nmemb);
  result_size += (size * nmemb);
  result[result_size] = '\0';

  return (size * nmemb);
}

int get_next_page() 
{
  // free the last result
  if(NULL != result) {
    free(result);
    result = NULL;
    result_size = 0;
  }

  
  // according to the blip api docs the pages start with 0
  // but obviously they don't. page 0 and page 1 have exactly the same content
  page++; // is initially 0

  // todo: make sure we don't create a buffer overflow
  char url[1000];
  sprintf(url, "http://blip.tv/%s?skin=api&page=%d&file_type=m4v&sort=date", sourcename, page);


// show_nsfw=1
          
  // set the new url and perform the request
  curl_easy_setopt(curl, CURLOPT_URL, url);
         
  CURLcode ret = curl_easy_perform(curl);
  

  // parse the response
  if(NULL != current_doc) {
    xmlFreeDoc(current_doc);
    current_doc = NULL;
  }

  first_asset = NULL;
  current_asset = NULL;
          

  current_doc = xmlReadMemory(result, result_size, "", NULL, XML_PARSE_NONET); // XML_PARSE_NOERROR | XML_PARSE_NOWARNING | 
  if(!current_doc) {
    printf("xml parser error");
    return -1;    
  }


  xmlNodePtr root = xmlDocGetRootElement(current_doc);
  xmlNodePtr sub = xmlFirstElementChild(root);
  xmlNodePtr tmp = NULL;

//printf(root->name);
          
  while(NULL != sub) {

    if(strcmp(sub->name, "status") == 0) {
      //printf("status: %s\n", sub->children->content);
    }

    else if(strcmp(sub->name, "payload") == 0) {
      tmp = xmlFirstElementChild(sub);
      while(NULL != tmp) {

        if(strcmp(tmp->name, "asset") == 0) {
          first_asset = tmp;          
          break;
        }
        
        tmp = xmlNextElementSibling(tmp);
      }


    }
    
    
    sub = xmlNextElementSibling(sub);
  }
  

  if(first_asset)
    printf("got first asset: %s\n", first_asset->name);


  return (first_asset ? 0 : -1);
}

int get_next_media(struct metadata_t* metadata) 
{
  if(NULL == current_media_list)
    return -1;

  if(NULL == current_media)
    current_media = xmlFirstElementChild(current_media_list);
  else
    current_media = xmlNextElementSibling(current_media);

  if(NULL == current_media)
    return -1;


  set_value(metadata->title, sizeof(metadata->title), xmlNodeGetContent(current_title));
  set_value(metadata->file_name, sizeof(metadata->file_name), xmlNodeGetContent(current_guid));
  
  
  xmlNodePtr sub = xmlFirstElementChild(current_media);
  while(NULL != sub) {

/*
<role>Blip SD</role>
			<link type="video/x-m4v" href="http://blip.tv/file/get/NostalgiaCritic-SuburbanKnightsCharacterDescriptions837.m4v" />
			<width>640</width>
			<height>360</height>
			<duration>730</duration>
			<videocodec>ffh264</videocodec>
			<audiocodec>ffaac</audiocodec>
			<bitrate></bitrate>
			<audiobitrate>98</audiobitrate>
			<videobitrate>1275</videobitrate>
			<size>125528580</size>
      */
    if(strcmp(sub->name, "role") == 0) {
      //set_value(metadata->url, sizeof(metadata->url), xmlNodeGetContent(sub));
      // Source | Blip SD | Blip HD 720
    }
    else if(strcmp(sub->name, "link") == 0) {
      set_value(metadata->mime_type, sizeof(metadata->mime_type), xmlGetProp(sub, "type"));
      set_value(metadata->path, sizeof(metadata->path), xmlGetProp(sub, "href"));
    }
    else if(strcmp(sub->name, "width") == 0) {
      metadata->width = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "height") == 0) {
      metadata->height = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "duration") == 0) {
      metadata->duration_ms = strtoul(xmlNodeGetContent(sub), NULL, 0) * 1000;
    }
    else if(strcmp(sub->name, "audiobitrate") == 0) {
      metadata->audio_bitrate = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "videobitrate") == 0) {
      metadata->video_bitrate = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "size") == 0) {
      metadata->size = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }

    sub = xmlNextElementSibling(sub);
  }

  //set_value(metadata->url, sizeof(metadata->url), xmlNodeGetContent(sub));
  
  return 0;
}


int get_media(struct metadata_t* metadata) 
{
  if(NULL == current_media_list)
    return -1;

  current_media = xmlFirstElementChild(current_media_list);
  if(NULL == current_media)
    return -1;


  // find available roles
  xmlNodePtr roleSource = NULL;
  xmlNodePtr roleBlipSD = NULL;
  xmlNodePtr roleBlipHD720 = NULL;
  xmlNodePtr rolePortable = NULL;

  do {
  
    xmlNodePtr sub = xmlFirstElementChild(current_media);
    while(NULL != sub) {

      if(strcmp(sub->name, "role") == 0) {

        if(strcmp(xmlNodeGetContent(sub), "Source") == 0)
          roleSource = current_media;
        else if(strcmp(xmlNodeGetContent(sub), "Blip SD") == 0)
          roleBlipSD = current_media;
        else if(strcmp(xmlNodeGetContent(sub), "Blip HD 720") == 0)
          roleBlipHD720 = current_media;
        else if(strcmp(xmlNodeGetContent(sub), "Portable (iPod)") == 0)
          rolePortable = current_media;

        break;
      }
      
      sub = xmlNextElementSibling(sub);
    }

    current_media = xmlNextElementSibling(current_media);

  } while(NULL != current_media);

  
  


  if(NULL != roleBlipHD720)
    current_media = roleBlipHD720;
  else if(NULL != roleBlipSD)
    current_media = roleBlipSD;
  else if(NULL != rolePortable)
    current_media = rolePortable;
  else if(NULL != roleSource)
    current_media = roleSource;
  else
    return -1;
  

  set_value(metadata->title, sizeof(metadata->title), xmlNodeGetContent(current_title));
  set_value(metadata->file_name, sizeof(metadata->file_name), xmlNodeGetContent(current_guid));

  xmlNodePtr sub = xmlFirstElementChild(current_media);
  while(NULL != sub) {

/*
<role>Blip SD</role>
			<link type="video/x-m4v" href="http://blip.tv/file/get/NostalgiaCritic-SuburbanKnightsCharacterDescriptions837.m4v" />
			<width>640</width>
			<height>360</height>
			<duration>730</duration>
			<videocodec>ffh264</videocodec>
			<audiocodec>ffaac</audiocodec>
			<bitrate></bitrate>
			<audiobitrate>98</audiobitrate>
			<videobitrate>1275</videobitrate>
			<size>125528580</size>
      */
    if(strcmp(sub->name, "link") == 0) {
      set_value(metadata->mime_type, sizeof(metadata->mime_type), xmlGetProp(sub, "type"));
      set_value(metadata->path, sizeof(metadata->path), xmlGetProp(sub, "href"));
    }
    else if(strcmp(sub->name, "width") == 0) {
      metadata->width = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "height") == 0) {
      metadata->height = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "duration") == 0) {
      metadata->duration_ms = strtoul(xmlNodeGetContent(sub), NULL, 0) * 1000;
    }
    else if(strcmp(sub->name, "audiobitrate") == 0) {
      metadata->audio_bitrate = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "videobitrate") == 0) {
      metadata->video_bitrate = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }
    else if(strcmp(sub->name, "size") == 0) {
      metadata->size = strtoul(xmlNodeGetContent(sub), NULL, 0);
    }

    sub = xmlNextElementSibling(sub);
  }
  
  return 0;
}


int fuppes_source_open(plugin_info* plugin, const char* name)
{
  sourcename = strdup(name); 
  
  curl = curl_easy_init();
  if(NULL == curl)
    return -1;

  curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curl_write_data);
 
  return get_next_page();
}

int fuppes_source_next(plugin_info* plugin, struct metadata_t* metadata)
{
  if(NULL == first_asset && NULL == current_asset)  
	  return -1;


  // get the next entry in the current media list
  /*if(NULL != current_media_list) {
    if(get_next_media(metadata) == 0)
      return 0;
  }*/
  
  
  if(NULL == current_asset)
    current_asset = first_asset;
  else
    current_asset = xmlNextElementSibling(current_asset);
  current_media_list = NULL;
  current_media = NULL;
  current_title = NULL;
  current_guid  = NULL;
  
  // last asset
  if(NULL == current_asset) {
    printf("LAST ASSERT ON PAGE %d\n", page);
    //return -1;
    if(get_next_page() != 0) {
      printf("LAST PAGE %d\n", page);
	    return -1;
    }
    current_asset = first_asset;
  }

  
  printf("next: %s\n", current_asset->name);

  // find the media list
  xmlNodePtr sub = xmlFirstElementChild(current_asset);
  while(NULL != sub) {

    printf("sub: %s\n", sub->name);

    if(strcmp(sub->name, "title") == 0) {
      current_title = sub;
    }
    else if(strcmp(sub->name, "guid") == 0) {
      current_guid = sub;
    }
    else if(strcmp(sub->name, "mediaList") == 0) {
      current_media_list = sub;
    }
    
    sub = xmlNextElementSibling(sub);
  }


  //return get_next_media(metadata);
  return get_media(metadata);
}

void fuppes_source_close(plugin_info* plugin)
{
  if(NULL == curl)
    return;
  
  curl_easy_cleanup(curl);
  curl = NULL;

  if(result) {
    free(result);
    result = NULL;
  }

  if(current_doc) {
    xmlFreeDoc(current_doc);
    current_doc = NULL;
  }
}

void unregister_fuppes_plugin(plugin_info* plugin __attribute__((unused)))
{
}

#ifdef __cplusplus
}
#endif
