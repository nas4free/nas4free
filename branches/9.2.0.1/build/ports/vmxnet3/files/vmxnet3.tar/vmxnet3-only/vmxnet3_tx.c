/***********************************************************
 * Copyright (C) 2010 VMware, Inc. All Rights Reserved
 *
 * -- VMware Confidential
 ***********************************************************/

/*
 * vmxnet3_tx.c
 *      Trasmission of packets for VMXNET3 NIC driver.
 */

#include <vmxnet3_int.h>


/*
 *-----------------------------------------------------------------------------
 * 
 * vmxnet3_cleanup_tx --
 *
 *      Free memory allocated for tx descriptors.
 *
 * Results:
 *      Returns 0 for success, error code otherwise.
 *
 * Side effects:
 *      Sets intr type in driver soft state.
 *
 *-----------------------------------------------------------------------------
 */

void
vmxnet3_cleanup_tx(vmxnet3_adapter_t *sc, vmxnet3_tx_queue_t *tq)
{
   struct vmxnet3_cmd_ring *ring = &tq->cmd_ring;
   Vmxnet3_TxDesc *txd = NULL;
   vmxnet3_buf_info_t *tbi = NULL;
   VMXNET3_LOCK_TX(tq);
   VMXNET3_ASSERT(sc->state & (1 << VMXNET3_STATE_BIT_QUIESCED));

   VMXNET3_LOG(sc->dev, 2, "Forcibly aborting pending xmits.\n");
   while (tq->cmd_ring.next2comp != tq->cmd_ring.next2fill) {
      txd = (Vmxnet3_TxDesc *)tq->cmd_ring.base + tq->cmd_ring.next2comp;
      /* No need to worry about tx desc ownership, device is quiesced by now. */
      if (txd->eop == 1) {
         tbi = tq->cmd_ring.buf_info + tq->cmd_ring.next2comp;
         VMXNET3_ASSERT(tbi->m);
         m_freem(tbi->m);
         tbi->m = NULL;
      }
      vmxnet3_cmd_ring_adv_next2comp(&tq->cmd_ring);
   }


   if (ring->buf_info)
      free(ring->buf_info, M_DEVBUF);
   ring->buf_info = NULL;

   if (ring->base)
      vmxnet3_free_dma_mem(sc, ring->dma_tag, ring->dma_map, ring->base,
                           ring->basePA);
   ring->basePA = 0;
   ring->base = NULL;
   tq->comp_ring.basePA = 0;
   tq->comp_ring.base = NULL;
   VMXNET3_UNLOCK_TX(tq);
   VMXNET3_LOG(sc->dev, 1, "Completed cleaning up TX rings.\n");
}


/*
 *-----------------------------------------------------------------------------
 * 
 * vmxnet3_init_tx --
 *
 *      Initialize tx ring. Allocate DMAable memory for descriptors in ring.
 *
 * Results:
 *      Returns 0 for success, error code otherwise.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

int
vmxnet3_init_tx(vmxnet3_adapter_t *sc, vmxnet3_tx_queue_t *tq)
{
   int ret, size;
   struct vmxnet3_cmd_ring *ring;
   struct vmxnet3_comp_ring *comp_ring;


   VMXNET3_LOCK_TX(tq);
   tq->cmd_ring.next2fill = 0;
   tq->cmd_ring.next2comp = 0;
   tq->cmd_ring.gen = VMXNET3_INIT_GEN;
   tq->comp_ring.next2proc = 0;
   tq->comp_ring.gen = VMXNET3_INIT_GEN;

   VMXNET3_LOG(sc->dev, 1, "TX queue cmd ring size: %d.\n", tq->cmd_ring.size);
   ring = &tq->cmd_ring;
   comp_ring = &tq->comp_ring;
   size = sizeof(struct Vmxnet3_TxDesc) * ring->size;
   size += sizeof(struct Vmxnet3_TxCompDesc) * comp_ring->size;

   ret = vmxnet3_get_dma_mem(sc, size, &ring->dma_tag, &ring->dma_map,
                             VMXNET3_RING_BA_ALIGN, (void **)&ring->base,
                             &ring->basePA);
   if (ret) {
      VMXNET3_LOG(sc->dev, 0, "Error allocating DMA mem for tx ring: %d.\n",
                  ret);
      goto err;
   }

   comp_ring->base = ring->base + ring->size;
   comp_ring->basePA = ring->basePA +
                       (sizeof(struct Vmxnet3_TxDesc) * ring->size);

   ring->buf_info = malloc(ring->size * sizeof(vmxnet3_buf_info_t), M_DEVBUF,
                           M_ZERO | M_NOWAIT);
   if (!ring->buf_info) {
      VMXNET3_LOG(sc->dev, 0, "Error allocating mem for buf info.\n");
      ret = ENOMEM;
      goto err;
   }

   VMXNET3_LOG(sc->dev, 3, "cmd base : 0x%p comp ring base : 0x%p.\n",
                ring->base, comp_ring->base);
   VMXNET3_LOG(sc->dev, 3, "cmd basePA : 0x%lx comp ring basePA : 0x%lx.\n",
                (unsigned long)ring->basePA, (unsigned long)comp_ring->basePA);

   VMXNET3_LOG(sc->dev, 2, "Tx ring initialization completed.\n");
   VMXNET3_UNLOCK_TX(tq);
   return 0;

err:
   VMXNET3_UNLOCK_TX(tq);
   vmxnet3_cleanup_tx(sc, tq);
   return ret;

}


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_get_packet_info --
 *
 *      Parse the packet to determine its L3 and L4 type. Calculate header
 *      offsets accordingly so that they can be used later for CSO and TSO.
 *
 * Results:
 *      Returns 0 for success, error if the header buffer is too small to parse. *      When the packet does not have L3 as IP, ip_hdr_size will be 0, similarly
 *      when L4 header is not TCP or UDP then l4_hdr_size will be 0.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

static int
vmxnet3_get_packet_info(struct mbuf *m_head, vmxnet3_tx_ctx_t *tx_ctx,
                        vmxnet3_adapter_t *sc)
{
   struct ether_vlan_header *eh;
   struct ip6_hdr *ip6;
   struct ip *ip = NULL;
   struct tcphdr *th;
   uint16 etype;
   uint8 ipproto = 0;
   int etherhlen, iphlen = 0, thlen = 0;

   /* required_cont keeps count of number of bytes which should be in
    * contiguous and in the first buffer so that the packet can be parsed
    * correctly. It goes on increasing as identifiable headers are found in pkt.
    */
   int required_cont = sizeof(struct ether_vlan_header);

   if (m_head->m_flags & M_VLANTAG) {
      tx_ctx->is_vlan = TRUE;
      tx_ctx->evl_tag = m_head->m_pkthdr.ether_vtag;
   } else {
      tx_ctx->is_vlan = FALSE;
   }

   /* If no checksum offloaded is requested, don't parse the packet further */
   if ((m_head->m_pkthdr.csum_flags & (CSUM_DELAY_DATA | CSUM_IP |
        CSUM_TSO)) == 0) {
        VMXNET3_LOG(sc->dev, 3, "No offloading asked. Returning\n");
      return 0;
   }

   if (m_head->m_len < required_cont) {
      VMXNET3_LOG(sc->dev, 1, "Header buffer too small to parse L2 header.\n");
      return EINVAL;
   }

   eh = mtod(m_head, struct ether_vlan_header *);
   if (eh->evl_encap_proto == htons(ETHERTYPE_VLAN)) {
      etype = ntohs(eh->evl_proto);
      etherhlen = ETHER_HDR_LEN + ETHER_VLAN_ENCAP_LEN;
   } else {
      etype = ntohs(eh->evl_encap_proto);
      etherhlen = ETHER_HDR_LEN;
   }

   tx_ctx->eth_hdr_size = etherhlen;
   required_cont = etherhlen;


   switch(etype) {
   case ETHERTYPE_IP:
      VMXNET3_LOG(sc->dev, 3, "IPv4\n");
      tx_ctx->ip_type = ip_v4;
      if (m_head->m_len < (required_cont + sizeof(struct ip))) {
         VMXNET3_LOG(sc->dev, 1, "Header buf too small to parse IPv4 hdr.\n");
         return EINVAL;
      }
      ip = (struct ip *)(m_head->m_data + etherhlen);
      iphlen = ip->ip_hl << 2;
      ipproto = ip->ip_p;
      break;

   case ETHERTYPE_IPV6:
      tx_ctx->ip_type = ip_v6;
      if (m_head->m_len < (required_cont + sizeof(struct ip6_hdr))) {
         VMXNET3_LOG(sc->dev, 1, "Header buf too small to parse IPv6 hdr %d"
                     " < %d.\n", m_head->m_len, (int)(required_cont +
                     sizeof(struct ip6_hdr)));
         return EINVAL;
      }
      ip6 = (struct ip6_hdr *)(m_head->m_data + etherhlen);
      iphlen = sizeof(struct ip6_hdr);
      ipproto = ip6->ip6_nxt;
      break;
   default:
     tx_ctx->ip_type = ip_none;
     VMXNET3_LOG(sc->dev, 3, "Unknown etype : %d\n", etype);
     return 0;
   }

   tx_ctx->ip_hdr_size = iphlen;
   required_cont += tx_ctx->ip_hdr_size;

   /* If TCP/UDP checksum offload or TSO is not required, dont parse further */
   if ((m_head->m_pkthdr.csum_flags & (CSUM_DELAY_DATA | CSUM_TSO)) == 0) {
      VMXNET3_LOG(sc->dev, 3, "No l4 offload  asked for. Returning\n");
      return 0;
   }

more_ipv6_extensions:

   switch(ipproto) {
   case IPPROTO_TCP:
      VMXNET3_LOG(sc->dev, 3, "TCP\n");
      th = (struct tcphdr *)(m_head->m_data + required_cont);
      if (m_head->m_len < (required_cont + (offsetof(struct tcphdr, th_sum) +
          sizeof (th->th_sum)))) {
         VMXNET3_LOG(sc->dev, 1, "Header buf too small to parse TCP hdr %d <"
                     " %d\n", m_head->m_len, required_cont);
         return EINVAL;
      }
      thlen = th->th_off << 2;
      if (m_head->m_pkthdr.csum_flags & CSUM_TSO) {
         required_cont += thlen;
         if (m_head->m_len < required_cont) {
            VMXNET3_LOG(sc->dev, 1, "Header buf too small for TSO %d < %d\n",
                        m_head->m_len, required_cont);
            return EINVAL;
         }
      }
      break;

   case IPPROTO_UDP:
      VMXNET3_LOG(sc->dev, 3, "UDP\n");
      required_cont +=  sizeof(struct udphdr);
      if (m_head->m_len < required_cont) {
         VMXNET3_LOG(sc->dev, 1, "Header buf too small to parse UDP hdr "
                     " %d < %d.\n", m_head->m_len, required_cont);
         return EINVAL;
      }
      thlen = sizeof(struct udphdr);
      break;

   case IPPROTO_HOPOPTS:
   case IPPROTO_ROUTING:
   case IPPROTO_DSTOPTS: {
      /* get next header and header length */
      struct ipv6_opt *opt6;
      VMXNET3_LOG(sc->dev, 3, "IPv6 Extentions\n");
      /* Check if the type and hlen fields are within reach */
      if (m_head->m_len < (required_cont + 2)) {
         VMXNET3_LOG(sc->dev, 1, "Header buf too small to parse IPv6 hdrs"
                     " %d < %d.\n", m_head->m_len, (required_cont +2));
         return EINVAL;
      }

      opt6 = (struct ipv6_opt *)(m_head->m_data + required_cont);
      ipproto = opt6->opt6_nxt;
      required_cont += (opt6->opt6_hlen + 1) * 8;
      if (m_head->m_len < required_cont) {
         VMXNET3_LOG(sc->dev, 1, "Header buf too small to parse IPv6 hdrs"
                     " %d < %d.\n", m_head->m_len, required_cont);
         return EINVAL;
      }
      tx_ctx->ip_hdr_size += ((opt6->opt6_hlen + 1) * 8);
      /* goto the next header */
      goto more_ipv6_extensions;
      }

   /* TODO: support IPv6 Fragmentations extentions */
   case IPPROTO_FRAGMENT:
      VMXNET3_LOG(sc->dev, 3, "IPv6 Fragmentation ext not supported.\n");
      return EINVAL;

   default:
      VMXNET3_LOG(sc->dev, 3, "L4 header is not TCP or UDP\n");
      return 0;
   }

   tx_ctx->l4_hdr_size = thlen;
   tx_ctx->is_cso = TRUE;
   return 0;
}


/*
 *-----------------------------------------------------------------------------
 * 
 * vmxnet3_unmap_pkt --
 *
 *      Free mbuf once we receive tx completion. 
 *
 * Results:
 *      Returns number of tx descriptors processed.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

static int
vmxnet3_unmap_pkt(struct Vmxnet3_TxCompDesc *tcd, vmxnet3_tx_queue_t *tq,
                  vmxnet3_adapter_t *sc)
{
   int eop_idx = tcd->txdIdx;
   int desc_completed = 0;
   struct mbuf *m_head;

   VMXNET3_ASSERT(tq->cmd_ring.base[eop_idx].txd.eop == 1);
   m_head = tq->cmd_ring.buf_info[eop_idx].m;

   if (m_head == NULL) {
      VMXNET3_LOG(sc->dev, 0, "Error : EOP desc does not point to a valid mbuf"
                  " eop_idx : %d, comp desc : %d\n", eop_idx,
                  tq->comp_ring.next2proc);
      VMXNET3_ASSERT(FALSE);
   } else {
      m_freem(m_head);
   }

   tq->cmd_ring.buf_info[eop_idx].m = NULL;

   while (tq->cmd_ring.next2comp != eop_idx) {
      /* Driver and device should agree on which descriptors they skipped.
       * We verify this by making sure that device generated in-ordered tx comp
       * for every tx desc marked as eop by driver. This be ensured if we do not
       * encounter a tx desc with eop set while we are incrementing next2comp.
       */
      VMXNET3_ASSERT(tq->cmd_ring.base[tq->cmd_ring.next2comp].txd.cq == 0);
      vmxnet3_cmd_ring_adv_next2comp(&tq->cmd_ring);
      desc_completed++;
   }
   
   /* Mark the txd for which tcd was generated as completed */
   vmxnet3_cmd_ring_adv_next2comp(&tq->cmd_ring);
   desc_completed++;

   return(desc_completed);
}


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_encap --
 *
 *      Initialize tx command desc with details of the buffers to be sent out
 *      descriptor thereon. Increment tx prod register to indicate that new
 *      packet is available to be sent.
 *      This function expects that all L1, L2 and L3 headers be in the first
 *	buffer of the mbuf. The packet will be dropped if the packet has these
 *      headers but not in first buffer.
 *
 * Results:
 *      Returns 0 for success, error code otherwise.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

static int
vmxnet3_encap(vmxnet3_adapter_t *sc, struct mbuf **m_header)
{
   int count = 0;
   struct mbuf *m_head = *m_header;
   Vmxnet3_TxDesc *txd = NULL;
   Vmxnet3_TxDesc *sop;
   struct mbuf *m;
   vmxnet3_tx_queue_t *tq = &sc->tx_queue[0];
   vmxnet3_buf_info_t *tbi = NULL;
   int pktinfo_ret;
   /* Set the initial gen value to complement of ring's gen bit */
   uint32 gen_dw = (tq->cmd_ring.gen ^ 1);
   vmxnet3_tx_ctx_t ctx;

   bzero(&ctx, sizeof(ctx));

   for (m = m_head; m != NULL; m = m->m_next) {
      if (m->m_len)
         count++;
   }

   if (count > (tq->cmd_ring.size - 1)) {
      /* Too many descriptors required, drop the packet */
      /* May be it is time to resize the tx ring ? */
      VMXNET3_LOG(sc->dev, 2, "Descs required (%d) are more than tx ring size "
                  "(%d), Packet dropped.\n", count, (tq->cmd_ring.size - 1));
      tq->stats.drop_total++;
      tq->stats.drop_tso++;
      tq->stats.drop_oversized++;
      return EMSGSIZE;
   }

   if (count > VMXNET3_MAX_TXD_PER_PKT && !(m_head->m_pkthdr.csum_flags &
                                            CSUM_TSO)) {
      VMXNET3_LOG(sc->dev, 1, "Non-TSO packet cannot occupy more than %d tx "
                  "descs. Packet dropped.\n", VMXNET3_MAX_TXD_PER_PKT);
      tq->stats.drop_total++;
      tq->stats.drop_oversized++;
      return EMSGSIZE;
   }
   if (count > vmxnet3_cmd_ring_desc_avail(&tq->cmd_ring)) {
      VMXNET3_LOG(sc->dev, 1, "xmit decriptors full, deffering packets. "
                   "required:%d available:%d\n", count,
                   vmxnet3_cmd_ring_desc_avail(&tq->cmd_ring));
      tq->stats.tx_ring_full++;
      vmxnet3_tq_tx_complete(sc, tq);
      return ENOBUFS;
   }

   if ((m_head->m_pkthdr.csum_flags & CSUM_IP)) {
      VMXNET3_LOG(sc->dev, 1, "Warning : No support for IP csum offload !\n");
      tq->stats.drop_total++;
      return EINVAL;
   } 

   pktinfo_ret = vmxnet3_get_packet_info(m_head, &ctx, sc);
   if (pktinfo_ret) {
      VMXNET3_LOG(sc->dev, 2, "Packet dropped.");
      tq->stats.drop_total++;
      tq->stats.drop_hdr_inspect_err++;
      return EINVAL;
   }

   sop = (Vmxnet3_TxDesc *)(tq->cmd_ring.base + tq->cmd_ring.next2fill);

   for (m = m_head; m != NULL; m = m->m_next) {
      tbi = tq->cmd_ring.buf_info + tq->cmd_ring.next2fill;
      txd = (Vmxnet3_TxDesc *)tq->cmd_ring.base + tq->cmd_ring.next2fill;
      txd->tci = txd->ti = 0;
      txd->cq = txd->eop = 0;

      tbi->bufPA = vtophys(mtod(m, caddr_t));
      VMXNET3_ASSERT(tbi->bufPA);
      txd->addr = tbi->bufPA;

      txd->gen = gen_dw;
      txd->len = m->m_len;
      VMXNET3_ASSERT(txd->len <= VMXNET3_MAX_TX_BUF_SIZE);

      vmxnet3_cmd_ring_adv_next2fill(&tq->cmd_ring);
      /* For rest of the descriptors, make gen bit same as that in ring */
      gen_dw = tq->cmd_ring.gen;
   }

   /* Mark the last descriptor as End of Packet. */
   txd->cq = 1;
   txd->eop = 1;

   if (ctx.is_vlan) {
      sop->ti = 1;
      sop->tci = ctx.evl_tag;
   }

   /* Record current mbuf for freeing it later in tx complete */
   VMXNET3_ASSERT(m_head);
   tbi->m = m_head;
   tq->shared->ctrl.txNumDeferred++;

   if ((m_head->m_pkthdr.csum_flags & CSUM_TSO) && ctx.l4_hdr_size) {
      /* TSO was asked for */
      struct ip *iph = NULL;
      VMXNET3_ASSERT(ctx.ip_type != ip_none);
      sop->hlen = ctx.eth_hdr_size + ctx.ip_hdr_size + ctx.l4_hdr_size;
      sop->om = VMXNET3_OM_TSO;
      VMXNET3_ASSERT(m_head->m_pkthdr.tso_segsz <= VMXNET3_MAX_MTU);
      sop->msscof = m_head->m_pkthdr.tso_segsz;
      if (ctx.ip_type == ip_v4) {
         iph = (struct ip *)(m_head->m_data + ctx.eth_hdr_size);
         iph->ip_sum = 0;
      }
      VMXNET3_LOG(sc->dev, 3, "TSO was asked : hlen:%d msscof:%d IPv%d\n",
                  sop->hlen, sop->msscof, ctx.ip_type == ip_v4 ? 4 : 6);
   } else if ((m_head->m_pkthdr.csum_flags & CSUM_DELAY_DATA) && ctx.is_cso) {
      /* CSUM offload was asked for */
      VMXNET3_ASSERT(ctx.ip_type != ip_none);
      sop->hlen = ctx.eth_hdr_size + ctx.ip_hdr_size;
      sop->om = VMXNET3_OM_CSUM;
      sop->msscof = ctx.eth_hdr_size + ctx.ip_hdr_size +
                    m_head->m_pkthdr.csum_data;
      VMXNET3_ASSERT(sop->msscof <= VMXNET3_MAX_CSUM_OFFSET);
      VMXNET3_LOG(sc->dev, 3, "CSO was asked : hlen:%d msscof:%d IPv%d\n",
                  sop->hlen, sop->msscof, ctx.ip_type == ip_v4 ? 4 : 6);
   } else {
      sop->hlen = 0;
      sop->om = VMXNET3_OM_NONE;
      sop->msscof = 0;
   }

   /* finally flip the GEN bit of the SOP desc  */
   sop->gen = !sop->gen;
   return 0;
}


/*
 *-----------------------------------------------------------------------------
 * 
 * vmxnet3_start_locked --
 *
 *      Check if_snd queue for unsent packets and fill tx descriptors to send
 *      them over this interface.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

static void
vmxnet3_start_locked(vmxnet3_adapter_t *sc)
{

   struct ifnet *ifp = sc->ifp;
   struct mbuf *m_head;
   vmxnet3_tx_queue_t *tq = &sc->tx_queue[0];
   int ret = 0;

   if ((ifp->if_drv_flags & (IFF_DRV_RUNNING | IFF_DRV_OACTIVE)) !=
       IFF_DRV_RUNNING) {
      VMXNET3_LOG(sc->dev, 1, "Device not running or internal queue is full, "
                  "cannot xmit.\n");
      return;
   }

   if (tq->stopped == TRUE) {
      VMXNET3_LOG(sc->dev, 1, "Cannot xmit, tx queue is stopped.\n");
      return;
   }

   while (!IFQ_DRV_IS_EMPTY(&ifp->if_snd)) {

      IFQ_DRV_DEQUEUE(&ifp->if_snd, m_head);
      VMXNET3_ASSERT(m_head);

      if ((ret = vmxnet3_encap(sc, &m_head))) {
         VMXNET3_LOG(sc->dev, 2, "Packet encapsulation error : %d\n", ret);
         if (ret == ENOBUFS) {
            /* TX queue is marked as active (busy) and packet deferred untill
             * some tx completions are processed
             */
            tq->stats.deferred++;
            IFQ_DRV_PREPEND(&ifp->if_snd, m_head);
            VMXNET3_LOG(sc->dev, 1, "No bufs remain.\n");
         } else {
            m_freem(m_head);
         }
         break;
      }

      ETHER_BPF_MTAP(ifp, m_head);
   }

   if (tq->shared->ctrl.txNumDeferred >= tq->shared->ctrl.txThreshold) {
      tq->shared->ctrl.txNumDeferred = 0;
      VMXNET3_WRITE_BAR0_REG(sc, VMXNET3_REG_TXPROD,
                             tq->cmd_ring.next2fill);
      VMXNET3_LOG(sc->dev, 3, "vmxnet3: deferred : %d threshold:%d next2fill"
                   " %d next2comp:%d\n", tq->shared->ctrl.txNumDeferred,
                   tq->shared->ctrl.txThreshold, tq->cmd_ring.next2fill,
                   tq->cmd_ring.next2comp);
   }
}


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_start --
 *
 *      Wrapper to start xmitting packets.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

void
vmxnet3_start(struct ifnet *ifp)
{
   vmxnet3_adapter_t *sc = (vmxnet3_adapter_t *) ifp->if_softc;

   VMXNET3_LOCK_TX(sc->tx_queue);
   vmxnet3_start_locked(sc);
   VMXNET3_UNLOCK_TX(sc->tx_queue);

   return;
}

/*
 *-----------------------------------------------------------------------------
 * 
 * vmxnet3_tq_tx_complete --
 *
 *      Check for tx completions.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      The interface may be marked inactive(not busy).
 *
 *-----------------------------------------------------------------------------
 */

void
vmxnet3_tq_tx_complete(vmxnet3_adapter_t *sc, vmxnet3_tx_queue_t *tq)
{
   int completed = 0, i = 0;
   vmxnet3_comp_ring_t *comp_ring = &tq->comp_ring;
   struct Vmxnet3_TxCompDesc *tcd = (struct Vmxnet3_TxCompDesc *)
                                    (comp_ring->base + comp_ring->next2proc);

   VMXNET3_ASSERT_LOCK(sc);
   VMXNET3_ASSERT_TX_LOCK(tq);

   while (tcd->gen == comp_ring->gen) {
      VMXNET3_LOG(sc->dev, 3, "tcd#: %d for txd#: %d\n", comp_ring->next2proc,
                  tcd->txdIdx);
      completed += vmxnet3_unmap_pkt(tcd, tq, sc);
      i++;
      vmxnet3_comp_ring_adv_next2proc(comp_ring);

      tcd = (struct Vmxnet3_TxCompDesc *)(comp_ring->base +
                                          comp_ring->next2proc);
   }

   /* If IFF_DRV_OACTIVE was set due of lack of buffers, reset it. */
   if (i > 0 && tq->stopped == FALSE && sc->ifp->if_drv_flags & IFF_DRV_OACTIVE) {
      sc->ifp->if_drv_flags &= ~IFF_DRV_OACTIVE;
      VMXNET3_LOG(sc->dev, 1, "Interface available for tx again.\n");
   }

   VMXNET3_LOG(sc->dev, 3, "Processed %d tx comps, %d tx command descs.\n",
                i, completed);

}



