/***********************************************************
 * Copyright (C) 2010 VMware, Inc. All Rights Reserved
 *
 * -- VMware Confidential
 ***********************************************************/

/*
 * vmxnet3_rx.c
 *      Packet receiving for VMXNET3 NIC driver.
 */

#include <vmxnet3_int.h>


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_post_rx_bufs --
 *
 *      Allocate mbufs and clusters. Post rx descriptors with buffer details
 *      so that device can receive packets in those buffers.
 *	Ring layout:
 *      Among the two rings, 1st ring contains buffers of type 0 and type1.
 *      bufs_per_pkt is set such that for non-LRO cases all the buffers required
 *      by a frame will fit in 1st ring (1st buf of type0 and rest of type1).
 *      2nd ring contains buffers of type 1 alone. Second ring mostly be used
 *      only for LRO.
 *
 * Results:
 *	Returns
 *       n : where n is the number of buffers posted during this function call.
 *	-n : where n is the error code when this function could not post any
 *           buffers at all.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

int
vmxnet3_post_rx_bufs(vmxnet3_adapter_t *sc, struct vmxnet3_cmd_ring *ring,
                     int num_post)
{
   int i = 0, err = 0;
   uint32 val = 0;
   int max_frame_size = sc->cur_mtu + ETHER_HDR_LEN + ETHERNET_FCS_SIZE;

   VMXNET3_ASSERT_LOCK(sc);
   VMXNET3_LOG(sc->dev, 3, "descs available to be posted : %d, next2comp:%d"
               ", next2fill:%d\n", vmxnet3_cmd_ring_desc_avail(ring),
               ring->next2comp, ring->next2fill);

   while (vmxnet3_cmd_ring_desc_avail(ring) > 0 && i < num_post) {
      struct Vmxnet3_RxDesc *rxd;
      struct mbuf *m;
      vmxnet3_buf_info_t *buf_info = &ring->buf_info[ring->next2fill];
      rxd = (struct Vmxnet3_RxDesc *)(ring->base + ring->next2fill);

      if (ring->rid == 0) {
         /* One HEAD type buf buf per packet */
         val = (ring->next2fill % sc->bufs_per_pkt) ? VMXNET3_RXD_BTYPE_BODY :
                                                      VMXNET3_RXD_BTYPE_HEAD;
      } else {
         /* All BODY type buffers for 2nd ring */
         val = VMXNET3_RXD_BTYPE_BODY;
      }

      if (buf_info->m != NULL) {
         goto skip_desc;
      }

      if (max_frame_size > MCLBYTES) {
         m = m_getjcl(M_DONTWAIT, MT_DATA, val == VMXNET3_RXD_BTYPE_HEAD ?
                      M_PKTHDR : 0, MJUM9BYTES);
      } else {
         m = m_getcl(M_DONTWAIT, MT_DATA, val == VMXNET3_RXD_BTYPE_HEAD ?
                     M_PKTHDR : 0);
      }

      if (m == NULL) {
         VMXNET3_LOG(sc->dev, 1, "Error allocating mbuf \n");
         err = ENOMEM;
         goto error;
      }

      /* Buffer sizes MCLBYTES = 2k, MJUM9BYTES = 9k */
      m->m_len = (max_frame_size > MCLBYTES ? MJUM9BYTES : MCLBYTES);
      m_adj(m, ETHER_ALIGN);
      buf_info->m = m;
      buf_info->len = m_length(m, NULL);

      /* Clusters allocated by m_getcl/m_getjcl are physically contiguous
       * So, we can directly use PA obtained from vtophys
       */
      buf_info->bufPA = vtophys(mtod(buf_info->m, bus_addr_t));
      rxd->addr = buf_info->bufPA;

skip_desc:
      VMXNET3_ASSERT(rxd->addr != 0);

      rxd->btype = val;	
      rxd->len = buf_info->len;
      /* Flip gen bit at the end to change ownership */
      rxd->gen = ring->gen;

      vmxnet3_cmd_ring_adv_next2fill(ring);
      i++;
   }

   VMXNET3_LOG(sc->dev, 3, "%d rx buffers posted in this call.\n", i);
   return (ring->size - 1 - (vmxnet3_cmd_ring_desc_avail(ring)));

error:
   if (i == 0)
       VMXNET3_LOG(sc->dev, 3, "No buffers were posted in this call.\n");
   /* Return error only if no buffers are posted at present */
   if (vmxnet3_cmd_ring_desc_avail(ring) >= (ring->size -1))
      return -err;
   else
      return (ring->size - 1 - (vmxnet3_cmd_ring_desc_avail(ring)));
}

/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_free_rx_bufs --
 *
 *      Free up as many as 'count' mbufs allocated. This function doesn't check
 *      who is the owner of the descriptor pointing to the mbuf being deleted.
 *      Calling function should take care of that detail by providing the right
 *      count.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

static void
vmxnet3_free_rx_bufs(vmxnet3_adapter_t *sc, struct vmxnet3_cmd_ring *ring,
                     int count)
{
   int i = count;

   VMXNET3_ASSERT_LOCK(sc);
   while (i > 0 && vmxnet3_cmd_ring_desc_avail(ring) < ring->size) {
      vmxnet3_buf_info_t *buf_info = &ring->buf_info[ring->next2comp];
      if (buf_info->m) {
         m_freem(buf_info->m);
         buf_info->m = NULL;
         buf_info->bufPA = 0;
         buf_info->len = 0;
      }

      vmxnet3_cmd_ring_adv_next2comp(ring);
      i--;
   }
   VMXNET3_LOG(sc->dev, 3, "%d rx buffers freed.\n", count - i);
}


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_cleanup_rx --
 *
 *      Free all rx bufs posted for each ring. Free the memory for rx
 *      descriptors in the ring.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

void
vmxnet3_cleanup_rx (vmxnet3_adapter_t *sc, struct vmxnet3_rx_queue *rq)
{
   int i;
   struct vmxnet3_cmd_ring *ring;

   VMXNET3_ASSERT_LOCK(sc);
   for(i = 0; i < 2; i++) {
      ring = &rq->cmd_ring[i];
      vmxnet3_free_rx_bufs(sc, ring, ring->size);

      if (ring->buf_info)
         free(ring->buf_info, M_DEVBUF);
      ring->buf_info = NULL;

   }

   ring = &rq->cmd_ring[0];
   if (ring->base)
      vmxnet3_free_dma_mem(sc, ring->dma_tag, ring->dma_map, ring->base,
                              ring->basePA);
   ring->base = NULL;
   ring->basePA = 0;
   ring = &rq->cmd_ring[1];
   ring->base = NULL;
   ring->basePA = 0;
   rq->comp_ring.basePA = 0;

   VMXNET3_LOG(sc->dev, 3, "Rx queue was cleaned up.\n");
}


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_init_rx --
 *
 *      Allocate space required by rx descriptors and post rx buffers to device.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

int
vmxnet3_init_rx(vmxnet3_adapter_t *sc, vmxnet3_rx_queue_t *rq)
{
   int ret, size, i;
   struct vmxnet3_cmd_ring *ring0, *ring1, *ring;
   struct vmxnet3_comp_ring *comp_ring;
   int max_frame_size = sc->cur_mtu + ETHER_HDR_LEN + ETHERNET_FCS_SIZE;

   VMXNET3_ASSERT_LOCK(sc);

   rq->cmd_ring[0].next2fill = 0;
   rq->cmd_ring[1].next2fill = 0;
   rq->cmd_ring[0].next2comp = 0;
   rq->cmd_ring[1].next2comp = 0;
   rq->cmd_ring[0].gen = VMXNET3_INIT_GEN;
   rq->cmd_ring[1].gen = VMXNET3_INIT_GEN;
   rq->comp_ring.next2proc = 0;
   rq->comp_ring.gen = VMXNET3_INIT_GEN;

   if (max_frame_size > MCLBYTES) {
      sc->bufs_per_pkt = (max_frame_size + MJUM9BYTES - 1) / MJUM9BYTES;
   } else {
      sc->bufs_per_pkt = (max_frame_size + MCLBYTES - 1) / MCLBYTES;
   }

   ring0 = &rq->cmd_ring[0];
   ring1 = &rq->cmd_ring[1];
   comp_ring = &rq->comp_ring;

   size = sizeof(struct Vmxnet3_RxDesc) * (ring0->size + ring1->size);
   size += sizeof(struct Vmxnet3_RxCompDesc) * comp_ring->size;

   ret = vmxnet3_get_dma_mem(sc, size, &ring0->dma_tag, &ring0->dma_map,
                             VMXNET3_RING_BA_ALIGN, (void **)&ring0->base,
                             &ring0->basePA);
   if (ret) {
      VMXNET3_LOG(sc->dev, 0, "Error allocating DMA mem for rings.\n");
      goto error;
   }

   ring1->base = ring0->base + ring0->size;
   ring1->basePA = ring0->basePA + sizeof(struct Vmxnet3_RxDesc) * ring0->size;

   comp_ring->base = ring1->base +  ring1->size;
   comp_ring->basePA = ring1->basePA + sizeof(struct Vmxnet3_RxDesc) *
                       ring1->size;

   for(i = 0; i < 2; i++) {
      ring = &rq->cmd_ring[i];
      ring->buf_info = malloc(ring->size * sizeof(vmxnet3_buf_info_t), M_DEVBUF,
                              M_ZERO | M_NOWAIT);
      if (!ring->buf_info) {
         ret = ENOMEM;
         goto error;
      }

      ring->rid = i;
      ret = vmxnet3_post_rx_bufs(sc, ring, ring->size);
      if (ret <= 0) {
         ret = -ret;
         VMXNET3_LOG(sc->dev, 0, "Could not post any rx buffers. Error:%d \n",
                     ret);
          goto error;
      }
   }

   VMXNET3_LOG(sc->dev, 1, "RX ring initialization completed.\n");
   return 0;

error:
   VMXNET3_LOG(sc->dev, 2, "Cleaning up rx rings \n");
   vmxnet3_cleanup_rx(sc, rq);
   return ret;

}

/*
 *----------------------------------------------------------------------------
 *
 * vmxnet3_rx_csum --
 *
 *      Process csum related bits in EOP RCD to fill checksum info into
 *      the packet mbuf .
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *----------------------------------------------------------------------------
 */

static void
vmxnet3_rx_csum(vmxnet3_adapter_t *sc, struct mbuf *m,
                Vmxnet3_RxCompDesc *rcd)
{
   VMXNET3_ASSERT(m->m_pkthdr.csum_flags == 0);
   if (rcd->frg)
      m->m_flags |= M_FRAG;

   if (!rcd->cnc && (sc->ifp->if_capenable & IFCAP_RXCSUM)) {

      if (rcd->v4) {
         m->m_pkthdr.csum_flags |= CSUM_IP_CHECKED;
         if (rcd->ipc) {
            m->m_pkthdr.csum_flags |= CSUM_IP_VALID;
         }
      }

      /*
       * For fragments, csum_flags will be AND-ed and
       * csum_data will be summed.
       */

      if ((rcd->v4 || rcd->v6) && (rcd->tcp || rcd->udp)) {
         m->m_pkthdr.csum_flags |= CSUM_PSEUDO_HDR | CSUM_DATA_VALID;
         if (rcd->tuc && !rcd->frg) {
            m->m_pkthdr.csum_data = 0xffff;
         } else {
            m->m_pkthdr.csum_data = 0;
         }
      }
   }
}


/*
 *-----------------------------------------------------------------------------
 *
 * vmxnet3_rq_rx_complete --
 *
 *      Check for receive completions. Send the received frames up. This
 *      function is called from the deferred workqueue handler.
 *
 * Results:
 *      None.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

void
vmxnet3_rq_rx_complete(vmxnet3_adapter_t *sc, vmxnet3_rx_queue_t *rq)
{
   uint32 num_rxd = 0;
   Vmxnet3_RxCompDesc *rcd;
   struct ifnet *ifp = sc->ifp;
   int ring_idx, num_to_alloc, i;
   static uint32 rxprod_reg[2] = {VMXNET3_REG_RXPROD, VMXNET3_REG_RXPROD2};
   struct ether_header *eth;

   VMXNET3_ASSERT_LOCK(sc);
   rcd = &rq->comp_ring.base[rq->comp_ring.next2proc].rcd;
   VMXNET3_LOG(sc->dev, 3, "recv comp #%d gen:%d \n", rq->comp_ring.next2proc,
                rcd->gen);

   while (rcd->gen == rq->comp_ring.gen) {
      vmxnet3_buf_info_t *rbi;
      struct mbuf *m_head = NULL, *m = NULL;
      Vmxnet3_RxDesc *rxd;
      uint32 idx;
      uint32 pkt_len=0;

      /*
       * Process rcd untill an EOP is encountered. Link all the resulting
       * buffers in one mbuf chain.
       */
      do {
         rcd = &rq->comp_ring.base[rq->comp_ring.next2proc].rcd;
         if (rcd->gen != rq->comp_ring.gen) {
            VMXNET3_LOG(sc->dev, 0, "End of comp desc but eop packet not "
                        "found. Error !\n");
            /* Free the mbuf chain. For the first pass through this loop,
             * rcd->gen was validated by outer loop. Hence m_head must be
             * set to a non-NULL value.
             */
            VMXNET3_ASSERT(m_head);
            m_freem(m_head);
            goto rcd_done;
         }

         vmxnet3_comp_ring_adv_next2proc(&rq->comp_ring);

         idx = rcd->rxdIdx;
         ring_idx = rcd->rqID == rq->qid1 ? 0 : 1;
         rxd = (Vmxnet3_RxDesc *)rq->cmd_ring[ring_idx].base + idx;
         rbi = rq->cmd_ring[ring_idx].buf_info + idx;
         VMXNET3_LOG(sc->dev, 3, "rxd idx: %d ring idx: %d.\n", idx, ring_idx);

         VMXNET3_ASSERT(rcd->len <= rxd->len);
         VMXNET3_ASSERT(rbi->m);

         if (rcd->len == 0) {
            VMXNET3_LOG(sc->dev, 3, "Rx buf was skipped. rxring[%d][%d]\n)",
                         ring_idx, idx);
            if (!rcd->sop || !rcd->eop) {
               VMXNET3_LOG(sc->dev, 0, "Alert : Misbehaving device, SOP and EOP"
                           " bits of skipped buffer are not set.\n");
               if (m_head) {
                  VMXNET3_LOG(sc->dev, 1, "Dropping the received packet.");
                  m_freem(m_head);
                  m_head = NULL;
               }
            }

            VMXNET3_ASSERT(rcd->sop && rcd->eop);

            rq->cmd_ring[ring_idx].next2comp = idx;
            goto rcd_done;
         }


         if (rcd->sop) {
            /* First buffer of the packet (SOP) */

            if (m_head)
               VMXNET3_LOG(sc->dev, 0, "Alert : Misbehaving device, consecutive"
                          " SOP desc w/o an EOP desc. Packet dropped.\n");

            if (rxd->btype != VMXNET3_RXD_BTYPE_HEAD) {
               VMXNET3_LOG(sc->dev, 0, "Alert : Misbehaving device, incorrect "
                          " buffer type used. iPacket dropped.\n");
               goto rcd_done;
            }
            VMXNET3_ASSERT(!m_head);
            VMXNET3_ASSERT(rxd->btype == VMXNET3_RXD_BTYPE_HEAD);

            m_head = rbi->m;
            pkt_len = rcd->len;
         } else {
            /* Consecutive buffers of packet */

            if (rxd->btype != VMXNET3_RXD_BTYPE_BODY) {
               VMXNET3_LOG(sc->dev, 0, "Alert : Misbehaving device, incorrect "
                          " buffer type usedi for body. Packet dropped.\n");
               goto rcd_done;
            }
            VMXNET3_ASSERT(rxd->btype == VMXNET3_RXD_BTYPE_BODY);
            VMXNET3_ASSERT(m_head && m);

            /* Provide a safe way out for release builds where the above
             * ASSERT will not be fired */
            if (!m_head || !m) {
               /* Skip this EOP rcd as it did not have a preceding SOP rcd */
               VMXNET3_LOG(sc->dev, 1, "EOP buffer without a preceding SOP,"
                           " Error !\n");
               rq->cmd_ring[ring_idx].next2comp = idx;
               goto rcd_done;
            }
            m->m_next = rbi->m;
            pkt_len += rcd->len;
         }

         m = rbi->m;
         rbi->m = NULL;
         rbi->bufPA = 0;
         rq->cmd_ring[ring_idx].next2comp = idx;
      } while (rcd->eop != 1);

      m->m_next = NULL;

      /* For RCD with EOP set, check if there is frame error */
      if (rcd->err) {
         rq->stats.drop_total++;
         rq->stats.drop_err++;
         sc->ifp->if_ierrors++;

         if(!rcd->fcs) {
            rq->stats.drop_fcs++;
            VMXNET3_LOG(sc->dev, 1, "Recv packet dropped due to frame err.\n");
         }
         VMXNET3_LOG(sc->dev, 2, "Error in received packet rcd#:%d rxd:%d\n",
                     (int)(rcd - (struct Vmxnet3_RxCompDesc *)
                           rq->comp_ring.base), rcd->rxdIdx);
         m_freem(m_head);

         rq->cmd_ring[ring_idx].next2comp = idx;
         goto rcd_done;
      }

      VMXNET3_ASSERT(m_head && mtod(m_head, void *));
      vmxnet3_rx_csum(sc, m_head, rcd);

      ifp->if_ipackets++;
      ifp->if_ibytes += pkt_len;
      
      eth = mtod(m_head, struct ether_header *);
      if (0x1 & eth->ether_dhost[0]) {
         ifp->if_imcasts++;
         m_head->m_flags |= M_MCAST;
      }

      m_head->m_pkthdr.rcvif = ifp;
      m_head->m_pkthdr.len = m_head->m_len = pkt_len;

      /* Check for hardware stripped VLAN tag */
      if (rcd->ts) {
         VMXNET3_LOG(sc->dev, 2, "Received packet with vlan ID: %d.\n",
                     rcd->tci);
         m_head->m_flags |= M_VLANTAG;
         m_head->m_pkthdr.ether_vtag = rcd->tci;
      } else {
         m_head->m_flags &= ~M_VLANTAG;
      }

      /* device may have skipped some rx descs */
      rq->cmd_ring[ring_idx].next2comp = idx;

      VMXNET3_ASSERT(ifp->if_input);
      /* Send packet to the network stack */
      VMXNET3_UNLOCK(sc);
      (*ifp->if_input)(ifp, m_head);
      VMXNET3_LOCK(sc);

      m_head = NULL;

rcd_done:
      for (i = 0; i < 2; i++) {
         num_to_alloc = vmxnet3_cmd_ring_desc_avail(rq->cmd_ring + i);
         if (num_to_alloc > VMXNET3_RX_ALLOC_THRESHOLD(rq, i)) {
            VMXNET3_LOG(sc->dev, 3, "Posting buffers ring%d.\n", i);
            vmxnet3_post_rx_bufs(sc, &rq->cmd_ring[i], num_to_alloc);
            if (rq->shared->ctrl.updateRxProd) {
               VMXNET3_WRITE_BAR0_REG(sc, rxprod_reg[i] + rq->qid1 * 8,
                                      rq->cmd_ring[i].next2fill);
            }
         }
      }

      rcd = &rq->comp_ring.base[rq->comp_ring.next2proc].rcd;
      num_rxd++;
      if (num_rxd > rq->cmd_ring[0].size) {
         VMXNET3_LOG(sc->dev, 2, "Used up quota of receving packets,"
                     " relinquish control.\n");
         break;
      }
   }
}
