/***********************************************************
 * Copyright (C) 2010 VMware, Inc. All Rights Reserved
 *
 * -- VMware Confidential
 ***********************************************************/

#ifndef _VMXNET3_INT_H
#define _VMXNET3_INT_H

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/endian.h>
#include <sys/ktr.h>
#include <sys/mbuf.h>
#include <sys/socket.h>
#include <sys/sockio.h>
#include <sys/malloc.h>
#include <sys/kernel.h>
#include <sys/module.h>
#include <machine/atomic.h>
#include <sys/eventhandler.h>
#include <machine/bus.h>
#include <machine/bus_dma.h>
#include <machine/resource.h>
#include <sys/bus.h>
#include <sys/rman.h>
#include <sys/queue.h>
#include <sys/taskqueue.h>

#include <net/if.h>
#include <net/if_arp.h>
#include <net/ethernet.h>
#include <net/if_media.h>
#include <net/if_types.h>
#include <net/if_dl.h>
#include <net/if_var.h>
#include <net/if_vlan_var.h>

#include <net/bpf.h>

#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <netinet/in_systm.h>
#include <netinet/tcp.h>
#include <netinet/tcp_lro.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/udp.h>
#include <machine/in_cksum.h>

#include <vm/vm.h>
#include <vm/pmap.h>
#include <dev/pci/pcivar.h>
#include <dev/pci/pcireg.h>
#include <dev/de/dc21040reg.h>

#ifdef DDB
#include <ddb/ddb.h>
#endif

#include <vm_basic_types.h>
#include <vmxnet3_defs.h>

#ifndef likely
#define likely(x)       __builtin_expect((x), 1)
#endif

#ifndef unlikely
#define unlikely(x)     __builtin_expect((x), 0)
#endif

#define ETHERNET_FCS_SIZE 4

/* TODO Bring this from a Makefile */

#ifdef VMXNET3_DEBUG
#  define VMXNET3_LOG_MAXPRIORITY 2
#else
#  define VMXNET3_LOG_MAXPRIORITY 0
#endif

/*
 * VMXNET3_LOG verbosity guidelines :
 * 0 - errors messages / status which must be reported. [Recommended]
 * 1 - Less important errors. General info / statistics.
 * 2 - Verbose status / progress messages. More statistics.
 * 3 - Statistics in fast path. For debugging ring/queue problems.
 */

#define VMXNET3_LOG(dev, level, ...) do { \
                                        if (level <= VMXNET3_LOG_MAXPRIORITY) { \
                                           device_printf(dev, __VA_ARGS__); \
                                        } \
                                     } while(0)

#ifdef VMXNET3_DEBUG
#define VMXNET3_ASSERT(x) if(!(x)) panic("vmxnet3:%s(%d)" #x, __FUNCTION__, \
                                         __LINE__)
#else
#define VMXNET3_ASSERT(x)
#endif

#define VMXNET3_READ_BAR0_REG(sc, address) \
        bus_space_read_4(sc->bar0_bt, sc->bar0_bh, address)
#define VMXNET3_WRITE_BAR0_REG(sc, address, value) \
        bus_space_write_4(sc->bar0_bt, sc->bar0_bh, address, value)
#define VMXNET3_READ_BAR1_REG(sc, address) \
        bus_space_read_4(sc->bar1_bt, sc->bar1_bh, address)
#define VMXNET3_WRITE_BAR1_REG(sc, address, value) \
        bus_space_write_4(sc->bar1_bt, sc->bar1_bh, address, value)

#define VMXNET3_LOCK(sc)        mtx_lock(&sc->vmxnet3_mutex)
#define VMXNET3_LOCK_TX(tq)     mtx_lock(&tq->tx_lock)
#define VMXNET3_UNLOCK(sc)      mtx_unlock(&sc->vmxnet3_mutex)
#define VMXNET3_UNLOCK_TX(tq)   mtx_unlock(&tq->tx_lock)
#define VMXNET3_ASSERT_LOCK(sc) mtx_assert(&sc->vmxnet3_mutex, MA_OWNED)
#define VMXNET3_ASSERT_TX_LOCK(tq) mtx_assert(&tq->tx_lock, MA_OWNED)

#define VMXNET3_TX_QUEUES 1
#define VMXNET3_RX_QUEUES 1
#define VMXNET3_DEF_TX_RING_SIZE 512
#define VMXNET3_DEF_RX_RING_SIZE 256
#define VMXNET3_RX_ALLOC_THRESHOLD(rq, ring_idx) \
        ((rq)->cmd_ring[ring_idx].size >> 5)

#define VMXNET3_READ_BAR0(sc, reg) bus_space_read_4(sc->bar0_bt, sc->bar0_bh, \
                                                    reg);
#define VMXNET3_WRITE_BAR0(sc, reg, val) bus_space_write_4(sc->bar0_bt, \
                                                         sc->bar0_bh, reg, val);
#define VMXNET3_READ_BAR1(sc, reg) bus_space_read_4(sc->bar1_bt, sc->bar1_bh, \
                                                    reg);
#define VMXNET3_WRITE_BAR1(sc, reg, val) bus_space_write_4(sc->bar1_bt, \
                                                         sc->bar1_bh, reg, val);
#define VMXNET3_GET_ADDR_LO(dma)   ((uint32_t)(dma))
#define VMXNET3_GET_ADDR_HI(dma)   ((uint32_t)(((uint64_t)(dma)) >> 32))

/* Following are not neccesarily atomic operations */
static inline Bool
set_bit(uint8_t *field, uint8_t bit) {
   *field |= (1 << bit);
   return FALSE;
}
#define clear_bit(field, bit) (*(field) &= ~(0x1 << bit))

static inline Bool
test_and_set_bit(uint8_t *field, uint8_t bit) {
   return (*field & (1 << bit)) == 0 ? set_bit(field, bit) : TRUE;

}

typedef struct vmxnet3_buf_info {
   uint16_t               len;
   struct mbuf            *m;
   bus_addr_t             bufPA;
}vmxnet3_buf_info_t;


struct vmxnet3_cmd_ring {
   vmxnet3_buf_info_t     *buf_info;
   uint32_t               size;
   uint32_t               next2fill;
   uint32_t               next2comp;
   uint8_t                gen;
   uint8_t                rid;
   Vmxnet3_GenericDesc    *base;
   bus_addr_t             basePA;
   bus_dma_tag_t          dma_tag;
   bus_dmamap_t           dma_map;
};

static inline void
vmxnet3_cmd_ring_adv_next2fill(struct vmxnet3_cmd_ring *ring)
{
   ring->next2fill++;
   if (unlikely(ring->next2fill == ring->size)) {
      ring->next2fill = 0;
      VMXNET3_FLIP_RING_GEN(ring->gen);
   }
}


static inline void
vmxnet3_cmd_ring_adv_next2comp(struct vmxnet3_cmd_ring *ring)
{
   VMXNET3_INC_RING_IDX_ONLY(ring->next2comp, ring->size);
}


static inline int
vmxnet3_cmd_ring_desc_avail(struct vmxnet3_cmd_ring *ring)
{
   return (ring->next2comp > ring->next2fill ? 0 : ring->size) +
           ring->next2comp - ring->next2fill - 1;
}


static INLINE Bool
vmxnet3_cmd_ring_desc_empty(struct vmxnet3_cmd_ring *ring)
{
   return (ring->next2comp == ring->next2fill);
}


typedef struct vmxnet3_comp_ring {
   uint32_t               size;
   uint32_t               next2proc;
   uint8_t                gen;
   uint8_t                intr_idx;
   Vmxnet3_GenericDesc    *base;
   bus_addr_t             basePA;
   bus_dma_tag_t          dma_tag;
   bus_dmamap_t           dma_map;
} vmxnet3_comp_ring_t;

static inline void
vmxnet3_comp_ring_adv_next2proc(struct vmxnet3_comp_ring *ring)
{
   ring->next2proc++;
   if (unlikely(ring->next2proc == ring->size)) {
      ring->next2proc = 0;
      VMXNET3_FLIP_RING_GEN(ring->gen);
   }
}


struct vmxnet3_txq_stats {
   uint64_t               drop_total; /* # of pkts dropped by the driver, the
                                       * counters below track droppings due to
                                       * different reasons
                                       */
   uint64_t               drop_oversized;
   uint64_t               drop_hdr_inspect_err;
   uint64_t               drop_tso;
   uint64_t               deferred;
   uint64_t               tx_ring_full;
   uint64_t               linearized;  /* # of pkts linearized */
};

enum ipType {
   ip_none = 0,
   ip_v4,
   ip_v6,
};

typedef struct vmxnet3_tx_ctx {
   int      ip_type;
   Bool     is_vlan;
   Bool     is_cso;

   uint16_t evl_tag;		/* only valid when is_vlan == TRUE */
   uint32_t eth_hdr_size;       /* only valid for pkts requesting tso or csum
                                 * offloading */
   uint32_t ip_hdr_size;
   uint32_t l4_hdr_size;
} vmxnet3_tx_ctx_t;


typedef struct vmxnet3_tx_queue {
   struct vmxnet3_adapter       *sc;
   struct mtx                   tx_lock;
   char                         lock_name[15];
   struct vmxnet3_cmd_ring      cmd_ring;
   struct vmxnet3_comp_ring     comp_ring;
   int                          qid;
   struct Vmxnet3_TxQueueDesc   *shared;
   struct vmxnet3_txq_stats     stats;
   Bool                         stopped;
} vmxnet3_tx_queue_t;


struct vmxnet3_rxq_stats {
   uint64_t                     drop_total;
   uint64_t                     drop_err;
   uint64_t                     drop_fcs;
   uint64_t                     rx_buf_alloc_failure;
};

typedef struct vmxnet3_rx_queue {
   struct vmxnet3_adapter       *sc;
   struct vmxnet3_cmd_ring      cmd_ring[2];
   struct vmxnet3_comp_ring     comp_ring;
   uint32_t                     qid1;
   uint32_t                     qid2;
   Vmxnet3_RxQueueDesc          *shared;
   struct vmxnet3_rxq_stats     stats;
} vmxnet3_rx_queue_t;

typedef struct vmxnet3_mf_table {
   void                         *mfTableBase; /* Multicast addresses list */
   bus_addr_t                   mfTablePA;    /* Physical address of the list */
   uint16_t                     num_addrs;    /* number of multicast addrs */
   bus_dma_tag_t                dma_mf_tag;  
   bus_dmamap_t                 dma_mf_map;
} vmxnet3_mf_table_t;

typedef struct vmxnet3_intr {
   uint8_t                      type;
   uint8_t                      mask_mode;
   uint8_t                      num_intrs;
   uint8_t                      event_intr_idx;
   int                          rid;
   int                          msix_rid;
   struct resource              *irq;
   struct resource              *msix_mem;
   void                         *cookie;
} vmxnet3_intr_t;


#define VMXNET3_STATE_BIT_RESETTING 0
#define VMXNET3_STATE_BIT_QUIESCED  1
#define VMXNET3_STATE_BIT_LINK_ACTIVE 2

typedef struct vmxnet3_adapter {
   device_t                     dev;
   struct ifnet                 *ifp;
   struct ifmedia               media;
   uint8_t                      mac_addr[ETHER_ADDR_LEN];
   uint8_t                      vmxnet3_unit;
   struct mtx                   vmxnet3_mutex;

   /* PCI Bus resources */
   struct resource              *bar0res;
   struct resource              *bar1res;
   int                          bar0id;
   int                          bar1id;
   bus_space_tag_t              bar0_bt;
   bus_space_tag_t              bar1_bt;
   bus_space_handle_t           bar0_bh;
   bus_space_handle_t           bar1_bh;
                                
   Vmxnet3_TxQueueDesc          *tqd_start;
   Vmxnet3_RxQueueDesc          *rqd_start;
   Vmxnet3_DriverShared         *shared;
   bus_addr_t                   sharedPA;
   bus_addr_t                   queueDescPA;
                                
   bus_dma_tag_t                dma_qdesc_tag;
   bus_dma_tag_t                dma_shared_tag;
   bus_dmamap_t                 dma_qdesc_map;
   bus_dmamap_t                 dma_shared_map;
   uint16_t                     queue_desc_len;
   vmxnet3_tx_queue_t           tx_queue[VMXNET3_TX_QUEUES];
   vmxnet3_rx_queue_t           rx_queue[VMXNET3_RX_QUEUES];
   uint8_t                      bufs_per_pkt;
   uint8_t                      num_tx_queues;
   uint8_t                      num_rx_queues;
   uint16_t                     cur_mtu;
   vmxnet3_intr_t               intr;
   struct task                  rxtx_task;
   struct taskqueue             *taskqueue;
                                
   vmxnet3_mf_table_t            mf_table;

   /* Bitfield to keeps track of resetting and quiesced states of the device. */
   uint8_t                      state;

   /* A copy of if_flags from ifp is saved to contrast find out which bits 
    * have changed when SIOCSIFFLAGS ioctl is received the next time.
    */
   int                          saved_if_flags;

   /* Events to handle H/W VLAN tag stripping changes and the list of tags */
   eventhandler_tag             vlan_attach;
   eventhandler_tag             vlan_detach;
   int                          vlan_ids_filtered;

} vmxnet3_adapter_t;

struct ipv6_opt {
   uint8_t        opt6_nxt;       /* next header */
   uint8_t        opt6_hlen;	  /* header len */
};

void vmxnet3_dma_map_addr(void *, bus_dma_segment_t *, int, int);
int vmxnet3_get_dma_mem(vmxnet3_adapter_t *sc, int size, bus_dma_tag_t *tag,
                        bus_dmamap_t *map, bus_size_t align, void **base,
                        bus_addr_t *basePA);
void vmxnet3_free_dma_mem(vmxnet3_adapter_t *sc, bus_dma_tag_t tag,
                          bus_dmamap_t map, void *base, bus_addr_t basePA);


int vmxnet3_init_rx(vmxnet3_adapter_t *, vmxnet3_rx_queue_t *);
void vmxnet3_cleanup_rx(vmxnet3_adapter_t *sc, vmxnet3_rx_queue_t *rq);
int vmxnet3_init_tx(vmxnet3_adapter_t *, vmxnet3_tx_queue_t *);
void vmxnet3_cleanup_tx(vmxnet3_adapter_t *sc, vmxnet3_tx_queue_t *tq);
int vmxnet3_post_rx_bufs(vmxnet3_adapter_t *sc, struct vmxnet3_cmd_ring *ring,
                         int num_post);
void vmxnet3_start(struct ifnet *ifp);
void vmxnet3_rq_rx_complete(vmxnet3_adapter_t *sc, vmxnet3_rx_queue_t *rq);
void vmxnet3_tq_tx_complete(vmxnet3_adapter_t *sc, vmxnet3_tx_queue_t *tq);

#endif /* _VMXNET3_INT_H */
