/* $OpenBSD: version.h,v 1.61 2011/02/04 00:44:43 djm Exp $ */

#define SSH_VERSION	"OpenSSH_5.8"

#define SSH_PORTABLE	"p2"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
