
To make Areca arcsas.ko driver for ARC13x0 SAS/SATA Host Bus Adapter

1. create arcsas directory
   # mkdir /usr/src/sys/dev/arcsas
   # mkdir /usr/src/sys/modules/arcsas

2. copy arcsas.c, arcsas.h, arcsas-amd64.uu, arcsas-i386.uu
   to /usr/src/sys/dev/arcsas

3. copy Makefile to /usr/src/sys/modules/arcsas

4. cd /usr/src/sys/modules/arcsas

5. # make

That's it.
